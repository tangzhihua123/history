import React, { Component } from "react";
import ReactDOM from "react-dom";
import "./index.scss";
import ICON_SHARE from './share.png'

export default class ShareModal extends Component {
    constructor(props) {
        super(props);
    }

    componentWillReceiveProps(nextProps) {}

    handleClick() {
        this.props.hide();
    }

    render() {
        return (
            <div
                className="m-share-modal"
                onClick={this.handleClick.bind(this)}
            >
                <img className="arrow" src={ICON_SHARE} />
            </div>
        );
    }
}
