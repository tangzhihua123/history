import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Hammer from "utils/hammer.min.js";

import "./index.scss"

export default class Page extends React.Component { 
     constructor(props) {
        super(props)
        this.state = {};
        this.timer = null;
    }

     getMessage() {

        var message = "加载中···";
        if (
            (typeof this.props.hasMore !== "boolean" &&
            this.props.items.length === 0 ) || this.props.loading == false
        ) {
            return message;
        } else if ( typeof this.props.hasMore === "boolean" && !this.props.hasMore) {
            // 没有更多数据的时候，不显示任何文案
            // return (message = this.props.items.length <= 6 ? "" : "哎呀，你竟然看完了");
            message  = "";
        } else {
            // 加载更多数据
            message = this.props.loadMore ? "上拉查看更多" : "更多敬请期待...";
        }
        return message;
    }

    bindEvents() {
        this.loadMoreEvent();
    }

    /**
   * 加载更多事件回调
   */
    loadMoreEvent() {
        if (this.props.loadMore && typeof this.props.loadMore === "function") {
            let hammer = new Hammer(this.refs.baseList, {});
            hammer.on("swipeup panup", () => {
                if (this.__isNeedLoadMore()) {
                    this.__loadMore();
                }
            });
        }
    }

    /**
   * 函数分流，避免过于频繁地加载数据
   * @param  {Function} func  待执行的回调函数
   * @param  {Number}   delay 延迟时间
   */
    throttle(func, delay) {
        clearTimeout(this.timer);
        this.timer = setTimeout(() => {
            func.apply(this, arguments);
        }, delay);
    }

    /**
   * 判断页面是否需要加载
   */
    __isNeedLoadMore() {
        if (!this.props.hasMore) {
            return false;
        }
        return Util.DomInView(this.refs.loadMore);
    }

    __loadMore() {
        this.throttle(this.props.loadMore, 300);
    }

    render() {
        let items = []
        let length = this.props.items.length
        
        // 将传入的子控件作为列表项模板
        if(length) {
            let child = this.props.children

            items = this.props.items.map((item, index) => {
                item.index = index
                item.length = length
                let _item = React.cloneElement(child, {item: item}) // 克隆子节点属性

                return (
                    <li className="page-list-item" key={index} >
                        {_item}
                    </li>
                )
            })
        } else {
            items = <div className="m-loading fa-spinner fa-spin">加载中...</div>
        }
        
        let msg = this.getMessage.apply(this);

        return (
            <div ref="pagelist" className={'m-page-list ' + this.props.clazz} >
                {items}
                {
                    msg ?   
                    <div ref="loadMore" className="m-load-more fa-spinner fa-spin">
                       {this.getMessage.apply(this)}
                    </div>
                    : ""
                }
                
            </div>
                
        )
    }
}