import React, {Component} from 'react'
import PropTypes from 'prop-types'
import './index.scss'

import logo from './home_logo@3x.png'

export default class NoData extends Component {
    constructor(props) {
        super(props)

        this.state = {
            loading: false
        }
    }

    componentDidMount() {
        let oImg = new Image()
        oImg.src = logo

        // oImg.onload = () => {
        //     this.setState({
        //         loading: false
        //     })
        // }
    }

    render() {
        return (
            <div className="m-no-loading">
                {
                    !this.state.loading ?
                        <div>
                            <img src={logo} alt="logo" className="logo"/>
                            <p>——— 更多美味敬请期待 ———</p>
                        </div> : null
                }
               
            </div>
        )
       
    }
}