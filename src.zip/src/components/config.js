export const NAMESPACE = null; // 'am'
export const CLASSNAMES = {
  disabled: 'disabled',
  active: 'active',
};