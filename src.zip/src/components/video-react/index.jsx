import React, { Component } from "react";
import ReactDOM from "react-dom";
import "./index.scss";


export default class ShareModal extends Component {
    constructor(props) {
        super(props);
    }

    componentWillReceiveProps(nextProps) {}

    handleClick() {
        this.props.hide();
    }

    render() {
        return (
            <div
                className="m-video-modal"
                onClick={this.handleClick.bind(this)}
            >
              
                <video width ="100%" height="100%">
                    <source src={this.props.data.video_videoLink} type="video/mp4"></source>
                </video>
            </div>
        );
    }
}
