import React, { Component } from "react";
import "./index.scss";

export default class Slider2 extends Component {
    componentDidMount() {
        this.slider();
    }
    slider = () => {
        let _this = this;

        let interval = setInterval(_this.roll, 2000);
        _this.roll();
    };
    roll = () => {
        let rem = $(window).width() / 3.75;
        let slider = document.querySelector(".m-slider-three");
        let container = document.querySelector(".m-slider-t-container");
        let left = container.style.left;
        let leftValue = parseFloat(left);
        let $firstChild = container.find(".m-slider-t-li:first-child");

        container.css({
            left: leftValue - rem * 3.45,
            transition: "all .5s ease-in-out 0s"
        });

        container.one(
            "transitionend webkitTransitionEnd oTransitionEnd otransitionend MSTransitionEnd",
            function() {
                container
                    .append($firstChild)
                    .css({ left: leftValue, "transition-property": "none" });
            }
        );
    };
    render() {
        let { imageList } = this.props;
        console.log(imageList)
        // let imgs = imageList.map(function(item, i) {
        //     return (
        //         <div className="m-slider-t-li" key={i}>
        //             <a href={item.clickLink} className="m-slider-t-a">
        //                 <img src={item.imgLink} alt="" />
        //                 <div className="m-slider-des">
        //                     <div>
        //                         <div className="m-slider-des1">{item.title}</div>
        //                         <div className="m-slider-des2">{item.desc}</div>
        //                     </div>
                            
        //                 </div>
        //             </a>
        //         </div>
        //     );
        // });

        return (
            <div className="m-slider-three">
                <div className="m-slider-t-container">
                   
                </div>
            </div>
        );
    }
}
