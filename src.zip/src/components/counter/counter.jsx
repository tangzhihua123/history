import React, {Component} from 'react';
import Util from 'utils/util.js'
import Notification from "components/Notification/Notification.jsx";
import PropTypes from 'prop-types'
import MinusButtonCannot from './btn_reduce_noclick@2x.png'
import MinusButton from './btn_reduce@2x.png'
import PlusButtonCannot from './btn_plus_noclick@3x.png'
import PlusButton from './btn_plus@2x.png'

import './counter.scss'

export default class Counter extends Component {
    constructor(props) {
        super(props)
        this.state = {
            minNum: this.props.minValue,
            maxNum: this.props.maxValue,
            nowNum: this.props.currentValue
        }
    }
    componentWillReceiveProps(nextProps) {
        this.setState({ 
            maxNum: nextProps.maxValue,
            nowNum: nextProps.currentValue
        });
    }
    addClick = e => {
        // 有最大值限制，则限制，否则不限制
        if(this.props.addFn) {
            if(!this.props.addFn()) {
                return
            }
        }
        if (this.state.nowNum >= this.state.maxNum) {
            this.enter(this.props.tips);
        } else {
            this.setState(
                {
                    nowNum: this.state.nowNum + 1,
                },
                () => {
                    this.props.cb(this.state.nowNum)
                }
            );
        }
    };
    minusClick = e => {
        if (this.state.nowNum > this.state.minNum) {
            this.setState(
                {
                    nowNum: this.state.nowNum - 1,
                },
                () => {
                    this.props.cb(this.state.nowNum)
                }
            );
        } 
    };
    onChange = e => {
        let value = e.target.value;
        
        let isString = /[^1234567890]/.test(value);

        let nowNum;
        if (isString || !value) {
            nowNum = "";
        } else {
            nowNum = parseInt(value);
        }
        if (!!nowNum && nowNum > this.state.maxNum) {
            this.enter(this.props.tips);
            let temp = this.state.maxNum;
            this.setState(
                {
                    nowNum: temp,
                },
                () => {
                    // console.log('nowNum', this.state)
                    this.props.cb(this.state.nowNum)
                }
            );
        } else {
            this.setState(
                {
                    nowNum: nowNum,
                },
                () => {
                    // console.log('啦啦啦',this.state)
                    this.props.cb(this.state.nowNum)
                }
            );
        }
    };
    onBlur = () => {
        if (!this.state.nowNum ||this.state.nowNum < this.state.minNum) {
            this.setState(
                {
                    nowNum: this.state.minNum,
                },
                () => {
                    this.props.cb(this.state.nowNum)
                }
            );
        } else if (this.state.nowNum > this.state.maxBuyValue) {
            this.setState(
                {
                    nowNum: this.state.maxNum,
                },
                () => {
                    this.props.cb(this.state.nowNum)
                }
            );
        }
    };
    enter(message) {
        this.setState({
            enter: true,
            message: message,
        });
        setTimeout(
            function() {
                this.leave();
            }.bind(this),
            2000
        );
    }

    leave() {
        this.setState({
            enter: false,
            message: "",
        });
    }
    render () {
        let inputType = Util.isIOS() ? "number" : "tel";
        console.log('sttae,' ,this.state)
        return (
            <div>
                <Notification
                    enter={this.state.enter}
                    leave={this.leave.bind(this)}
                >
                    {this.state.message}
                </Notification>
                <div className="m-counter">
                    <div
                        className="m-minus-button"
                        onClick={this.minusClick}
                    >
                        {this.state.nowNum <= this.state.minNum &&
                        <img src={MinusButtonCannot} alt="" />}
                        {this.state.nowNum > this.state.minNum &&
                        <img src={MinusButton} alt="" />}
                    </div>
                    <div className="m-input-button">
                        <input
                            className="pwd-input"
                            pattern="\d*"
                            onBlur={this.onBlur}
                            type={inputType}
                            value={this.state.nowNum}
                            onChange={this.onChange.bind(this)}
                        />
                    </div>
                    <div
                        className="m-plus-button"
                        onClick={this.addClick}
                    >
                        {this.state.nowNum >=
                        this.state.maxNum &&
                        <img src={PlusButtonCannot} alt="" />}
                        {this.state.nowNum <
                        this.state.maxNum &&
                        <img src={PlusButton} alt="" />}
                    </div>
                </div>
            </div>
        )
    }
}
Counter.prpoTypes = {
    currentValue: PropTypes.number.isRequired, // 输入框当前显示的数字
    cb: PropTypes.func.isRequired, // 数字变动时执行的回调，会把输入框值传进去
    tips: PropTypes.string.isRequired, // 数字达到最大时的提示语
    minValue: PropTypes.number.isRequired, // 输入框能达到的最小值
    maxValue: PropTypes.number.isRequired, // 输入框能达到的最大值
    addFn: PropTypes.func
}