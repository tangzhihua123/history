import React, { Component } from 'react'
import PropTypes from 'prop-types'
import classnames from 'classnames'
import ImageCompressor from '@xkeshi/image-compressor';

import './index.scss'
const Loading = 'data:image/gif;base64,R0lGODlhUABQANU4AH5+fjExMYCAgOTk5Orq6oGBge3t7fz8/PX19dfX19nZ2fj4+MPDw6KiooqKipGRkfPz87q6uqampqSkpJ6enpaWlqOjo1RUVDIyMjMzM83NzT8/P1FRUTk5OVVVVff397+/v6ioqO7u7ubm5tPT0+Hh4XFxcURERExMTFBQULKysvHx8UVFRXNzc8XFxcbGxoyMjFdXV1lZWfDw8Pv7+9ra2ktLS1NTU////wAAAAAAAAAAAAAAAAAAAAAAAAAAACH/C05FVFNDQVBFMi4wAwEAAAAh/wtYTVAgRGF0YVhNUDw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTMyIDc5LjE1OTI4NCwgMjAxNi8wNC8xOS0xMzoxMzo0MCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTUuNSAoTWFjaW50b3NoKSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDoyOTNDODM5NEMzOUUxMUU3QThFOEJFMjcyQzgwNTczNCIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDoyOTNDODM5NUMzOUUxMUU3QThFOEJFMjcyQzgwNTczNCI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOkZBMzdCREZGQzJEMTExRTdBOEU4QkUyNzJDODA1NzM0IiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOkZBMzdCRTAwQzJEMTExRTdBOEU4QkUyNzJDODA1NzM0Ii8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+Af/+/fz7+vn49/b19PPy8fDv7u3s6+rp6Ofm5eTj4uHg397d3Nva2djX1tXU09LR0M/OzczLysnIx8bFxMPCwcC/vr28u7q5uLe2tbSzsrGwr66trKuqqainpqWko6KhoJ+enZybmpmYl5aVlJOSkZCPjo2Mi4qJiIeGhYSDgoGAf359fHt6eXh3dnV0c3JxcG9ubWxramloZ2ZlZGNiYWBfXl1cW1pZWFdWVVRTUlFQT05NTEtKSUhHRkVEQ0JBQD8+PTw7Ojk4NzY1NDMyMTAvLi0sKyopKCcmJSQjIiEgHx4dHBsaGRgXFhUUExIREA8ODQwLCgkIBwYFBAMCAQAAIfkEBQQAOAAsAAAAAFAAUAAABv9AnHBILBqPyKRyyWw6n9CodEqtWq/YrHbL7Xq/4LB4TC6bz+i0es1uu9/wuHxOr9vv+Lx+z+/7/4CBdgEBgkYJDESERAIWgQMAAgRDi0IaGAEggRIADZSFQhwBHoIGBQAKQpUhARkkfgNEEQAPBzgnJzgfGwEmRJp4CQASBkILDhMIRCMXHSJCJB4BjncMAgAFEQs4EEglOCImGQEYBXkEDQAADt1JJR2EMTV8Cg8TTBcpL38HyksrtgwJHKKuYAUnFAqqs6MQwMEmCRUOnNiPCYKAferdWzLhQao96NSxUwLBgboGk/BYw6aNG5JuCyKcEpDojjBixpD5E4JggoNebTgMcEqQJ9aQWbVwUKCA48ADABGIGOVjCpWQhTgUYCu2qRNBAEPSSXgUKSUOrDgIXJvqBxERtDgYEJ14Fizdu3jz6t3Lt6/fv4ADCx5MuLDhw4gTK17MuLHjx1uCAAAh+QQFBAA4ACwnABsADgAOAAAGMEAAAEcsGonCoxKXXBqbTuQQp4pWKjha1GjYenECL0ez3YS8o893TUQF3m/nDf4OAgAh+QQFBAA4ACwqABwACgAUAAAGSUCckJEQGoUEAWBwFDYAkiZOASgYmocHICJFTBwLYfEIwSFaUhwhzW6731IUXDr6sC+bkHTGCgQ4Gk0fMBkBGAJSAzIBFmwuOEEAIfkEBQQAOAAsKgAgAAoAFAAABkpAnHAoHBCHBgkgQVxECgABYwhxAAANwnHyUByFiMN3TC6bz2hiqTMu4UQm4urSEQlJnmEqEB+ChC8BGSRjMQF5XzUYAX9fBRZHQQAh+QQFBAA4ACwnACcADgAOAAAGMUCccCikAI5HItGIBCif0KGBFn2qqtiscoS9oXCfTTUQEIbGZSEnSh5q2GmhANrOBgEAIfkEBQQAOAAsIAAqABQACgAABkhAnHBIJCIOxaRy8lAonziIAwBoEIiz53URKQAEDOGHdRkpEUKDBJAQwgKbDw5VbBEHwkEmEIK2izIBHFBKLgEYGoRKFgKKSUEAIfkEBQQAOAAsHAAqABQACgAABkpAnFC4GhqPx1fqgmwKa7FAoFNyHguYQMYkwlWbkKEl4CEJRR0kYuJYDEFGU/PwAESaZqcCUDAgPVY4DQASR3CBBAIAA4FNDAk4QQAh+QQFBAA4ACwbACcADgAOAAAGL8CAUGjDGY/GofCEbDqfzc8IegxtqDgNB4sTcLmGL46Go1CoKiMA8F232Vx3HBAEACH5BAUEADgALBwAIAAKABQAAAZJQJwLRywSLQHZwEgUYAIZ2Iep4QQCrBkTF9pctsTPCEwunsrotLpMALcQOAgzQVw4JnBmBPA4MA0FAApbEgANWwMAAm1bCQxFQQAh+QQFBAA4ACwcABwACgAUAAAGSECcUGgpDI+gAKZ2HHoCsaaQlAm8hKCjKZBykoSizmWlFeFKUlwHnW673/C4+4BIKx6TJqEBADggQwwCAAURC0cJABIGaQNtQQAh+QQFBAA4ACwbABsADgAOAAAGMkCccEgUBgJFoYB4TAo1w6aTE0U6cSGj1bn54E62q3AkLpuLqrOQZlBfAXB45R0HzJ1BACH5BAUEADgALBwAHAAUAAoAAAZJQJxwSCwKBRajkqjBBFzLJScgMyaioUBmIOQOW8UT7rMJwIQJgMQgRChHF9ZHyBAACpEFjrCcEQkNAAAOEFFKCg8ThksHbotCQQA7'
const prefixCls = 'xg-image-picker'
export default class ImagePicker extends Component {
  fileSelectorInput = []
  constructor(props) {
    super(props)
  }
  removeImage(index) {
    const newImages = [];
    const { files = [] } = this.props;
    files.forEach((image, idx) => {
      if (index !== idx) {
        newImages.push(image);
      }
    });
    if (this.props.onChange) {
      this.props.onChange(newImages, 'remove', index);
    }
  }
  addImage(imgItem) {
    const { files = [] } = this.props

    files[imgItem.index] = imgItem

    if (this.props.onChange) {
      this.props.onChange(files, 'add');
    }
  }
  compress = (file, index) => {
    let _this = this
    console.log('file', file)
    let quality
    if(file.size < 500 * 1000) {
      quality = 0.8
    } else if(file.size < 2000 * 1000) {
      quality = 0.6
    } else if(file.size < 5000 * 1000) {
      quality = 0.4
    } else {
      quality = 0.3
    }
    console.log('quality', quality)
    new ImageCompressor(file, {
      quality: quality,
      convertSize: 500000,
      success: (result) => {
        _this.blob2DataURL(result, index)
      },
      error: (e) => {
        console.log(e.message);
      },
    });
  }
  blob2DataURL = (blob, index) => {
    const reader = new FileReader()
    const fileSelectorEl = this.fileSelectorInput
    reader.onload = (e) => {
      const dataURL = e.target.result
      this.addImage({
        url: dataURL,
        blob: blob,
        index
      })
      fileSelectorEl.value = ''
    }
    reader.readAsDataURL(blob)
  }
  onFileChange = () => {
    const { files = [] } = this.props

    const length = files.length
    const fileSelectorEl = this.fileSelectorInput
    if(fileSelectorEl && fileSelectorEl.files && fileSelectorEl.files.length) {
      const file = fileSelectorEl.files[0]
      this.addImage({
        url: Loading,
        index: length,
        loading: true
      })
      this.compress(file, length)
    }
  }

  render() {
    const {
      files = [],
      onAddImageClick
    } = this.props
    console.log('change upload files', files)
    const itemList = []
    files.forEach((image, index) => {
      const imgStyle = {
        backgroundImage: `url(${image.url})`
      }
      itemList.push(
        <div key={index} className={`${prefixCls}-item`}>
          <div className={`${prefixCls}-item-remove`}
            onClick={() => { this.removeImage(index) }}
          />
          <div 
            className={`${prefixCls}-item-content`}
            style={imgStyle}
          />
        </div>
      )
    })
    const addEl = (
      <div
        key="add"
        className={`${prefixCls}-item ${prefixCls}-upload-btn`}
        onClick={onAddImageClick}
      >
        <input
          ref={(input) => { this.fileSelectorInput = input; }}
          type="file"
          accept="image/jpg,image/jpeg,image/png,image/gif"
          onChange={() => { this.onFileChange() }}
        />
      </div>
    )
    let allEl = itemList.concat([addEl])
    const length = allEl.length
    if (length !== 0 && length % 4 !== 0) {
      const blankCount = 4 - length % 4
      let fillBlankEl = []
      for (let i = 0; i < blankCount; i++) {
        fillBlankEl.push(<div key={`blank-${i}`} className={`${prefixCls}-item`}/>)
      }
      allEl = allEl.concat(fillBlankEl);
    }
    const flexEl = []
    for (let i = 0; i < allEl.length / 4; i++) {
      const rowEl = allEl.slice(i * 4, i * 4 + 4);
      flexEl.push(rowEl);
    }
    const renderEl = flexEl.map((item, index) => {
      return (<div key={prefixCls + 'col' + index} className={`${prefixCls}-list`}>
        {item}
      </div>)
    })
    

    return (
      <div className={`${prefixCls}`}>
        <div className={`${prefixCls}-warpper`}>
            {renderEl}
        </div>
      </div>
    )
  }
}
/**
 * 需要先判断一下回调中的对象是否有loading属性，如果
 * loading为true，则不要发送请求，此时是loading图片
 */
ImagePicker.propTypes = {

};