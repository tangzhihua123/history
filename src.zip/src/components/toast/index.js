import React from 'react'
import Notification from 'rc-notification'
import classnames from 'classnames'

import './style/toast.scss'

let messageInstance
let prefixCls = 'xg-toast'

function getMessageInstance(mask) {
    if (messageInstance) {
        messageInstance.destroy()
        messageInstance = null
    }
    messageInstance = Notification.newInstance({
        prefixCls,
        style: { },
        className: classnames({
            [`${prefixCls}-mask`]: mask,
            [`${prefixCls}-nomask`]: !mask
        })
    })

    return messageInstance
}

function notice(content, duration = 1.5, mask = false, onClose) {
    let instance = getMessageInstance(mask)
    instance.notice({
        duration,
        style: {},
        content: (
            <div className={`${prefixCls}-text`}>
                <div>{content}</div>
            </div>
        ),
        onClose: () => {
            if (onClose) {
                onClose()
            }
            instance.destroy()
            instance = null
            messageInstance = null
        }
    })
}


export default {
    show(content, duration, mask, onClose) {
        return notice(content, duration, mask, onClose)
    },
    hide() {
        if (messageInstance) {
            messageInstance.destroy()
            messageInstance = null
        }
    },
}
