import React from 'react'

import './index.scss'

export default function SplitLine(props) {
  const {
    size = '1px',
    color = ''
  } = props
  const heightObj = {
    height: size + 'px',
    backgroundColor: color
  }
  return <div style={heightObj}></div>
}
