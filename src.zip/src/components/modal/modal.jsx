import React, { Component } from 'react'
import PropTypes from 'prop-types'
import classnames from 'classnames'

import './style/modal.scss'

let prefixCls = 'xg-modal'

export default class Modal extends Component {
    constructor(props) {
        super(props)
    }
    
    render() {
        const { footer = [], mask = true } = this.props
        const modalClassName = classnames({
            [`${prefixCls}-mask`]: true,
            [`${prefixCls}`]: true
        })
        return (
            <div className={modalClassName}>
                <div className={`${prefixCls}-content` }>
                  <div className={`${prefixCls}-text`}>
                      {this.props.children}
                  </div>
                  <div className={`${prefixCls}-buttons`}>
                    {
                    footer.map((item, index) => {
                        return (<div key={index} className={`${prefixCls}-button`} onClick={item.onPress}>
                            {item.text}
                        </div>)
                    })
                    }
                  </div>
                </div>
            </div>
        )
    }
}

Modal.propTypes = {
    footer: PropTypes.any,
    children: PropTypes.any,
    mask: PropTypes.any
};