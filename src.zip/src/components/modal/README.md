---
category: Components
type: Feedback
title: modal
subtitle: 重提示
---


一种较重的提示或让用户做出选择，打断用户操作的内容，适合用于选择确认，弹窗提示的等场景。


### 规则
- 一次只显示一个 modal


## API

- `modal.alert(content, actions)`

参数如下：

属性 | 说明 | 类型 | 默认值
----|-----|------|------
| content    | 提示内容       | React.Element or String    | 无           |
| actions   | 对象数组，对像必须包含text 与onPress方法 | array                 | 无          |


```
// 使用例子
Modal.alert('撤销后，若超出订单服务保障期则无法在发起售后申请', [
    {
        text: '放学',
        onPress: () => {
            console.log('左侧按钮')
        }
    }, {
        text: '别跑',
        onPress: () => {
            console.log('右侧按钮')
        }
    }
])
```

## TODO
- 添加Modal 动画
