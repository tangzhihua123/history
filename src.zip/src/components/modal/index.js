import alert from './alert.jsx'
import Modal from './modal.jsx'

Modal.alert = alert

export default Modal