import React from 'react'
import ReactDOM from 'react-dom'
import Modal from './modal'

export default function(
    message,
    actions = [{ text: '确定' }]
) {
    if (!message) {
        console.error('请配置message')
        return
    }
    const prefixCls = 'xg-modal'
    const div = document.createElement('div')
    document.body.appendChild(div)

    function close() {
        ReactDOM.unmountComponentAtNode(div);
        if (div && div.parentNode) {
            div.parentNode.removeChild(div);
        }
    }
    const footer = actions.map(button => {
        const orginPress = button.onPress || function() {};
        button.onPress = () => {
            const res = orginPress()
            // 支持Promise
            if (res && res.then) {
                res.then(() => {
                    close()
                });
            } else {
                close()
            }
        }
        return button
    }) 

    ReactDOM.render(
      <Modal
        footer={footer}
      >
          <div>{message}</div>
      </Modal>, div
    )
    
    return {
        close
    }
}
