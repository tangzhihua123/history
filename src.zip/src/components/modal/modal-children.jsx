import React, {Component} from 'react'
import PropTypes from 'prop-types'
import './modal-children.scss'
/**
 * 模态框，里面的内容全部由组件children定义，背景z-index为1，注意设置自组件z-index
 * @module ModalChildren
 * @param {boolean} isShow 控制模态框的显示
 * @param {function} closeCb 传入一个关闭
 */
export default class ModalChildren extends Component {
    constructor(props) {
        super(props)
        this.state = {
            isShow: this.props.isShow
        }
    }
    componentDidMount() {
        
        
    }
    handleModalTop = () => {
        this.setTop0('modal-with-children')
    }
    setTop0 = (cla) => {
        // document.body.scrollTop 在chrome 61中被废弃
        // var bodyST = document.getElementsByTagName('body')[0].scrollTop
        var bodyST = window.scrollY
        document.getElementsByClassName(cla)[0].style.top = bodyST + 'px'
        // console.log('top高度值', document.getElementsByClassName(cla)[0])
    }

    handleScroll = () => {
        if(!this.props.canScroll) {
            var modal = document.querySelector('.modal-with-children')
            modal.addEventListener('touchmove',  function(e) {
                e.preventDefault()
            }, false)
            var childCls = this.props.scrollChild
            if(childCls && typeof childCls === 'string') {
                var child = document.querySelector(childCls)
                console.log('spec-list', child)
                child.addEventListener('touchmove', function(e) {
                    e.stopPropagation()
                }, false)
            }
        }
        
    }
    componentWillReceiveProps(nextProps) {
        var _this = this
        this.setState({
            isShow: nextProps.isShow
        })

    }
    componentDidUpdate() {
        // console.log('完成更新 isShow', this.state.isShow)
        if(this.state.isShow) {
            console.log('被执行了')
            this.handleModalTop()
            this.handleScroll()
        }
        
    }
    hideFn = () => {
        // let el = document.querySelector('.modal-with-children')
        // if(el) el.parentNode.removeChild(el)
        this.props.hideFn()
    }
    render() {
        return (
            this.state.isShow?<div className="modal-with-children"
            >
                <div className="bg-40" onClick={this.props.clickBgHide?this.hideFn :()=>{}}></div>
                {this.props.children}
            </div>:null
        )
    }
}
ModalChildren.propTypes = {
    /**
     * 模态框唤起时，默认页面不能滚动，如果需要滚动，
     * canScroll设置为true
     * 模态框内的子元素可能有区域需要滚动，
     * 把子元素的类名或者id传递scrollChild，
     * 类名前面需要有. id需要有#
     * 例如 '.app', '#app'
     */
    clickBgHide: PropTypes.bool, // 点击背景是否能隐藏
    hideFn: PropTypes.func, // 如果能够点击背景隐藏，则必须提供此函数，用于设置最外层的isShow属性为false
    isShow: PropTypes.bool.isRequired, // 是否显示模态框
    canScroll: PropTypes.bool, // 模态框显示时，页面是否能够滚动
    scrollChild: PropTypes.string // 当页面设置成不可滚动时，如果子元素内有一块区域需要滚动，则把id或者class传递进来
}
