import React, { Component } from 'react'
import PropTypes from 'prop-types'
import classnames from 'classnames'
import AlloyFinger from './AlloyFinger'
import Icon from 'components/Icon'

import './index.scss'

let prefixCls = 'xg-swipe-action'

export default class SwipeAction extends Component {
  btnLeftWidth = 0
  constructor(props) {
    super(props)
    this.state = {
      contStyle: {
        transform: 'translate(0, 0)'
      }
    }
  }
  componentDidMount() {
    // 获取btns 宽度
    this.btnLeftWidth = this.refs.btns.offsetWidth
  }
  onSwipe= (event) => {
    if (event) {
      if (event.direction === 'Left' && event.distance > this.btnLeftWidth) {
        this.setState({
          contStyle: {
            transform: `translate(-${this.btnLeftWidth}px, 0)`
          }
        })
      } else if(event.direction === 'Right' && event.distance > this.btnLeftWidth) {
        this.setState({
          contStyle: {
            transform: 'translate(0, 0)'
          }
        })
      }
    }
  }
  onPress=() => {
    this.props.onPress()
    this.setState({
      contStyle: {
        transform: 'translate(0, 0)'
      }
    })
  }
  render() {
    const {
      children
    } = this.props
    return (
      <AlloyFinger
        onSwipe={this.onSwipe}
      >
        <div className={prefixCls}>
          <div className='swipe-container' style={this.state.contStyle}>
            {children}
            <div className="swipe-action-btns" ref="btns">
              <div className="swipe-action-btn" onClick={this.onPress}>
                <Icon type="delete"/>
                <p className="swipe-action-btn-text">删除</p>
              </div>
            </div>
          </div>
        </div>
      </AlloyFinger>
    )
  }
}

SwipeAction.propTypes = {
  children: PropTypes.any,
};