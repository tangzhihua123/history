---
category: Components
type: Feedback
title: swipe-action
subtitle: 滑动删除
---


### 提示
- 根据目前业务需求仅实现滑动删除功能

参数如下：

属性 | 说明 | 类型 | 默认值
----|-----|------|------
| onPress    | 用户点击删除后触发       | Function    | 无           |



```
// 使用例子
<SwipeAction key={i} onPress={this.onDeleteItem.bind(this)}><CartItem></CartItem></SwipeAction>
```

## TODO
- 支持右滑
- 支持多按钮组配置，包括但不限于icon、text 等内容