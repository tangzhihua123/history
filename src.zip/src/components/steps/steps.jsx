
import React, { Component } from 'react'

export default class Steps extends Component {
  constructor(props) {
    super(props)
  }

  render() {
    const {
      children,
      status,
      current
    } = this.props

    return (
      <div>
      
      
      </div>
    )
  }
}