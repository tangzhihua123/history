import React from 'react'


const prefixCls = 'xg-step'

export default class Step extends React.Component {
  constructor(props) {
    super(props)
  }
  render() {
    const {
      title, desc
    } = this.props

    return (
      <div>
        <div>
          {title}
        </div>
        <div>
          icon
        </div>
      </div>
    )
  }
}