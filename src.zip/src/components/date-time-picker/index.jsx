import React, { Component } from 'react'
import PropTypes from 'prop-types'
import classnames from 'classnames'

import './index.scss'

let prefixCls = 'xg-date-time-picker'

export default class DateTimePicker extends Component {
  constructor(props) {
    super(props)
  }

  renderDateItems(data) {
    const items = data.map((date, index) => {
      return <li className={`${prefixCls}-date-item`} key={index}>{date.label}</li>
    })
    
    return (
      <div className={`${prefixCls}-date`}>
        <div className={`${prefixCls}-date-scroller`}>
          <ul className={`${prefixCls}-date-items`}>
            {items}
          </ul>
        </div>
      </div>
    )
  }

  renderTimeItems(data) {
    const items = data.map((time, index) => {
      return <li className={`${prefixCls}-date-item`} key={index}>{time.label}</li>
    })

    return (
      <div className={`${prefixCls}-time`}>
        <ul className={`${prefixCls}-time-items`}>
          {items}
        </ul>
      </div>
    )
  }


  render() {
    const dateArr = [
      { value: '', label: '7月19日' },
      { value: '', label: '7月20日' },
      { value: '', label: '7月21日' },
      { value: '', label: '7月21日' },
      { value: '', label: '7月21日' },
      { value: '', label: '7月21日' },
      { value: '', label: '7月21日' },
      { value: '', label: '7月21日' },
      { value: '', label: '7月21日' },
      { value: '', label: '7月21日' },
      { value: '', label: '7月21日' },
      { value: '', label: '7月21日' },
      { value: '', label: '7月21日' },
      { value: '', label: '7月21日' },
      { value: '', label: '7月21日' }
    ]
    const timeArr = [
      { value: '', label: '18:00-18:30' },
      { value: '', label: '18:00-18:30' },
      { value: '', label: '18:00-18:30' },
      { value: '', label: '18:00-18:30' },
      { value: '', label: '18:00-18:30' },
      { value: '', label: '18:00-18:30' },
      { value: '', label: '18:00-18:30' }
    ]
    return (
      <div className={prefixCls}>
        <div className={`${prefixCls}-warpper`}>
            <div className={`${prefixCls}-select`}></div>
            {this.renderDateItems(dateArr)}
            {this.renderTimeItems(timeArr)}
        </div>
      </div>
    )

  }
}
