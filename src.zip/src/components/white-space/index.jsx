import React from 'react'

export default function WhiteSpace(props) {
  const {
    size = '.1rem'
  } = props
  const heightObj = {
    height: size
  }
  return <div style={heightObj}></div>
}

