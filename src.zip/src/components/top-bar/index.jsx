import React, {Component} from 'react'

import './index.scss'

export default class MyComponent extends Component {
    constructor(props) {
        super(props)
    }

    render() {
        return (
            <div className="top-bar">
                I am TopBar.
                lalala
                <svg width="27" height="27" viewBox="0 0 27 27" xmlns="http://www.w3.org/2000/svg"><title>弹框-关闭</title><g transform="translate(1 1)" stroke="#FFF" fill="none" fill-rule="evenodd"><circle cx="12.5" cy="12.5" r="12.5"/><g stroke-linecap="square"><path d="M7.697 7.197l10.606 10.606M18.607 7L8 17.607"/></g></g></svg>
            </div>
        )
    }
}
