import React, { Component } from 'react'
import PropTypes from 'prop-types'
import cname from 'classnames'
import { ClassNameMixinFunc } from '../mixins/ClassNameMixin'
import TransitionEvents from '../utils/TransitionEvents'
// import Icon from '../Icon';
import Touchable from './Touchable';
import "./_slider.scss"



class Slider extends React.Component {
    static propTypes = {
        classPrefix: PropTypes.string,
        controls: PropTypes.bool, //prev/next icon
        pager: PropTypes.bool, // indicators or thumbs
        slide: PropTypes.bool, // what is this?
        interval: PropTypes.number, // interval
        autoPlay: PropTypes.bool, // auto Play 
        loop: PropTypes.bool, // loop slide

        pauseOnHover: PropTypes.bool,
        // touch: PropTypes.bool,
        
        onAction: PropTypes.func,
        onSlideEnd: PropTypes.func,
        activeIndex: PropTypes.number,
        defaultActiveIndex: PropTypes.number,
        direction: PropTypes.oneOf(['prev', 'next']), // 限制你的属性值是某个特定值之一
        prevIcon: PropTypes.node, // PropTypes.node: 任何可被渲染的元素（包括数字、字符串、子元素或数组）
        nextIcon: PropTypes.node,
        getClassSet: PropTypes.func,
        prefixClass: PropTypes.func,
        setClassNS: PropTypes.func
    }

    static defaultProps = {
        classPrefix: 'slider',
        controls: true,
        pager: true,
        slide: true,
        interval: 5000,
        autoPlay: true,
        loop: true,
        pauseOnHover: true,
        // prevIcon: <Icon name='left-nav' />,
        // nextIcon: <Icon name = 'right-nav' />,
    }

    constructor(props) {
        super(props)

        this.state = {
            activeIndex: this.props.defaultActiveIndex == null ? 
                0 : this.props.defaultActiveIndex,
            previousActiveIndex: null,
            direction: null
        } 
    }

    componentWillReceiveProps(nextProps) {
        let _this = this
        let activeIndex = this.getActiveIndex();

        if (nextProps.activeIndex != null &&
            nextProps.activeIndex !== activeIndex) {
            clearTimeout(this.timeout);
            this.setState({
                previousActiveIndex: activeIndex,
                direction: nextProps.direction != null ? nextProps.direction :
                this.getDirection(activeIndex, nextProps.activeIndex)
            },function () {
                // console.log("Slider componentWillReceiveProps")
            });
        }
    }
    componentDidMount() {
        this.props.autoPlay && this.waitForNext();
    }

    componentWillUnmount() {
        clearTimeout(this.timeout);
    }


    waitForNext() {
        // console.log("wait");
        if (!this.isPaused && this.props.slide && this.props.interval &&
          this.props.activeIndex == null) {
          this.timeout = setTimeout(this.next.bind(this), this.props.interval);
        }
    }
    
    getDirection(prevIndex, index) {
        if (prevIndex === index) {
            return null;
        }

        return prevIndex > index ? 'prev' : 'next';
    }

    next(e) {
        e && e.preventDefault();
        let index = this.getActiveIndex() + 1;
        let count = React.Children.count(this.props.children);

        if (index > count - 1) {
            if (!this.props.loop) {
                return;
            }
            index = 0;
        }

        this.handleSelect(index, 'next');
    }

    prev(e) {
        e && e.preventDefault();

        let index = this.getActiveIndex() - 1;

        if (index < 0) {
            if (!this.props.loop) {
                return;
            }
            index = React.Children.count(this.props.children) - 1;
        }

        this.handleSelect(index, 'prev');
    }

    pause() {
        this.isPaused = true;
        clearTimeout(this.timeout);
    }

    play() {
        this.isPaused = false;
        this.waitForNext();
    }

    handleMouseOver() {
        if (this.props.pauseOnHover) {
            this.pause();
        }
    }

    handleMouseOut() {
        if (this.isPaused) {
            this.play();
        }
    }

    handleSwipeLeft(e) {
        // console.log('swipe left');
        this.next();
    }

    handleSwipeRight(e) {
        // console.log('swipe right....');
        this.prev();
    }

    getActiveIndex() {
        return this.props.activeIndex != null ?
        this.props.activeIndex : this.state.activeIndex;
    }
    
    handleItemAnimateOutEnd() {
        this.setState({
            previousActiveIndex: null,
            direction: null
        }, function() {
            this.waitForNext();
            // console.log("handleItemAnimateOutEnd");
            if (this.props.onSlideEnd) {
                this.props.onSlideEnd();
            }
        });
    }
    
    handleSelect(index, direction, e) {
        e && e.preventDefault();
        clearTimeout(this.timeout);

        let previousActiveIndex = this.getActiveIndex();
        direction = direction || this.getDirection(previousActiveIndex, index);

        if (this.props.onAction) {
            this.props.onAction(index, direction);
        }

        if (this.props.activeIndex == null && index !== previousActiveIndex) {
            if (this.state.previousActiveIndex != null) {
                // If currently animating don't activate the new index.
                // TODO: look into queuing this canceled call and
                // animating after the current animation has ended.
                return;
            }

            this.setState({
                activeIndex: index,
                previousActiveIndex: previousActiveIndex,
                direction: direction
            });
        }
    }

    renderControls() {
        return this.props.controls ? (
            <div className={this.props.prefixClass('control')}>
                <Touchable
                    className={this.props.prefixClass('control-prev')}
                    onTap={this.prev.bind(this)}
                    stopPropagation >
                    {this.props.prevIcon} 
                </Touchable>
                <Touchable
                    className={this.props.prefixClass('control-next')}
                    onTap={this.next.bind(this)}
                    stopPropagation
                >
                    {this.props.nextIcon}
                </Touchable>
          </div>
        ) : null;
    }

    renderPager() {
        let _this = this
        if (this.props.pager) {
            let isThumbnailNav = false;

            let children = React.Children.map(this.props.children, (child, i) => {
                let className = (i === this.getActiveIndex()) ?
                    this.props.setClassNS('active') : null;
                let thumb = child.props.thumbnail;

                if (!isThumbnailNav) {
                    isThumbnailNav = !!thumb;
                }

                return (
                    <div>
                        <Touchable
                        component="li"
                        className={className}
                        key={i}
                        onTap={this.handleSelect.bind(_this, i, null)}
                    >
                        {thumb ? <img src={thumb} /> : null}
                    </Touchable>
                    </div>
                    

                );
            });

            let pagerClassName = this.props.prefixClass(isThumbnailNav ? 'thumbs' : 'indicators');

            return (
                <ol
                  className={cname(this.props.prefixClass('pager'), pagerClassName)} >
                    {children} 
                </ol>
            );
        }
       
        return null;
    }

    renderItem(child, index) {  
        let _this = this
        let activeIndex = this.getActiveIndex();
        let isActive = (index === activeIndex);
        let isPreviousActive = this.state.previousActiveIndex != null &&
          this.state.previousActiveIndex === index && this.props.slide;

        let props = {
            active: isActive,
            ref: child.ref,
            key: child.key ? child.key : index,
            index: index,
            animateOut: isPreviousActive,
            animateIn: isActive && this.state.previousActiveIndex != null &&
            this.props.slide,
            direction: this.state.direction,
            onAnimateOutEnd: isPreviousActive ? this.handleItemAnimateOutEnd.bind(_this) : null
        };
      
        return React.cloneElement(child, props)
    }
   
    render() {

        let _this = this
        let classSet = this.props.getClassSet()
        let {
          className,
          children,
          ...props
        } = this.props;
        
        
        delete props.classPrefix;
        delete props.onAction;
        delete props.pager;
        delete props.controls;
        delete props.slide;
        delete props.interval;
        delete props.pauseOnHover;
        delete props.prevIcon;
        delete props.nextIcon;

        // TODO: 优化 swipe，左右方向阻止默认事件，垂直方向不阻止

        return (
            <div>
                <Touchable
                    {...props}
                    component="div"
                    className={cname(classSet, className)}
                    onMouseOver={this.handleMouseOver.bind(_this)}
                    onMouseOut={this.handleMouseOut.bind(_this)}
                    onSwipeLeft={this.handleSwipeLeft.bind(_this)}
                    onSwipeRight={this.handleSwipeRight.bind(_this)}
                    preventDefault={false}
                    stopPropagation={true}
                >
                    <ul className={this.props.prefixClass('slides')} >
                        {React.Children.map(children, this.renderItem.bind(_this))}
                    </ul>
                    {this.renderControls()}
                    {this.renderPager()}
                </Touchable>
            </div>
       
        );
    }  
}

class SliderTest extends React.Component {
    constructor(props) {
        super(props)
    }
    
    test() {
        this.props.getClassSet()
    }

    render() {
        // console.log(this,2222) // SliderTest
        var a = this.props.getClassSet()

        return <div>
            {this.props.style}
        </div>
    }
}

// 高阶组件写法
export default ClassNameMixinFunc(Slider)


