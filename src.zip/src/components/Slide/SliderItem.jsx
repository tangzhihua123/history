import React, { Component } from 'react'
import PropTypes from 'prop-types'
import ReactDOM from 'react-dom'
import cname from 'classnames'
import TransitionEvents from '../utils/TransitionEvents'
import "./_slider.scss"
import './SliderItem.scss'
export default
class SliderItem extends  Component {

    static propTypes = {
        direction: PropTypes.oneOf(['prev', 'next']),
        onAnimateOutEnd: PropTypes.func,
        active: PropTypes.bool,
        animateIn: PropTypes.bool,
        animateOut: PropTypes.bool,
        caption: PropTypes.node,
        index: PropTypes.number,
        thumbnail: PropTypes.string,
        videoUrl: PropTypes.string,
        imgUrl: PropTypes.string, // 需要点击放大的时候，videoUrl和imgUrl至少传入一个，videoUrl优先级大于imgUrl
        urlCb: PropTypes.func, // 需要点击放大的时候，传入函数，返回一个对象{url: '', type: 'img'||'video'}
    }

    static defaultProps = {
        animation: true
    }

    constructor(props) {
        super(props)

        this.state = {
            direction: null,
            mounted: true
        }

        // this.handleAnimateOutEnd = this.handleAnimateOutEnd.bind(this)
    }



    componentWillReceiveProps(nextProps) {
        if (this.props.active !== nextProps.active) {
                this.setState({
                    direction: null
                });
        }
    }

    componentDidUpdate(prevProps) {
        let _this = this
        if (!this.props.active && prevProps.active) {
            TransitionEvents.on(ReactDOM.findDOMNode(_this), this.handleAnimateOutEnd.bind(_this));
        }
        
        if (this.props.active !== prevProps.active) {
            setTimeout(this.startAnimation.bind(_this), 50);
        }
    }

    handleAnimateOutEnd() {
        
        if (this.props.onAnimateOutEnd && this.state.mounted) {
            this.props.onAnimateOutEnd(this.props.index);
        }
    }

    // componentDidMount() {
    //     // this.setState({
    //     //     mounted: true
    //     // })
    // }

    // componentWillUnmount() {
    //     // this.setState({
    //     //     mounted: false
    //     // })
    // }
    itemClick = (e) => {

        if(this.props.videoUrl) {
            this.props.urlCb && this.props.urlCb({
                type: 'video',
                url: this.props.videoUrl
            })

        } else {
            this.props.urlCb && this.props.urlCb({
                type: 'img',
                url: this.props.imgUrl
            })
        }


    }
    startAnimation() {
        if (!this.state.mounted) {
            return;
        }

        this.setState({
            direction: this.props.direction === 'prev' ? 'right' : 'left'
        });
    }

    genMask = () => {
        let content,
            type = this.state.type
        if(type === 'img') {
            content = <img src={this.state.url}/>
        } else if(type === 'video') {
            content = <video >
                <source src={this.state.url} type="video/mp4"></source>
            </video>
        }
        return <div className="slider-mask-div" style={{display: this.state.maskSHow ? 'block': 'none'}}>
            <div className="slider-mask-con">
                {content}
            </div>
            
        </div>
    }

    render() {
        
        let {
            className,
            active,
            animateIn,
            animateOut,
            direction,
        } = this.props;

        let classSet = {
            active: (active && !animateIn) || animateOut,
            next: active && animateIn && direction === 'next',
            prev: active && animateIn && direction === 'prev'
        };
        
        if (this.state.direction && (animateIn || animateOut)) {
            classSet[this.state.direction] = true;
        }
        let click = this.props.imgUrl || this.props.videoUrl
        return (
            <li onClick={click ? this.itemClick : null}
                className={cname(className, classSet)}
            >
                {this.props.children}
            </li>
        );
    }
}