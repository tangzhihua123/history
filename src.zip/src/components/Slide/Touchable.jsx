/**
 * React port of Zepto touch.
 *
 * @see https://github.com/joakimbeng/react-swiper
 * @see https://github.com/dogfessional/react-swipeable
 * @see https://github.com/damusnet/react-swipe-views
 * @see http://www.javascriptkit.com/javatutors/touchevents3.shtml
 * @see https://github.com/JedWatson/react-tappable
 * @see https://github.com/madrobby/zepto/blob/master/src/touch.js
 */

import React, { Component } from 'react'
import PropTypes from 'prop-types'
import createChainedFunction from '../utils/createChainedFunction'
import supportTouch from '../utils/isTouchSupported'
import '../utils/ucUIControl'

import { TouchableMixin } from '../mixins/TouchableMixin'


class Touchable extends React.Component {
    static propTypes = {
        component: PropTypes.any, //任意类型的数据
        getTouchHandlers: PropTypes.func,
    }

    constructor(props) {
        super(props)
        
        this.state = {
            component: 'span',
        }
    }


    render() {
        let _this = this
        // console.log(this.props,666)
        const {
            component: Component,
            onTap,
            ...props,
        } = this.props;

        
        if (supportTouch) {
            Object.assign(props, this.props.getTouchHandlers());
        } else {
            // handle `tap` as `click` on non-touch devices
            try {
                props.onClick = createChainedFunction(props.onClick, onTap).bind(_this);
            }catch(e) {
                console.log('touchable err', e)
            }
            
        }

        // console.log(props)

        delete props.moveThreshold;
        delete props.tapDelay;
        delete props.pressDelay;
        delete props.preventDefault;
        delete props.stopPropagation;
        delete props.onSwipe;
        delete props.onSwipeLeft;
        delete props.onSwipeUp;
        delete props.onSwipeRight;
        delete props.onSwipeDown;
        delete props.onTap;
        delete props.onSingleTap;
        delete props.onDoubleTap;
        delete props.onPress;
        
        // console.log(Component,77)
        // console.log(this)
        // let Comcopy = React.createElement(Component, null, '')
        // console.log(Comcopy)
        let comp= null 
        
        if(Component == 'div') {
            comp =  (
                <div {...props}>
                     {this.props.children}
                </div>
            )
        } 
        

        if(Component == 'li') {
            comp =  (
                <li
                    {...props}>
                    {this.props.children}
                </li>
            )
        }
        return comp
    }
}

// 高阶组件写法
export default TouchableMixin(Touchable)
