/* eslint-disable */
// inspried by https://github.com/kisenka/svg-sprite-loader/blob/master/runtime/browser-sprite.js
// Much simplified, do make sure run this after document ready
const svgSprite = contents => `
<svg
  xmlns="http://www.w3.org/2000/svg"
  xmlns:xlink="http://www.w3.org/1999/xlink"
  id="__XG_SVG_NODE__"
  style="position:absolute;width:0;height:0"
>
  <defs>
    ${contents}
  </defs>
</svg>
`;

// both minified by https://github.com/svg/svgo
const icons = {
  'delete': '<svg viewBox="0 0 20 22"><g fill="none" fill-rule="evenodd"><path d="M-2-1h24v24H-2z"/><g><path stroke="#FFF" stroke-width="1.5" d="M2.503 2.4l2.058 18.85H15.44L17.497 2.4H2.503z"/><rect width="20" height="1.5" y="1.65" fill="#FFF" rx=".75"/><rect width="3.333" height="2.3" x="8.333" fill="#FFF" rx="1.15"/></g></g></svg>',
  'close': '<svg viewBox="0 0 14 14"><polygon fill="#333" fill-rule="evenodd" points="15 13.939 9.873 8.813 8.813 9.873 13.939 15 8.813 20.127 9.873 21.187 15 16.061 20.127 21.187 21.187 20.127 16.061 15 21.187 9.873 20.127 8.813" transform="translate(-8 -8)"/></svg>',
  'arrow': '<svg viewBox="0 0 8 14"><g fill="none" fill-rule="evenodd" transform="translate(-3)"><rect width="14" height="14"/><polygon fill="#999" points="9.121 7 3.464 12.657 4.172 13.364 10.536 7 4.172 .636 3.464 1.343"/></g></svg>',
  'selected': '<svg viewBox="0 0 19 19"><g fill="none" fill-rule="evenodd"><circle cx="9.5" cy="9.5" r="9.5" fill="#333"/><polygon fill="#FFF" points="8.263 11.091 13.566 5.788 14.627 6.848 8.263 13.212 4.373 9.323 5.434 8.263"/></g></svg>',
  'arrow-yellow': '<svg viewBox="0 0 8 14"><g fill="none" fill-rule="evenodd"><path d="M-3 0h14v14H-3z"/><path fill="#CA6" d="M6.121 7L.464 12.657l.708.707L7.536 7 1.172.636l-.708.707z"/></g></svg>',
  'location': '<svg viewBox="0 0 16 24"><g fill="none" fill-rule="evenodd"><path d="M-5-1h26v26H-5z"/><path fill="#333" d="M10.636 20.794a.647.647 0 0 1 .035.206c0 .71-1.195 1.286-2.668 1.286-1.472 0-2.667-.576-2.667-1.286 0-.07.012-.139.035-.206-1.615.295-2.702.852-2.702 1.492 0 .948 2.388 1.714 5.334 1.714 2.946 0 5.335-.766 5.335-1.714-.002-.64-1.089-1.197-2.702-1.492zM5.415 7.778c0-1.42 1.195-2.572 2.667-2.572 1.474 0 2.667 1.15 2.667 2.572 0 1.42-1.195 2.571-2.667 2.571-1.472-.002-2.667-1.152-2.667-2.571zM16 7.512C16 3.363 12.186 0 7.948 0 3.709 0 0 3.363 0 7.512 0 11.359 7.859 20.57 7.859 20.57S16 11.487 16 7.512z"/></g></svg>',
  'edit': '<svg viewBox="0 0 16 16"><g fill="none" fill-rule="evenodd"><path d="M-2-2h20v20H-2z"/><path fill="#CCC" d="M11.28 0L.166 11.075 0 16l4.885-.12L16 4.805 11.28 0zM1.557 11.687l9.712-9.669 2.713 2.763-9.698 9.657-2.82.072.093-2.823z"/></g></svg>',
  'arrow-left': '<svg viewBox="0 0 12 22"><path fill="#333" fill-rule="evenodd" d="M12.01 1.808L10.596.393-.01 11l10.606 10.607 1.414-1.415L2.818 11z"/></svg>'
};

const renderSvgSprite = () => {
  const symbols = Object.keys(icons).map(iconName => {
    const svgContent = icons[iconName].split('svg')[1];
      return `<symbol id=${iconName}${svgContent}symbol>`;
  }).join('');
  return svgSprite(symbols);
};

const loadSprite = () => {
if (!document) {
  return;
}
const existing = document.getElementById('__XG_SVG_NODE__');
const mountNode = document.body;

if (!existing) {
  mountNode.insertAdjacentHTML('afterbegin', renderSvgSprite());
}
};

export default loadSprite;
