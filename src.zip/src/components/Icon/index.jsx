import React, { Component } from 'react'
import classnames from 'classnames'
import loadSprite from './loadSprite'

import './style/index.scss'

export default class extends Component {
  componentDidMount() {
    loadSprite()
  }
  render() {
    const {
      type,
      style,
      size = 'md',
      className,
      ...restProps
    } = this.props
    const iconClassName = classnames(
      'xg-icon',
      `xg-icon-${type}`,
      `xg-icon-${size}`,
      className
    )
    return (
      <svg className={iconClassName} style={style} {...restProps}>
        <use xlinkHref={`#${type}`} />
      </svg>
    )
  }
}