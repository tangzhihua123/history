---
category: Components
type: Feedback
title: Icon 
subtitle: 小图标
---


### 使用提示

参数如下：

属性 | 说明 | 类型 | 默认值
----|-----|------|------
| type    | 图标类型       | String    | 无           |
| size    | 图标尺寸       | String    | 'md'         |
| style    | svg外层样式       | Object or String    | 无           |
| className    | svg外层类      | String    | 无           |
type 为必传属性，会根据业务逐步添加， 目前可选的值： delete、arrow、 location  
size 默认值为md 具体的尺寸对应关系  

size | 说明 
----|-----|
| xxs   | 0.14rem
| xs   | 0.18rem
| sm   | 0.20rem
| md   | 0.24rem
| lg   | 0.26rem

```
// 使用例子
<Icon type="delete" size="sm"/>
```

## 已有图标
- delete
- arrow
- arrow-yellow
- location
- edit
- close
- arrow-left

## TODO
- 更多图标选项