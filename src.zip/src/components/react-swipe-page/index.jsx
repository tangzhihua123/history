import React, { Component } from 'react'
import PropTypes from 'prop-types'

import './index.scss'
export default class ReactSwipePage extends React.Component { 
    constructor(props) {
        super(props)
        this.state = {
            pageIndex: this.props.pageIndex || 0,
            pageCount: this.props.pageCount || 0
        }
    }

    componentWillReceiveProps(nextProps) {
        this.setState({
            pageIndex: nextProps.pageIndex,
            pageCount: nextProps.pageCount,
        })
    }

    GetPages() {
        let lis = null
        let counts = []
        for(let i = 0; i < this.state.pageCount; i++ ) {
            counts.push(1)
        }


        lis = counts.map((item, index) => {
            let cls = ''
            if(index == this.state.pageIndex) {
                cls = 'active'
            }
            return <li className={cls} key={index} ></li>
        })
        return lis
    }

    render() {
        let bottom = this.props.bottom ? this.props.bottom : ''

        return (
            <div className="react-swipe-pager" style={{bottom: bottom}}>
                <ul className="slider-indicators">
                    {this.GetPages()}
                </ul>
            </div>
        )
    }
}