import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Hammer from 'utils/hammer.min.js'

import './index.scss'

export default class Slider extends Component { 
    static propTypes = {
        controls: PropTypes.bool, //right/left icon 是否显示
        pager: PropTypes.bool,// 是否显示下面切换页效果（常规-圆圈）
        slide: PropTypes.bool,// 表示是轮播效果
        interval: PropTypes.number, // 自动轮播间隔时间
        autoPlay: PropTypes.bool, // 是否自动播放
        loop: PropTypes.bool, // loop slide 是否循环播放
        activeIndex: PropTypes.number, // 当前播放index
        defaultActiveIndex: PropTypes.number, // 默认播放index
        direction: PropTypes.oneOf(['prev', 'next']), // 限制你的属性值是某个特定值之一，向左滑动或者向右滑动
        number:PropTypes.number, // 轮播内容数目
    }

    static defaultProps = {
        controls: true,
        pager: true,
        slide: true,
        interval: 5000,
        autoPlay: true,
        loop: true,
        defaultActiveIndex:0,
    }

    constructor(props) {
        super(props)
        this.state = {
            activeIndex: this.props.defaultActiveIndex == null ? 0 : this.props.defaultActiveIndex,
            previousActiveIndex: null,
            direction: null
        }
    }
    
    componentWillReceiveProps(nextProps) {
        let activeIndex = this.getActiveIndex();

        if (nextProps.activeIndex != null &&
            nextProps.activeIndex !== activeIndex) {
            clearTimeout(this.timeout);
            this.setState({
                previousActiveIndex: activeIndex,
                direction: nextProps.direction != null ? nextProps.direction :
                  this.getDirection(activeIndex, nextProps.activeIndex)
            },function () {
                console.log("Slider componentWillReceiveProps");
            });
        }
    }

    getDirection(prevIndex, index) {
        console.log('Slider getDirection')
        if (prevIndex === index) {
          return null;
        }

        return prevIndex > index ? 'prev' : 'next';
    }

    /**
     * [componentWillUnmount 没有挂载元素时清除timeout]
     * @return {[type]} [description]
     */
    componentWillUnmount() {
        console.log('Slider componentWillUnmount')
        clearTimeout(this.timeout);
    }

    componentDidMount = () => {
        console.log('Slider componentDidMount')
        var slides_dom = this.refs.slides;
        var hammer = new Hammer(slides_dom, {});
        hammer.on(
            "swipeleft",
            function() {
                // console.log('swipe left');
                this.next();
            }.bind(this)
        );

        hammer.on(
            "swiperight",
            function() {
                // console.log('swipe right....');
                this.prev();
            }.bind(this)
        );

        this.props.autoPlay && this.waitForNext();
    }
    
    waitForNext() {
         console.log("wait");
        if (!this.isPaused && this.props.slide && this.props.interval &&
          this.props.activeIndex == null) {
          this.timeout = setTimeout(this.next, this.props.interval);
        }
    }

    next = (e) => {
         console.log("next");
        e && e.preventDefault();
        
        let index = this.getActiveIndex() + 1;
        let count = React.Children.count(this.props.children);
        console.log(count,'count')
        if (index > count - 1) {
          if (!this.props.loop) {
            return;
          }
          index = 0;
        }
        console.log(index, 'tt')
        this.handleSelect(index, 'next');
    }

    prev(e) {
        e && e.preventDefault();

        let index = this.getActiveIndex() - 1;

        if (index < 0) {
          if (!this.props.loop) {
            return;
          }
          index = React.Children.count(this.props.children) - 1;
        }

        this.handleSelect(index, 'prev');
    }

    pause() {
        this.isPaused = true;
        clearTimeout(this.timeout);
    }

    play() {
        this.isPaused = false;
        this.waitForNext();
    }

    getActiveIndex() {
        console.log("Slider getActiveIndex")
        return this.props.activeIndex != null ?
            this.props.activeIndex : this.state.activeIndex;
    }

    handleItemAnimateOutEnd = () =>{
        console.log('爱你，关键点')
        
        this.setState({
            previousActiveIndex: null,
            direction: null
        }, function() {
          this.waitForNext();
        
          if (this.props.onSlideEnd) {
            this.props.onSlideEnd();
          }

          console.log("handleItemAnimateOutEnd")
        });
       
    }
    
    componentDidUpdate() {
        console.log("update")
    }

    handleSelect(index, direction, e) {
        e && e.preventDefault();
        clearTimeout(this.timeout);


        let previousActiveIndex = this.getActiveIndex();
        console.log(previousActiveIndex, 'previousActiveIndex')

        direction = direction || this.getDirection(previousActiveIndex, index);
        console.log(direction,'direction')
        /*暂时不会执行*/
        if (this.props.onAction) {
            this.props.onAction(index, direction);
        }

        if (this.props.activeIndex == null && index !== previousActiveIndex) {
            if (this.state.previousActiveIndex != null) {
                // If currently animating don't activate the new index.
                // TODO: look into queuing this canceled call and
                // animating after the current animation has ended.
                return;
            }

            console.log(index, '是否执行')
          
            this.setState({
                activeIndex: index,
                previousActiveIndex: previousActiveIndex,
                direction: direction
            },function () {
                console.log("handleSelect")
            });
        }
     }
    
    /**
     * [renderPager 渲染滑动下面 页面效果]
     * @return {[type]} [description]
     */
    renderPager() {
        // if (this.props.pager) {
        //   let isThumbnailNav = false;

        // let children = React.Children.map(this.props.children, (child, i) => {
        //     let className = (i === this.getActiveIndex()) ?
        //           'pager-active': null;
        //     return (
        //         <li>
        //             className={className}
        //             key={i} >
        //             { child }
        //         </li>
        //     );
        // });
        // return (
        //     <ul className="slider-pager">
        //         {children}
        //     </ul>
        // }

        return null;
    }

    renderItem = (child, index) => {
        let activeIndex = this.getActiveIndex();
        console.log(activeIndex, 'renderItem activeIndex')
        let isActive = (index === activeIndex);
        let isPreviousActive = this.state.previousActiveIndex != null &&
          this.state.previousActiveIndex === index && this.props.slide;

        let props = {
          active: isActive,
          ref: child.ref,
          key: child.key ? child.key : index,
          index: index,
          animateOut: isPreviousActive,
          animateIn: isActive && this.state.previousActiveIndex != null &&
          this.props.slide,
          direction: this.state.direction,
          onAnimateOutEnd: isPreviousActive ? this.handleItemAnimateOutEnd : null
        };
        console.log(props,'renderitem props cloneelement')

        return React.cloneElement(child, props);
    }
    render() {
        console.log('Slider render')
        let {
          children,
          ...props
        } = this.props;

        return (
            <div  >
                <ul className="slides" ref="slides">
                    {React.Children.map(children, this.renderItem)}
                </ul>
                {this.renderPager()}
            </div>
        )
    }


}



