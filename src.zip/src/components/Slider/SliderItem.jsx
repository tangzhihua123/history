import React, { Component } from 'react'
import PropTypes from 'prop-types'
import ReactDOM from 'react-dom'
import cname from 'classnames'
import TransitionEvents from '../utils/TransitionEvents'
import "./_slider.scss"

export default
class SliderItem extends  Component {
    static propTypes = {
        direction: PropTypes.oneOf(['prev', 'next']),
        onAnimateOutEnd: PropTypes.func,
        active: PropTypes.bool,
        animateIn: PropTypes.bool,
        animateOut: PropTypes.bool,
        index: PropTypes.number,
        thumbnail: PropTypes.string,
    }

    static defaultProps = {
        animation: true
    }

    constructor(props) {
        super(props)

        this.state = {
            direction: null,
            mounted: true
        }
    }



    componentWillReceiveProps(nextProps) {
        if (this.props.active !== nextProps.active) {
            this.setState({
                direction: null
            },function () {
                console.log("SliderItem componentWillReceiveProps")
            });
        }
    }

    componentDidUpdate = (prevProps) => {
        /**
         * 此处有问题，startAnimation 一直比handleAnimateOutEnd 后输出,暂时先不处理.有时间优化.
         */
        console.log("SlideItem componentDidUpdate")
        let _this = this
        console.log(prevProps.active, this.props.active, '22222')

        if (!this.props.active && prevProps.active) {
            console.log(_this, 'love')
            console.log(ReactDOM.findDOMNode(_this),3333)
            TransitionEvents.on(ReactDOM.findDOMNode(_this), this.handleAnimateOutEnd.bind(_this));
        }

        if (this.props.active !== prevProps.active) {
            setTimeout(this.startAnimation.bind(_this), 20);
        }
        
       
    }

    handleAnimateOutEnd() {
        console.log("SliderItem handleAnimateOutEnd")
        if (this.props.onAnimateOutEnd) {
            console.log(this.props.index,'ttt')
            this.props.onAnimateOutEnd(this.props.index);
        }
    }

    // componentDidMount() {
    //     // this.setState({
    //     //     mounted: true
    //     // })
    // }

    // componentWillUnmount() {
    //     // this.setState({
    //     //     mounted: false
    //     // })
    // }

    startAnimation() {
        // if (!this.state.mounted) {
        //     return;
        // }

        this.setState({
            direction: this.props.direction === 'prev' ? 'right' : 'left'
        },function (argument) {
            console.log("startAnimation")
        });
    }

    render() {
        console.log("SliderItem render");
        let {
            className,
            active,
            animateIn,
            animateOut,
            direction,
        } = this.props;
        
        console.log("SliderItem render props")

        let classSet = {
            active: (active && !animateIn) || animateOut,
            next: active && animateIn && direction === 'next',
            prev: active && animateIn && direction === 'prev'
        };
        
        console.log(classSet,"classSet")

        if (this.state.direction && (animateIn || animateOut)) {
            classSet[this.state.direction] = true;
        }

        console.log(classSet,"classSetNew")
        return (
            <li
                className={cname(className, classSet)}
            >
                {this.props.children}
            </li>
        );
    }
}