import React from 'react'
import PropTypes from 'prop-types';
import ReactDOM from 'react-dom'

import {
  NAMESPACE,
  CLASSNAMES,
} from '../config';

const namespace = (NAMESPACE ? NAMESPACE + '-' : '');

export let  ClassNameMixinFunc = function (ComponentClass)  {
    return class ClassNameMixin extends React.Component {
        static propTypes = {
             classPrefix: PropTypes.string,
        }

        static defaultProps = {
             classPrefix: 'slider',
        }

        constructor(props) {
            super(props)
        }

        setClassNS(classPrefix) {

            const prefix = classPrefix || this.props.classPrefix || ''
            return namespace + prefix
            
        }
        
        getClassSet(ignorePrefix) {
            let classNames = {};
            const {
                amSize,
                amStyle,
                hollow,
                radius,
                rounded,
                active,
                selected,
                disabled,
                inset,
            } = this.props;

            

            // uses `.am-` as prefix if `classPrefix` is not defined
            let prefix = namespace;

            if (this.props.classPrefix) {
                const classPrefix = this.setClassNS();

                prefix = classPrefix + '-';

                // don't return prefix if ignore flag set
                !ignorePrefix && (classNames[classPrefix] = true);
            }

            if (amSize) {
                classNames[prefix + amSize] = true;
            }

            if (amStyle) {
                classNames[prefix + amStyle] = true;
            }

            if (hollow) {
                classNames[prefix + 'hollow'] = true;
            }

            classNames[this.prefixClass('radius')] = radius;
            classNames[this.prefixClass('rounded')] = rounded;

            classNames[this.prefixClass('inset')] = inset;

            // state className
            // `selected` is an alias of active
            classNames[CLASSNAMES['active']] = active || selected;
            classNames[CLASSNAMES['disabled']] = disabled;

            // shape
            // classNames[constants.CLASSES.radius] = this.props.radius;
            // classNames[constants.CLASSES.round] = this.props.round;

            return classNames;
        }
        
        prefixClass(subClass) {
            return this.setClassNS() + '-' + subClass;
        }

        getDom(dom) {
            this.dom = dom 
        }

        render() {
            const Props = {
                ...this.props,
                getClassSet: (ignorePrefix) => this.getClassSet(ignorePrefix),
                prefixClass: (subClass) => this.prefixClass(subClass),
                setClassNS: (classPrefix) => this.setClassNS(classPrefix)
            };
            
            return (
                <ComponentClass {...Props} ref={(dom) => this.dom = dom} />
            )
        }
    }
}



// export let  ClassNameMixinFunc = function (ComponentClass) {
//     return class HOC extends React.Component {
      
//         componentDidMount() {
//             console.log(this,111111111) // this -->HOC 高阶组件
//             console.log(this.dom,77777777777777)
//         }

//         getClassSet() {
//             console.log(this,333333) // this --> HOC 高阶组件
//         }

//         getDom(dom) {
//             console.log(dom)
//             // return dom; // dom -> SliderTest 被包裹组件
//         }

//         render() {
//             return <ComponentClass {...this.props}   getClassSet={this.getClassSet.bind(this)} ref={(dom) => this.dom = dom}  />
//         }
//     }
// }


 
