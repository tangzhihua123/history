---
category: Components
type: Feedback
title: Switch
subtitle: 状态切换
---

一个在checkbox基础上UI友好状态切换组件，也称开关组件。


## API

- `Toast.show(content, duration, mask, onClose)`

参数如下：

属性 | 说明 | 类型 | 默认值
----|-----|------|------
| content    | 提示内容       | React.Element or String    | 无           |
| duration   | 自动关闭的延时，单位秒 | number                 | 1.5          |
| mask    | 是否显示透明蒙层，防止触摸穿透 |  Boolean  | false          |
| onClose    | 关闭后回调 |  Function                 | 无          |

> **注：**  duration = 0 时，onClose 无效，toast 不会消失；隐藏 toast 需要手动调用 hide

还提供了全局配置和全局销毁方法：

- `Toast.hide()`

## 调用示例
```
Toast.show('你好', 2, false, function() {
    console.log('onClose')
}) 
```
## TODO
- Toast.loading 提示
