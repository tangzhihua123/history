import React from 'react'
import classnames from 'classnames'

import './index.scss'

const prefixCls = 'xg-switch'

export default class Switch extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      checked: props.checked ? props.checked : false
    }
  }
  onClick = (e) => {
    if (this.props.onClick) {
      let val
      if (e && e.target && e.target.checked !== undefined) {
        val = e.target.checked
      } else {
        val = this.props.checked
      }
      this.props.onClick(val)
    }
  }
  onChange = (e) => {
    const checked = e.target.checked
    this.setState({
      checked: checked
    })
    if (this.props.onChange) {
      this.props.onChange(checked)
    }
  }
  render() {
    let {
      checked = false,
      disabled = false,
      color,
      className,
      ...restProps
    } = this.props

    const wrapCls = classnames(prefixCls, className)

    const fackInputCls = classnames('checkbox', {
      [`checkbox-disabled`]: disabled
    })

    const globalProps = Object.keys(restProps).reduce((prev, key) => {
      if (key.substr(0, 5) === 'aria-' || key.substr(0, 5) === 'data-' || key === 'role') {
        prev[key] = restProps[key]
      }
      return prev;
    }, {})
    
    const style = this.props.style || {}
    if (color && checked) {
      style.backgroundColor = color
    }
    
    return (
      <div className={wrapCls}>
          <input 
            type="checkbox"
            className={`${prefixCls}-checkbox`}
            disabled={disabled}
            checked={this.state.checked}
            value={this.state.checked ? 'on' : 'off'}
            onChange={this.onChange}
            {...(!disabled ? { onClick: this.onClick } : {})}
            {...globalProps}
          />
          <div 
            className={fackInputCls}
            style={style}
            {...(disabled ? { onClick: this.onClick } : {})}
          >
          </div>
      </div>
    )
  }
}