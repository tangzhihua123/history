import React from 'react'

import './index.scss'

export default function SuspensionFrame(props) {
  const {
    size = '1px',
    color = ''
  } = props
  const heightObj = {
    height: size + 'px',
    backgroundColor: color
  }
  return <div className="content-title" onClick={props.onClick} style={heightObj}>
      {/*{props.text}*/}
      <div className="text">{props.text.substring(0,2)}</div>
      <div className="text1">{props.text.substring(2)}</div>

      </div>
}
