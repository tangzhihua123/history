import React, {Component} from 'react'
import PropTypes from 'prop-types'
import TopImg from './top@2x.png'
import './back-top.scss'

export default class BackTop extends Component {

    constructor(props) {
        super(props)
        this.state = {
            topShow: this.props.topShow,
            topTime: this.props.topTime || 300
        }
    }
    componnetDidMount() {
        
    }

    backTopFn = () => {
        var body = document.querySelector('body'),
            curScrollTop = window.scrollY || document.documentElement.scrollTop,
            time = this.state.topTime,
            dist = curScrollTop/time * 20,
            last = false   
        var interval = setInterval(function() {
            if((window.scrollY || document.documentElement.scrollTop) < dist) {
                dist = window.scrollY || document.documentElement.scrollTop
                last = true
            }
            // document.documentElement.scrollTop = (window.scrollY || document.body.scrollTop) - dist
            window.scrollTo(0, (window.scrollY || document.body.scrollTop) - dist)
            
            if(last) {
                clearInterval(interval)
            }
        }, 20)  
    }
    componentWillReceiveProps(nextProps) {
        
        this.setState({
            topShow: nextProps.topShow
        })
        
    }
    
    render() {

        let style = {
            visibility: this.state.topShow ?'visible':'hidden'
        }

        return (
            <div className="m-back-top-con" 
            style={style}
            onClick={this.backTopFn}>{
                <div className="m-back-top">
                    <img src={TopImg} alt=""/>
                </div>
            }
            </div>
        )
    }
}
BackTop.PropTypes ={
    topShow: PropTypes.bool, // 控制按钮的显示与隐藏
    topTime: PropTypes.number // 回到顶部时间，默认300ms
}