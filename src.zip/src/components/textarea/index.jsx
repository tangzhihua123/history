import React, {Component} from 'react'
import PropTypes from 'prop-types'

import './index.scss'

export default class TextareaInput extends Component {
    constructor(props) {
        super(props)
        this.state = {
            letter: this.props.letter || 200,
            nowLetter: 0
        }
    }

    textareaChange = (e) => {
        
        let value = e.target.value
        let total = value.length
        this.setState({
            nowLetter: total
        })
        this.props.textareaCb && this.props.textareaCb(value)
    }
    render() {
        return (
            <div className="textarea-div">
                <textarea className="textarea-input" 
                placeholder={this.props.defaultText}
                onChange={this.textareaChange}></textarea>
                <div className="num-calc">
                    {this.state.nowLetter}/{this.state.letter}
                </div>
            </div>
        )
    }
}

TextareaInput.propTypes = {
    letter: PropTypes.number, // 文字的最大数量
}