/**
 * 列表数据加载逻辑公用处理
 * props: 
 * ----- show: 是否显示加载中组件
 * ----- hasMore: 是还还有数据(如果show==false  && hasMore 表示还有数据 ) ---显示文字 '上啦查看更多'(临时写的，视觉还没有给到效果，后期再优化补上)
 * 否则表示没有数据，调用组件<Nodata>
 * 
 */
import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Util from 'utils/util'
import Nodata from 'components/no-data'
import './index.scss'

import Img from './bottom-refresh-icon.gif'
import logo from 'assets/home_logo@3x.png'

export default class BottomRefresh extends Component {
    static defaultProps = {
        hasMore: true
    }

    constructor(props) {
        super(props)
        this.state = {
            loading: this.props.show, // 初始化列表加载
            hasMore: this.props.hasMore,

        }
    }
    componentWillReceiveProps(nextProps) {
        this.setState({
            loading: nextProps.show,
            hasMore: nextProps.hasMore,
            hasMoreData: nextProps.hasMoreData
        })
    }
    
    /**
     * [componentDidMount logo 图片预加载处理]
     * @return {[type]} [description]
     */
    componentDidMount() {
        console.log(logo,"logo图片地址");
        // Util.preloadImg(logo)
    }

    render() {
        // console.log(this.state.hasMore,"hasMore")

        return (
            <div>
                <div className="bottom-refresh-div" >

                   {
                       this.state.loading && this.state.hasMore!==false && this.state.hasMoreData !== false ?
                       <div>
                            <img src={Img} className="bottom-load-img" alt="" />
                            <div className="load-text">玩命加载中</div>
                        </div>:
                        this.state.hasMore === false ? 
                        <Nodata />:
                        <div>{/*还有更多*/}</div>

                   } 

                </div>
                
            </div>
           


        )
    }
}
BottomRefresh.propTypes = {
    show: PropTypes.bool, // 在调用组件的地方传入show，控制组件的显示与隐藏
    hasMore: PropTypes.bool, // 在调用组件的地方传入，没有更多商品数据了，显示：四季严选，更多美味，即将到来
    hasMoreData: PropTypes.bool // 没有更多数据了，显示：没有数据了
}

