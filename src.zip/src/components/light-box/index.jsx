import React, {Component} from 'react'
import PropTypes from 'prop-types'


import './index.scss'

// import  Img from './123321.jpeg'

export default class LightBox extends Component {
    constructor(props) {
        super(props)
        this.state = {
            canHide: true
        }
    }
    componentDidMount() {
        
    }
    componentWillReceiveProps(next) {
        if(next.data.show) {
            this.handleModalTop()
            this.handleScroll()
            
        }
    }
    componentDidUpdate(prevProps) {
        if(this.props.data.show === prevProps.data.show) {
            return
        }
        this.handleSize()
    }
    handleModalTop = () => {
        this.setTop0('light-box-xg')
    }
    setTop0 = (cla) => {
        // document.body.scrollTop 在chrome 61中被废弃
        // var bodyST = document.getElementsByTagName('body')[0].scrollTop
        var bodyST = window.scrollY
        document.getElementsByClassName(cla)[0].style.top = bodyST + 'px'
    }

    handleScroll = () => {
        if(!this.props.canScroll) {
            var modal = document.querySelector('.light-box-xg')
            modal.addEventListener('touchmove',  function(e) {
                e.preventDefault()
            }, false)
            
        }
        
    }

    handleSize = () => {
        let con = document.querySelector('.light-box-con'),
            img,
            video,
            naturalH,
            naturalW,
            screenW = window.screen.availWidth,
            screenH = window.screen.availHeight
            function load(img) {
                return new Promise((resolve, reject) => {
                    img.onload = () => {
                        resolve({nW: img.naturalWidth, nH: img.naturalHeight})
                    }
                })

            }
            async function loadImg(img) {
                await load(img)

                naturalW = img.naturalWidth
                naturalH = img.naturalHeight
                if(naturalH/naturalW > screenH/screenW) {
                    // set height 100%
                    con.style.height = '100%'
                    con.style.width = "auto"
                    img.style.height = '100%'
                    img.style.width = "auto"
                } else {
                    // set width 100%
                    con.style.width = '100%'
                    con.style.height = 'auto'
                    img.style.width = '100%'
                    img.style.height = 'auto'
                }

            }
        if(this.props.data.type === 'img') {
            img = con.querySelector('img')
            if(!img) return
            loadImg(img)

        } else {
            video = con.querySelector('video')

            var modal = document.querySelector('.light-box-xg')

            /* this.setState({
                canHide: false
            }) */

            video.addEventListener('click', (e) => {
                e.stopPropagation()
            })

        }
    }
    hideFn = () => {
        this.props.hideFn && this.props.hideFn()
    }
    render() {
        return <div className="light-box-xg" style={{
            display: this.props.data.show ? 'flex':'none'
        }} onClick={this.hideFn}>
            <div className="light-box-con">
            {
                this.props.data.type === 'img' ? 
                <img src={this.props.data.url} className="light-box-pic" alt=""/>:
                <video src={this.props.data.url} autoPlay>
                    {/* <source src={this.props.data.url} type="video/mp4"></source> */}
                </video>
            }
            </div> 
        </div>
    }
}

LightBox.propTypes = {
    url: PropTypes.string,
    type: PropTypes.string, // img 或者 video
}