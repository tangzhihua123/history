import React, {Component} from 'react'
import PropTypes from 'prop-types'


import './index.scss'

import PlayIcon from './video_play_icon.png'

export default class VideoCom extends Component {
    constructor(props) {
        super(props)
        console.log('-----video-----', this.props)
    }
    componentDidMount() {
        console.log('-----video-----', this.props)
    }
    render() {
        return <div className="video-player-xg" style={{height: this.props.height || '3.75rem',
                                                        width: this.props.width || '100%'
            }}>
            <img src={PlayIcon} className="play-video-icon" alt=""/>
            <img src={this.props.data.picUrl} className="video-pic-show" alt=""/>
            <video>
                <source src={this.props.data.videoAddr} type="video/mp4"></source>
            </video>
        </div>
    }
}

VideoCom.propTypes = {
    data: PropTypes.shape({
        picUrl: PropTypes.string, // 视频的默认图片
        videoAddr: PropTypes.string // 视频的地址
    }),
    width: PropTypes.string, // 组件宽度，默认100%
    height: PropTypes.string, // 窗口的高度，需要带单位，默认值2rem
}