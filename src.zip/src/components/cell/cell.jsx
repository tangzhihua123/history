import React, {Component} from 'react'
import PropTypes from 'prop-types'
import arrow from './right.png'
import './cell.scss'
export default class Cell extends Component {
    render() {
        return (
            <div className="single-cell" onClick={this.props.onClick}>
                <div className="single-cell-left">
                <div className="single-cell-title">
                    {this.props.title}
                </div>
                <div className="single-cell-children">
                    {this.props.children}
                </div>
                </div>
                <img src={arrow} alt="" className="cell-arrow"/>
            </div>
        )
    }
}

Cell.PropTypes = {
    title: PropTypes.string.isRequired
}