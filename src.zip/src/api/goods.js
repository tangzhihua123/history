import request from 'utils/request-util'

/**
 * 活动商品： 免邮or 凑单
 */
export const fetchGoodsActivity = (data) => {
  return request.fetchPromise({
    url: '/shopping/getGoodsActivity',
    data
  })
}
