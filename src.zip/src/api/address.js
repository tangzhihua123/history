
// 地址相关
import request from 'utils/request-util'

export const fetchShippingAddressList = (shippingId) => {
  return request.fetchPromise({
    data: {
      pageIndex: 1,
      pageSize: 1000
    },
    url: '/user/shippingAddressList'
  })
}

export const saveShippingAddress = (data) => {
  return request.fetchPromise({
    data: data,
    url: '/user/saveShippingAddress'
  })
}

export const deleteShippingAddress = (shippingId) => {
  return request.fetchPromise({
    data: {
      shippingId
    },
    url: '/user/deleteShippingAddress'
  })
}