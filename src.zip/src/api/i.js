/**
 * 用户相关请求都放在这
 */


import request from 'utils/request-util'

export const fetchUserInfo = () => {
  return request.fetchPromise({
    data: {},
    url: '/user/myPageInfo'
  })
}

/**
 * 刷新会员码
 */
export const refreshMemberCode = (memberCode) => {
  return request.fetchPromise({
    data: {
      memberCode
    },
    url: '/user/refreshMemberCode'
  })
}

/**
 * 检查会员码
 * @param {*} memberCode 
 */
export const checkMemberCode = (memberCode) => {
  return request.fetchPromise({
    data: {
      memberCode
    },
    url: '/user/checkMemberCode'
  })
}

export const fetchOpenid = (code) => {
  return request.fetchPromise({
    data: {
      code
    },
    url: '/sys/getopenid'
  })
}

