
import request from 'utils/request-util'

/**
 * 拉去购物车列表
 */
export const fetchCart = (data) => {
  return request.fetchPromise({
    url: '/shopping/getCartList',
    data
  })
}

/**
 * 操作购物车
 * @param {*} data 
 */
export const fetchOperCart = (data) => {
  return request.fetchPromise({
    data,
    url: '/shopping/operCart'
  })
}

/**
 * 全选或取消全选
 */
export const selectedAllCart = (data) => {
  return request.fetchPromise({
    data,
    url: '/shopping/selectedCart'
  })
}

/**
 * 获取购物车数量
 */
export const fetchCartGoodsCount = () => {
  return request.fetchPromise({
    url: '/shopping/getCartGoodsAmont'
  })
}

/**
 * 批量删除购物车商品
 * @param {*} data 
 */
export const removeCart = (data) => {
  return request.fetchPromise({
    data,
    url: '/shopping/removeCart'
  })
}

/**
 * 批量加入购物车
 * @param {*} data 
 */
export const batchJoinToCart = (data) => {
  return request.fetchPromise({
    data,
    url: '/shopping/BatchJoinToCart'
  })
}
