import request from 'utils/request-util'

export const fetchOrderUnCreate = (data) => {
  return request.fetchPromise({
    data: data,
    url: '/order/ConfirmOrder'
  })
}

/**
 * 获取 订单列表
 * @param {*} data 
 */
export const fetchOrderList = (data) => {
  return request.fetchPromise({
    data: data,
    url: '/user/getOrderList'
  })
}

export const fetchOrderDetail = (data) => {
  return request.fetchPromise({
    data,
    url: '/user/getOrderInfo'
  })
}

/**
 * 改变订单状态
 * @param {*} data 
 */
export const fetchChangeOrderStatus = (data) => {
  return request.fetchPromise({
    data,
    url: '/user/changeOrderStatus'
  })
}

/**
 * 获取售后单信息
 * @param {*} data 
 */
export const fetchAfterSaleInfo = (data) => {
  return request.fetchPromise({
    data,
    url: '/user/getAfterSaleInfo'
  })
}

/**
 * 申请售后
 * @param {*} data 
 */
export const fetchApplyAfterSale = (data) => {
  return request.fetchPromise({
    data,
    url: '/user/applyAfterSale'
  })
}
export const fetchCancelAfterSale = (data) => {
    return request.fetchPromise({
        data,
        url: '/user/cancelAfterSale'
    })
}
export const fetchOrderCreate = (data) => {
  return request.fetchPromise({
    data,
    url: '/order/create'
  })
}

export const fetchPayConfig = (data) => {
  return request.fetchPromise({
    data,
    url: '/shopping/getPayConfig'
  })
}




