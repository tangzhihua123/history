// import ObjValues from 'object.values';

import { take, put, call, fork, select, all } from 'redux-saga/effects'
import { getCarts, watchGetCarts, watchIncreaseCount, watchDecreaseCount  } from './cart'


import * as cart from  './cart'
import * as i from  './i'
import * as order from './order'
import * as address from './address'
import * as goods from './goods'
// 在这里添加自启动后发起的saga
const sagas = [
  cart,
  i,
  order,
  address,
  goods
]

// 返回fork 包装的数组
function getTasks(sagas) {
  let forkSaga = []
  sagas.map(saga => {
    const values = []
    for (let i in saga) {
      values.push(saga[i])
    }
    const forks = values.map(v => {
      return fork(v)
    })
    forkSaga = forkSaga.concat(forks)
  })
  return forkSaga
}

export default function* root() {
  yield all(getTasks(sagas))
}
