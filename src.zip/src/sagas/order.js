import { put, select, call, fork, all, takeEvery, takeLatest } from 'redux-saga/effects'

import * as actions from '../actions/order'
import { TOKEN_INVALID } from '../actions/i'


import { fetchOrderUnCreate, fetchOrderCreate, fetchOrderList, fetchOrderDetail, fetchAfterSaleInfo, fetchApplyAfterSale, fetchPayConfig, fetchChangeOrderStatus,fetchCancelAfterSale } from '../api/order'

function* fetchOrderInfoUnCreate(action) {
  const { params } = action 
  const { data, resultCode } = yield call(fetchOrderUnCreate, params)
  if (resultCode === 4005) {
    yield put({
      type: TOKEN_INVALID,
      data
    })
    return 
  }
  yield put({
    type: actions.RECEIVE_ORDER_UNCREATE,
    data
  })
}

function* fetchOrderCreateSaga(action) {
  const { params } = action 
  const { data, resultCode } = yield call(fetchOrderCreate, params)
  if (resultCode === 2000) {
    yield put({
      type: actions.CREATE_ORDER_SUCCESS,
      data
    })
  }
}

function* fetchPayConfigSaga(action) {
  const { params } = action 
  const { data, resultCode } = yield call(fetchPayConfig, params)
}

function* fetchOrderListSaga(action) {
  const { params } = action 
  const { data, resultCode } = yield call(fetchOrderList, params)
  yield put({
    type: actions.RECEIVE_ORDER_LIST,
    data: data.list
  })
}

function* fetchOrderDetailSaga(action) {
  const { params } = action 
  const { data, resultCode } = yield call(fetchOrderDetail, params)
  yield put({
    type: actions.RECEIVE_ORDER_DETAIL,
    data: data
  })
}

function* fetchAfterSaleInfoSaga(action) {
  const { params } = action 
  const { data, resultCode } = yield call(fetchAfterSaleInfo, params)
  yield put({
    type: actions.RECEIVE_AFTER_SALE_INFO,
    data: {
        data
        // status: 3,// 售后状态  售后申请中 = 0,退款中 = 1,拒绝售后 = 2,退款成功 = 3,售后已取消 = 4,等待买家退货 = 5,买家退货等待确认 = 6,售后完成 = 7,售后关闭 = 8
        // orderItemId:20171214101702382500,
        // reason:1,
        // issue:'不喜欢',
        // pictureUrls:'https://img.yzcdn.cn/upload_files/2017/05/08/149421656829915091.jpg?imageView2/2/w/200/h/200/q/75/format/jpg,https://img.yzcdn.cn/upload_files/2017/05/08/149421656829915091.jpg?imageView2/2/w/200/h/200/q/75/format/jpg,https://img.yzcdn.cn/upload_files/2017/05/08/149421656829915091.jpg?imageView2/2/w/200/h/200/q/75/format/jpg,https://img.yzcdn.cn/upload_files/2017/05/08/149421656829915091.jpg?imageView2/2/w/200/h/200/q/75/format/jpg,https://img.yzcdn.cn/upload_files/2017/05/08/149421656829915091.jpg?imageView2/2/w/200/h/200/q/75/format/jpg',
        // type:1,
        // num:2,
        // money:143.5,
        // serviceNo:20171214101702382500,
        // applyTime:"2017/6/21 14:26:19",
        // list: [{
        //     "userName": "客服",// 用户 或客服
        //     "content": "退款金额：￥143.50",//内容
        //     "time": "2017/6/21 14:26:49"//时间
        // }],
        // pictureUrl: null,//商品图片
        // title: null,//商品标题
        // sku:"",//规格名称
        // price: 0.0,//商品价格
        // amount: 0,//数量
    }
  })
}

function* fetchApplySaleSaga(action) {
  const { params } = action
  const { data, resultCode,resultMsg } = yield call(fetchApplyAfterSale, params)
  yield put({
    type: actions.RECEIVE_APPLY_AFTER_SALE,
    data: data,
    resultMsg:resultMsg
  })
}
function* fetchCancelAfterSaleSaga(action) {
    const { params } = action
    const { data, resultCode,resultMsg } = yield call(fetchCancelAfterSale, params)
    yield put({
        type: actions.RECEIVE_CANCEL_APPLY_AFTER_SALE,
        data: data,
        resultMsg:resultMsg
    })
}
// 改变订单状态
function* fetchChangeOrderStatusSaga(action) {
  const { data, resultCode } = yield call(fetchChangeOrderStatus, action.params)
  yield put({
    type: actions.FETCH_ORDER_LIST,
    params: {
      type: 0,
      pageIndex: 1,
      pageSize: 1000
    }
  })

  yield put({
    type: actions.CHANGE_ORDER_STATUS_SUCCESS,
    changeOrderType: action.params.status
  })
}

/**
 * 获取待确认订单信息
 */
export function* watchFetchOrderUncreate() {
  yield takeEvery(actions.FETCH_ORDER_UNCREATE, fetchOrderInfoUnCreate)
}
/**
 * 创建订单
 */
export function* watchFetchOrdencreate() {
  yield takeEvery(actions.FETCH_CREATE_ORDER, fetchOrderCreateSaga)
}

export function* watchFetchOrderList() {
  yield takeEvery(actions.FETCH_ORDER_LIST, fetchOrderListSaga)
}

export function* watchFetchOrderDetail() {
  yield takeEvery(actions.FETCH_ORDER_DETAIL, fetchOrderDetailSaga)
}


export function* watchFetchAfterSaleInfo() {
  yield takeEvery(actions.FETCH_AFTER_SALE_INFO, fetchAfterSaleInfoSaga)
}

export function* watchFetchApplySale() {
  yield takeEvery(actions.FETCH_APPLY_AFTER_SALE, fetchApplySaleSaga)
}
export function* watchFetchCancelApplySale() {
    yield takeEvery(actions.FETCH_CANCEL_APPLY_AFTER_SALE, fetchCancelAfterSaleSaga)
}

export function* watchFetchApplySaleSaga() {
  yield takeEvery(actions.FETCH_PAY_CONFIG, fetchPayConfigSaga)
}

export function* watchChangeOrderStatusSaga() {
  yield takeEvery(actions.CHANGE_ORDER_STATUS, fetchChangeOrderStatusSaga)
}
