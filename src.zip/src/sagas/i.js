
import { put, select, call, fork, all, takeEvery, takeLatest } from 'redux-saga/effects'

import * as actions from '../actions/i'

import { fetchUserInfo, refreshMemberCode, checkMemberCode } from '../api/i'

function* getUserInfo () {
  const { data,  resultCode } = yield call(fetchUserInfo)
  if (resultCode === 4005) {
    yield put({
      type: actions.TOKEN_INVALID
    })
    return 
  }
  yield put({
    type: actions.RECEIVE_USERINFO,
    userInfo: data
  })
}

function* refreshMemCode(action) {
  const { data, resultCode } = yield call(refreshMemberCode, action.membercode)
  if(resultCode === 2000) {
    yield put({
      type: actions.RECEIVE_MEMBER_CODE,
      membercode: data.memberCode
    })
  }
  
}


function* checkMemCode(action) {
  const membercode = yield call(checkMemberCode, action.membercode)
  // yield put({
  //   type: actions.RECEIVE_MEMBER_CODE,
  //   data: 
  // })
}

function* checkTokenSaga() {
  const res =  yield call(fetchUserInfo)
  if (res.resultCode === 4005) { // tooken失效
    yield put({
      type: actions.TOKEN_INVALID
    })
  }
}

export function* watchRefreshMemCode() {
  yield takeEvery(actions.REFRESH_MEMBER_CODE, refreshMemCode)
}

export function* watchDecreaseCount() {
  yield takeEvery(actions.FETCH_USERINFO, getUserInfo)
}


export function* watchCheckMemCode() {
  yield takeEvery(actions.CHECK_MEMBER_CODE, checkMemCode)
}


export function* watchCheckToken() {
  yield takeEvery(actions.CHECK_TOKEN, checkTokenSaga)
}