import { put, select, call, fork, all, takeEvery, takeLatest } from 'redux-saga/effects'

import * as actions from '../actions/goods'
import { fetchGoodsActivity } from '../api/goods'


function* fetchGoodsActivitySaga(action) {
  const { data, resultCode } = yield call(fetchGoodsActivity, action.params)
  if (resultCode === 2000) {
    yield put({
      type: actions.RECEIVE_ACTIVITY_GOODS,
      data: data.list
    })
  }
}

export function* watchFetchGoodsActivitySaga() {
  yield takeEvery(actions.FETCH_ACTIVITY_GOODS, fetchGoodsActivitySaga)
}