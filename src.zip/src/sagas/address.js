
import { put, select, call, fork, all, takeEvery, takeLatest } from 'redux-saga/effects'

import * as actions from '../actions/address'
import * as actions_i from '../actions/i' 

import { fetchShippingAddressList, saveShippingAddress, deleteShippingAddress } from '../api/address'



function* getShippingAddressList() {
  const res = yield call(fetchShippingAddressList)
  if (res.resultCode === 2000) {
    yield put({
      type: actions.RECEIVE_SHIPPING_ADDRESS_LIST,
      list: res.data.list
    })
  } else if(res.resultCode === 4005) {
    yield put({
      type: actions_i.TOKEN_INVALID
    })
  }
}

function* addOrSaveShippingAddress(action) {
  const res = yield call(saveShippingAddress, action.address)
  // if (res.resultCode === 2000) {
  //   yield put({
  //     type: actions.ADD_SAVE_SHIPPING_ADDRESS_SUCCESS,
  //     list: res.data.list
  //   })
  // } else { // 请求失败
  //   yield put({
  //     type: actions.ADD_SAVE_SHIPPING_ADDRESS_FAIL,
  //     list: res.data.list
  //   })
  // }
}


function* delShippingAddressSaga(action) {
  const res = yield call(deleteShippingAddress, action.shippingId)
  if (res.resultCode === 2000) {
    yield put({
      type: actions.FETCH_SHIPPING_ADDRESS_LIST
    })
  } else if(res.resultCode === 4005) {
    yield put({
      type: actions_i.TOKEN_INVALID
    })
  }
}

export function* watchGetShippingAddressList() {
  yield takeEvery(actions.FETCH_SHIPPING_ADDRESS_LIST, getShippingAddressList)
}

export function* watchDelShippingAddress() {
  yield takeEvery(actions.DELETE_SHIPPING_ADDRESS, delShippingAddressSaga)
}

export function* watchSaveShippingAddress() {
  yield takeEvery(actions.ADD_SAVE_SHIPPING_ADDRESS, addOrSaveShippingAddress)
}