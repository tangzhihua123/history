

/**
 * saga 迷思？ 该不该在这里改变数据
 */


import { put, select, call, fork, all, takeEvery, takeLatest } from 'redux-saga/effects'

import * as actions from '../actions/cart'

import { getCartState } from '../reducers/cart'

import { fetchCart, fetchOperCart, selectedAllCart, fetchCartGoodsCount, removeCart, batchJoinToCart } from '../api/cart'


/**
 * 获取购物车
 */
function* getCarts(action) {
  const params = {}
  const cartData = localStorage.getItem('cartList')
  if (cartData) {
    params.cartData = cartData
    params.autoCoupon = 1 //默认选取优惠券
  }
  if (action.autoCoupon === 0) {
    params.autoCoupon = action.autoCoupon
  }

  if (action.params && action.params.couponNo) {
    params.couponCode = action.params.couponNo
  }

  const carts = yield call(fetchCart, params)
  yield put({
    type: 'RECEIVE_CART',
    cartInfo: carts
  })
}

function* operCart(action) {
  // 获取cart的state
  const { product = {}, type } = action
  const { goodsId, productId, isChecked, count } = product
  const isDelete = type === actions.DEL_CART_ITEM ? 1 : 0
  const params = {
    goodsId,
    productId,
    isChecked,
    count,
    isDelete
  }
  // const cart = yield select(getCartState)
  // 发起异步请求
  const { resultCode } = yield call(fetchOperCart, params)
  // 请求结束,调用success action, 更新state
  yield put({
    type: actions.FETCH_CART,
  })
  
}

function* switchAllCheckStatus(action) {
  const params = {
    checkAll: action.checkAll
  }
  const cart = yield call(selectedAllCart, params)
  yield put({
    type: actions.FETCH_CART
  })
}


function* fetchCartGoodsCountSaga() {
  const { data, resultCode } = yield call(fetchCartGoodsCount)
  if (resultCode === 2000) {
    const { count } = data
    yield put({
      type: actions.RECEIVE_CART_GOODS_COUNT,
      count
    })
  } else {
    yield put({
      type: actions.RECEIVE_CART_GOODS_COUNT
    })
  }
}

function* fetchRemoveCart(action) {
  const { data, resultCode } = yield call(removeCart, {
    cartData: action.cartData
  })
  yield put({
    type: actions.REMOVE_LOCAL_CART,
    cartData: action.cartData
  })
  yield put({
    type: actions.FETCH_CART
  })
}

function* batchJoinToCartSaga(action) {
  const { data, resultCode } = yield call(batchJoinToCart, {
    cartData: action.cartData
  })
  if (resultCode === 2000) {
    // 应是发起action, 清空本地购物车
    localStorage.removeItem('cartList')
    yield put({
      type: actions.FETCH_CART
    })
  } else {
    yield put({
      type: actions.FETCH_CART,
      params: {
        cartData: action.cartData
      }
    })
  }
}

/**
 * 监听 FETCH_CART action 触发
 */
export function* watchGetCarts() {
  yield takeEvery(actions.FETCH_CART, getCarts)
}

/**
 * 监听增加数量
 */
export function* watchIncreaseCount() {
  yield takeEvery(actions.INCREASE_COUNT, operCart)
}


/**
 * 监听减少数量
 */
export function* watchDecreaseCount() {
  yield takeEvery(actions.DECREASE_COUNT, operCart)
}

/**
 * 监听删除
 */
export function* watchDeleteItem() {
  yield takeEvery(actions.DEL_CART_ITEM, operCart)
}

/**
 * 监听check
 */
export function* watchTriggerCheckStatus() {
  yield takeEvery(actions.TRIGGER_CHECK_STATUS, operCart)
}

export function* watchTriggerAllCheckStatus() {
  yield takeEvery(actions.TRIGGER_ALL_CHECK_STATUS, switchAllCheckStatus)
}

export function* watchTriggerCouponCheckStatus() {
  yield takeEvery(actions.TRIGGER_COUPON_CHECK_STATUS, getCarts)
}

export function* watchFetchCartGoodsCount() {
  yield takeEvery(actions.FETCH_CART_GOODS_COUNT, fetchCartGoodsCountSaga)
}

export function* watchRemoveCart() {
  yield takeEvery(actions.REMOVE_CART, fetchRemoveCart)
}

export function* watchBatchJoinToCart() {
  yield takeEvery(actions.BATCH_JOINTO_CART, batchJoinToCartSaga)
}



