

export const FETCH_ORDER_UNCREATE = 'FETCH_ORDER_UNCREATE'
export const RECEIVE_ORDER_UNCREATE = 'RECEIVE_ORDER_UNCREATE'
export const FETCH_CREATE_ORDER = 'FETCH_CREATE_ORDER'

export const FETCH_ORDER_LIST = 'FETCH_ORDER_LIST'
export const RECEIVE_ORDER_LIST = 'RECEIVE_ORDER_LIST'


export const FETCH_ORDER_DETAIL = 'FETCH_ORDER_DETAIL'
export const RECEIVE_ORDER_DETAIL = 'RECEIVE_ORDER_DETAIL'

export const CHANGE_ORDER_STATUS = 'CHANGE_ORDER_STATUS'
export const CHANGE_ORDER_STATUS_SUCCESS = 'CHANGE_ORDER_STATUS_SUCCESS'
export const CHANGE_ORDER_STATUS_FAIL = 'CHANGE_ORDER_STATUS_FAIL'


// 售后
export const FETCH_AFTER_SALE_INFO = 'FETCH_AFTER_SALE_INFO'
export const FETCH_APPLY_AFTER_SALE = 'FETCH_APPLY_AFTER_SALE'
export const RECEIVE_AFTER_SALE_INFO  = 'RECEIVE_AFTER_SALE_INFO'
export const RECEIVE_APPLY_AFTER_SALE = 'RECEIVE_APPLY_AFTER_SALE'

export const CREATE_ORDER_SUCCESS = 'CREATE_ORDER_SUCCESS'

export const FETCH_PAY_CONFIG = 'FETCH_PAY_CONFIG'
export const FETCH_CANCEL_APPLY_AFTER_SALE = 'FETCH_CANCEL_APPLY_AFTER_SALE'
export const RECEIVE_CANCEL_APPLY_AFTER_SALE = 'RECEIVE_CANCEL_APPLY_AFTER_SALE'




export function fetchOrderUncreate(params) {
	return {
		type: FETCH_ORDER_UNCREATE,
		params
	}
}

export function receiveOrderUncreate(data) {
	return {
		type: RECEIVE_ORDER_UNCREATE,
		data
	}
}

export function fetchCreateOrder(params) {
	return {
		type: FETCH_CREATE_ORDER,
		params
	}
}

/**
 * 获取订单列表
 * @param {*} params 
 */
export function fetchOrderList(params) {
	return {
		type: FETCH_ORDER_LIST,
		params
	}
}

export function receiveOrderList(data) {
	return {
		type: RECEIVE_ORDER_LIST,
		data
	}
}


export function fetchOrderDetail(params) {
	return {
		type: FETCH_ORDER_DETAIL,
		params
	}
}

export function receiveOrderDetail(data) {
	return {
		type: RECEIVE_ORDER_DETAIL,
		data
	}
}


export function fetchAfterSaleInfo(params) {
	return {
		type: FETCH_AFTER_SALE_INFO,
        params
	}
}
export function fetchCancelAfterSale(params) {
    return {
        type: FETCH_CANCEL_APPLY_AFTER_SALE,
        params
    }
}

export function fetchApplyAfterSale(params) {
	return {
		type: FETCH_APPLY_AFTER_SALE,
        params
	}
}

export function receiveAfterSaleInfo(data) {
	return {
		type: RECEIVE_AFTER_SALE_INFO,
		data
	}
}

export function receiveApplyAfterSale(data,resultMsg) {
	return {
		type: RECEIVE_APPLY_AFTER_SALE,
		data,
        resultMsg
	}
}


export function createOrderSuccess(data) {
	return {
		type: CREATE_ORDER_SUCCESS,
		data
	}
}

export function fetchPayConfig(params) {
	return {
		type: FETCH_PAY_CONFIG,
		params
	}
}
/**
 * 改变订单状态
 * @param {*} params 
 */
export function changeOrderStatus(params) {
	return {
		type: CHANGE_ORDER_STATUS,
		params
	}
}
