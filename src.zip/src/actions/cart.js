/**
 * 购物车相关actions
 */
export const FETCH_CART = 'FETCH_CART'
export const RECEIVE_CART = 'RECEIVE_CART'
export const DECREASE_COUNT = 'DECREASE_COUNT'
export const INCREASE_COUNT = 'INCREASE_COUNT'
export const DEL_CART_ITEM = 'DEL_CART_ITEM'
export const TRIGGER_CHECK_STATUS = 'TRIGGER_CHECK_STATUS'
export const TRIGGER_ALL_CHECK_STATUS = 'TRIGGER_ALL_CHECK_STATUS'
export const TRIGGER_COUPON_CHECK_STATUS = 'TRIGGER_COUPON_CHECK_STATUS'

export const FETCH_CART_GOODS_COUNT = 'FETCH_CART_GOODS_COUNT'
export const RECEIVE_CART_GOODS_COUNT = 'RECEIVE_CART_GOODS_COUNT'

export const REMOVE_CART = 'REMOVE_CART'

export const BATCH_JOINTO_CART = 'BATCH_JOINTO_CART'


/**
 * 购物车本地数据操作, 有一部分有用，一部分未用到
 */

export const FETCH_LOCAL_CART = 'FETCH_LOCAL_CART'
export const RECEIVE_LOCAL_CART = 'RECEIVE_LOCAL_CART'
export const DECREASE_LOCAL_COUNT = 'DECREASE_LOCAL_COUNT'
export const INCREASE_LOCAL_COUNT = 'INCREASE_LOCAL_COUNT'
export const DEL_LOCAL_CART_ITEM = 'DEL_LOCAL_CART_ITEM'

export const REMOVE_LOCAL_CART = 'REMOVE_LOCAL_CART'

export const TRIGGER_LOCAL_CHECK_STATUS = 'TRIGGER_LOCAL_CHECK_STATUS'


/**
 * 获取购物车详情
 */
export function fetchCart(params) {
	return {
		type: FETCH_CART,
		params
	}
}

/**
 * 请求返回结果后发起的action
 * @param {*} cartInfo 
 */
export function receiveCart(cartInfo) {
	return {
		type: RECEIVE_CART,
		cart: cartInfo
	}
}

/**
 * 减少购买数量
 * @param {*} productId 
 */
export function decreaseCount(product) {
	return {
		type: DECREASE_COUNT,
		product
	}
}

/**
 * 增加购买数量
 * @param {*} productId 
 */
export function increaseCount(product) {
	return {
		type: INCREASE_COUNT,
		product
	}
}

/**
 * 删除某项购物车商品
 * @param {*}  
 */
export function delCartItem(product) {
	return {
		type: DEL_CART_ITEM,
		product
	}
}

/**
 * 改变购物车check状态
 * @param {*} product 
 */
export function triggerCheckStatus(product) {
	return {
		type: TRIGGER_CHECK_STATUS,
		product
	}
}

/**
 * 购物车全选或取消全选
 * @param {boolean} checkAll 是否全选
 */
export function triggerAllCheckStatus(checkAll) {
	return {
		type: TRIGGER_ALL_CHECK_STATUS,
		checkAll
	}
}


export function triggerCouponCheckStatus(checked) {
	// console.log('checked', checked)
	return {
		type: TRIGGER_COUPON_CHECK_STATUS,
		autoCoupon: checked ? 1 : 0
	}
}

/**
 * 获取购物车数量
 */
export function fetchCartGoodsCount() {
	return {
		type: FETCH_CART_GOODS_COUNT
	}
}

export function receiveCartGoodsCount(count) {
	return {
		type: RECEIVE_CART_GOODS_COUNT,
		count
	}
}


export function removeCart(cartData, couponCode) {
	return {
		type: REMOVE_CART,
		cartData,
		couponCode
	}
}



/**
 * 本地操作action
 */
export function fetchLocalCart() {
	return {
		type: FETCH_LOCAL_CART
	}
}

export function decreaseLocalCount(product) {
	return {
		type: DECREASE_LOCAL_COUNT,
		product
	}
}

export function increaseLocalCount(product) {
	return {
		type: INCREASE_LOCAL_COUNT,
		product
	}
}

export function delCartLocalItem(product) {
	return {
		type: DEL_LOCAL_CART_ITEM,
		product
	}
}


export function triggerLocalCheckStatus(product) {
	return {
		type: TRIGGER_LOCAL_CHECK_STATUS,
		product
	}
}

export function removeLocalCart(cartData) {
	return {
		type: REMOVE_LOCAL_CART,
		cartData
	}
}


/**
 * 批量加入购物车
 * @param {*} params 
 */
export function batchJoinToCart(cartData) {
	return {
		type: BATCH_JOINTO_CART,
		cartData
	}
}
