/**
 * 商品相关的action 
 */

export const FETCH_ACTIVITY_GOODS = 'FETCH_ACTIVITY_GOODS' // 获取活动商品列表

export const RECEIVE_ACTIVITY_GOODS = 'RECEIVE_ACTIVITY_GOODS'

export function fetchActivityGoods(params) {
  return {
    type: FETCH_ACTIVITY_GOODS,
    params
  }
}


export function receiveActivityGoods(data) {
  return {
    type: RECEIVE_ACTIVITY_GOODS,
    data
  }
}