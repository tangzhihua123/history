// 地址相关

export const FETCH_SHIPPING_ADDRESS_LIST = 'FETCH_SHIPPING_ADDRESS'
export const ADD_SAVE_SHIPPING_ADDRESS = 'ADD_SAVE_SHIPPING_ADDRESS'
export const ADD_SAVE_SHIPPING_ADDRESS_SUCCESS = 'ADD_SAVE_SHIPPING_ADDRESS_SUCCESS'
export const ADD_SAVE_SHIPPING_ADDRESS_FAIL = 'ADD_SAVE_SHIPPING_ADDRESS_FAIL'

export const RECEIVE_SHIPPING_ADDRESS_LIST = 'RECEIVE_SHIPPING_ADDRESS_LIST'

export const DELETE_SHIPPING_ADDRESS = 'DELETE_SHIPPING_ADDRESS'

export const SELECT_ADDRESS = 'SELECT_ADDRESS'

export function fetchShippingAddressList() {
  return {
    type: FETCH_SHIPPING_ADDRESS_LIST
  }
}

export function receiveShippingAddressList(list) {
  return {
    type: RECEIVE_SHIPPING_ADDRESS_LIST,
    list
  }
}

export function addOrEditShippingAddress(address) {
  return {
    type: ADD_SAVE_SHIPPING_ADDRESS,
    address
  }
}

export function delShippingAddress(shippingId) {
  return {
    type: DELETE_SHIPPING_ADDRESS,
    shippingId
  }
}

export function selectAddress(address) {
  return {
    type: SELECT_ADDRESS,
    selected: address
  }
}
