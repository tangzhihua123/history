/**
 * 个人中心相关action
 */

export const FETCH_USERINFO = 'FETCH_USERINFO'
export const RECEIVE_USERINFO =  'RECEIVE_USERINFO'
export const REFRESH_MEMBER_CODE = 'REFRESH_MEMBER_CODE'
export const CHECK_MEMBER_CODE = 'CHECK_MEMBER_CODE'
export const RECEIVE_MEMBER_CODE =  'RECEIVE_MEMBER_CODE'

export const CHECK_TOKEN = 'CHECK_TOKEN'
export const TOKEN_INVALID = 'TOKEN_INVALID'


/**
 * 拉取会员信息
 */
export function fetchUserInfo() {
   return {
     type: FETCH_USERINFO
   }
}

/**
 * 得到会员信息
 */
export function receiveUserInfo(userInfo) {
  return {
    type: RECEIVE_USERINFO,
    userInfo
  }
}

/**
 * 刷新会员码
 */
export function refreshMemberCode(membercode) {
  return {
    type: REFRESH_MEMBER_CODE,
    membercode
  }
}


/**
 * 检查会员码
 */
export function checkMemberCode(membercode) {
  return {
    type: CHECK_MEMBER_CODE,
    membercode
  }
}

/**
 * check token的可用性
 */
export function checkToken() {
  return {
    type: CHECK_TOKEN
  }
}

export function tokenIvalid() {
  return {
    type: TOKEN_INVALID
  }
}

