
import React, {Component} from 'react'

import './index.scss'
import Icon from 'components/Icon'
import barterImg from './barter@2x.png'
import refundImg from './refund@2x.png'


export default class AftersalesModal extends Component {
  constructor(props) {
    super(props)
    this.state = {
      modalVisible: props.modalVisible
    }
  }
  componentWillReceiveProps(nextProps) {
    this.setState({
      modalVisible: nextProps.modalVisible
    })
  }
  closeModal=()=> {
    this.setState({
      modalVisible: false
    })
    this.props.onClose && this.props.onClose()
  }
  onItemClick=(type)=> {
    this.props.onItemClick && this.props.onItemClick(type)
    this.closeModal()
  }
  render() {
    const { modalVisible } = this.state
    const { info, onItemClick, title } = this.props
    return (
      <div className="xg-modal">
        <div className="modal-mask" 
          style={{
            display: modalVisible? 'block' : 'none'
          }}
        >
          <div className="modal">
            <div className="modal-title">
              <p>{title}</p>
              <div className="modal-close" onClick={this.closeModal}>
                <Icon type="close" size="xxs"/>
              </div>
            </div>
            <div className="modal-body">
              <div className="aftersales-items">
                <div className="aftersales-item" onClick={()=> { this.onItemClick(0)}}>
                  <div className="aftersales-action">
                  <img className="action-img" src={barterImg} />
                  <span className="action-text">仅换货</span></div>
                  <p className="aftersales-tips">不满意已收到的货物或其他原因需要调换已收到的货物</p>
                </div>
                <div className="aftersales-item" onClick={()=> { this.onItemClick(1)}}>
                  <div className="aftersales-action">
                  <img className="action-img" src={refundImg} />
                 <span className="action-text">退货/退款</span></div>
                  <p className="aftersales-tips">未收到货物，直接退款，或已收到货，需要退还已收到的货物</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}