import React from 'react'

import './index.scss'

export default function OrderFee(props) {
  const { fees = [], payment } = props
  return (
    <div className="order-fee">
      <div>
        {
          fees.map(function (el, index) {
            return (<div key={index} className="fee-item">
              <span className="fee-label">{el.text}</span>
              <span className="fee-value">{el.value}</span>
            </div>)
          })
        }
        {
          payment?  <div className="fee-item">
          <span></span>
          <span className="right-text">实付 ¥{payment}</span>
        </div> : null
        }
      </div>
    </div>
  )
}