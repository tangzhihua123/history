import React, {Component} from 'react'
import Request from 'utils/request-util.js'
import Load from 'utils/load.js'
import Util from 'utils/util.js'
import PropTypes from 'prop-types'
import Tab from "components/Tab/Tab"
import CouponItem from './coupon-item'

import CouponTips from './coupon-tips.png'
import NoCoupon from './no_coupon.png'

import './list.scss'

const couponsText = [
    '暂时没有可使用的优惠券哦~',
    '您还没有使用过的优惠券哦~',
    '您还没有已过期的优惠券哦~'
]

export default class ConponList extends Component {
    constructor(props) {
        super(props)
        this.state = {
            pageIndex1: 1,
            pageIndex2: 1,
            pageIndex3: 1, // 三种状态优惠券的页面索引
            couponsData1: [],
            couponsData2: [],
            couponsData3: [],
            tab: 1,
            pageSize: 10,
            get1: false,
            get2: false,
            get3: false,
            end1: false,
            end2: false,
            end3: false
        }
        console.log('构造器方法')
    }
    componentWillMount() {
        this.fetchCoupons({type: 'click', index: 1})
    }
    componentWillUnmount() {
        this.state.destroyScroll && this.state.destroyScroll()
    }
    componentDidMount() {
        Util.setFullHeight('.conpon-detail-list')

        let destroyScroll = Load.bottomLoad(() => {
            this.fetchCoupons({index: this.state.tab})
        })
        this.setState({
            destroyScroll: destroyScroll
        })
    }

    fetchCoupons = ({index, type}) => {
        console.log('滚动事件')
        if(type === 'click' && this.state['get'+index]) {
            return
        }
        if(this.state['end'+index]) {
            return
        }
        let param = {
                data: {
                    type: index,
                    pageIndex: this.state['pageIndex'+index],
                    pageSize: this.state.pageSize
                },
                url: '/user/couponlist',
                successFn: (res) => {
                    console.log('请求成功的评论数据', res)
                    let data = res.data.list
                    if(data.length < this.state.pageSize) {
                        this.setState({
                            ['end'+index]: true
                        })
                    }
                    this.setState({
                        ['couponsData'+index]: this.state['couponsData'+index].concat(data),
                        ['pageIndex'+index]: this.state['pageIndex'+index] + 1,
                        ['get'+index]: true
                    })
                },
                errorFn: (error) => {
                    console.log('请求失败的错误', error)
                }
            }
        Request.fetch(param)    
    }
    handleTopTabChange = (tabText, tabIndex) => {
        console.log('tab标签切换了')
        console.log(tabText, tabIndex)
        this.setState({
            tab: tabIndex+1
        })
        this.fetchCoupons({index: tabIndex+1, type: 'click'})

    }
    genItems = () => {
        let tab = this.state.tab
        var arr = this.state['couponsData'+tab]
        /* var arr = [{
            couponId: 0,//优惠券ID
            title: "100减50",//名称 100减50 满200使用等
            couponType: 4,//4 免运费 6满折券 7 满减券 8满免费，实物兑换券
            expiries: "",//有效期
            desc: "30",// 折扣、满减、免邮券、商品兑换图片地址
            useStatus: 1,//状态:1=未使用 2=已使用 3=已过期
            online: 1,//是否线上使用
            couponNo: "",//优惠券码
            scene: "线下门店使用",//场景 如线下门店使用 App新人专享
            limitDesc: "仅限兑换区使用"//规则性描述 如仅限兑换区使用 
        }, {
            couponId: 0,//优惠券ID
            title: "100减50",//名称 100减50 满200使用等
            couponType: 4,//4 免运费 6满折券 7 满减券 8满免费，实物兑换券
            expiries: "",//有效期
            desc: "30",// 折扣、满减、免邮券、商品兑换图片地址
            useStatus: 1,//状态:1=未使用 2=已使用 3=已过期
            online: 1,//是否线上使用
            couponNo: "",//优惠券码
            scene: "线下门店使用",//场景 如线下门店使用 App新人专享
            limitDesc: "仅限兑换区使用"//规则性描述 如仅限兑换区使用 
        },] */

        if(arr.length === 0) {
            
            return (
                <div className="no-coupons-div">
                    <img src={NoCoupon} className="no-coupons-img" alt=""/>
                    <div className="no-coupons-des">{couponsText[tab-1]}</div>
                </div>
            )
        }
        var items = arr.map(function(item ,i) {
            return <CouponItem data={item} key={i} />
        })
        return items
    }
    gotoPage = (url) => () => {
        location.href = '//'+location.host+url
    }
    render() {
        let topTabStatus = ['未使用', '已使用', '已过期'],
        activeIndex = 0
        return (
            <div className="conpon-detail-list">
                <Tab
                        ref="topTab"
                        isTopTab={true}
                        display={true}
                        tabs={topTabStatus}
                        activeIndex={activeIndex}
                        context={this}
                        handleItemClick={this.handleTopTabChange}
                    />
                <div className="coupons-container">
                    {this.genItems()}
                </div>    
                <div className="coupon-tips-div">
                    <img className="coupon-tips-img" src={CouponTips} onClick={this.gotoPage('/coupon-intro')} alt=""/>
                </div>
            </div>
        )
    }
}