import React, { Component } from 'react'
import CouponItem from './coupon-item.jsx'
import { Redirect } from 'react-router-dom'
import Request from 'utils/request-util.js'
import './select-list.scss'

let array = [{
    couponId: 12,
    couponNo: "12345678",
    title: "100减20元",
    expiries: "2017-10-01 12:12:12",
    desc: "20元",
    useStatus: 1,
    online: 1,
    isChecked: true,
}, {
    couponId: 12,
    couponNo: "12345679",
    title: "100减20元",
    expiries: "2017-10-01 12:12:12",
    desc: "20元",
    useStatus: 1,
    online: 1,
    isChecked: false,
}]
export default class SelectList extends Component {
    constructor(props) {
        super(props)
        this.state = {
            data: this.props.location.state.couponList,// this.props.data || [],
            selected: false
        }
    }
    componentDidMount() {
        console.log(this.props)
        
    }
    genList = () => {
        
        let divs = [],
            array = this.state.data
        divs = array.map(function (item, i) {
            return <CouponItem data={item} key={i} select={true} />
        })
        return divs
    }
    updateSelectStatus = (No) => {
        let array = this.state.data,
            newArr = [],
            obj = {}
        newArr = array.map(function (item) {
            obj = {}
            obj = { ...item }
            if (No == item.couponNo) {
                obj.isChecked = true
            } else {
                obj.isChecked = false
            }
            return obj
        })
        return newArr
    }
    selectHandle = (e) => {

        console.log('e.target', e.target)
        let target = e.target
        while (target !== document.body && target.className.indexOf('couponNo') === -1) {
            target = target.parentNode
            console.log('cla', target.className)
        }
        if (target === document.body) {
            return
        }
        let id = target.className.slice(8)
        console.log('更新前的state', JSON.stringify(this.state.data))
        this.setState({
            couponNo: id,
            data: this.updateSelectStatus(id)
        }, () => {
            console.log('更新后的state', JSON.stringify(this.state.data))
            setTimeout(() => {
                this.setState({
                    selected: true,
                })
            }, 200)
        })
        
        console.log('选择的id', id)
        // this.props.couponCB && this.props.couponCB(id)
    }
    render() {
        console.log('优惠券列表的state', this.state)
        return (this.state.selected ? <Redirect push to={{ pathname: '/app/mycart', state: { couponNo: this.state.couponNo } }}></Redirect> :
            <div className="coupon-select-div" onClick={this.selectHandle}>
                {this.genList()}
            </div>
        )
    }
}