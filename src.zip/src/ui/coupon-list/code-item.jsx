import React, { Component } from 'react'

import CodeImg from './coupon_code@2x.png'
import Bg from './coupon_xianxia@2x.png'
import Close from './coupon_xianxia_close@2x.png'

import './code-item.scss'

export default class CodeItem extends Component {
    constructor(props) {
        super(props)
        this.state = {
            show: this.props.show,
            data: this.props.data || {}
        }

    }
    componentWillReceiveProps(nextProps) {
        this.setState({
            show: nextProps.show,
            data: this.props.data
        })
    }
    genTitle = () => {
        let couponType = this.state.data.couponType
        console.log('couponType', couponType)
        if(couponType === 7) {
            return (
            <div className="title">
                <span className="rmb">¥</span>
                <span className="text">{parseInt(this.state.data.desc)}</span>
            </div>
        )
        } else if(couponType === 8) {
            return (
            <div className="title">
                <img src={this.state.data.desc} className="coupon-list-item-img" alt=""/>
            </div>
        )
        } else {
            return (
                <div className="title">
                    <span className="text">
                        {this.state.data.desc}
                    </span>
                </div>
            )
        }
        
    }
    close = () => {
        this.setState({
            show: false
        })
    }
    render() {
        return (
            <div className="coupon-code-item" style={{ display: this.state.show ? "block" : "none" }}>
                <div className="coupon-code-bg" onClick={this.close}></div>
                <div className="coupon-code-container">
                    <div className="bg-line">
                        <img src={Bg} alt=""/>
                    </div>
                    <div className="content-div">
                        {this.genTitle()}
                        <div className="detail-div">
                            <div className="des-div">
                                <div className="range">{this.state.data.scene}</div>
                                <div className="money">{this.state.data.title}</div>
                                <div className="date">{this.state.data.expiries}</div>
                            </div>
                        </div>
                    </div>
                    <div className="code-div">
                        <div className="des-div">门店结账时出示此码,自动使用优惠券</div>
                        <img src={CodeImg} className="code-img" alt="" />
                        <div className="num-div">{this.state.data.couponNo}</div>
                    </div>
                    <div className="close-div" onClick={this.close}>
                        <img src={Close} className="close-img" alt=""/>
                    </div>
                </div>

            </div>
        )
    }
}