import React, { Component } from 'react'
import Util from 'utils/util.js'
import PropTypes from 'prop-types'
import CodeItem from './code-item.jsx'
import './coupon-item.scss'

import UsedImg from './coupon_used@2x.png'
import ExpireImg from './coupon_expired@2x.png'
import CodeImg from './coupon_code@2x.png'
import SelectImg from './coupon_selected.png'
import UnselectImg from './coupon_unselected.png'
import Down from './coupon_down@2x.png'
import Up from './coupon_up.png'

let dataObj = {
    couponId: 0,//优惠券ID
    title: "100减50",//名称 100减50 满200使用等
    couponType: 4,//4 免运费 6满折券 7 满减券 8满免费，实物兑换券
    expiries: "",//有效期
    desc: "30",// 折扣、满减、免邮券、商品兑换图片地址
    useStatus: 1,//状态:1=未使用 2=已使用 3=已过期
    online: 1,//是否线上使用
    couponNo: "",//优惠券码
    scene: "线下门店使用",//场景:如线下门店使用 App新人专享
    limitDesc: "仅限兑换区使用"//规则性描述 如仅限兑换区使用 
}
export default class CouponItem extends Component {
    constructor(props) {
        super(props)
        this.state = {
            code: false,
            data: this.props.data || {},
            codeShow: false,
            selectStatus: this.props.select, // 优惠券是否在选择页面
            isChecked: this.props.data.isChecked,// 如果在选择列表页面，是否是选中状态
            textId: Util.makeID(),
            iconDown: true
        }
    }

    componentDidMount() {
        this.calculateDesHeight()
    }
    componentWillReceiveProps(nextProps) {
        this.setState({
            data: nextProps.data,
            isChecked: nextProps.data.isChecked
        })
    }
    genSelect = () => {
        if (this.state.selectStatus) {
            if (this.state.isChecked) {
                return (
                    <div className="coupon-check-div">
                        <img src={SelectImg} className="coupon-check-img" alt="" />
                    </div>
                )
            } else {
                return (
                    <div className="coupon-check-div">
                        <img src={UnselectImg} className="coupon-check-img" alt="" />
                    </div>
                )
            }
        }
    }

    calculateDesHeight = () => {
        let el = document.querySelector('.coupon-con-text-' + this.state.textId)
        let height = parseInt(getComputedStyle(el).height)
        let rem = window.screen.availWidth / 375 * 100
        let lh = rem * 0.17
        // 元素超过一行
        console.log('高度', lh, height)
        if (height > lh) {
            this.setState({
                textOverflow: true
            }, () => {
                this.setDesTextStyle()
            })
        }
    }
    triggerTextShow = () => {
        this.setState({
            iconDown: !this.state.iconDown
        }, () => {
            this.setDesTextStyle()
        })
    }
    setDesTextStyle = () => {
        let el = document.querySelector('.coupon-con-text-' + this.state.textId)
        if (this.state.iconDown) {
            //一行
            el.style.maxHeight = '0.17rem'
            el.style.textOverflow = 'ellipsis'
            el.style.whiteSpace = 'nowrap'
        } else {
            //多行
            el.style.maxHeight = ''
            // el.style.textOverflow = 'ellipsis'
            el.style.whiteSpace = 'normal'

        }
    }
    genShowDes = () => {
        if (this.state.textOverflow) {
            return (
                <div className="text-icon-div" onClick={this.triggerTextShow}>
                    {this.state.iconDown ?
                        <img src={Down} className="text-icon-img" alt="" /> :
                        <img src={Up} className="text-icon-img" alt="" />
                    }
                </div>
            )
        }
    }
    genItem = () => {
        return (
            <div className="coupon-detail-item">
                {this.genSelect()}
                <div className="main-div">
                    {this.genTitle()}
                    <div className="detail-div">
                        <div className="des-div">
                            <div className="range">{this.state.data.scene}</div>
                            <div className="money">{this.state.data.title}</div>
                            <div className="date">{this.state.data.expiries}</div>
                        </div>
                        {
                            this.state.data.useStatus === 1 ?
                                <div className="code-div-con">
                                    {
                                        this.genLookDiv()
                                    }
                                </div> :
                                this.genLookDiv()
                        }

                    </div>
                </div>
                <div className="left-cricle"></div>
                <div className="right-cricle"></div>
                <div className="limit-div">

                    <div className="con-div">
                        <div className={"coupon-con-text coupon-con-text-" + this.state.textId}>
                            {this.state.data.limitDesc}
                        </div>
                        {this.genShowDes()}
                    </div>
                </div>
            </div>
        )
    }
    showCode = () => {
        this.setState({
            codeShow: true
        })
    }
    genTitle = () => {
        let couponType = this.state.data.couponType
        if (couponType === 7) {
            return (
                <div className="title">
                    <span className="rmb">¥</span>
                    <span className="text">{parseInt(this.state.data.desc)}</span>
                </div>
            )
        } else if (couponType === 8) {
            return (
                <div className="title">
                    <img src={this.state.data.desc} className="coupon-list-item-img" alt="" />
                </div>
            )
        } else {
            return (
                <div className="title">
                    <span className="text">
                        {this.state.data.desc}
                    </span>
                </div>
            )
        }

    }
    
    lookGoodsDetail = (goodsId) => () => {
        window.location.href = window.location.origin + '/app/goodsdetail?goodsId=' + goodsId + "&goodsSource=13" + "&sourceId=0"
    }

    genLookDiv = () => {
        let {
            couponType,
            online,
            goodsId,
            useStatus
            } = this.state.data

        if (useStatus === 2) {
            return <div className="unnormal-div" >
                <img src={UsedImg} className="unnormal-div-img" alt="" />
            </div>
        } else if (useStatus === 3) {
            return <div className="unnormal-div" >
                <img src={ExpireImg} className="unnormal-div-img" alt="" />
            </div>
        }
        if (online === 1) {
            if (couponType === 8) { // 实物兑换
                return (
                    <div className="look-div" onClick={this.lookGoodsDetail(goodsId)}>
                        查看
                    </div>
                )
            }
        } else { // 线下使用
            return (
                <div className="code-div" onClick={this.showCode}>
                    <img src={CodeImg} alt="" />
                    <div className="text">查看条形码</div>
                </div>
            )
        }
    }
    genCodeItem = () => {

        if (this.state.data.online !== 1) {
            let data = this.state.data
            return (
                <CodeItem show={this.state.codeShow}
                    data={{
                        couponNo: data.couponNo,
                        desc: data.desc,
                        scene: data.scene,
                        expiries: data.expiries,
                        title: data.title,
                        couponType: data.couponType
                    }}
                />
            )
        }
    }
    render() {
        return (
            <div className={"couponNo" + this.state.data.couponNo}>
                {this.genItem()}
                {this.genCodeItem()}
            </div>
        )


    }
}
CouponItem.propTypes = {
    data: PropTypes.object, // 优惠券数据
    select: PropTypes.bool // 是否是选择优惠券的页面
}
