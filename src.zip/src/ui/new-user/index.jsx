import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Util from 'utils/util.js'
import Load from 'utils/load.js'
import RequestUtil from 'utils/request-util'
import URLUtil from 'utils/url-util'
import PullToRefresh from 'utils/pulltorefresh.js'
import LoadingDiv from 'components/bottom-refresh/index.jsx'

import ActivityProductItem from './item'
import GoodsSkuSelect  from 'ui/goods-sku-select/goods-des'

import CartAndMenu from 'ui/cart-menu'
import Request from 'utils/request-util.js'

import './index.scss'
import NotificationBlock from 'components/Notification/NotificationBlock.jsx'


export default class TopicList extends Component {
    constructor(props) {
        super(props)

        this.state = {
            pageIndex: 1,
            pageSize: 10,
            hasMore: true,
            bannerBig: '',// 活动主图
            title: '',//活动标题
            banner: [],// 栏目banner
            packageId: 0,
            GetCouoponStatus:false,//立即领取
            // scrollWidth:document.body.scrollWidth,
            couponList: [],
            list: [],

            /*购买相关*/
            cartNum:0, //购物车数量
            noLogin: false,
        }
    }

    componentWillMount() {
        this.GetActivityInfo()
        // this.GetAjaxCouponList()
        this.fetchCartNum()


        let destoryFn = this.getTopicList()
        this.setState({
            destoryFn: destoryFn
        })

    }



    /**
     * [GetActivityInfo 获取活动信息]
     */
    GetActivityInfo() {
        let param = {
            data: {},
            url: '/Active/NewUserGiftList',
            successFn: (data) => {
                if(data.resultCode == 2000) {
                    this.setState({
                        bannerBig: data.data[0].ngImages,
                        title: data.data[0].ngTitle,
                    })

                }else if(data.resultCode == 5000) {
                    alert("网络异常，请稍后再试")
                }


            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }
        RequestUtil.fetch(param)
    }

    componentDidMount() {
        let destroyScroll = this.state.hasMore ? Load.bottomLoad(this.getTopicList) : null
        this.setState({
           
            destroyScroll: destroyScroll
        })
        this.NewUserGiftCouponList()

    }
    NewUserGiftCouponList = () => {

        let param = {
            data: {

            },
            // url: '/Active/NewUserGiftList',
            url: '/Active/NewUserGiftCouponList',
            successFn: (res) => {
                console.log('请求成功的优惠券数据', res)
                let data = res.data;
                this.setState({
                    couponList:data,
                    packageId:data[0].CpkId,
                })

            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }
        Request.fetch(param)
    }

    /**
     * [getTopicList 获取主题活动下的’最佳拍档商品列表,接口还没提供，暂时注释掉.]
     * @return {[type]} [description]
     */
    getTopicList= () => {
        this.setState({
            loading: true
        })

        let param = {
            data: {
                pageIndex: this.state.pageIndex,
                pageSize: this.state.pageSize,
            },
            url: '/Active/UserGiftGoodsList',
            successFn: (data) => {
                if(data.resultCode == 2000) {
                    if(data.data.length == 0) {
                        this.setState({
                            hasMore: false,
                            loading: false
                        })
                    }

                    else if(data.data.length > 0) {
                        this.setState({
                            list: this.state.list.concat(data.data),
                            pageIndex: this.state.pageIndex + 1,
                            hasMore: true,
                            loading: false

                        })
                    }

                }else if(data.resultCode == 5000) {
                    // alert("网络异常，请稍后再试")
                }


            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }
        RequestUtil.fetch(param)
    }



    /**
     * [获取购物车数量]
     * @return {[type]} [description]
     */
    fetchCartNum = () => {
        RequestUtil.fetchCartNum({
            noLogin: (num) => {
                this.setState({
                    noLogin: true,
                    cartNum: num
                })
            },
            Login: (num) => {
                this.setState({
                    cartNum: num
                })
            },
            ErrorFun: (msg) => {
                this.enter(msg)
            }
        })
    }

    /**
     * [遍历商品数据列表]
     * @return {[type]} [description]
     */
    genItem = () => {
        var arr = this.state.list
        if(!Util.isArray(arr)) return


        var list = arr.map( (item, i) => {
            let last = false;
            if(i == (arr.length - 1)) last = true
            return (
                <ActivityProductItem data={item} key={i} last={last} addCartHandle={this.addCart_Comm.bind(this)} />
            )
        })
        return list
    }




     /**
     * [领取优惠券]
     * @param  {[type]} id [优惠券id]
     * @return {[type]}    [description]
     */
    GetAjaxCouponList = () => {
        // console.log(URLUtil.fetchValueByURL("amid"), 'ttt') // 189
        let param = {
            data: {
                amid: URLUtil.fetchValueByURL("amid")
            },
            url: '/Active/ActiveCouponList',
            successFn: (data) => {
                if(data.resultCode == 2000) {
                    if(data.data.length > 0) {
                        let _d = data.data
                        for(let i = 0 ;i<_d.length;i ++ ) {
                            _d[i].countText = "满" + _d[i].FromMoney + '使用'
                            if(_d[i].pmtType == 8) {
                                _d[i].countText = _d[i].CpnsName
                            }


                        }
                        this.setState({
                            couponList: _d,
                        })
                    }

                }else if(data.resultCode == 5000) {
                    alert("网络异常，请稍后再试")
                }


            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }
        RequestUtil.fetch(param)
    }
    
    GetCouoponData() {
        let param = {
            data: {
                cpkid: this.state.packageId,
                type:1,
            },
            url: '/Active/NewUserReceiveCoupon',
            successFn: (data) => {
                if(data.resultCode == 2000) {
                    if(data.data==1) {
                        this.enter('不是新用户不能领取')
                    }else if(data.data==2) {
                        this.enter('领取成功')
                        this.setState({
                            GetCouoponStatus:true,//已领取
                        })
                    }else {
                        this.enter('领取失败')
                    }
                }else if(data.resultCode == 5017) {
                    this.enter('领取失败，新人优惠券包已经过期')
                }else if(data.resultCode == 5000) {
                    this.enter('网络异常，请稍后再试')
                }else if(data.resultCode == 4005) {
                    // 跳转到登录页面处理
                    // this.enter('领取失败')
                    URLUtil.redirectPage({
                        page: 'app/login',
                        options: {
                            redirect: "/" + window.location.href.split('/')[3]
                        }
                    })
                }


            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }
        RequestUtil.fetch(param)
    }

    /**
     * [领取优惠券]
     * @param  {[type]} id [优惠券id]
     * @return {[type]}    [description]
     */
    GetCouopon(id) {
        let self = this
         if(Util.isCustomAgent()) {
            try{
                JSBridge.getData({
                    type: ['token', 'userId'],
                    success: function(data) {
                        let params = store.get('user') ? store.get('user') : {}
                        params.userId = data.userId
                        params.token = data.token
                        store.set('user', params)
                        data.userId && self.GetCouoponData()
                    }
                })
            }catch (err) {
                console.log(err)
            }  
        }else{
            this.GetCouoponData()
        }
       
    }
    enter = (message) => {
        this.setState({
            enter: true,
            message: message
        });
        setTimeout(
            function () {
                this.leave();
            }.bind(this),
            2000
        );
    }

    leave = () => {
        this.setState({
            enter: false,
            message: ""
        });
    }
    setTimeInterval = () => {
        let time = this.state.time
        let interval = setInterval(() => {
            if (time <= 0) {
                clearInterval(interval)
                this.setState({
                    time: this.state.totalTime,
                    getCode: false
                })
            } else {
                time--
                this.setState({
                    time: time
                })
            }
        }, 1000)

    }
    /**
     * [获取优惠券数据列表]
     * @return {[type]} [description]
     */
    getCouponList = () => {
        let len = this.state.couponList.length
        let arr = this.state.couponList

        let list = null


            list = arr.map((item, i) => {
                // {this.setState(
                //     packageId:item.CpkId,
                // )}
                return (
                    <div className='m-gift-item' key={i}>
                        <div  className="info">
                            <img src={item.NgiImages } className="imgs" />
                        </div>
                    </div>
                )
            })


        return list

    }


    enter = (message) => {
        this.setState({
            enter: true,
            message: message,
        });
        setTimeout(
            function() {
                this.leave();
            }.bind(this),
            2000
        );
    }

    leave = () => {
        this.setState({
            enter: false,
            message: "",
        });
    }

  
    addCart_Comm(goodsId) {
        this.setState({
            specShow: true,
            goodsId
        })
    }

    hideSkuSelectDialog() {
        this.setState({
            specShow: false
        })
    }

    UpdataCartNum(addCartNum) {
        this.setState({
            cartNum:  this.state.cartNum + addCartNum
        })
    }


    render() {

        return (
            <div className="m-activity-list">
                <div className="big-img"><img src={this.state.bannerBig} alt= {this.state.title} /></div>
                <div className="m-coupon">
                    {this.getCouponList()}
                </div>
                <div className="receiveGifr">
                    {this.state.GetCouoponStatus?(
                        <div  className="hasReceiveGifr_item">
                            已领取
                        </div>
                    ):(
                        <div onClick={this.GetCouopon.bind(this)} className="receiveGifr_item">
                            立即领取
                        </div>
                    )}

                </div>
                <div className="newUserM">
                    <div className="newUserM_item">
                        - 新手必买 -
                    </div>
                </div>

                <div className="m-list-flex">
                    {this.genItem()}
                </div>
                <LoadingDiv show={this.state.loading} hasMore={this.state.hasMore}/>
                {
                    this.state.specShow ?
                    <GoodsSkuSelect
                        AddCartSource={{
                            goodsSource: 18,
                            sourceId: 0
                        }}
                        noLogin={this.state.noLogin}
                        isShow={this.state.specShow}
                        goodsId={this.state.goodsId}
                        hideDialog={this.hideSkuSelectDialog.bind(this)}
                        UpdateCartNumHandle={this.UpdataCartNum.bind(this)}
                        ></GoodsSkuSelect>:''
                }
                <CartAndMenu cartNum={this.state.cartNum}></CartAndMenu>
                <NotificationBlock enter={this.state.enter} leave={this.leave}>
                    {this.state.message}
                </NotificationBlock>
            </div>
        )
    }
}