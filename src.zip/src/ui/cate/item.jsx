import React, { Component } from 'react'
import PropTypes from 'prop-types'
import RequestUtil from 'utils/request-util'
import URLUtil from 'utils/url-util'
import './item.scss'
import Util from 'utils/util.js'

import AddToCart from 'ui/add-to-cart'

export default class CategoryList extends Component {
    constructor(props) {
        super(props)

        this.state = {
            data: this.props.data || {},
            key: this.props.index  || 0,
            id: "map"+ this.props.index
        }
    }

    /**
     * [redirectCate 跳转到三级类目列表页面]
     * @param  {[type]} catId [description]
     * @return {[type]}       [description]
     */
    RedirectCate(catId,title,linkType) {
        URLUtil.redirectPage({
            page: 'cate-level',
            options: {
                catId: catId,
                title: title,
                catType:linkType,
            }
        })  
    }
    
    RedirectPage(url) {
        window.location.href = url
    }
    // getScrollTop() {
    //     var scrollPos;
    //     if (window.pageYOffset) {
    //         scrollPos = window.pageYOffset; }
    //     else if (document.compatMode && document.compatMode != 'BackCompat')
    //     { scrollPos = document.documentElement.scrollTop; }
    //     else if (document.body) { scrollPos = document.body.scrollTop; }
    //     return scrollPos;
    // }

    componentDidMount() {

    }

    render() {
        
        return (
            <div className='m-cate-item' id={this.state.id} ref='divs'
                 // ref={"divs"+this.props.index}
            >
                {
                    this.state.key != 0 ? 
                        <div>
                            <div className="title">{this.state.data.title}</div>
                            <img src={this.state.data.pictureUrl} alt={this.state.data.title} className="big_img" onClick={this.RedirectPage.bind(this, this.state.data.link)} />
                        </div>
                    : <div>
                         <img src={this.state.data.pictureUrl} alt={this.state.data.title} className="big_img"/>
                         <div className="title">{this.state.data.title}</div>
                           
                    </div>
                       
                }
                <div className="catList">
                    {
                        this.state.data.subList.map((item, i) => {
                            return (
                                <div className="two-level-cat" key={i} >
                                    <div onClick={this.RedirectCate.bind(this, item.catId, item.title, item.catType)}>
                                        <div className='img_wrap'>
                                             <img src={item.topPictureUrl} alt={item.title} />
                                        </div>
                                       
                                        <p>{item.title}</p>
                                    </div>
                                </div>
                            )
                        })
                    }
                </div>
            </div>
        )
    }
}