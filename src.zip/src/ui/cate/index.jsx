import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Util from 'utils/util.js'
import RequestUtil from 'utils/request-util'
import Notification from "components/Notification/NotificationBlock.jsx"
import LazyLoad from 'components/Lazyload'
import CartAndMenu from 'ui/cart-menu'
import CategoryList from './item'

import './index.scss'
let topArr = [];
let heightArr = [];
let maxHeight = [];

export default class TopicList extends Component {
    constructor(props) {
        super(props)
        let that = this;
        this.state = {
            catList: [], // 一级分类列表数据
            catId: 0, // 默认选中一级类目id
            catName: '', // 默认选中一级类目 名称
            activeCate: 0, // 选中类别 激活

            /*购买相关*/
            cartNum:0, //购物车数量
            enter: false,
            message: '',
        }
    }
     enter = (message) => {
        this.setState({
            enter: true,
            message: message,
        });
        setTimeout(
            function() {
                this.leave();
            }.bind(this),
            2000
        );
    }

    leave = () => {
        this.setState({
            enter: false,
            message: "",
        });
    }

    componentWillMount() {
        this.fetchCartNum()
        this.getCategoryList()
        document.getElementById("map0")
    }

    componentDidMount() {
        let scrollFn = (e) => {
            // console.log("window.scrollY-------------"+window.scrollY)
            let scrollYHeight = window.scrollY;
            let valueH = 0
            //maxHeight
            for(let i=0;i<topArr.length;i++) {
                if(scrollYHeight<=maxHeight[i]) {
                    valueH = i;
                    break
                }
            }
            if(topArr[valueH] <= scrollYHeight <= maxHeight[valueH]) {
                this.setState({
                    topSrc:valueH,
                    catId:valueH
                },()=>{
                    // console.log("topSrc----------"+this.state.topSrc)
                })
            }

        }
        let warp = Util.throttle(scrollFn, 100)
        window.addEventListener('scroll', warp, false)
    }

    /**
     * [获取购物车数量]
     * @return {[type]} [description]
     */
    fetchCartNum = () => {
        RequestUtil.fetchCartNum({
            noLogin: (num) => {
                this.setState({
                    noLogin: true,
                    cartNum: num
                })
            },
            Login: (num) => {
                this.setState({
                    cartNum: num
                })
            },
            ErrorFun: (msg) => {
                this.enter(msg)
            }
        })
        // let param = {
        //     data: {
        //     },
        //     url: '/shopping/getCartGoodsAmont',
        //     successFn: (data) => {
        //         if(data.resultCode !== 2000) {
        //             this.enter('获取购物车数量失败')
        //             return
        //         }
        //         this.setState({
        //             cartNum: data.data.count
        //         })
        //     },
        //     errorFn: (error) => {
        //         console.log('请求失败的错误', error)
        //     }
        // }
        // RequestUtil.fetch(param)
        
    }
    
    
  
    /**
     * [获取分类列表]
     * @return {[type]} [description]
     */
    getCategoryList = () => {
        let param = {
            data: {},
            url: '/goods/goodsCategory',
            successFn: (data) => {
                if(data.resultCode == 2000) {
                    if(data.data.list.length > 0) {
                        this.setState({
                            catList: this.state.catList.concat(data.data.list),
                            activeCate: data.data.list[0].catId,
                            catName: data.data.list[0].title,
                            catId: 0
                        })
                    }
                    
                }else  {
                    this.enter("网络异常，请稍后再试")
                } 

               
            },
            errorFn: () => {
                this.enter("网络异常，请稍后再试")
            }
        }
        RequestUtil.fetch(param)    
    }
    
    /**
     * [遍历商品分类列表]
     * @return {[type]} [description]
     */
    refCb(instance) {
        topArr.push(instance.refs.divs.offsetTop)
        heightArr.push(instance.refs.divs.offsetHeight)
        maxHeight.push(instance.refs.divs.offsetTop+instance.refs.divs.offsetHeight)
        // console.log("height-------"+heightArr)
        // console.log("topArr-------"+topArr)
        // console.log("maxHeight-------"+maxHeight)
    }

    genItem = () => {
        var arr = this.state.catList
        if(!Util.isArray(arr)) return
        console.log(this.state.catList,222)
        var list = arr.map((item, i) => {
            let last = false;
            let refValue = "map"+ i;
            if(i == (arr.length - 1)) last = true


            return (
                <LazyLoad height={500} key={i}>
                    <CategoryList data={item} key={i} last={last} index={i} ref={this.refCb}  />
                </LazyLoad>
                
            )
        })
        return list
    }
    
    /**
     * [获取分类列表项目]
     * @return {[type]} [description]
     */
    getCateList = () => {
        var arr = this.state.catList
        
        if(!Util.isArray(arr)) return
        

        var list = arr.map( (item, i) => {
            let last = false;
            if(i == (arr.length - 1)) last = true
                // onClick={this.selCat(item.catId, item.title)}
            let map_str = '#map' + i
            let cls = i == this.state.catId ? 'active' : ''
            return (
                //onClick={this.RedirectCate.bind(this, item.catId, item.title)}
               //<li key={i} className={cls} onClick={this.selCat.bind(this,item.catId, item.title)} ><a href={map_str} >{item.title}</a></li>
            <li key={i} className={cls} onClick={this.selCat.bind(this,i, item.title)} >{item.title}</li>

            )
        })
        return list
    }
    
    /**
     * [selCat 选择一级分类]
     * @return {[type]} [description]
     */
    selCat(catId) {
        // if(catId==0) {
        //     window.scrollTo(0,0)
        // }else {
        //     window.scrollTo(0,newArr[catId])
        // }
        window.scrollTo(0,topArr[catId])
        // alert("12")
        this.setState({
            catId:catId,
            // catName,
            // activeCate: catId
        })
    }
    
  
    

    render() {
        return (
            <div className="m-cate-list">
                <div className="left">
                    <ul>{this.getCateList()}</ul>

                </div>
                <div className="m-list-flex">
                    {this.genItem()}
                </div>
                <CartAndMenu cartNum={this.state.cartNum}></CartAndMenu>
                 <Notification
                                enter={this.state.enter}
                                leave={this.leave.bind(this)}
                            >
                                {this.state.message}
                </Notification>
            </div>
        )
    }
}