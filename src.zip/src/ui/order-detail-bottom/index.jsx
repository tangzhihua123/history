import React from 'react'
import './index.scss'

// 状态对应按钮
// 未支付： 联系客服、取消订单、去支付
// 配货中： 联系客服、取消订单
// 配送中： 联系客服、取消订单
// 已完成： 联系客服、评价
// 已取消： 联系客服
// 已关闭： 联系客服

// 或者说 组件只管展示

export default function OrderBottom(props) {
  const status = props.status || '' //状态
  const btns = props.btns
  const onClick = props.onClick || function() {}
  let bottom = []
  const icon = <i className="service"></i>
  
  // const iconBtn = <div className="btn btn-icon" key="icon">{icon}</div>// 联系客服 单icon
  // const contact = <div className="btn btn-primary" key="contact">{icon} <span className="text">联系客服</span></div> // 带icon配字的联系客服
 
  // const text = <div className="btn btn-primary" key="text"><span className="text">联系客服</span></div> 
 
  // const cancel = <div className="btn btn-black" key="2"><span className="text">撤销申请</span></div>
  btns && btns.map((item, index)=>{
    if (item.type === 'icon') {
      bottom.push(
        <div className="btn btn-icon" onClick={()=> {onClick(item.action)}}  key={index}>{icon}</div>
      )
    } else if (item.type === 'text') {
      bottom.push(
        <div className="btn btn-primary" onClick={()=> {onClick(item.action)}}  key={index}><span className="text">联系客服</span></div> 
      )
    } else if(item.type === 'black') {
      bottom.push(
        <div className="btn btn-black" onClick={()=> {onClick(item.action)}}  key={index}><span className="text">{item.text}</span></div>
      )
    } else if(item.type === 'icon_text') {
      bottom.push(
        <div className="btn btn-primary" key="contact"onClick={()=> {onClick(item.action)}}  key={index} >{icon} <span className="text pl10">{item.text}</span></div> 
      )
    }
  })
  return (
    <div className="order-detail-bottom">
      {bottom}
    </div>
  )
}