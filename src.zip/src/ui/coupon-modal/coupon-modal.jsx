import React, {Component} from 'react'
import Util from 'utils/util.js'
import store from 'store'
import Request from 'utils/request-util.js'
import PropTypes from 'prop-types'
import Coupon from 'ui/coupon/coupon-receive.jsx'
import ModalChildren from 'components/modal/modal-children.jsx'
import Line from './line-three.png'
import Close from './close-coupon-modal@2x.png'
import './coupon-modal.scss'

export default class CouponModal extends Component {
    constructor(props) {
        super(props)
        this.state = {
            isUsed: false,
            isShow: this.props.isShow,
            data: this.props.data,
        }
    }
    componentWillReceiveProps(nextProps) {
        this.setState({
            isShow: nextProps.isShow,
            data: nextProps.data,
        })
    }
    receiveCoupon = (id) => () => {

        if(this.props.noLogin) {
            Util.gotoLogin()
            return
        }
        
        let data = this.state.data,
            newData = [],
            param = {
                data: {
                    couponId: id,
                },
                url: '/user/getCoupon',
                successFn: (data) => {
                    if(data.resultCode !== 2000) {
                        if(data.resultCode === 9104) {
                            this.props.modalInfo && this.props.modalInfo('优惠券已领完')
                            return
                        }
                        this.props.modalInfo && this.props.modalInfo('领取优惠券失败，请重新再试')
                        return
                    }
                    if(Util.isArray(this.state.data)) {
                        newData = this.state.data.map(function(item, i) {
                            if(item.couponId === id) {
                                item.status = 2
                            }
                            return item
                        })
                        this.setState({
                            data: newData
                        })
                    }
                    
                },
                errorFn: () => {
                    this.props.modalInfo && this.props.modalInfo('领取优惠券失败，请重新再试')
                }
            }
        Request.fetch(param)
        
        
    }


    genCoupons = () => {

        if(this.state.data && Object.prototype.toString.call(this.state.data)==="[object Array]") {
            
            let coupons = [],
                _this = this
            coupons = this.state.data.map(function(item, i) {
                return <Coupon data={item} key={i} handleClick={_this.receiveCoupon(item.couponId)}/>
            })
            return coupons
        }
    }

    render() {

        return (
            <ModalChildren 
            isShow={this.state.isShow}
            clickBgHide={true}
            canScroll={false}
            scrollChild=".coupon-modal-list"
            hideFn={this.props.hideFn}
            >
                <div className="coupon-modal">
                    <div className="coupon-modal-title">
                        <span className="img-1"><img src={Line} alt="" /></span>
                        <span className="title-span">领取优惠券</span>
                        <span className="img-2"><img src={Line} alt="" /></span>
                    </div>
                    <div className="coupon-modal-list">
                        {this.genCoupons()}
                    </div>
                    <div className="coupon-modal-close" onClick={this.props.hideFn}>
                        <img src={Close} alt="" />
                    </div>
                </div>
            </ModalChildren>
        )
    }
}
Coupon.propTypes = {
    isShow: PropTypes.bool,
    data: PropTypes.object
}