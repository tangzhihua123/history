import React from 'react'

import './index.scss'

export default function Loading () {
  return (
    <div className="loading-cont">
      <div className="loading-tips">
          加载中... 请稍后
      </div>
    </div>
  )
}