import React, { Component } from 'react'
import PropTypes from 'prop-types'
import RequestUtil from 'utils/request-util'
import URLUtil from 'utils/url-util'
import ARROW from './Group_Copy_8@3x.png'
import CONCAT from './my_service@3x.png'
import Modal from 'components/modal'

import './index.scss'


export default class MainFloor extends Component { 
    constructor(props) {
        super(props)
    }

    RedirectUrl(t) {
        URLUtil.redirectPage({
            page: 'help-detail',
            options: {
               t
            }
        })
    }

    render() {
        return (
            <div className="invite-intro-wrap">
                <div className="items" onClick={this.RedirectUrl.bind(this, 1)}>支付问题<img src={ARROW} alt="" className="arrow_icon"/></div>
                <div className="items" onClick={this.RedirectUrl.bind(this, 2)}>配送问题<img src={ARROW} alt="" className="arrow_icon"/></div>
                <div className="items" onClick={this.RedirectUrl.bind(this, 3)}>售后问题<img src={ARROW} alt="" className="arrow_icon"/></div>
                <div className="items" onClick={this.RedirectUrl.bind(this, 4)}>常见问题<img src={ARROW} alt="" className="arrow_icon"/></div>
                <div className="concat" ><img src={CONCAT} alt="" className="concat_icon"/><a href="tel:400-632-1827">联系客服</a></div>
            </div>
        )
    }
}