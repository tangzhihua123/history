import React, {Component} from 'react'
import URLUtil from 'utils/url-util'
import Util from 'utils/util.js'
import ModalChildren from 'components/modal/modal-children.jsx'
import Cell from 'components/cell/cell.jsx'
import './goods-detail-cells.scss'


export default class GoodsDes extends Component {
    constructor(props) {
        super(props)
        this.state = {
            data: this.props.data || {}
        }
    }
    componentWillReceiveProps(nextProps) {
        this.setState({
            data: nextProps.data
        })
    }
    clickCell1 =() => {
        this.props.clickCb && this.props.clickCb({el: 'cell1'})
    }
    clickCell2 =() => {
        this.props.clickCb && this.props.clickCb({el: 'cell2'})
    }
    clickCell3 =() => {
        /* this.props.clickCb && this.props.clickCb({el: 'cell3'}) */
        // Util.gotoPage({
        //     page: 'app/addon',
        //     options: {
        //         activityid: this.state.data.pmtId
        //     }
        // })

        URLUtil.redirectPage({
            page: 'app/addon',
            options: {
                activityid: this.state.data.pmtId,
                activityname: this.state.data.activity
            }
        })
    }
    genCouponCell = () => {
        let coupons = this.state.data.coupons
        if(Util.isArray(coupons)) {
            let spans = []
            spans = coupons.map(function(item, i) {
                return (
                    <span className="ticket-span" key={i}>{item.title}</span>
                )
            })
            return (
                <Cell title="领券" onClick={this.clickCell2}>
                    {spans}
                </Cell>
            )
        }
    }
    genActivity = () => {
        let activity = this.state.data.activity
        if(activity) {
            return (
                <Cell title="活动" onClick={this.clickCell3}>
                    <span className="activity-span">{activity}</span>
                </Cell>
            )
        }
    }
    render() {
        return (
            <div className="goods-detail-cells">
                <Cell title="规格数量选择" onClick={this.clickCell1}>
                    <span className="spec-str-span">{this.props.data.specStr}</span>
                </Cell>
                {/* <Cell title="领券" onClick={this.clickCell2}>
                    <span className="ticket-span">满199减100</span>
                    <span className="ticket-span">满99减40</span>
                </Cell> */}
                {this.genCouponCell()}
                {/* <Cell title="活动" onClick={this.clickCell3}>
                    <span className="activity-span">满199减100</span>
                </Cell> */}
                {this.genActivity()}
            </div>
        )
    }
}