import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Modal from 'components/modal'
import './index.scss'
import { Link } from 'react-router-dom';

export default class Cart extends Component {
  constructor(props) {
    super(props)
  }
  onClearInvaildClick = () => {
    const { clearInvaild, cartList } = this.props
    Modal.alert('确定清空所有失效商品吗？', [
      {
        text: '暂不',
        onPress: () => { }
      }, {
        text: '清空',
        onPress: () => {
          clearInvaild(formatCartParams(cartList))
        }
      }
    ])

    function formatCartParams(group) {
      const items = group.items.map((item) => {
        return JSON.stringify({
          "isChecked": 0,
          "count": item.count,
          "goodsId": item.goodsId,
          "productId": item.productId
        })
      })
      return `[${items.join(',')}]`
    }
  }
  renderGroupTitle = (cartList) => {
    // 不是很好
    if (cartList.groupType === 1 && cartList.groupTitle) {
      const addonLink = `/app/addon?activityid=${cartList.groupId}&activityname=${cartList.groupTitle}`
      return (
        <div className="activity">
          <div className="activity-tip">
            <i className="activity-icon"></i>
            <span>{cartList.groupTitle}</span>
          </div>
          <Link to={addonLink}>
            <div className="activity-do">
              <span className="activity-do-text">凑单</span>
              <i className="activity-icon-broadcast"></i>
            </div>
          </Link>
        </div>
      )
    } else if (cartList.groupType === 2) {
      return (
        <div className="activity invalid">
          <div className="activity-tip">
            <span>{cartList.groupTitle}</span>
          </div>
          <div className="activity-do">
            <span className="activity-do-text" onClick={this.onClearInvaildClick}>清除</span>
          </div>
        </div>
      )
    } else {
      return null
    }
  }
  render() {
    const { cartList } = this.props
    return (
      <div>
        {this.renderGroupTitle(cartList)}
        {this.props.children}
      </div>
    )
  }
}

Cart.propTypes = {

};