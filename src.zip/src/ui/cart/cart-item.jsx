import React, { Component } from 'react'
import PropTypes from 'prop-types'
import classnames from 'classnames'
import Toast from 'components/toast'
import './cart-item.scss'
import URLUtil from 'utils/url-util'

// TODO: 待优化DOM结构
export default class CartItem extends Component {
  constructor(props) {
    super(props)
  }
  onDecreaseInfo() {
    if (this.props.item.count < 2) {
      Toast.show('最少购买件数为1', 1.5, false)
    } else {
      this.props.onDecrease()
    }
  }
  onDecreaseClick = () => {
    this.onDecreaseInfo()
  }
  onIncreaseClick = () => {
    if (this.props.item.storeCount <= 99) {
      if (this.props.item.count === this.props.item.storeCount) {
        Toast.show('超过最大购买件数', 1.5, false)
        return
      }
    } else {
      if (this.props.item.count === 99) {
        Toast.show('最多购买件数为99', 1.5, false)
        return
      }
    }
    this.props.onIncrease()
  }

  goInfoPage(id) {
      URLUtil.redirectPage({
          page: 'app/goodsdetail',
          options: {
              id,
              goodsSource: 17,
              sourceId: 0
          }
      })

  }
  render() {
    const { item, onCheckClick, type } = this.props
    const itemImgStyle = {
      'backgroundImage': `url(${item.imgLink})`
    }

    const checkboxClass = classnames({
      'select-area': true,
      'selected': item.isChecked,
      'unselected': !item.isChecked,
    })

    const statusTips = classnames({
      'select-area': true,
      'gift': item.gift,
      'invalid': type === 2
    })

    const contStyle = classnames({
      'cart-item-cont': true,
      'invaild': type === 2,
      'gift': item.gift
    })

    return (
      <div className="cart-item" key={item.goodsId}>
        <div className={contStyle}>
          {
            (item.gift || type === 2) ?
              <div className={statusTips}></div> :
              <div className={checkboxClass} onClick={onCheckClick}></div>
          }
          <div className="img-cont" onClick={this.goInfoPage.bind(this, item.goodsId)} style={itemImgStyle}></div>
          <div className="item-detail">
            <p className="item-title">{item.goodsName}</p>
            <p className="item-price">¥{item.goodsPrice}</p>
            <div className="item-unit">{item.subTitle}</div>
            {
              (item.gift || type === 2) ? <div className="item-num-operator">
                <span className="number">x{item.count}</span>
              </div> :
                <div className="item-num-operator">
                  <span className="reduce btn-operator" onClick={this.onDecreaseClick}></span>
                  <span className="number">{item.count}</span>
                  <span className="plus btn-operator" onClick={this.onIncreaseClick}></span>
                  {
                    item.storeCount < 6 ? <span className="stock">仅剩{item.storeCount}件</span> : null
                  }
                </div>
            }

          </div>
        </div>
        {
          type === 2 ? <div className="invalid-mask"> </div> : null
        }
      </div>
    )
  }
}

CartItem.propTypes = {
  // onDecrease: propTypes.
};