import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import './cart-null.scss'
import URLUtil from 'utils/url-util'

import img from './img/no_shopping@2x.png'
export default class CartNull extends Component {
    constructor(props) {
        super(props)
    }
    RedirectToCart() {
        URLUtil.redirectPage({
            page: 'home',
            options: {}
        })
    }
    render() {
        return (
            <div className="cart-null">
              <div className="cart-null-cont">
                <div className="">
                  <img className="cart-null-img" src={img}/>
                </div>
                <p className="cart-null-tips">您的购物车还没有商品</p>
                {/*<Link to="../home/">*/}
                  <div className="btn-go-shoppping" onClick={this.RedirectToCart.bind(this)}>去逛逛</div>
                {/*</Link>*/}
              </div>
            </div>
        )
    }
}
