import React, { Component } from 'react'
import PropTypes from 'prop-types'
import './goods-des.scss'

export default class GoodsDes extends Component {
    constructor(props) {
        super(props)
        this.state = {
            // isPreSold: false,
            data: this.props.data || {},
            // deadline: this.props.deadline
        }
        if (this.state.data.saleMode && this.state.data.downShelfTime > (+new Date())) {
            var a = this.getTime(this.state.data.downShelfTime)
            this.state = {
                d: a[0],
                h: a[1],
                m: a[2],
                s: a[3],
            }
        }
    }
    componentDidMount() {

    }
    componentWillUnmount() {
        console.log('清理时候的interval', this.state.interval)
        console.log('state.interval', this.state)
        clearInterval(this.state.interval)
    }
    componentWillReceiveProps(nextProps) {
        this.setState({
            // isPreSold: nextProps.isPreSold,
            data: {
                ...nextProps.data,
                downShelfTime: +new Date(nextProps.data.downShelfTime),
                // saleMode: 1
            }
        }, () => {
            if(!this.state.interval) {
                this.initTime()
            }
        })
    }
    genPreDiv = () => {
        if (!this.state.data.downShelfTime) {
            return
        }
        if (this.state.data.saleMode) {
            var deadline = this.state.data.downShelfTime,
                now = +new Date(),
                isEnd = false
            if (now >= deadline) {
                isEnd = true
                return (
                    <div className="pre-sold end">
                        <span>预售活动结束</span>
                    </div>
                )
            } else {
                return (
                    <div className="pre-sold">
                        <span className="text">正在预售，距预售截止</span>
                        <div>
                            <span className="time-span">{this.state.d}</span>
                            <span className="del-span">:</span>
                            <span className="time-span">{this.state.h}</span>
                            <span className="del-span">:</span>
                            <span className="time-span">{this.state.m}</span>
                            <span className="del-span">:</span>
                            <span className="time-span">{this.state.s}</span>
                        </div>
                    </div>
                )
            }

        }
    }
    initTime = () => {
        var _this = this
        let time = _this.state.data.downShelfTime
        if (this.state.data.saleMode) {
            if (this.state.data.downShelfTime > (+new Date)) {
                var a
                let interval = setInterval(function () {
                    a = _this.getTime(time)
                    _this.setState({
                        d: a[0],
                        h: a[1],
                        m: a[2],
                        s: a[3]
                    })
                }, 1000)
                this.setState({
                    interval: interval
                },() => {
                    console.log('设置时候的interval', interval)
                })
            }


        }
    }
    format = (num) => {
        if (num.toString().length === 1) {
            return '0' + num
        } else {
            return num
        }
    }
    getTime = (time) => {
        var djs = time / 1000
        var b = Math.round(new Date().getTime() / 1000)
        var cc = djs - b
        var d = Math.floor(cc / (3600 * 24))
        var h = Math.floor((cc - d * 3600 * 24) / 3600)
        var m = Math.floor(((cc - d * 3600 * 24 - h * 3600)) / 60)
        var s = Math.floor(cc - d * 3600 * 24 - h * 3600 - m * 60)
        return [this.format(d),
        this.format(h),
        this.format(m),
        this.format(s)]
    }
    genMemos = () => {
        let memo = this.state.data.memo
        if (!memo) return
        let memoArr = memo.split('|'),
            memoSpan = []
        memoSpan = memoArr.map(function (item, i) {
            return (<span key={i}>{item}</span>)
        })
        return memoSpan
    }
    render() {
        return (
            <div className="goods-des-div">
                {this.genPreDiv()}
                <div className="goods-des-tags">
                    {this.genMemos()}
                </div>
                <div className="goods-name">{this.state.data.title}</div>
                <div className="goods-des">{this.state.data.subTitle}</div>
                <div className="goods-price-div">
                    <div className="goods-price__now">
                        <span className="rmb">¥</span>
                        <span className="price">{this.state.data.skuPrice || this.state.data.price}</span>
                        {/* <span className="goods-unit">/{this.state.data.unit}</span> */}
                    </div>
                    {/* <div className="goods-price__old">
                        <span>¥{this.state.data.marketPrice}</span>
                    </div> */}
                </div>
                <div className="send-time">
                    {this.state.data.arrivalTime}
                </div>
            </div>
        )
    }
}
GoodsDes.PropTypes = {
    data: PropTypes.object, // 基本信息
}