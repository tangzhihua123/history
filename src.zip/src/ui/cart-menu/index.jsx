import React, { Component } from 'react'
import PropTypes from 'prop-types'
import {
    Link
} from 'react-router-dom'
import Barcode from 'react-barcode'
import store from 'store'
import Util from 'utils/util'
import URLUtil from 'utils/url-util'
import RequestUtil from 'utils/request-util'
import CART from 'assets/home_Shopping cart@3x.png'
import HomeMenu from 'assets/home_unfold@3x.png'
import SHAOMA  from 'assets/home_Bar code@3x.png'
import USERCENTER from 'assets/home_mine@3x.png'
import CLOSE from 'assets/home_close@3x.png'
import './index.scss'

import USER_CENTER_LOGO from 'assets/center_logo.png'
import USER_DIALOG_CLOSE from 'assets/close.png'

export default class CartAndMenu extends Component {
    constructor(props) {
        super(props)
        this.state = {
            cartNum: this.props.cartNum,
            isShowCart: this.props.isShowCart,
            showMenu: false,
            modalVisiable: false,
            memberCode: '111111111111111',
        }
    }

   

    componentWillReceiveProps(nextProps) {
        this.setState({
            cartNum: nextProps.cartNum,
            isShowCart: nextProps.isShowCart,
        })
    }

    RedirectToCart() {
        URLUtil.redirectPage({
            page: 'app/mycart',
            options: {}
        })
    }

    RedirectToUserCenter() {
        URLUtil.redirectPage({
            page: 'app/i',
            options: {}
        })
    }

    expandMenu(t) {
        if(t == 1) {
            this.setState({
                showMenu: true,
            })
        }else {
            this.setState({
                showMenu: false,
            })
        }
       
    }

    /**
     * [获取购物车数量]
     * @return {[type]} [description]
     */
    fetchCartNumMenu = () => {
        RequestUtil.fetchCartNum({
            noLogin: (num) => {
                this.setState({
                    cartNum: num
                })
            },
            Login: (num) => {
                this.setState({
                    cartNum: num
                })
            },
            ErrorFun: (msg) => {
                this.enter(msg)
            }
        })
    }
    refreshMemberCode() {
        let param = {
            data: {
                memberCode: this.state.memberCode
            },
            url: '/user/refreshMemberCode',
            successFn: (data) => {
                if(data.resultCode == 2000) {
                    this.setState({
                        memberCode: data.data.memberCode
                    })
                }else if(data.resultCode == 5000) {
                    alert("网络异常，请稍后再试")
                }else if(data.resultCode == 4005) {
                    URLUtil.redirectPage({
                        page: 'app/login',
                        options: {
                            redirect: "/" + window.location.href.split('/')[3]
                        }
                    })
                }

               
            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }
        RequestUtil.fetch(param)    
    }

    ShowModal() {
        const user = store.get('user') || {}
        if(JSON.stringify(user) != "{}") {//如果是登陆状态才显示
            this.setState({
                modalVisiable: true,
            }, () => {
                this.refreshMemberCode()
            })
        }else{
            this.refreshMemberCode()
        }

    }
    onMemberCodeCloseClick () {
         this.setState({
            modalVisiable: false,
        })
    }


    render() {
        return (
           
            <div className="cart-menu-container">
                {
                    !Util.isCustomAgent() ? (
                        <div>
                            {
                                this.state.isShowCart == false ? "" :  
                                <div className="cart-wrap" >
                                    <img src={CART} alt="购物车" onClick={this.RedirectToCart.bind(this)} className='icon-cart'/>
                                    {this.state.cartNum == 0 ? '' : <span className="cart-num">{ this.state.cartNum > 99 ? '99+' : this.state.cartNum }</span>}
                                </div>
                            }
                            {
                                this.state.showMenu == false ? 
                                    <div className="home-menu" onClick={this.expandMenu.bind(this,1)}>
                                        <img src={HomeMenu} alt="菜单" className="icon-home-menu"/>
                                    </div>: null
                            }

                           
                            {
                                this.state.showMenu ?  <div className="home-menu-expand">
                                    <img src={SHAOMA} alt="" onClick={this.ShowModal.bind(this)}/>
                                    <img src={USERCENTER} alt="" onClick={this.RedirectToUserCenter.bind(this,2)} />
                                    {this.state.isShowCart == false ? 
                                        <div className="cart-wrap-inner" >
                                            <img src={CART} alt="" onClick={this.RedirectToCart.bind(this)}/>
                                            {this.state.cartNum == 0 ? '' : <span className="cart-num">{ this.state.cartNum > 99 ? '99+' : this.state.cartNum }</span>}
                                        </div> : null 
                                        
                                    }
                                    <img src={CLOSE} alt="" onClick={this.expandMenu.bind(this,2)}/>
                                </div> : null
                            }

                            { this.state.modalVisiable ? 
                                <div className="membercode-modal">
                                    <div className="member-code-warpper">
                                        <div className="member-code">
                                            <div className="member-code-tips">
                                                <p className="main-tip">会员专属码</p>
                                                <p className="sub-tip">门店结账时出示,自动享受会员价并获取积分</p>
                                            </div>
                                            <div className="barcode-warpper" onClick={()=> this.refreshMemberCode(this.state.memberCode)}>
                                                <Barcode className="barcode"
                                                  value={this.state.memberCode} 
                                                  fontSize={13}
                                                  textMargin={8}
                                                  marginLeft={24}
                                                  marginTop={32}
                                                  marginBottom={24}
                                                  ></Barcode>
                                            </div>
                                            <div className="">
                                                <img className="logo" src={USER_CENTER_LOGO}></img>
                                            </div>
                                        </div>
                                        <div className="tips-bottom">
                                            <img className="icon-close" src={USER_DIALOG_CLOSE} onClick={this.onMemberCodeCloseClick.bind(this)}></img>
                                        </div>
                                    </div>
                                </div> : ''
                            }  
                            </div> 
                    ): <div></div>
                }
               
            </div>
        )
    }
}

CartAndMenu.PropTypes = {
   
}