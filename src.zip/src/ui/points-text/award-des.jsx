import React from 'react'

import './points-des.scss'

export default class PointsDes extends React.Component {
    constructor(props) {
        super(props)
    }
    componentDidMount() {
        document.title = '规则说明'
    }
    render() {
        return (
            <div className="points-des-container">
                <div className="title">·活动形式</div>
                <div className="para">1、关于积分消费</div>
                <div className="para">2、 每次抽奖需要扣除 10 个四季严选积分,扣除的积分不退还,每天参与抽奖次数不限。</div>
                <div className="title">·关于奖品</div>
                <div className="para">1、本活动奖品分为:购物券类奖品和四季严选积分奖品,每天奖品数量超过 500 份。 2.1 礼券奖品</div>
                <div className="para">2、 四季严选购物券是四季严选平台丏属购物券,获得四季严选购物券的用户可以四 季严选 APP 购物消费时凭券享受折扣让利。</div>
                <div className="para">3、四季严选购物券存在不同优惠类型,具体以实际发放购物券券面说明为准。 2.1.3 在四季严选 APP 购物时,点击购买后,页面会提示可供使用的四季严选购物券, 只要选择该四季严选购物券即可按面额或可抵扣金额进行抵扣。使用时仅可用于抵扣商 品金额,不能抵扣运费、增值服务等非商品金额。</div>
                <div className="para">4、 购物券不得提现,不得转赠他人,不得为他人付,不得拆分使用。</div>
                <div className="para">5、同一个订单只能使用一张四季严选购物券。</div>
                <div className="para">6、四季严选购物券自领取之日起 30 天内有效(部分活动券可能存在不同有效期, 具体以实际发放购物券券面说明为准。)</div>
                <div className="para">7、使用四季严选购物券的订单若交易未成功或发生退款及售后时,所使用的购物券 则不再补发;</div>
                <div className="para">8、四季严选积分奖品</div>
                <div className="para">9、四季严选积分奖品可设置为 8、58、88 和 188 个四季严选积分奖品等。(具体以实际当期活动设置为准)</div>
                <div className="para">10、四季严选积分直接发放到中奖用户的积分账户。</div>
            </div>
        )
    }
}