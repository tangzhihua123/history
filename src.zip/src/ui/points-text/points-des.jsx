import React from 'react'

import './award-des.scss' 

export default class AwardDes extends React.Component {
    constructor(props) {
        super(props)
    }
    componentDidMount() {
        document.title = '积分说明'
    }
    render() {
        return (
            <div className="award-des-container">
                <div className="title">·什么是四季严选会员积分</div>
                <div className="para">四季严选积分是会员通过 APP 完成结账消费,或者在四季严选 APP 完成指定行为给予的专属福利,仅限四季严选平台使用。</div>
                <div className="title">·如何获取四季严选积分</div>
                <div className="para">四季严选积分有以下几种获得方式</div>
                <div className="para title2">1、购物奖励积分</div>
                <div className="para">交易成功后,获得实付金额 1:1 的奖励积分,如遇小数点,则往前进一位(如用户 消费 39.9 元,则返还用户 39 积分);</div>
                <div className="para title2">2、完善信息奖励积分 </div>
                <div className="para">用户完成会员注册后,完善个人信      息,即可获得相应奖励积分; </div>
                <div className="para title2">3、评价奖励积分</div>
                <div className="para">使用评价功能对商品进行评价,每个商品评价成功后可以获得评价奖励积分; </div>
                <div className="para title2">4、分享奖励积分</div>
                <div className="para">用户分享四季严选 APP 中的商品、活动等指定页面,即可获得相应的奖励积分;</div>
                <div className="title">·积分有效期</div>
                <div className="para">自获取之日起长期有效。</div>
                <div className="title">·商品退换货</div>
                <div className="para">1、如买家发起全额退款/退货操作,对应订单返还买家的积分数量会相应的扣除;如买家发起部分商品的退款/退货操作,退货部分对应的积分数量会进行扣除处理(如返 还用户 39.9 元,则扣除用户 39 积分);如果用户的积分账户剩余积分数量不足以 扣除,则自商品退款金额中扣除相应的等值现金;</div>
                <div className="para">2、如买家发起全额退款/退货操作,买家支付订单时使用的积分也会返还到对应的账户中;如买家发起部分商品的退款/退货操作,则按退款商品所占交易金额比例返还积分。</div>
                <div className="para">*对于任何非法途径获得积分,四季严选有权对其进行处理,并保留最终解释权</div>
            </div>
        )
    }
}