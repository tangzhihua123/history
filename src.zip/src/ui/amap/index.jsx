import React ,{ Component } from 'react'
import { Map } from 'react-amap'
import Geolocation from 'react-amap-plugin-geolocation';

import Icon from 'components/Icon'

import './index.scss'

export default class Amap extends Component {
  constructor() {
    super()
    this.state = {
      current: {},
      searchResult: []
    }
    this.amapEvents = {
      created: (mapInstance) => {
        this.amapInstance = mapInstance
        this.initPlaceSearch(this.amapInstance)
      }
    }
  }
  initPlaceSearch=(map) => {
    AMap.service('AMap.PlaceSearch', () => {//回调函数
      this.placeSearch = new AMap.PlaceSearch({ //构造地点查询类
        pageSize: 10,
        pageIndex: 1,
        type: '生活服务|商务住宅|政府机构及社会团体|公司企业|地名地址信息|公共设施',
        // city: "0579", //城市
        map
      })
    })
  }
  searchPlace=(e) => {
    const value = e.currentTarget.value
    this.placeSearch.search(value, (status, result) => {
      if (result.info === 'OK') {
        this.setState({
          searchResult: result.poiList && result.poiList.pois
        })
      }
    })
  }
  onGeoComplete=(e)=> {
    if (e.info === 'SUCCESS' && e.addressComponent) {
      const addcom = e.addressComponent
      this.setState({
        current: {
          detailAddress: e.formattedAddress,
          position: e.position,
          addressComponent: addcom,
          address: addcom.province + addcom.city + addcom.district + addcom.township + addcom.street +  addcom.streetNumber
        }
      })
      if (e.position.lng && e.position.lat) {
        this.amapInstance.setZoomAndCenter(16, [e.position.lng, e.position.lat])
      }
      if (e.position.lng && e.position.lat && this.placeSearch) {
        this.placeSearch.setCity(e.addressComponent.citycode)
        this.placeSearch.searchNearBy('', [e.position.lng, e.position.lat], 200, (status, result) => {
          if (result.info === 'OK') {
            this.setState({
              searchResult: result.poiList && result.poiList.pois
            })
          }
        })
      }
    }
  }
  onGeoError(e) {
    console.log(e)
    alert('定位失败')
  }
  onItemClick=(type, item) => {
    const { selectedCb } = this.props
    const obj = {}
    if (type === 'current') {
      const ac = item.addressComponent
      obj.adcode = ac.adcode
      obj.province = ac.province
      obj.city = ac.city
      obj.citycode = ac.citycode
      obj.adname = ac.district
      obj.street = ac.street + ac.streetNumber
      obj.address = item.address
      obj.detailAddress = item.detailAddress
      obj.name = ac.neighborhood
      obj.lat = item.position.lat
      obj.lng = item.position.lng
    } else if(type === 'result') {
      obj.adcode = item.adcode
      obj.province = item.pname
      obj.city = item.cityname
      obj.citycode = item.citycode
      obj.adname = item.adname
      obj.street = item.address
      obj.address = item.pname + item.cityname + item.adname + item.address
      obj.detailAddress = obj.address + item.name
      obj.name = item.name
      obj.lat = item.location.lat
      obj.lng = item.location.lng
    }
    selectedCb && selectedCb(obj)
  }
  render() {
    const { returnCb } = this.props
    const pluginProps = {
      enableHighAccuracy: true,
      timeout: 10000,
      showButton: true,
      events: {
        created: (geolocation) => {
          // console.log(geolocation)
          AMap.event.addListener(geolocation, 'complete', this.onGeoComplete)
          AMap.event.addListener(geolocation, 'error', this.onGeoError)
        }
      }
    }
    const plugins = [{
        name: 'ToolBar',
        options: {
          visible: true,  // 不设置该属性默认就是 true
          onCreated(ins) {
            // console.log(ins)
          }
        }
      }
    ]
    return (
      <div className="xg-amap">
        <div className="amap-top">
          <div className="arrow-return"
          onClick={returnCb}
          >
          <Icon type="arrow-left" size="lg"></Icon></div>
          <input className="search-input" placeholder="请输入关键字" id="tipinput" 
            onChange={this.searchPlace}/>
        </div>
        <div className="amap-container">
          <Map 
            plugins={plugins}
            events={this.amapEvents}
            amapkey='46ef813d4667e4c0b2ce5c8a92f7a893'>
            <Geolocation {...pluginProps} />
          </Map>
        </div>
        {
          this.state.current.detailAddress? <div className="cur-location search-result-item"
          onClick={()=> this.onItemClick('current', this.state.current)}
          >
            <div className="search-result-item-cont">
              <div className="cur-loc-left">
                <Icon type="location" size="xs"></Icon>
              </div>
              <div className="cur-short-loc">
                <span className="current-tips">[当前]</span><span> {this.state.current.detailAddress}</span>
              </div>
              <div>
              {this.state.current.address}
              </div>
            </div>
          </div> : null
        }
        <div id="search-result">
            {
              this.state.searchResult.map((item)=> {
                return <div key={item.id} className="search-result-item"
                  onClick={()=> this.onItemClick('result', item)}
                  >
                  <div className="search-result-item-cont">
                    <p className="search-result-title">{item.name}</p>
                    <p className="search-result-detail">
                      { item.pname + item.cityname + item.adname + item.address}
                    </p>
                  </div>
                </div>
              })
            }
        </div>
      </div>
    )
  }
}