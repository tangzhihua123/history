import React, { Component } from 'react'
import PropTypes from 'prop-types'
import './index.scss'

import GoodItem from './good-item'

export default class GoodsList extends Component {
  constructor(props) {
    super(props)
  }
  render() {
    const { list } = this.props
    let itemList = list.map(function (el, index) {
      return <GoodItem key={index} item={el}></GoodItem>
    })
    return (
      <div className="goods-list">
        {itemList}
      </div>
    )
  }
}

GoodsList.propTypes = {

}