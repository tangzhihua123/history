import React from 'react'
import { Link } from 'react-router-dom'
import './good-item.scss'

export default function GoodItem(props) {
  const { item } = props
  return (
    <div className="good-item">
      <Link to={`/app/goodsdetail?goodsId=${item.goodsId}`}>
      <div className="item-img-cont">
        {
          item.status? <span className="activity-label">{item.status}</span> : null
        }
        <img className="main-img" src={item.pictureUrl}/>
      </div>
      <p className="item-title">{item.title}</p>
      <p className="item-desc">{item.subTitle}</p>
      <div className="item-buy">
        <div className="item-price">¥{item.price}</div>
        <div className="add-to-cart"></div>
      </div>
      </Link>
    </div>
  )
}