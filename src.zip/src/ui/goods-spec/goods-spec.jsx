import React, { Component } from 'react'
import {
    BrowserRouter,
    Link,
    Redirect,
    Route
} from 'react-router-dom'
import Util from "utils/util.js"
import PropTypes from 'prop-types'
import SKU from 'utils/SKU.js'
import ModalChildren from 'components/modal/modal-children.jsx'
import Notification from "components/Notification/Notification.jsx";
import Counter from 'components/counter/counter.jsx'
import './goods-spec.scss'
import DesPng from './1.png'
import Close from './spec-close@2x.png'

export default class GoodsSpec extends Component {
    constructor(props) {
        super(props)
        this.state = {
            isShow: this.props.isShow,
            nowKey: [],
            specs: this.props.data.specs,
            totalStore: this.props.data.store,
            store: this.props.data.store,
            nowNum: 1, // 当前商品选择的数量
            data: this.props.data || {},
            skuPrice: this.props.data.price,
            goodsPrice: this.props.data.price,
            specTextDefault: '请选择规格',
            specText: '请选择规格',
            maxSelectNum: 99,
            initKey: false
        }
    }
    setStateNum = 0
    initState = (props, cb) => {
        this.setState({
            isShow: props.isShow,
            nowKey: [],
            specs: props.data.specs,
            totalStore: props.data.store,
            store: props.data.store,
            nowNum: 1, // 当前商品选择的数量
            data: props.data || {},
            skuPrice: props.data.price,
            goodsPrice: props.data.price,
            specTextDefault: '请选择规格',
            specText: '请选择规格',
            maxSelectNum: 99,
            initKey: false
        }, () => {
            cb && cb()
        })
    }

    componentWillReceiveProps(nextProps) {
        // 如果不是同一个商品id，需要初始化state
        if(nextProps.data.goodsId !== this.props.data.goodsId) {
            this.setStateNum = 0
            this.initState(nextProps, () => {
                if (Util.isArray(this.state.data.products)) {
                        this.handleSKU()
                        this.genSpecItems()
                        this.genSpecList()
                }
            })
        } else {
            this.setState({
                data: nextProps.data,
                isShow: nextProps.isShow,
                totalStore: nextProps.data.store,
                goodsPrice: nextProps.data.price,
                type: nextProps.type,
            }, () => {
                if (Util.isArray(this.state.data.products)) {
                        this.handleSKU()
                        this.genSpecItems()
                        this.genSpecList()
                }
            })
        } 
        
    }
    /* shouldComponentUpdate(nextProps, nextState) {
        if(!nextProps.isShow && !this.props.isShow) {
            return false
        } else {
            return true
        }
    } */
    genSpecItems = () => {
        // 按照规格，把商品分到不同的数组中
        let specs = this.state.data.specs,
            specDesc = this.state.data.specDesc,
            specsObj = {}

        if (!Util.isArray(specs)) {
            return
        }
        specs.forEach(function (item) {
            specsObj[item.keyId] = {
                values: item.values,
                children: {
                }
            }

        })
        specDesc.forEach(function (item) {
            specsObj[item.specId].children[item.specValueId] = item
        })
        this.setState({
            specsObj: specsObj
        }, () => {
            this.setStateNum += 1
            if(this.setStateNum === 2) {
                
                this.initNowKeys()
            }
            
        })
        // console.log('specsObj',specsObj)
    }
    handleSKU = () => {
        let skuObj = {},
            skuList = this.state.data.products,
            newSkuList = [],
            singleItem

        if (!Util.isArray(skuList)) {
            return
        }
        newSkuList = skuList.map(function (item, i) {

            return {
                key: item.pdtDesc.split(',').sort().join(','),
                value: {
                    store: item.store,
                    price: item.price,
                    productId: item.productId
                }
            }
        })

        skuObj = SKU.allSkuValue(newSkuList, 'store')
        this.setState({
            skuStoreObj: skuObj
        }, () => {
            

            this.setStateNum += 1
           if(this.setStateNum === 2) {
                this.initNowKeys()
            }
            
        })

    }
    addSkuFn = () => {
        let {
            nowKey,
            data: { specs }
        } = this.state
        if (nowKey.length !== specs.length) {
            this.enter('请先选择规格')
            return false
        } else {
            return true
        }

    }

    // 首次打开页面时，选中sku的第一个可选值
    initNowKeys = () => {
        let {
            specsObj,
            skuStoreObj,
            totalStore: store,
        } = this.state,
        
            specKeys = Object.keys(specsObj).sort(),
            l = specKeys.length,
            children,
            specKeyArr = [],
            nowSpecIndex,

            // specsArr：二维数组
            specsArr = new Array(l)

        specsArr.fill(new Array())

        if (!store) {
            return
        }
        let tempChildrenArr
        for (var i = 0; i < l; i++) {
            children = specsObj[specKeys[i]].children
            tempChildrenArr = []
            for (var ci in children) {
                tempChildrenArr.push(children[ci])
            }
            tempChildrenArr.sort(function (a, b) {
                return a.specValue > b.specValue
            })
            specsArr[i] = tempChildrenArr
        }
        // 遍历，看是否有库存
        let tempSpecKeyArr

        for (var j = 0; j < l; j++) {

            for (var k = 0, kl = specsArr[j].length; k < kl; k++) {
                tempSpecKeyArr = specKeyArr.concat(specsArr[j][k].specValue).sort()
                if (skuStoreObj[tempSpecKeyArr.join(',')].store) {
                    specKeyArr = tempSpecKeyArr

                    break;
                }
            }

        }
        let specText = specKeyArr.join(','),
            price = skuStoreObj[specText].price,
            
            productId = skuStoreObj[specText].productId
            // console.log('price', price, skuStoreObj, specText)
        this.setState({
            nowKey: specKeyArr,
            store: skuStoreObj[specText].store,
            specText: specText,
            skuPrice: price,
            productId: productId
        }, () => {
            // console.log(this.state,)
            this.props.initSubmit && this.props.initSubmit({
                init: true,
                key: this.state.nowKey
            })
        })



    }
    handleSKUClick = (contentText) => (e) => {
        // 先求出点击的元素的一级规格的id，以便去除同级的子规格id
        let nowSpecId, cla
        let target = e.target
        while (target.className.indexOf('goods-spec-div') === -1) {
            target = target.parentNode
        }
        cla = target.className
        nowSpecId = cla.match(/specId([\d]+)/)[1]

        let brother = this.state.specsObj[nowSpecId].children

        let nowKey = this.state.nowKey,
            specText,
            productId
        let same = false
        // 同一个元素，去掉当前，同级元素，去掉同级，选中当前
        if (nowKey.indexOf(e.target.innerHTML) !== -1) {
            nowKey.splice(nowKey.indexOf(e.target.innerHTML), 1)
        } else {
            for (var k in brother) {
                let i = nowKey.indexOf(brother[k].specValue)

                if (i !== -1) {
                    nowKey.splice(i, 1)
                    break
                }
            }

            nowKey.push(contentText)
            nowKey.sort()
        }
        let store,
            price,
            equal
        if (nowKey.length === 0) {

            store = this.state.totalStore
            // console.log('totalStore', store, this.state.data)
        } else {
            store = this.state.skuStoreObj[nowKey.join(',')].store
        }
        if (nowKey.length === this.state.data.specs.length) {

            specText = nowKey.join(',')
            price = this.state.skuStoreObj[specText].price
            productId = this.state.skuStoreObj[specText].productId
            equal = true
        } else {
            price = this.state.goodsPrice
            specText = this.state.specTextDefault
            productId = false
            equal = false
        }


        this.setState({
            nowKey: nowKey,
            nowNum: 1,
            store: store,
            skuPrice: price,
            specText: specText,
            productId: productId
        }, () => {
            if(equal) {
                this.props.initSubmit && this.props.initSubmit({
                    init: true,
                    key: this.state.nowKey,
                    price: price
                })
            }
        })

    }
    genSpecList = () => {
        // <div className="goods-spec-div">
        //     <div className="goods-spec-title">{item.values}</div>
        //     <div className="goods-spec-span-list">
        //         <span className="spec-span select">300g/袋</span>
        //         <span className="spec-span">500g/袋</span>
        //         <span className="spec-span disable">1000g/袋</span>
        //     </div>
        // </div>
        if (!(this.state.specsObj)) {
            return
        }
        let specKeys = Object.keys(this.state.specsObj).sort(),
            specsObj = this.state.specsObj

        let divs = [],
            divDes,
            childArr,
            subKeys,
            specKey,
            subChild,
            contentText,
            nowKey = this.state.nowKey,
            tempKeys,
            selectKeys = [].concat(nowKey),
            diffArr = [].concat(nowKey),// 去掉同一级规格的数组
            brother = false,
            childArrSort = []

        for (var i = 0, l = specKeys.length; i < l; i++) {
            // 初始化同级规格
            brother = false

            diffArr = [].concat(nowKey)
            childArrSort = []
            let spans = []
            specKey = specKeys[i]
            childArr = specsObj[specKey].children


            for (var broKey in childArr) {
                childArrSort.push(childArr[broKey])
                if (diffArr.indexOf(childArr[broKey].specValue) !== -1) {
                    diffArr.splice(diffArr.indexOf(childArr[broKey].specValue), 1)
                    brother = true

                }
            }
            childArrSort.sort(function (a, b) {
                return a.specValue > b.specValue
            })

            subKeys = Object.keys(childArr).sort()
            for (var j = 0, m = childArrSort.length; j < m; j++) {
                let nowArr
                subChild = childArrSort[j]
                contentText = subChild.specValue

                if (brother) {
                    nowArr = diffArr

                } else {
                    nowArr = selectKeys
                }

                // 先标记选中的颜色
                if (selectKeys.indexOf(contentText) !== -1) {
                    spans.push(<span className="spec-span select" onClick={this.handleSKUClick(contentText)} key={j} >{contentText}</span>)
                } else {
                    // 再标记有无库存
                    tempKeys = [].concat(nowArr).concat(contentText).sort().join(',')
                    if (!this.state.skuStoreObj[tempKeys].store) { // 标记不可选
                        spans.push(<span className="spec-span disable" key={j} >{contentText}</span>)
                    } else {
                        spans.push(<span className="spec-span" onClick={this.handleSKUClick(contentText)} key={j} >{contentText}</span>)
                    }

                }

            }
            divDes = (
                <div key={i} className={"goods-spec-div specId" + specKey}>
                    <div className={"goods-spec-title"}>{specsObj[specKey].values}</div>
                    <div className="goods-spec-span-list">
                        {spans}
                    </div>
                </div>
            )
            divs.push(
                divDes
            )
        }
        return divs
    }

    hideFn = () => {
        /* this.setState({
            nowKey: []
        }) */

        this.props.hideFn && this.props.hideFn()
    }

    skuSubmit = () => {

        if (this.state.nowKey.length !== this.state.data.specs.length) {
            this.enter('请先选择规格')
            return
        }
        if (!this.state.nowNum) {
            this.enter('请选择商品数量')
            return
        }
        this.props.submitFn && this.props.submitFn({
            key: this.state.nowKey,
            num: this.state.nowNum,
            productId: this.state.productId,
            store: this.state.store,
            price: this.state.skuPrice
        })
        this.hideFn()
    }
    enter(message) {
        this.setState({
            enter: true,
            message: message,
        });
        setTimeout(
            function () {
                this.leave();
            }.bind(this),
            2000
        );
    }

    leave() {
        this.setState({
            enter: false,
            message: "",
        });
    }
    counterCb = (num) => {
        this.setState({
            nowNum: num
        })
    }
    render() {
        return (
            <ModalChildren isShow={this.state.isShow}
                hideFn={this.hideFn}
                clickBgHide={true}
                canScroll={false}
                scrollChild=".goods-spec-list"
            >
                <Notification
                    enter={this.state.enter}
                    leave={this.leave.bind(this)}
                >
                    {this.state.message}
                </Notification>
                <div className="goods-spec-container">
                    <div className="goods-spec-basic">
                        <img src={this.props.data.picUrl} alt="" />
                        <div className="goods-spec-price">
                            <span className="fs-14">¥</span>
                            <span className="price">{this.state.skuPrice}</span>
                            <span className="unit"></span>
                        </div>
                        <div className="tips">{this.state.specText}</div>
                    </div>
                    <div className="goods-spec-list">
                        {this.genSpecList()}
                    </div>
                    <div className="goods-spec-num-select">
                        <div className="num-text">数量：</div>
                        {/* <div className="rest">剩余{this.state.store}</div> */}
                        <Counter currentValue={this.state.nowNum} cb={this.counterCb} tips="超出当前可购买最大数"
                            addFn={this.addSkuFn}
                            minValue={1}
                            maxValue={this.state.store > this.state.maxSelectNum ? this.state.maxSelectNum : this.state.store}
                        />
                    </div>
                    {
                        this.state.type === 'buy' ?
                            <Link to="/app/mycart" onClick={this.skuSubmit}>
                                <div className="goods-spec-submit" >
                                    选好了
                            </div>
                            </Link> :
                            <div className="goods-spec-submit" onClick={this.skuSubmit}>
                                选好了
                        </div>
                    }

                    <div className="goods-spec-close" onClick={this.hideFn}>
                        <img src={Close} alt="" />
                    </div>
                </div>
            </ModalChildren>

        )
    }
}
GoodsSpec.propTypes = {
    /**
     * 具体使用示例在ui/goods-detail/goods-detail.jsx <GoodsSpec />组件中
     * data类型：{
     *      goodsId: number, 商品id，必传
     *      price: number,商品的价格, 是不选择sku时候的这个goodsId的价格
     *      store: number,商品的库存, 不选择sku时候的这个goodsId下的的总库存,
     *      specs: array<object> 商品的一级属性数组，比如颜色，大小等一级属性，示例：
     *                                                                         {
     *                                                                            "keyId": 6982,
     *                                                                            "values": "大小"
     *                                                                         },
     *      specDesc: array<object> 商品的二级属性对象数组，例如黑色，红色，37码，38码等，示例：{
     *                                                       "specId": 6994,
     *                                                       "showType": "text",
     *                                                       "specValue": "简装",
     *                                                       "specValueId": 42731,
     *                                                       "specImage": "",
     *                                                       "goodsImageIds": []
     *                                                   },
     *      products: array<object>, sku具体的对象数组, 里面的对象示例：
     *          {
     *               "productId": 33128,
     *               "bn": "NP003-6",
     *               "price": 180.000,
     *               "weight": 0.000,
     *               "store": 200,
     *               "unit": "",
     *               "pdtDesc": "1.5kg,精装",
     *               "props": [
     *               {
     *                   "specId": 6982,
     *                   "specValueId": 42708,
     *                   "specValue": "1.5kg"
     *               },
     *               {
     *                   "specId": 6994,
     *                   "specValueId": 42732,
     *                   "specValue": "精装"
     *               }
     *               ]
     *           },
     *      picUrl: string, 商品图片url
     *   
     */
    isShow: PropTypes.bool.isRequired, // 是否显示
    hideFn: PropTypes.func.isRequired, // 用来隐藏弹窗的函数，因为最外层的state控制的组件的显示与否，最内层的对象需要调用这个函数修改最外层的state 
    type: PropTypes.string, // 非必需，点击的类型，有三种，'buy' 'add' ''，为了区分点击[选好了]按钮的动作
    initSubmit: PropTypes.func, // 用于商品详情页面初始化的时候，设置显示的规格，非必需
    data: PropTypes.object.isRequired, // 规格相关的数据
    submitFn: PropTypes.func.isRequired // 选好的回调
}