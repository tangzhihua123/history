import React, { Component } from 'react'
import PropTypes from 'prop-types'
import RequestUtil from 'utils/request-util'
import URLUtil from 'utils/url-util'
import INTRO from './intro.json'


import './index.scss'


export default class MainFloor extends Component { 
    constructor(props) {
        super(props)
    }

   
    render() {
        let t = URLUtil.fetchValueByURL("t")
        let data;
        data = INTRO.data.map((item, i) => {
            if(item.type == t) {
                document.title = item.title;
                let ques = item.ques;
                return ques.map((data, j) => {
                    return (
                        <div key={j}>
                           {/* <div className="title">{data.title}</div>*/}
                            <div className="ans">
                                {
                                    data.ans.map((d,k) => {
                                        return (
                                                <div  key={k}>
                                                    <span className="circle">Q{j+1}</span>
                                                    <p className="question" key={k} >
                                                        {d}
                                                    </p>
                                                </div>
                                        )
                                    })
                                }
                                {
                                    data.ques.map((d,k) => {
                                        return (

                                            <div  key={k}>
                                                <p className="answer" key={k} >
                                                    {d}
                                                </p>
                                            </div>
                                        )
                                    })
                                }
                            </div>
                        </div>
                    )
                })
                    
            }
        })
        return (
            <div className="intro-wrap">
                {data}
            </div>
        )
    }
}