import React, { Component } from 'react'
import PropTypes from 'prop-types'
import RequestUtil from 'utils/request-util'

import Cart from 'assets/Group_28@3x.png'
import './index.scss'

/**
 * 单个sku，默认数量1添加到购物车公用业务组件
 */
export default class AddToCart extends Component {
    constructor(props) {
        super(props)
        this.state = {
            goodsId: this.props.goodsId, 
            productId: this.props.productId,
            count: 1,
            size: this.props.size,
        }
    }

     /**
     * [addCart '添加购物车'操作调用后端接口]
     * @param {[type]} itemId [description]
     */
    addCart() {
        let self = this
        let param = {
            data: {
                goodsId: this.state.goodsId,
                productId: this.state.productId,
                count: 1,
                isChecked: 1
            },
            url: '/shopping/joinToCart',
            successFn: (data) => {
                if(data.resultCode == 2000) {
                    console.log('添加成功')
                }else if(data.resultCode == 4005) {
                    console.log("请登录后再添加至购物车")
                    window.location.href = '/app' // 跳转至登录页面
                }else if(data.resultCode == 5000) {
                    alert("网络异常，请稍后再试")
                }

               
            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }
        RequestUtil.fetch(param)    
    }
    

    render() {
        let goodsId = this.state.goodsId
        let productId = this.state.productId

        return (
            <div className="m-addto-cart">
                <img src={Cart} alt="添加到购物车" className="icon-cart" onClick={this.addCart.bind(this)} style={{
                width: this.state.size
                }} />
            </div>
        )
    }


}