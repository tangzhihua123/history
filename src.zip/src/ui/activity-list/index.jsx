import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Util from 'utils/util.js'
import Load from 'utils/load.js'
import RequestUtil from 'utils/request-util'
import URLUtil from 'utils/url-util'
import PullToRefresh from 'utils/pulltorefresh.js'
import LoadingDiv from 'components/bottom-refresh/index.jsx'

import GoodsSkuSelect  from 'ui/goods-sku-select/goods-des'
import ActivityProductItem from './item'

import './index.scss'


export default class TopicList extends Component {
    constructor(props) {
        super(props)

        this.state = {
            pageIndex: 1,
            pageSize: 10,
            hasMore: true,
            list: [],
            catName: ''

        }
    }
    
    componentWillMount() {
        // this.getCategoryList()
        // this.getCategoryList(() => {
            let destoryFn = this.getTopicList()
            this.setState({
                destoryFn: destoryFn
            })
        // })
       
    }

    componentDidMount() {
        console.log('componentDidMount')
       
        // let destroyRefresh = PullToRefresh.initWarp(this.pullFetch)
        
       
        let destroyScroll = this.state.hasMore ? Load.bottomLoad(this.getTopicList) : null
        this.setState({
            
            destroyScroll: destroyScroll
        })

        
    }
    
   
    
    
    /**
     * [getTopicList 获取主题活动下的’最佳拍档商品列表,接口还没提供，暂时注释掉.]
     * @return {[type]} [description]
     */
    getTopicList= () => {
        this.setState({
            loading: true
        })

        let param = {
            data: {
                pageIndex: this.state.pageIndex,
                pageSize: this.state.pageSize,
                isrec: 1,
                // ctId: 304, // 临时测试，后期该参数删除掉
                amId: URLUtil.fetchValueByURL("amid"), //URLUtil.fetchValueByURL("amid")
            },
            url: '/Active/LessActiveGoodsList',
            successFn: (data) => {
                if(data.resultCode == 2000) {
                    if(data.data.length == 0) {
                        this.setState({
                            hasMore: false,
                            loading: false
                        })  
                    }

                    else if(data.data.length > 0) {
                        this.setState({
                            list: this.state.list.concat(data.data),
                            pageIndex: this.state.pageIndex + 1,
                            hasMore: true,
                            loading: false
                            
                        })
                    }
                    
                }else if(data.resultCode == 5000) {
                    // alert("网络异常，请稍后再试")
                }

               
            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }
        RequestUtil.fetch(param)    
    }


    addCart_Comm(goodsId) {
        this.setState({
            specShow: true,
            goodsId
        })
    }

    hideSkuSelectDialog() {
        this.setState({
            specShow: false
        })
    }

    UpdataCartNum(addCartNum) {
        if(this.props.UpdateCartNumHandle)
            this.props.UpdateCartNumHandle(addCartNum)
    }


    genItem = () => {
        var arr = this.state.list
        if(!Util.isArray(arr)) return
        

        var list = arr.map( (item, i) => {
            let last = false;
            if(i == (arr.length - 1)) last = true

            return (
                <ActivityProductItem data={item} key={i} last={last}  addCartHandle={this.addCart_Comm.bind(this)} />
            )
        })
        return list
    }

    render() {
        return (
            <div className="m-activity-list">
                <div className="header">
                    — {this.state.catName} —
                </div>
                <div className="m-list-flex">
                    {this.genItem()}

                     {
                        this.state.specShow ? 
                        <GoodsSkuSelect 
                            AddCartSource={{
                                goodsSource: 23,
                                sourceId: URLUtil.fetchValueByURL("amid")
                            }}
                            noLogin={this.props.noLogin}
                            isShow={this.state.specShow} 
                            goodsId={this.state.goodsId} 
                            hideDialog={this.hideSkuSelectDialog.bind(this)} 
                            UpdateCartNumHandle={this.UpdataCartNum.bind(this)}
                            ></GoodsSkuSelect>:''
                    }
                </div>
                <LoadingDiv show={this.state.loading} hasMore={this.state.hasMore}/>
                
            </div>
        )
    }
}