import React, { Component } from 'react'
import Load from 'utils/load.js'
import Util from 'utils/util.js'
import PropTypes from 'prop-types'
import Request from 'utils/request-util.js'
import Tab from './Tab.jsx'
import LoadingDiv from 'components/bottom-refresh/index.jsx'

import './index.scss'

// 收入
let data0 = [
    {
        score: 100,
        time: "2017-10-01 13:13:13",
        income: 1,
        status: "",
        desc: "我是商品描述",
        title: "我是商品"
    },
    {
        score: 100,
        time: "2017-10-01 13:13:13",
        income: 1,
        status: "",
        desc: "我是商品描述",
        title: "我是商品"
    }
]
// 支出
/* let data1 = [
    {
        score: 100,
        time: "2017-10-01 13:13:13",
        income: 0,
        status: "",
        desc: "我是商品描述",
        title: "我是商品"
    },
    {
        score: 100,
        time: "2017-10-01 13:13:13",
        income: 0,
        status: "",
        desc: "我是商品描述",
        title: "我是商品"
    }
]
// 冻结
let data2 = [
    {
        score: 100,
        time: "2017-10-01 13:13:13",
        income: 1,
        status: 1,
        desc: "我是商品描述",
        title: "我是商品"
    },
    {
        score: 100,
        time: "2017-10-01 13:13:13",
        income: 1,
        status: 1,
        desc: "我是商品描述",
        title: "我是商品"
    }
]
// 全部
let data3 = [].concat(data0, data1, data2) */

export default class PointsDetail extends Component {
    constructor(props) {
        super(props)
        this.state = {
            freeze: false,
            pageSize: 10,
            status0: {
                pageIndex: 1,
                init: false,
                data: []
            },
            status1: {
                pageIndex: 1,
                init: false,
                data: []
            },
            status2: {
                pageIndex: 1,
                init: false,
                data: []
            },
            status3: {
                pageIndex: 1,
                init: false,
                data: []
            },
            tab: 0,
            hasMore: true
        }
    }
    componentDidMount() {
        Util.setFullHeight('.points-details-list')
        let destroyScroll = Load.bottomLoad(() => {
            this.fetchList({index: this.state.tab, click: false})
        })
        this.fetchPoints()
        this.fetchList({ index: 0, click: true })
        this.setState({
            destroyScroll: destroyScroll
        })
    }
    componentWillUnmount() {
        this.state.destroyScroll && this.state.destroyScroll()
    }
    handleTopTabChange = (tabText, tabIndex) => {
        
        this.setState({
            hasMore: true
        })
        if (tabIndex === 3) {
            this.setState({
                freeze: true,
                tab: tabIndex
            })
        } else {
            this.setState({
                freeze: false,
                tab: tabIndex
            })
        }
        this.fetchList({ index: tabIndex, click: true })

    }
    fetchPoints = () => {
        let param = {
            data: {},
            url: '/user/myScore',
            successFn: (res) => {
                this.setState({
                    totalScore: res.data.totalScore
                })
            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }

        Request.fetch(param)
    }
    fetchList = ({ index, click }) => {

        this.setState({
            tab: index
        })
        if (click && this.state['status' + index].init) {
            return
        }
        if (this.state['status' + index].end) {
            return
        }
        this.setState({
            loading: true
        })
        let param = {
            data: {
                type: index,
                pageIndex: this.state['status' + index].pageIndex,
                pageSize: this.state.pageSize
            },
            url: '/user/myScoreList',
            successFn: (res) => {
                if(res.resultCode === 4005) {
                    this.setState({
                        loading: false,

                    })
                    return
                }
                let status = this.state['status' + index]
                let obj = {
                    init: true,
                    pageIndex: status.pageIndex + 1,
                    data: status.data.concat(res.data.list)
                }
                let stateObj = {
                    loading: false
                }
                if (res.data.list.length < this.state.pageSize) {
                    obj.end = true
                    stateObj.hasMore = false
                    
                    if(obj.data.length === 0) {
                        stateObj.loading = false
                    } else {
                        stateObj.loading = true
                    }
                }

                stateObj['status' + index] = obj

                this.setState(stateObj)
            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }

        Request.fetch(param)
    }

    genList = () => {
        let tab = this.state.tab
        let array = this.state['status' + tab].data
        /* let array
        if(tab === 0) {
            array = data3
        } else if(tab === 1) {
            array = data0
        } else if(tab === 2) {
            array = data1
        } else if(tab === 3) {
            array = data2
        } */
        let type = ''
        let pre = ''
        if(array.length <=0) {
            
            
            return <div className="points-list-blank">
            <div>暂时没有数据哦～</div>
            </div>
        }
        let list = array.map(function (item, i) {
            if (item.income === 1) {
                type = 'in'
                pre = '+'
            } else {
                type = 'out'
                pre = '-'
            }
            if (item.status) {
                type = 'freeze'
            }

            /* if(i < 3) {
                type = 'in'
                pre = '+'
            } else if(i < 6) {
                type = 'out'
                pre = '-'
            } else if(i < 10) {
                type = 'freeze'
                pre = '-'
            } */

            return <div className={"points-detail-item " + type} key={i}>
                <div className="des-div">
                    <div className="name">{item.title}</div>
                    <div className="time">{item.time}</div>
                </div>
                <div className="points-div">
                    <div className="num">
                        <span className="num-span">{pre + item.score}</span>
                        <span className="text-span"> 积分</span>
                    </div>
                    {type === 'freeze' ? <div className="freeze-div">冻结</div> : null}
                </div>
            </div>
        })
        return list
    }

    render() {
        let topTabStatus = ['全部', '收入', '支出', '冻结'],
            activeIndex = 0
        return (
            <div className="points-details-list">
                <div className="list-title">
                    <span className="text">我的积分</span>
                    <span className="num">{this.state.totalScore}</span>
                </div>
                <div className={"list-container" + (this.state.freeze ? ' freeze' : '')}>
                    <Tab
                        ref="topTab"
                        isTopTab={true}
                        display={true}
                        tabs={topTabStatus}
                        activeIndex={activeIndex}
                        context={this}
                        handleItemClick={this.handleTopTabChange}
                    />
                    <div className="list-div">
                        {this.genList()}
                        {<LoadingDiv show={this.state.loading} hasMore={this.state.hasMore}/>}
                    </div>
                </div>
            </div>
        )
    }
}