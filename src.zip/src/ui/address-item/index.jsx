import React from 'react'
import classnames from 'classnames'
import Icon from 'components/Icon'
import './index.scss'


export default function AddressItem(props) {
  const { status = '', address = {}, onEditClick, onItemClick } = props
  let statusIcon = null
  const contCls = classnames(
    'address-item',
    status
  )
  if (status == 'current') {
    statusIcon = <span className="status">当前</span>
  } 

  return (
    <div className={contCls}>
      <div className="address-recipients" onClick={onItemClick}>
        <p className="recipients">{address.name}</p>
        {statusIcon}
      </div>
      <div className="address-detail" onClick={onItemClick}>
        <p className="phone">{address.mobile}</p>
        <p>{address.province + address.city + address.area + address.street + address.address}</p>
      </div>
      <div className="address-edit" onClick={onEditClick}>
        <Icon type="edit" size="sm"></Icon>
      </div>
    </div>
  )
}