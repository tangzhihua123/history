import React, { Component } from 'react'
import ImagePicker from 'components/image-picker'
import TextareaInput from 'components/textarea/index.jsx'
import Notification from "components/Notification/NotificationBlock.jsx"
import Util from 'utils/util.js'
import Request from 'utils/request-util.js'
import qs from 'query-string'
import './index.scss'
import { goodsStatus as rateStatus, greyImgs } from 'data/rate/rate-img.js'
import Y1 from './rate-1-1@2x.png'
import Y2 from './rate-1-2@2x.png'
import Y3 from './rate-1-3@2x.png'
import Y4 from './rate-1-4@2x.png'
import Y5 from './rate-1-5@2x.png'
import G1 from './rate-1@2x.png'
import G2 from './rate-2@2x.png'
import G3 from './rate-3@2x.png'
import G4 from './rate-4@2x.png'
import G5 from './rate-5@2x.png'
import Tbb from './tbb_logo.png'

const images = [{
    url: 'https://img.yzcdn.cn/upload_files/2017/05/08/149421656829915091.jpg?imageView2/2/w/200/h/200/q/75/format/jpg',
    id: '2121',
}, {
    url: 'https://img.yzcdn.cn/upload_files/2017/05/08/149421656829915091.jpg?imageView2/2/w/200/h/200/q/75/format/jpg',
    id: '2122',
}, {
    url: 'https://img.yzcdn.cn/upload_files/2017/05/08/149421656829915091.jpg?imageView2/2/w/200/h/200/q/75/format/jpg',
    id: '2123',
}, {
    url: 'https://img.yzcdn.cn/upload_files/2017/05/08/149421656829915091.jpg?imageView2/2/w/200/h/200/q/75/format/jpg',
    id: '2124',
}, {
    url: 'https://img.yzcdn.cn/upload_files/2017/05/08/149421656829915091.jpg?imageView2/2/w/200/h/200/q/75/format/jpg',
    id: '2125',
}];
export default class OrderRate extends Component {
    constructor(props) {
        super(props)
        this.state = {
            goodsEmojiArray: [Y5, Y5, Y5, Y5, Y5],
            expressEmojiArray: [Y5, Y5, Y5, Y5, Y5],
            goodsRate: 5,
            expressRate: 5,
            rateText: ['极差', '很差', '一般', '很好', '极好'],
            filesObj: {},
            filesURLObj: {},
            orderId: qs.parse(location.search).orderid,
            goodsList: [],
            rateObj: {}
        }
        
    }
    componentDidMount() {
        this.fetchOrderInfo()
    }

    fetchOrderInfo = () => {
        let param = {
            data: {
                orderId: this.state.orderId
            },
            url: '/user/getOrderInfo',
            successFn: (res) => {
                if (res.resultCode === 4005) {
                    Util.gotoLogin()
                    
                } else if(res.resultCode === 2000) {
                    this.setState({
                        goodsList: res.data.goodsList
                    })
                } else {
                    console.log('请求失败')
                }
                

            },
            errorFn: (error) => {
                console.log(error)
            }
        }

        Request.fetch(param)
    }
    makeid = (length) => {
        var text = "";
        var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

        for (var i = 0; i < length; i++)
            text += possible.charAt(Math.floor(Math.random() * possible.length));

        return text;
    }
    dataURItoBlob = (dataURI) => {
        var byteString = atob(dataURI.split(',')[1]);
        var ab = new ArrayBuffer(byteString.length);
        var ia = new Uint8Array(ab);
        for (var i = 0; i < byteString.length; i++) {
            ia[i] = byteString.charCodeAt(i);
        }
        return new Blob([ab], { type: 'image/png' });
    }

    uploadImgFail = (index, productId) => {

        let arr = this.state.filesObj[productId].filter((item, i) => {
            return i !== index
        })

        this.setState({
            filesObj: {
                ...this.state.filesObj,
                [productId]: arr
            } 
            
        })
        this.enter('上传失败，请重试')
    }
    uploadImg = (fileObj, index, productId) => {
        if (fileObj.loading) return
        let blob = fileObj.blob

        let fd = new FormData()
        fd.append("file", blob, this.makeid(10) + '.png')
        let param = {
            data: fd,
            url: '/user/uploadCommentsPictures',
            successFn: (res) => {
                if (res.resultCode !== 2000) {
                    this.uploadImgFail(index, productId)
                    return
                }
                let obj = this.state.filesURLObj[productId],
                    arr
                if(!obj) {
                    arr = []
                } else {
                    arr = obj.map((item) => {
                        return item
                    })
                }

                arr[index] = res.data.urls
                this.setState({
                    filesURLObj: {
                        ...this.state.filesURLObj,
                        [productId]: arr
                    }
                })

            },
            errorFn: (error) => {
                this.uploadImgFail(index, productId)
            }
        }

        Request.uploadImg(param)
    }

    onImagesChange = (productId) => (files, type, index) => {

        if (type === 'add') {
            let fileObj = files[files.length - 1]

            this.uploadImg(fileObj, files.length - 1, productId)

        } else if (type === 'remove') {
            let urlObj = this.state.filesURLObj[productId],
                arr

            if(!urlObj) {
                arr = []
            } else {
                arr = urlObj.map((item, i) => {
                    return item
                })
            }
            
            arr.splice(index, 1)

            this.setState({
                filesURLObj: {
                    ...this.state.filesURLObj,
                    [productId]: arr
                }
                
            })
        }

        this.setState({
            filesObj: {
                ...this.state.filesObj,
                [productId]: files
            }
        })
    }
    emojiClickHandler = (type, productId) => (ele) => {
        let index,
            classN
        // console.log('e.target', ele.target)
        // console.log('cls', ele.target.className)

        if (ele.target.className.indexOf('img-div') > -1) {
            classN = ele.target.className
        } else if (ele.target.parentNode.className.indexOf('img-div') > -1) {
            classN = ele.target.parentNode.className
        }
        console.log(classN, classN)
        index = parseInt(classN.match(/img-div(\d)/)[1])
        console.log('目前的索引', index)
        if (type === 'goods') {
            this.setState({
                rateObj: {
                    ...this.state.rateObj,
                    [productId]: {
                        ...this.state.rateObj[productId],
                        score: index
                    },
                    
                }
            }, () => {
                console.log('this.state', this.state)
            })
        } else {
            this.setState({
                expressRate: index
            })
        }
    }
    genRateImgList = (type, productId) => {

        let array, index, 
            obj = this.state.rateObj[productId]
        if (type === 'goods') {
            array = this.state.goodsEmojiArray
            if(!obj || !obj.score ) {
                index = 5
            } else {
                index = obj.score
            }
            // index = this.state.rateObj[productId].content === undefined ? 5:this.state.rateObj[productId].content
        } else if (type === 'express') {
            array = this.state.expressEmojiArray
            index = this.state.expressRate
        }
        let imgs = [],
            index1, index2
        for (var i = 0; i < index; i++) {
            index1 = i + 1
            imgs.push(
                <div className={"img-div img-div" + index1} onClick={this.emojiClickHandler(type, productId)}>
                    <img className="emoji-img" src={rateStatus[i].img} alt="" />
                </div>
            )
        }
        for (var j = index; j < 5; j++) {
            index2 = j + 1
            imgs.push(
                <div className={"img-div img-div" + index2} onClick={this.emojiClickHandler(type, productId)}>
                    <img className="emoji-img" src={greyImgs[j]} alt="" />
                </div>
            )
        }
        return (
            <div className="rate-img-con">
                <div className="container">
                    {imgs}
                </div>
                <div className="text">{rateStatus[index - 1].text}</div>
            </div>
        )
    }
    goodsCb = (productId) => (value) => {
        console.log('回调的值', value)
        this.setState({
            rateObj: {
                ...this.state.rateObj,
                [productId]: {
                    ...this.state.rateObj[productId],
                    content: value,
                }
            }
        })
    }
    expressCb = (value) => {
        this.setState({
            expressRateContent: value
        })
    }
    submitRate = () => {
        let list = [],
            goodsList = this.state.goodsList,
            rateObj = this.state.rateObj
        if(Util.isArray(goodsList)) {
            for(let i = 0, l = goodsList.length; i < l; i++) {
                let productId = goodsList[i].productId
                let obj = rateObj[productId] || {},
                    urlObj = this.state.filesURLObj[productId],
                    urlStr
                if(Util.isArray(urlObj) && urlObj.length > 0) {
                    urlStr = urlObj.join(',')
                } else {
                    urlStr = ''
                }
                list.push({
                    score: obj.score || 5,
                    content: obj.content || '',
                    imageList: urlStr,
                    productId: productId,
                    
                    
                })
            }
        } else {
            return
        }
        let data = {
            score: this.state.expressRate,
            content: this.state.expressRateContent || '',
            orderId: this.state.orderId,
            list: list,
        } 
        console.log(JSON.stringify(data))
        let param = {
            data: {
                data: JSON.stringify(data)
            },
            url: '/user/comments',
            successFn: (data) => {
                console.log('请求成功的数据', data)
                if(data.resultCode === 2000) {
                    this.enter('评价成功')
                    setTimeout(() => {
                        Util.gotoPage({
                            page: '/app/order'
                        })
                    }, 2000)
                    
                } else {
                    this.enter('提交失败，请重试')
                }
            },
            errorFn: () => {
                console.log('请求失败的错误', error)
            }
        }

        Request.fetch(param)

    }
    enter = (message) => {
        this.setState({
            enter: true,
            message: message,
        });
        setTimeout(
            function () {
                this.leave();
            }.bind(this),
            2000
        );
    }

    leave = () => {
        this.setState({
            enter: false,
            message: "",
        });
    }
    genRateList = () => {
        let list = this.state.goodsList,
            array = []
        array = list.map((item, i) => {
            return (
                <div className="rate-item-con" key={item.id}>
                    <div className="goods-img-div">
                        <img src={item.pictureUrl} className="goods-img" alt="" />
                        {this.genRateImgList('goods', item.productId)}
                    </div>
                    <TextareaInput
                        defaultText="金主，说出您的感受吧，小伙伴们很想知道呢"
                        letter={200}
                        textareaCb={this.goodsCb(item.productId)}
                    />
                    <div className="upload-div">
                        <ImagePicker
                            files={this.state.filesObj[item.productId]}
                            onChange={this.onImagesChange(item.productId)}
                            onImageClick={(index, fs) => console.log(index, fs)}
                        />
                    </div>
                </div>
            )
        })
        return array

    }
    render() {
        return (
            <div className="order-rate-container">
                <div className="goods-rate-con">
                    <div className="title-div">
                        <div className="line"></div>
                        <div className="title">商品评价</div>
                        <div className="line"></div>
                    </div>
                    {this.genRateList()}
                </div>
                <div className="express-rate-con">
                    <div className="title-div">
                        <div className="line"></div>
                        <div className="title">物流评价</div>
                        <div className="line"></div>
                    </div>
                    <img src={Tbb} alt="" className="tbb-img" />
                    <div className="tbb-title">兔波波配送</div>
                    <div className="send-time">8月6日 12:00送达</div>
                    <div className="goods-img-div">
                        {this.genRateImgList('express')}
                    </div>
                    <TextareaInput
                        defaultText="金主，说出您的感受吧，小伙伴们很想知道呢"
                        letter={200}
                        textareaCb={this.expressCb}
                    />
                </div>
                <div className="submit-order-rate" onClick={this.submitRate}>提交</div>
                <Notification
                    enter={this.state.enter}
                    leave={this.leave.bind(this)}
                >
                    {this.state.message}
                </Notification>
            </div>
        )
    }
}