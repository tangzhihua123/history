import React, { Component } from 'react'
import PropTypes from 'prop-types'
import RequestUtil from 'utils/request-util'
import Request from 'utils/request-util.js'

import './index.scss'
import Bg from './background.jpg'
import Logo from './header.png'
import Logo2 from './header2.png'
import URLUtil from 'utils/url-util'

export default class MainFloor extends Component { 
    constructor(props) {
        super(props)
        this.state = {
            // name:"tangzl邀请你",
            name:"",
            heardImg: Logo,
            uObj:null,//分享者的信息
            imbyqDesc:"",//被邀请人优惠
            imyqDesc:"",//邀请人优惠
            imCpkId:"",//邀请人优惠券
            imCpkId2:"",//被邀请人优惠券
            imid:"",//邀请返现活动id
        }
    }
    CollectImmed(id) {
        console.log("11111-------"+this.state.uObj);
        URLUtil.redirectPage({
            page: 'visit-share-register',
            options: {
                vid : URLUtil.fetchValueByURL("vid"),
                ut : URLUtil.fetchValueByURL("ut"),
                imCpkId:this.state.imCpkId,//邀请人优惠券
                imCpkId2:this.state.imCpkId2,//被邀请人优惠券
                imid:this.state.imid,//邀请返现活动id
            },
        })
    }
    getInvitationList() {
        let param = {
            data: {
                // vid : URLUtil.fetchValueByURL("vid"),
                // ut : URLUtil.fetchValueByURL("ut"),
            },
            url: '/Active/InvitationList',//判断是否是新用户接口
            successFn: (res) => {
                let data = res.data;
                this.setState({
                    imbyqDesc:data.imbyqDesc,//被邀请人优惠
                    imyqDesc:data.imyqDesc,//邀请人优惠
                    imCpkId:data.imCpkId,//邀请人优惠券
                    imCpkId2:data.imCpkId2,//被邀请人优惠券
                    imid:data.imId,//邀请返现活动id
                })

            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }
        Request.fetch(param)
    }
    getUserInfo() {
        let param = {
            data: {
                // vid : URLUtil.fetchValueByURL("vid"),
                // ut : URLUtil.fetchValueByURL("ut"),
                shareUserId:URLUtil.fetchValueByURL("vid"),
            },
            url: '/user/findByUserId',//判断是否是新用户接口
            successFn: (res) => {
                let data = res.data;
                this.setState({
                    name:data.nickName+"邀请你",//昵称
                    heardImg:data.faceLink,//头像

                })

            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }
        Request.fetch(param)
    }
    componentDidMount() {
        this.getInvitationList();
        this.getUserInfo();


    }

    render() {

        return (

            <div className="visit-share">
                <img src={Bg} alt="" className="visit-share-bg-img" />
                <div className="content">
                    <div className="flexCenter">
                        <div className="circular" style={{backgroundImage:'url(' + this.state.heardImg + ')'}}>
                            {/*<img src={Logo} alt="" className="logo-img" />*/}
                        </div>
                    </div>
                    <div className="flexCenter">
                        <div className="frendName">
                            {this.state.name}
                        </div>
                    </div>
                    <div className="flexCenter">
                        {/*<img src={Logo2} alt="" className="logo-img2" />*/}
                        <div className="contentInfo">
                            注册四季严选可获得
                        </div>
                    </div>
                    <div className="flexCenter">
                        <div className="contentInfo2">
                            {/*150元现金+20元礼包*/}
                            {this.state.imbyqDesc}
                        </div>
                    </div>
                    <div className="flexCenter">
                        <div onClick={this.CollectImmed.bind(this)} className="collectImmed">
                            立即领取
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}