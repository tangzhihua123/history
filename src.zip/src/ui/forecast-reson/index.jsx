
import React, { Component } from 'react'
import DOMScroller from 'zscroller/lib/DOMScroller'
import classnames from 'classnames'
import Icon from 'components/Icon'

import './index.scss'

export default class ForecastReson extends Component {
  constructor(props) {
    super(props)
    this.state = {
      index: 0,
      selectedValue: '商品质量问题',
    }
  }
  componentWillReceiveProps(nextProps) {
    // this.setState({
    //   selectedValue: nextProps.selectedTime.timeFormat || nextProps.time[0].timeFormat || ''
    // })
  }
  componentDidMount() {
    // 暂时写死，挂载到this
    this.itemHeight = Math.floor((document.documentElement.clientWidth / 3.75) * 0.55)
    const itemsHeight = (this.refs.timeItems).getBoundingClientRect().height
    this.domScroller = new DOMScroller(this.refs.timeItems, {
      scrollingX: false,
      snapping: true,
      locking: false,
      penetrationDeceleration: .1,
      minVelocityToKeepDecelerating: 0.5,
      scrollingComplete: this.scrollingComplete
    })
    this.domScroller.scroller.setSnapSize(0, this.itemHeight)
  }
  scrollingComplete = () => {
    const top = this.domScroller.scroller.getValues().top
    const index = Math.floor(top / this.itemHeight)
    this.setState({
      index,
      selectedValue: this.props.reson[index].aftersales_reson
    })
  }
  render() {
    const { reson = [],  modalVisible ,onClick,onCompleteClick} = this.props
    const selectedValue = this.state.selectedValue;
    const items = reson.map((item, index)=> {
      const itemCls = classnames({
        'time-item': true,
        'time-selected': selectedValue === item.aftersales_reson
      })
      return <li className={itemCls} key={index}>
        {item.aftersales_reson}
      </li>
    })
    return (
      <div className="forecast-reson">

        <div className="time-select-mask" style={{
          display: modalVisible? 'block' : 'none'
        }}>
          <div className="time-select-modal">
            <div className="time-select-title">
              <div className="content-title">
                <span className="reson_cancle" onClick={onClick}>取消</span>
                <span className="reson_ok" onClick={()=> {
                    onCompleteClick(reson[this.state.index])
                }} >完成</span>
              </div>
            </div>
            <div className="modal-main">
              <div className="time-list">
                <ul className="time-items" ref="timeItems">
                  {items}
                </ul>
              </div>
              <div className="selected-area"></div>
            </div>
            <div className="time-modal-bottom">
              {/*<div className="time-modal-btn" onClick={()=> {*/}
                {/*onCompleteClick(time[this.state.index])*/}
              {/*}} >完成</div>*/}
            </div>
          </div>
        </div>
      </div>
    )
  }
}