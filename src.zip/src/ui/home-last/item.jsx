import React, { Component } from 'react'
import PropTypes from 'prop-types'
import URLUtil from 'utils/url-util'
import RequestUtil from 'utils/request-util'
import LazyLoad from 'components/Lazyload'
import './item.scss'

import AddToCart from 'ui/add-to-cart'

export default class TopicList extends Component {
    constructor(props) {
        super(props)

        this.state = {
            data: this.props.data || {}
        }
    }

    RedirectDetail() {
        URLUtil.redirectPage({
            page: 'app/goodsdetail',
            options: {
               goodsId: this.state.data.goodsId,
               goodsSource: 8,
               sourceId: 0
            }
        })
    }

    render() {
       
        return (
            <div className='m-topic-item' onClick={this.RedirectDetail.bind(this)}>
                <div className="info">
                        {/*<LazyLoad height={200}>*/}
                        <img src={this.state.data.imgLink } className='imgs' alt={this.state.data.userName} />
                        {/*</LazyLoad>*/}
                    {
                        this.state.data.tag != '' ? 
                            <span className="coupon-flag">
                            {this.state.data.tag}
                            </span> : ''
                    }
                </div>
               
                <div className="title">{this.state.data.title}</div>
                <div className='price'>
                    &yen;{ this.state.data.goodsPrice }
                    {/*<AddToCart {...cartParam} ></AddToCart>*/}
                </div>
            </div>
        )
    }
}