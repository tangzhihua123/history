import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Util from 'utils/util.js'
import Load from 'utils/load.js'
import RequestUtil from 'utils/request-util'
import PullToRefresh from 'utils/pulltorefresh.js'
import LoadingDiv from 'components/bottom-refresh/index.jsx'
import LazyLoad from 'components/Lazyload'
import ProductItem from './item'

import './index.scss'


export default class TopicList extends Component {
    constructor(props) {
        super(props)

        this.state = {
            pageIndex: 1,
            pageSize: 10,
            hasMore: true,
            list: [], // 达人食荐商品列表

        }
    }
    
    componentDidMount() {
      
        let destoryFn = this.getList()
        this.setState({
            destoryFn: destoryFn
        })
        console.log(this.state.hasMore,'tttttttttt')
        let destroyScroll = this.state.hasMore ? Load.bottomLoad(this.getList) : null
        this.setState({
            destroyScroll: destroyScroll
        })
    }

    /**
     * [getList 获取达人食荐分页数据列表]
     * @return {[type]} [description]
     */
    getList= () => {
        this.setState({
            loading: true
        })
        let param = {
            data: {
                pageIndex: this.state.pageIndex,
                pageSize: this.state.pageSize,
            },
            url: '/home/list',
            successFn: (data) => {
                if(data.resultCode == 2000 ) {
                    if(data.data.list.length == 0) {
                        this.setState({
                            hasMore: false,
                            loading: false
                        })  
                    }
                    else if(data.data.list.length > 0) {
                        this.setState({
                            list: this.state.list.concat(data.data.list),
                            pageIndex: this.state.pageIndex + 1,
                            hasMore: true,
                            loading: false
                            
                        })
                    }
                    
                }else if(data.resultCode == 5000) {
                    alert("网络异常，请稍后再试")
                }

               
            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }
        RequestUtil.fetch(param)    
    }

    genItem = () => {
        var arr = this.state.list
        if(!Util.isArray(arr)) return
        

        var list = arr.map(function (item, i) {
            let last = false;
            if(i == (arr.length - 1)) last = true

            return (
                    <ProductItem data={item} key={i} last={last} />
            )
        })
        return list
    }

    render() {

        return (
            <div className="m-activity-list" id="map6">
                <div className="header">
                    — 达人食荐 —
                </div>
                <div className="m-list-flex">
                    {this.genItem()}
                </div>
                
                <LoadingDiv show={this.state.loading} hasMore={this.state.hasMore}/>
                
            </div>
        )
    }
}