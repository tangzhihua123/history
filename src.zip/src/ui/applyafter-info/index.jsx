import React from 'react'
import SplitLine from 'components/split-line'

import './index.scss'

export default function OrderFee(props) {
  const { fees = [], payment } = props
  return (
    <div className="apply-after-info">
      <div>
        {
          fees.map(function (el, index) {
              let {content} = el
              //0=仅换货，1=退货退款，2=平台协助收货，3=补货，4=退款
              if(content ==0) {
                  content = '申请-仅换货'
              }else if(content ==1) {
                  content = '申请-退货退款'
              }else if(content ==2) {
                  content = '申请-平台协助收货'
              }else if(content ==3) {
                  content = '申请-补货'
              }else if(content ==4) {
                  content = '申请-退款'
              }
            return (<div key={index} className="content">
                    <div key={index} className="fee-item">
                        <div>
                            <div className="fee-label">{el.userName}</div>
                            <div className="heightWhite"></div>
                            <div className="fee-content">{content}</div>
                        </div>
                        <span className="fee-value">{el.time}</span>
                    </div>
                    <SplitLine size="1" color="#e5e5e5"></SplitLine>
                </div>
                )
          })
        }
      </div>
    </div>
  )
}