import React, {Component} from 'react'
import Request from 'utils/request-util.js'
import {Link} from 'react-router-dom'

import './index.scss'

import Share from './points-share.png'
import Con from './points-con.png'
import Cost from './points-cost.png'
import Rate from './points-rate.png'

class PointsCell extends Component {
    constructor(props) {
        super(props)
        this.state = {
            data: this.props.data
        }
    }
    componentWillReceiveProps(nextProps) {
        this.setState({
            data: nextProps.data
        })
    }
    gotoPage = (url) => () => {
        location.href = '//'+location.host+url
    }
    
    render() {
        return (
            <div className="complete-cell">
                <div className="left">
                    <span className="title">{this.props.data.title}</span>
                    <span className="des">{this.props.data.num}</span>
                </div>
                <div className="right">
                    {
                        this.state.data.complete ? 
                        <div className="complete-des">已完成</div>:
                        <div className="uncomplete-des" onClick={this.gotoPage('/app/i')}>去设置 ></div>
                    }
                </div>
            </div>
        )
    }
}
export default class PointsEarn extends Component {
    constructor(props) {
        super(props)
        this.state = {
            data: {
                "faceReward": 5,
                "genderReward": 3,
                "nickNameReward": 4,
                "birthdayReward": 2,
            }
        }
    }
    componentDidMount() {
        this.fetchPointsConfig()
    }
    fetchPointsConfig = () => {
        let param = {
            data: {
            },
            url: '/sys/getScoreConfig',
            successFn: (res) => {
                console.log('请求成功的数据', res)
                this.setState({
                    data: res.data,
                })
            },
            errorFn: () => {
                console.log('请求失败的错误', error)
            }
        }

        Request.fetch(param)
    }
    gotoPage = (url) => () => {
        location.href = '//'+location.host+url
    }
    render() {
        let d = this.state.data
        return (
            <div className="points-earn-div">
                <div className="cost-div earn-div">
                    <div className="left-div">
                        <img src={Cost} alt="" />
                        <div className="des-div">
                            <div className="title">消费送积分</div>
                            <div className="des">每1元获取{d.consumeReward}积分</div>
                        </div>
                    </div>
                    <div className="right" onClick={this.gotoPage('/home')}>去消费</div>
                </div>
                <div className="share-div earn-div">
                    <div className="left-div">
                        <img src={Share} alt="" />
                        <div className="des-div">
                            <div className="title">分享送积分</div>
                            <div className="des">分享商品{d.shareGoodsReward}分/活动{d.shareActReward}分，日上限{d.shareMaxReward}</div>
                        </div>
                    </div>
                    <div className="right" onClick={this.gotoPage('/home')}>去分享</div>
                </div>
                <div className="rate-div earn-div">
                    <div className="left-div">
                        <img src={Rate} alt="" />
                        <div className="des-div">
                            <div className="title">评价送积分</div>
                            <div className="des">晒图{d.commentImageReward}分/文字{d.commentTextReward}分，日上限{d.commnetMaxReward}</div>
                        </div>
                    </div>
                    <div className="right" onClick={this.gotoPage('/app/order')}>去评价</div>
                </div>
                <div className="complete-div earn-div">
                    <div className="left-div">
                        <img src={Con} alt="" />
                        <div className="des-div">
                            <div className="title">完善资料送积分</div>
                            <div className="des">完善资料获取积分</div>
                        </div>
                    </div>
                </div>
                <PointsCell data={
                    {title:'完善头像信息',
                    num: '+' + (d.faceReward||0),
                    complete: this.state.data.faceRewardFinish
                    }
                }/>
                <PointsCell data={
                    {title:'完善性别信息',
                    num: '+' + (d.genderReward||0),
                    complete: this.state.data.genderRewardFinish
                    }
                }/>
                <PointsCell data={
                    {title:'完善昵称信息',
                    num: '+' + (d.nickNameReward||0),
                    complete: this.state.data.nickNameRewardFinish
                    }
                }/>
                <PointsCell data={
                    {title:'完善生日信息',
                    num: '+' + (d.birthdayReward||0),
                    complete: this.state.data.birthdayRewardFinish
                    }
                }/>
            </div>
        )
    }
}