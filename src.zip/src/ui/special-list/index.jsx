import React, { Component } from 'react'
import PropTypes from 'prop-types'
import RequestUtil from 'utils/request-util'
import WeixinUtil from 'utils/WeixinUtil'
import Util from 'utils/util'
import URLUtil from 'utils/url-util'
import SpecialItem from './special-item'
import GoodsSkuSelect  from 'ui/goods-sku-select/goods-des'
import ActivityListUI from 'ui/activity-list'
import CartAndMenu from 'ui/cart-menu'
import Load from 'utils/load.js'
import LoadingDiv from 'components/bottom-refresh/index.jsx'
import './index.scss'


import ActivityProductItem from './item_spu'



export default class SpecialList extends Component {
    constructor(props) {
        super(props)

        this.state = {
            pageIndex: 1,
            pageSize: 10,
            banner: '',// 主题活动banner图
            title: '',
            actdesc: '',
            list: [],
            catName: '',
            

            pageIndex2: 1,
            pageSize2: 10,
            hasMore: true,
            list2: [],

            /*购买相关*/
            cartNum:0, //购物车数量
            noLogin: this.props.noLogin,
        }
    }
    addCart_Comm(goodsId) {
        this.setState({
            specShow: true,
            goodsId
        })
    }

    hideSkuSelectDialog() {
        this.setState({
            specShow: false
        })
    }

    UpdataCartNum(addCartNum) {
        if(this.props.UpdateCartNumHandle)
            this.props.UpdateCartNumHandle(addCartNum)
    }
    
    weixinShare ()  {
        let self = this
        WeixinUtil.shareByPageOption({
            title: self.state.title,
            desc: self.state.actdesc,
            link: window.location.href,
            imgUrl: self.state.banner, 
            success: () => {
                console.log('share success')
            },
            cancel: () => {
                console.log('share cancel')
            }
        })
    }


    componentDidMount() {
        this.getBanner()
        this.getList()

        let destoryFn = this.getSPUList()
        this.setState({
                destoryFn: destoryFn
        })

        let destroyScroll = this.state.hasMore ? Load.bottomLoad(this.getSPUList) : null
        this.setState({
            destroyScroll: destroyScroll
        })
    }

    getBanner= () => {

        let param = {
            data: {
                amid : URLUtil.fetchValueByURL("amid"),
            },
            url: '/Active/ActiveList',
            successFn: (data) => {
                console.log(data,'tt')
                if(data.resultCode == 2000) {
                    if(data.data[0].amTImages) 
                    {
                        this.setState({
                            banner: data.data[0].amTImages,
                            title: data.data[0].amTitle,
                            actdesc: data.data[0].desc,
                            catName: data.data[0].recTitle
                        }, () => {
                            document.title = this.state.title.length > 10 ? (this.state.title.substring(0,10) + '...') : this.state.title
                           
                            this.weixinShare()
                        })
                    }

                }else if(data.resultCode == 5000) {
                    alert("网络异常，请稍后再试")
                }


            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }
        RequestUtil.fetch(param)
    }
    
    /**
     * [getList 获取少商品"添加商品]
     * @return {[type]} [description]
     */
    getList= () => {
        this.setState({
            loading: true
        })
        let param = {
            data: {
                pageIndex: this.state.pageIndex,
                pageSize: this.state.pageSize,
                amId: URLUtil.fetchValueByURL("amid"),
                isrec: 0,
            },
            url: '/Active/LessActiveGoodsList',
            successFn: (data) => {
                if(data.resultCode == 2000) {
                    if(data.data.length > 0) {
                            this.setState({
                                list: this.state.list.concat(data.data),
                            })
                    }
                    
                }else if(data.resultCode == 5000) {
                    alert("网络异常，请稍后再试")
                }

               
            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }
        RequestUtil.fetch(param)    
    }

    /**
     * [getTopicList 获取主题活动下的’最佳拍档商品列表,接口还没提供，暂时注释掉.]
     * @return {[type]} [description]
     */
    getSPUList= () => {
        this.setState({
            loading: true
        })

        let param = {
            data: {
                pageIndex: this.state.pageIndex2,
                pageSize: this.state.pageSize2,
                isrec: 1,
                amId: URLUtil.fetchValueByURL("amid"), 
            },
            url: '/Active/LessActiveGoodsList',
            successFn: (data) => {
                if(data.resultCode == 2000) {
                    if(data.data.length == 0) {
                        this.setState({
                            hasMore: false,
                            loading: false
                        })  
                    }

                    else if(data.data.length > 0) {
                        this.setState({
                            list2: this.state.list.concat(data.data),
                            pageIndex2: this.state.pageIndex2 + 1,
                            hasMore: true,
                            loading: false
                            
                        })
                    }
                    
                }else if(data.resultCode == 5000) {
                    // alert("网络异常，请稍后再试")
                }

               
            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }
        RequestUtil.fetch(param)    
    }

    genItem = () => {
        var arr = this.state.list
        if(!Util.isArray(arr)) return
        

        var list = arr.map( (item, i) => {
            let last = false;
            if(i == (arr.length - 1)) last = true

            return (
                <SpecialItem data={item} key={i} last={last} addCartHandle={this.addCart_Comm.bind(this)} />
            )
        })
        return list
    }

    genItemSpu = () => {
        var arr = this.state.list2
        if(!Util.isArray(arr)) return
        

        var list = arr.map( (item, i) => {
            let last = false;
            if(i == (arr.length - 1)) last = true

            return (
                <ActivityProductItem data={item} key={i} last={last}  addCartHandle={this.addCart_Comm.bind(this)} />
            )
        })
        return list
    }

   

    render() {
        return (
            <div className="m-special-list">
                <img src={this.state.banner} alt={this.state.title} className='banner'/>
                {this.genItem()}
                <div className="spaceLine"></div>
                <div className="header">
                    — {this.state.catName} —
                </div>
                <div className="m-list-flex">
                    {this.genItemSpu()}
                </div>
               
                {
                    this.state.specShow ? 
                    <GoodsSkuSelect 
                        AddCartSource={{
                            goodsSource: 23,
                            sourceId: URLUtil.fetchValueByURL("amid")
                        }}
                        noLogin={this.props.noLogin}
                        isShow={this.state.specShow} 
                        goodsId={this.state.goodsId} 
                        hideDialog={this.hideSkuSelectDialog.bind(this)} 
                        UpdateCartNumHandle={this.UpdataCartNum.bind(this)}
                        ></GoodsSkuSelect>:''
                }

                 <LoadingDiv show={this.state.loading} hasMore={this.state.hasMore}/>
            </div>
        )
    }
}