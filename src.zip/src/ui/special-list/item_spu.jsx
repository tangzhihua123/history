import React, { Component } from 'react'
import PropTypes from 'prop-types'
import RequestUtil from 'utils/request-util'
import URLUtil from 'utils/url-util'
import Util from 'utils/util'
import './item_spu.scss'

import AddToCart from 'ui/add-to-cart'

import icon_cart from 'assets/Group_28@3x.png'


export default class TopicList extends Component {
    constructor(props) {
        super(props)

        this.state = {
            data: this.props.data || {}
        }
    }

    addCart(goodsId,productId) {
        if(Util.isCustomAgent()) {
            try{
                JSBridge.getData({
                    type: ['token', 'userId'],
                    success: function(data) {
                        let params = store.get('user')
                        params.userId = data.userId
                        params.token = data.token
                        store.set('user', params)
                        data.userId && this.props.addCartHandle(goodsId)
                    }
                })
            }catch (err) {
                console.log(err)
            }  
        }else {
            this.props.addCartHandle(goodsId)
        }
       
    }

    RedirectDetail() {
        URLUtil.RedirectDetail(this.state.data.goodsId , 23, URLUtil.fetchValueByURL("amid"))
        // URLUtil.redirectPage({
        //     page: 'app/goodsdetail',
        //     options: {
        //         goodsId: this.state.data.goodsId
        //     }
        // })
    }

    render() {
        let cartParam = {
            goodsId: this.state.goodsId,
            productId: this.state.productId,
            count: 1,
            size: '0.3rem',
        }

        return (
            <div className='m-topic-item' >
                <div onClick={this.RedirectDetail.bind(this)}>
                    <div className="info">
                        <img src={this.state.data.Thumbnail_Pic } className='imgs' alt={this.state.data.GoodsName} />
                        {this.state.data.GoodsTag ? 
                            <span className="coupon-flag">
                                {this.state.data.GoodsTag}
                            </span> : ''
                        }
                        
                    </div>
                   
                    <div className="title">{this.state.data.GoodsName}</div>
                    {/*<div className="subtitle">{this.state.data.cgTitle2}</div>*/}
                </div>
                <div className='price'>
                    &yen;{ this.state.data.GoodsPrice }
                    <div className='add-cart' onClick={this.addCart.bind(this, this.state.data.goodsId, this.state.data.productId)}>
                                <img src={icon_cart} alt="购物车" />
                    </div>
                    {/*<AddToCart {...cartParam} ></AddToCart>*/}
                </div>
            </div>
        )
    }
}