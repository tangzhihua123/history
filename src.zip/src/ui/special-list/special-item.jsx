import React, { Component } from 'react'
import PropTypes from 'prop-types'
import store from 'store'
import RequestUtil from 'utils/request-util'
import URLUtil from 'utils/url-util'
import './special-item.scss'
import LazyLoad from 'components/Lazyload'
import AddToCart from 'ui/add-to-cart'
import Cart from 'assets/Group_28@3x.png'
import icon_cart from 'assets/Group_28@3x.png'
import Util from 'utils/util'

export default class TopicList extends Component {
    constructor(props) {
        super(props)

        this.state = {
            data: this.props.data || {}
        }
    }

    addCart(goodsId,productId) {
        let self = this
        if(Util.isCustomAgent()) {
            try{
                JSBridge.getData({
                    type: ['token', 'userId'],
                    success: function(data) {
                        let params = store.get('user') ? store.get('user') : {}
                        params.userId = data.userId
                        params.token = data.token
                        store.set('user', params)
                        data.userId && self.props.addCartHandle(goodsId)
                    }
                })
            }catch (err) {
                console.log(err)
            }  
        }else  {
            this.props.addCartHandle(goodsId)
        }
        
    }
    
    RedirectDetail() {
        URLUtil.RedirectDetail(this.state.data.goodsId, 23, URLUtil.fetchValueByURL("amid"))
        // URLUtil.redirectPage({
        //     page: 'app/goodsdetail',
        //     options: {
        //         goodsId: this.state.data.goodsId
        //     }
        // })
    }
   
    render() {
        let goodsId = this.state.data.goodsId
        let productId = this.state.data.productId

        let cls = this.props.last ? 'm-special-item' : 'm-special-item border-bottom'
        
        let cartParam = {
            goodsId: this.state.data.goodsId,
            productId: this.state.data.productId,
            count: 1,
            size: '0.48rem',
        }
        return (
            <div className={cls} >
                <div className="m-special-item-content">
                    <div onClick={this.RedirectDetail.bind(this)}>
                        <div className="info">
                            <LazyLoad height={200} >
                                <img src={ this.state.data.Thumbnail_Pic } className='header' alt={this.state.data.cgTitle} />
                            </LazyLoad>
                        </div>
                        <div className="title">{ this.state.data.cgTitle }</div>
                        <div className="subtitle">{ this.state.data.cgTitle2 }</div>
                        <div className="desc">
                            { this.state.data.cgDesc }
                        </div>
                    </div> 
                        <div className="m-buy">
                            <span className="f-small black">&yen;</span><span className="price black">{this.state.data.GoodsPrice}</span>{/*<span className='f-small black'>/ {this.state.data.unit}</span>*/}
                        {this.state.data.MktPrice != 0 ? <span className="market f-small" >&yen; {this.state.data.MktPrice}{/*/{this.state.data.unit}*/}</span> : null}
                            
                            <div className='add-cart' onClick={this.addCart.bind(this, this.state.data.goodsId, this.state.data.productId)}>
                                <img src={icon_cart} alt="购物车" />
                            </div>
                           {/* <div className="icon-cart-wrap">
                                <AddToCart {...cartParam} ></AddToCart>
                            </div>*/}
                            
                            
                        </div>
                      
                </div>
            </div>
        )
    }
}