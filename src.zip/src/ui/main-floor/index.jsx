import React, { Component } from 'react'
import PropTypes from 'prop-types'
import {
    BrowserRouter as Router,
    Route,
    Link
} from 'react-router-dom'
import VConsole from 'vconsole'

import Hammer from 'utils/hammer.min.js'
// import JSBridge from 'utils/JSBridge'
import Util from 'utils/util'
import StatisticUtil from 'utils/statisticUtil'

import ReactSwipe from 'react-swipe';
import ReactSwipePage from 'components/react-swipe-page'
import { Carousel } from 'react-responsive-carousel';
import styles from 'style/carsousel.scss'

// import ReactSwipeMany from 'components/react-swipes'
import RequestUtil from 'utils/request-util'
import WeixinUtil from 'utils/WeixinUtil'
import URLUtil from 'utils/url-util'
import LazyLoad from 'components/Lazyload'
import ShareModal from 'components/share-modal'
import VideoComponent from 'components/video-react/index.jsx'

import Notification from "components/Notification/NotificationBlock.jsx"

// import Slider from 'components/Slider'
// import SlideItem from 'components/Slider/SliderItem'
// 后期完善后再修改为项目中库
// import {
//   Slider
// } from 'amazeui-touch';
// import 'amazeui-touch/dist/amazeui.touch.min.css';
// import 'components/Slider/_slider_tmp.scss'

import './index.scss'

import HomeComment from './img/home_new_message@3x.png'
import ICON_SHARE from './img/home_new_sharing@3x.png'
import ICON_CHECKOUT from './img/home_Check out more@3x.png'
import ICON_TAG from './img/home_labelling@3x.png'
import ICON_CART from './img/home_new_Shopping cart@3x.png'
import CartAndMenu from 'ui/cart-menu'
import ICON_PLAY from 'assets/home_play@3x.png'
import ICON_ADDR  from 'assets/home_localize@3x.png'

import GoodsSkuSelect  from 'ui/goods-sku-select/goods-des'
import HomeMenu from 'ui/home-menu'
import MapGaode from 'ui/map-gaode'
import HomeLastUI from 'ui/home-last'



export default class MainFloor extends Component { 
    constructor(props) {
        super(props)
        this.state = {
            Floor1: {}, 
            banner1SlideIndex: 0,
            banner2SlideIndex: 0,
            banner3SlideIndex: 0,
            banner4SlideIndex: 0,
            banner5SlideIndex: 0,
            banner6SlideIndex: 0,
            Floor2: {},
            Floor3: {},
            Floor4: {},
            Floor5: {},
            Floor6: {},
            show: false,

            video_picUrl: '',
            video_videoLink : '',
            mapVisiable: false,
            noLogin: false,

            enter: false,
            message: '',
            SliderBuyState: 0
        }
    }

    enter = (message) => {
        this.setState({
            enter: true,
            message: message,
        });
        setTimeout(
            function() {
                this.leave();
            }.bind(this),
            2000
        );
    }

    leave = () => {
        this.setState({
            enter: false,
            message: "",
        });
    }

    componentWillMount() {
        
        this.GetHomeData()
        this.fetchCartNum()
    }

    componentDidMount() {
        var vConsole = new VConsole();
        WeixinUtil.initWeixinJSBridge()
    }

    
    /**
     * [SliderBuy 垂直轮播入店必买商品]
     */
    SliderBuy() {
        let self = this
        window.setInterval(self.SliderBuyData.bind(self),4000)
    }
    
    SliderBuyData() {
        let self = this
        let l = document.querySelectorAll('.floor2_pro .pro-item')
        let newIndex = self.state.SliderBuyState + 1
        self.setState({
            SliderBuyState: (newIndex > 2) ? 0 : newIndex
        }, () => {
            [].map.call(l, (item, i) => {
                if(parseInt(i / 3) ==  this.state.SliderBuyState ) {
                    item.style.display = 'block'
                    Util.addClass(item, 'slider')
                } else  {
                    item.style.display = 'none'
                    Util.removeClass(item, 'slider')
                }
            })
        })
        

    }
    
    /**
     * [componentDidUpdate 轮播图内容滚动处理]
     * @return {[type]} [description]
     */
    componentDidUpdate() {
        let items = document.querySelectorAll('.banner_items')
       
        for(let i = 0;i<items.length; i++) {
            items[i].addEventListener('touchstart',(e) => {
                e.stopPropagation()
            }, false);  
        }
       
       
    }


    

    GetHomeData() {
        let self = this
        let param = {
            data: {},
            url: '/home/index',
            successFn: (data) => {
                if(data.resultCode == 2000 || data.resultCode == 2001) {
                    if(data.data.list.length > 0) {
                        self.setState({
                            show: true,
                            Floor1: self.GetFloorInfo(1, data.data.list),
                            Floor2: self.GetFloorInfo(3, data.data.list),
                            Floor3:  self.GetFloorInfo(4, data.data.list),
                            Floor4:  self.GetFloorInfo(5, data.data.list),
                            Floor5:  self.GetFloorInfo(6,data.data.list),
                            Floor6:  self.GetFloorInfo(7,data.data.list),
                        }, () => {
                            self.SliderBuy()  
                        })


                    }
                    
                }else if(data.resultCode == 5000) {
                    self.enter("网络异常，请稍后再试")
                }
            },
            errorFn: (error) => {
                self.enter("网络异常，请稍后再试")
            }
        }
        RequestUtil.fetch(param)    
    }
    
    /**
     * [GetFloorInfo 获取不同楼层数据信息]
     * @param {[type]} type [description]
     * @param {[type]} data [description]
     */
    GetFloorInfo(type, data) {
        let _d = {}
       
        data.map((item, i) => {
            if(item.type == type) {
                _d = item
            }
        })
        return _d
    }

    
    /**
     * [GetBanner1List 首页-推荐轮播图]
     */
    GetBanner1List() {
        let self = this
        let pageIndex = 0 
        const swipeOptions = {
            continuous: true,
            auto: 5000,
            transitionEnd(index, elem) {
                self.setState({
                    banner1SlideIndex :index
                })
               
            }
        };

        let bannerlist = null
        if(this.state.Floor1.bannerInfo) {
            bannerlist = this.state.Floor1.bannerInfo.map((item, i) => {
                return (
                    <div key={i}>
                        <div className="item"><img src={item.imgLink}  key={i} onClick={this.RedirectAbsoluteUrl.bind(this, item.clickLink, 1)}/></div>
                    </div>
                    
                )
            })
            
        }

        return  (
            <div>
                <ReactSwipe ref={reactSwipe => this.reactSwipe = reactSwipe} className="mySwipe" swipeOptions={swipeOptions}>
                    {bannerlist}
                </ReactSwipe>
                <ReactSwipePage pageCount={this.state.Floor1.bannerInfo && this.state.Floor1.bannerInfo.length} pageIndex={self.state.banner1SlideIndex} ></ReactSwipePage>
            </div>
        )
    }
    
    /**
     * [GetBanner2List 入店必买轮播]
     */
    GetBanner2List() {
        let self = this
        let pageIndex = 0 
        const swipeOptions = {
            continuous: true,
            transitionEnd(index, elem) {
                self.setState({
                    banner2SlideIndex :index
                })
               
            }
        };

        let bannerlist = null
        if(this.state.Floor2.bannerInfo) {
            bannerlist = this.state.Floor2.bannerInfo.map((item, i) => {
                return (
                    <div key={i}>
                        <div className="item"><img src={item.imgLink}  key={i} onClick={this.RedirectAbsoluteUrl.bind(this, item.clickLink, 3)} /></div>
                    </div>
                )
            })
            
        }

        return  (
            <div>
                <ReactSwipe  className="mySwipe" swipeOptions={swipeOptions}>
                    {bannerlist}
                </ReactSwipe>
                {/*<ReactSwipePage pageCount={this.state.Floor2.bannerInfo && this.state.Floor2.bannerInfo.length} pageIndex={self.state.banner2SlideIndex} ></ReactSwipePage>*/}
            </div>
        )   
    }

    /**
     * [RedirectUrlDetail 跳转到详情页面]
     * @param {[type]} goodsId [description]
     */
    RedirectUrlDetail(goodsId) {
        URLUtil.redirectPage({
            page: 'app/detail',
            options: {
                id: goodsId
            }

        })
    }

    /**
     * [RedirectTopic 跳转到主题页面]
     */
    RedirectTopic(event) {
        event.stopPropagation();

        URLUtil.redirectPage({
            page: 'topic-list',
            options: {}
        })
    }

 

    RedirectDetail(goodsId,goodsSource) {
       
        URLUtil.redirectPage({
            page: 'app/goodsdetail',
            options: {
                goodsId: goodsId,
                goodsSource,
                sourceId: 0,
            }
        })
    }

    /**
     * [RedirectAbsoluteUrl 内跳地址处理]
     * @param {[type]} url [description]
     */
    RedirectAbsoluteUrl (url, goodsSource) {
       
        
        if(url.indexOf('app/viewpage') >=0) {
            if(url.indexOf('goodsdetail') > 0) {
                URLUtil.redirectPage({
                    page: 'app/goodsdetail',
                    options: {
                       goodsId: URLUtil.fetchValueByURL2(url, 'goodsid' ),
                       goodsSource,
                       sourceId: 0 
                    }
                })
            }else if(url.indexOf('integral') > 0) {
                URLUtil.redirectPage({
                    page: 'points/getaward',
                    options: {}
                })
            }else if(url.indexOf('coupons') > 0) {
                URLUtil.redirectPage({
                    page: 'app/couponlist',
                    options: {}
                })
            }else if(url.indexOf('shoopingcar') > 0) {
                URLUtil.redirectPage({
                    page: 'app/mycart',
                    options: {}
                })
            }else if(url.indexOf('allorder') > 0) {
                URLUtil.redirectPage({
                    page: 'app/order',
                    options: {}
                })
            }else if(url.indexOf('aftersaleorder') > 0) {
                URLUtil.redirectPage({
                    page: 'app/order',
                    options: {}
                })
            }else if(url.indexOf('aftersaleorder') > 0) {
                URLUtil.redirectPage({
                    page: 'app/order',
                    options: {}
                })
            }else if(url.indexOf('orderdetail') > 0) {
                URLUtil.redirectPage({
                    page: 'app/order-detail',
                    options: {
                        orderid: URLUtil.fetchValueByURL2(url, 'orderid' )
                    }
                })
            }else if(url.indexOf('invite') > 0) {
                URLUtil.redirectPage({
                    page: 'invite',
                    options: {}
                })
            }

        }else {
            if(url.indexOf('goodsdetail') > 0) {
                window.location.href = window.location.href + '&goodsSource='+ goodsSource + "&sourceId=0"
            }else {
                window.location.href = url
            }    
        }
        
    }

    shareSet(goodsId, title, desc, img) {
        WeixinUtil.shareByPageOption({
            title: title,
            desc: desc,
            link: '/app/goodsdetail?goodsId='+ goodsId,
            imgUrl: img, // 分享的商品图标
            success: () => {
                console.log('share success')
            },
            cancel: () => {
                console.log('share cancel')
            }
        })

        this.handleClick()
    }

    addCart(goodsId, event) {
        event.stopPropagation();
        this.addCartHandle(goodsId)
    }

    addCartHandle(goodsId) {
        this.setState({
            specShow: true,
            goodsId
        })
    }


    hideSkuSelectDialog() {
        this.setState({
            specShow: false
        })
    }

    UpdataCartNum(addCartNum) {
        this.setState({
            cartNum:  this.state.cartNum + addCartNum
        })
    }
    
        /**
     * [获取购物车数量]
     * @return {[type]} [description]
     */
    fetchCartNum = () => {
        RequestUtil.fetchCartNum({
            noLogin: (num) => {
                this.setState({
                    noLogin: true,
                    cartNum: num
                })
            },
            Login: (num) => {
                this.setState({
                    cartNum: num
                })
            },
            ErrorFun: (msg) => {
                this.enter(msg)
            }
        })
        
        
    }

    handleClick() {
       document.querySelector('.m-share-modal').style.display = 'block';
    }

    /**
    * 隐藏分享模态框
    **/
    hide() {
        document.querySelector('.m-share-modal').style.display = 'none';
        
    }

    hideVideo() {
        document.querySelector('.m-video-modal').style.display = 'none';
    }
    
    handleClickVideo(picUrl, videoLink) {
        document.querySelector('.m-video-modal').style.display = 'block';
        this.setState({
            video_videoLink: videoLink,
            video_picUrl : picUrl
        })
        
    }

    statusFormatter(current, total) {
        return <span>
            <span className="current">{current}</span><span className='total'>/ {total}</span>
        </span>
    }

    
    /**
     * [getProductList description]
     * @return {[type]} [description]
     */
    getProductList(type) {
        let self = this
        let data = []
        let list_dom = null
        if(type == 3) {
            data = this.state.Floor2.items ? this.state.Floor2.items : []

            list_dom = data.map((item,i) => {
                let abs_cls = ((parseInt(i / 3) == 1 || parseInt(i / 3) == 2) && i % 3 == 0 ) ? 'abs ' : ''
                let abs_cls2 = ((parseInt(i / 3) == 1 || parseInt(i / 3) == 2) && i % 3 == 1 ) ? 'abs2 ' :'' 
                let abs_cls3 = ((parseInt(i / 3) == 1 || parseInt(i / 3) == 2) && i % 3 == 2 ) ? 'abs3 ' :'' 

                return (
                    <div className={'pro-item ' + abs_cls + abs_cls2 + abs_cls3} key={i} onClick={this.RedirectAbsoluteUrl.bind(this, item.clickLink, 3)} ref={'group' + i} >
                        <span className="num"><span>{i < 10 ? ('0'+ (i+1)) : i+1}</span></span>
                        <img src={item.imgLink} alt={item.title} className='pro_img' />
                        <div className="info">
                            <div className="title">{item.title}</div>
                            <div className="desc">{item.desc}</div>
                            <div className="price">
                                <span className="currentprice">&yen;{item.goodsPrice}</span> <span className='goodsPrice'>&yen;{item.curentPrice}</span>
                            </div>
                        </div>
                    </div>
                )
            })
        }else if(type == 4) {
            const swipeOptions = {
                continuous: true,
                transitionEnd(index, elem) {
                    self.setState({
                        banner4SlideIndex :index
                    })
                   
                }
            };

            let bannerlist = null
            if(this.state.Floor3.items) {
                bannerlist = this.state.Floor3.items.map((item, i) => {
                    return (
                        <div key={i}>
                            <div className="item pro-item" >
                                <img src={item.imgLink}  key={i} onClick={this.RedirectDetail.bind(this, item.goodsId, 4)} />
                                <div className="content" onClick={this.RedirectDetail.bind(this, item.goodsId, 4)}>
                                    <span className="tag">
                                        {item.tag}
                                    </span>
                                    <div className="title">{item.title}</div>
                                    <div className="desc">{item.desc}</div>
                                    <div className="price">&yen;{item.goodsPrice}</div>
                                   
                                </div>
                                <div className="do">
                                        <img src={ICON_CART} alt={item.title} className="cart" onClick={this.addCart.bind(this, item.goodsId, event) }/>
                                        <img src={ICON_SHARE} alt={item.title} className="share" onClick={this.shareSet.bind(this, item.goodsId, item.title, item.desc, item.imgLink)} /> 
                                        <Link to={{
                                            pathname: "/ratelist",
                                            state: { goodsId: item.goodsId }
                                        }}>
                                            <img src={HomeComment} alt={item.title} className="comment"/>{item.commentCount}
                                        </Link>
                                </div>
                                <div className="do_link">查看全部新品<img src={ICON_CHECKOUT} alt={item.title} className="icon_link"/></div>
                            </div>
                        </div>
                        
                    )
                })
                
            }
            return  (
                <div>
                    <ReactSwipe  className="mySwipe" swipeOptions={swipeOptions}>
                        {bannerlist}
                    </ReactSwipe>
                    <ReactSwipePage pageCount={this.state.Floor3.items && this.state.Floor3.items.length} pageIndex={self.state.banner4SlideIndex} ></ReactSwipePage>
                </div>
            )  
        }else if(type == 6) {
            
            const swipeOptions = {
                continuous: true,
                transitionEnd(index, elem) {
                    self.setState({
                        banner6SlideIndex :index
                    })
                   
                }
            };

            let bannerlist = null
            if(this.state.Floor5.bannerInfo) {
                bannerlist = this.state.Floor5.bannerInfo.map((item, i) => {
                    return (
                        <div key={i}>
                            <div className="item pro-item" >
                                <img src={item.imgLink} alt={item.title} onClick={this.RedirectAbsoluteUrl.bind(this, item.clickLink, 6 )}  className="imgs"/>
                                <div className="content" onClick={this.RedirectAbsoluteUrl.bind(this, item.clickLink, 6)}>
                                   {/* <div className="title">{item.title}</div>
                                    <div className="desc">{item.desc}</div>*/}
                                    <div className="do_link" onClick={this.RedirectTopic.bind(this)}>查看更多专题<img src={ICON_CHECKOUT} alt={item.title} className="icon_link"/></div>
                                    
                                </div>
                                <div className="banner_items" ref="banner_items">
                                        {
                                            item.items.map((itemGood, j) => {
                                                return (
                                                    <div key={j} className="banner_item_one" onClick={this.RedirectDetail.bind(this, itemGood.goodsId, 6)} >
                                                       <img src={itemGood.imgLink} alt={itemGood.title} />
                                                       <div className="goods_title">{itemGood.title}</div>
                                                       <div className="price">&yen;{itemGood.goodsPrice}</div>
                                                    </div>
                                                )
                                            })
                                        }

                                        <div className="banner_item_one all" onClick={this.RedirectAbsoluteUrl.bind(this, item.clickLink, 6)} >
                                            <span className="cn_all"  >查看全部</span><span className="en_all">See more</span>
                                        </div>
                                       
                                </div>
                            </div>
                        </div>
                        
                    )
                })
            }


            return  (
                <div>
                    <ReactSwipe  className="mySwipe" swipeOptions={swipeOptions}>
                        {bannerlist}
                    </ReactSwipe>
                    <ReactSwipePage pageCount={this.state.Floor5.bannerInfo && this.state.Floor5.bannerInfo.length} pageIndex={self.state.banner5SlideIndex} bottom='2.02rem'></ReactSwipePage>
                </div>
            ) 
        }else if(type == 5) {
            data = this.state.Floor4.items ? this.state.Floor4.items : []
            list_dom = data.map((item,i) => {
                return (
                        <div className="pro-item" key={i} onClick={this.RedirectDetail.bind(this,item.goodsId, 5)}>
                            <img src={item.imgLink} alt={item.title} className='pro_img' />
                            <div className="info">
                                <div className="title">{item.title}</div>
                                <div className="desc">{item.startTime.split('-')[0]+'.' + item.startTime.split('-')[1]+'.' + item.startTime.split('-')[2] }-{item.endTime.split('-')[1]+'.' + item.endTime.split('-')[2]  }送达</div>
                                <div className="price">
                                   <span className='goodsPrice'>&yen;{item.goodsPrice}</span>
                                </div>
                            </div>
                        </div>
                   
                )
            })
        }else if(type == 1) {
            let bannerlist = null
            bannerlist = this.state.Floor1.items.map((item, i) => {
                return (
                    <div key={i} className="center-car-style" onClick={this.RedirectAbsoluteUrl.bind(this, item.clickLink, 2)} >
                        <div className="imgs" style={{backgroundImage:"url("+item.imgLink+")", backgroundSize: 'cover'}}>
                            
                        </div>
                       {/* <img src={item.imgLink} />*/}
                        <div className='title'>{item.title}</div>
                        <div className='desc'>{item.desc}</div>
                    </div>
                )
            })
            list_dom = 
                <Carousel centerMode centerSlidePercentage={92} emulateTouch showArrows={false} showStatus={true} showThumbs={false} showIndicators={false} statusFormatter={this.statusFormatter.bind(this)}>
                       {bannerlist}
                </Carousel>
            // 首页今日推荐
            // const swipeOptions1 = {
            //     continuous: true,
            // };

            // let style = {
            //     container: {
            //         overflow: 'hidden',
            //         visibility: 'hidden',
            //         position: 'relative'
            //     },
            //     child: {
            //         float: 'left',
            //         position: 'relative',
            //         transitionProperty: 'transform',
            //         width: '337px',
                   
            //     },
            //     wrapper: {
            //         overflow: 'hidden',
            //         position: 'relative'
            //     },
            // }

            // let bannerlist = null
            // if(this.state.Floor1.items) {
            //     bannerlist = this.state.Floor1.items.map((item, i) => {
            //         return (
            //             <div key={i}>
            //                 <div className="item_three">
            //                     <div style={{backgroundImage:"url("+item.imgLink+")", backgroundSize: 'cover'}} key={i} className="imgs">
            //                     </div>
            //                     {/*<img src={item.imgLink}  key={i} onClick={this.RedirectUrl.bind(this, item.clickLink)} />*/}
            //                 </div>
            //             </div>
                        
            //         )
            //     })
                
            // }
            // list_dom = 
            //     <ReactSwipe  className="mySwipe" 
            //     swipeOptions={swipeOptions1} 
            //     style={style} 
            //    >
            //         {bannerlist}
            //     </ReactSwipe>
                 
            // swipes 的配置
            // let opt = {
            //     distance: 335, // 每次移动的距离，卡片的真实宽度
            //     currentPoint: 1,// 初始位置，默认从0即第一个元素开始
            //     swTouchend: (ev) => {
            //         let data = {
            //             moved: ev.moved,
            //             originalPoint: ev.originalPoint,
            //             newPoint: ev.newPoint,
            //             cancelled: ev.cancelled
            //         }
            //         console.log(data);
            //         this.setState({
            //             curCard: ev.newPoint
            //         })
            //     }
            // }

            // dom 部分
            // 第一层div
            // list_dom = 
            // <div className="card-swipe" >
            //     <ReactSwipeMany className="card-slide" options={opt}>
            //         {
            //             this.state.Floor1.items.length && this.state.Floor1.items.map((item, index) => <div className="item"></div>)
            //         }
            //     </ReactSwipeMany>
            // </div>
        }else if(type == 7) {
            const swipeOptions = {
                continuous: true,
                transitionEnd(index, elem) {
                    self.setState({
                        banner6SlideIndex :index
                    })
                   
                }
            };

            let bannerlist = null
            if(this.state.Floor6.bannerInfo) { 
                bannerlist = this.state.Floor6.bannerInfo.map((item, i) => {
                    let _pro = item.items[0] 
                    if(_pro) {
                        return (
                            <div key={i}>
                                <div className="item pro-item" >
                                    <div className="imgs" style={{background:"url("+item.imgLink+") no-repeat", backgroundSize: 'cover', backgroundPosition: 'center'}} onClick={this.RedirectAbsoluteUrl.bind(this, item.clickLink, 7)} ></div>
                                    <div className="video-desc">
                                        <div className="title">{item.title}</div>
                                        <div className="desc">{item.desc}</div>
                                        <img src={ICON_PLAY} alt={item.title}  className="m-video_play" onClick={this.handleClickVideo.bind(this,item.imgLink, item.videoLink)}/>
                                    </div>
                                    <div className="item_one" onClick={this.RedirectDetail.bind(this, _pro.goodsId, 7)}>
                                        <img src={_pro.imgLink} alt={_pro.title} />
                                        <div className="desc">
                                            <div className="title">{_pro.title}</div>
                                            <div className="price">&yen;{_pro.goodsPrice}</div>
                                        </div>

                                    </div>
                                  
                                </div>
                            </div>
                        )
                    }else {
                        return <div></div>
                    }
                    
                })
            }

            return  (
                <div>
                    <ReactSwipe  className="mySwipe" swipeOptions={swipeOptions} >
                        {bannerlist}
                    </ReactSwipe>
                    <ReactSwipePage pageCount={this.state.Floor6.bannerInfo && this.state.Floor6.bannerInfo.length} pageIndex={self.state.banner6SlideIndex} ></ReactSwipePage>
                </div>
            )
            
        }

        return list_dom
        
    }
    
    onMapAddressClick=(e)=> {
        e.stopPropagation()
        this.setState({
            mapVisiable: true
        })
    }

    onMapSelected=(loc)=> {
        this.setState({
          address: loc.address,
          mapVisiable: false,
        }) 
    }

    render() {
        return (
            <div>  
            {
                this.state.show ? 
                    <div>
                        {
                            this.state.mapVisiable ?  <MapGaode onSelected={this.onMapSelected} ></MapGaode> : 
                                <div>
                                    {/*推荐*/}
                                    <div className="m-floor1" id="map0">
                                        <div className="floor1_banner">
                                            {this.GetBanner1List()}
                                            <div onClick={this.onMapAddressClick} className="current_address">
                                                <img src={ICON_ADDR} alt={this.state.address} className="icon_addr"/>{this.state.address ? (this.state.address.length > 6 ? (this.state.address.substring(0,6) + '...') : this.state.address) : '定位失败，手动切换'}
                                            </div>
                                        </div>
                                        <div className="floor1_pro">
                                            <div className="title_header">波仔推荐</div>
                                            <div className="floor1_banner2">
                                                {this.getProductList(1)}
                                               
                                            </div>
                                        </div>
                                    </div>
                                    {/*入店必买*/}
                                    <div className="m-floor2" id="map1">
                                        <div className="floor2_banner">
                                            <LazyLoad height={200} >
                                                 {this.GetBanner2List()}

                                            </LazyLoad>
                                        </div>
                                        <div className="floor2_pro">
                                            {this.getProductList(3)}
                                        </div>
                                    </div>
                                    {/*初见尝鲜*/}
                                    <div className="m-floor3" id="map2">
                                        <div className="floor3_pro">

                                            {this.getProductList(4)}
                                            
                                        </div> 
                                    </div>
                                    {/*预售商品*/}
                                    <div className="m-floor4 " id="map3">
                                        <div className="floor4_pro clearfix">
                                            <div className="head_info">
                                                    <span className="title">{this.state.Floor4.title}</span>
                                                    <span className="time">{this.state.Floor4.deliveryTime}</span>
                                                    <span className="line"></span>
                                                    <div className="tip">{this.state.Floor4.desc}</div>
                                                    
                                            </div>
                                            {this.getProductList(5)}
                                        </div>
                                    </div>
                                    {/*不食不时*/}
                                    <div className="m-floor5" id="map4">
                                        <div className="floor5_pro">
                                            {this.getProductList(6)}

                                        </div> 
                                    </div>
                                    {/*节气餐桌*/}
                                    <div className="m-floor6" id="map5">
                                        <div className="floor6_pro">
                                                {this.getProductList(7)}

                                        </div> 
                                    </div>
                                    <HomeLastUI ></HomeLastUI>
                                    {
                                        this.state.specShow ? 
                                        <GoodsSkuSelect 
                                            AddCartSource={{
                                                goodsSource: 4,
                                                sourceId: 0
                                            }}
                                            noLogin={this.state.noLogin}
                                            isShow={this.state.specShow} 
                                            goodsId={this.state.goodsId} 
                                            hideDialog={this.hideSkuSelectDialog.bind(this)} 
                                            UpdateCartNumHandle={this.UpdataCartNum.bind(this)}
                                            ></GoodsSkuSelect>:''
                                    }
                                    <CartAndMenu cartNum={this.state.cartNum} isShowCart={false}></CartAndMenu>
                                    <HomeMenu></HomeMenu>
                                 
                                    <ShareModal hide={this.hide.bind(this)} />
                                    <VideoComponent hide={this.hideVideo.bind(this)} data={{
                                        video_picUrl: this.state.video_picUrl,
                                        video_videoLink: this.state.video_videoLink
                                    }}></VideoComponent>
                                </div>

                        }

                    </div> :  
                    <div> 
                        <Notification
                                enter={this.state.enter}
                                leave={this.leave.bind(this)}
                            >
                                {this.state.message}
                        </Notification>
                    </div>
                   
                
            }
            </div>
            
        )

    }
}
