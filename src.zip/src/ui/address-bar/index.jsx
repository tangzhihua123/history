
import React from 'react'
import Icon from 'components/Icon'

import './index.scss'

export default  function AddressBar(props) {
  const { address } = props
  let arrow = null
  if (props.onClick) {
    arrow = <span className="go-address-list">
              <Icon type="arrow" size="xxs"></Icon>
            </span>
  }
  return  (
    <div className="address-bar">
      <div className="border-container">
        <div className="contact-container" onClick={props.onClick} >
        <i className="location-icon"></i>
        {
          address ? 
          <div className="contact-info">
            <div className="user-info">
              <span className="nickname">{address.name}</span>
              <span className="phone">{address.mobile}</span>
            </div>
            <p className="address">
              {address.province + address.city + address.area + address.street + address.address}
            </p>
         </div> : <div className="contact-info"><p className="add-address">添加收货地址</p></div>
        }
        {arrow}
      </div>
      </div>
    </div>
  )
}