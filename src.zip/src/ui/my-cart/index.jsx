import React, { Component } from 'react'
import ReactDOM from 'react-dom'
import {
  BrowserRouter,
  Route
} from 'react-router-dom'
import request from 'utils/request-util'

import 'style/base.scss'
import 'style/common.scss'

import './index.scss'

import Cart from '../../ui/cart'
import CartBottom from '../../ui/cart-bottom'
import CouponBar from '../../ui/cart-bottom/coupon-bar'
import Tips from '../../ui/cart-bottom/tips'


export default class MyCart extends Component {
  constructor(props) {
    super(props)
    this.state = {
      items: [],
      sumInfo: {}
    }
  }
  fetchCartInfo() {
    request.fetch({
      data: {},
      url: '/shopping/getCartList',
      successFn: (res) => {
        this.setState({
          items: res.data.cartsList
        })
        // console.log(res)
      },
      errorFn: () => {
        
      }
    })
  }
  componentDidMount() {
    this.fetchCartInfo()
    console.log('购物车的props', this.props)
  }
  render() {
    return (
      <div className="cart-cont">
        <Cart items={this.state.items}></Cart>
        <div className="cart-bottom">
          <Tips ></Tips>
          <CouponBar></CouponBar>
          <CartBottom sumInfo={this.state.sumInfo}></CartBottom>
        </div>
      </div>
    )
  }
}
