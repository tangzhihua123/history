import React, { Component } from 'react'
import PropTypes from 'prop-types'
import RequestUtil from 'utils/request-util'
import AddToCart from 'ui/add-to-cart'
import URLUtil from 'utils/url-util'
import './item.scss'

import Cart from 'assets/Group_28@3x.png'

export default class TopicList extends Component {
    constructor(props) {
        super(props)

        this.state = {
            data: this.props.data || {},
            
        }
    }
    
    addCart() {
        this.props.addCartHandle(this.state.data.goodsId)
    }

    RedirectDetail() {
        URLUtil.redirectPage({
            page: 'app/goodsdetail',
            options: {
                goodsId: this.state.data.goodsId
            }
        })
    }


    render() {
        
        return (
            <div className='m-item' >
               
                    <div className="info" onClick={this.RedirectDetail.bind(this)}>
                        <img src={this.state.data.pictureUrl } className='imgs' alt={this.state.data.userName} />
                        {
                            this.state.data.status.trim()!='' ? 
                                <span className="coupon-flag">
                                    {this.state.data.status}
                                </span>
                            : ''
                        }
                        
                    </div>
                   
                    <div className="title">{this.state.data.title}</div>
                    <div className='price'  >
                        &yen;{ this.state.data.price }
                        <div className="m-addto-cart" onClick={this.addCart.bind(this)}>
                            <img src={Cart} alt="添加到购物车" className="icon-cart"  />
                        </div>
                    </div>
               

               
            </div>
        )
    }
}