import React, { Component } from 'react'
import PropTypes from 'prop-types'
import {
    Link
} from 'react-router-dom'
import cart from './cart.png'
import './cart-bar.scss'
export default class CartBar extends Component {
    constructor(props) {
        super(props)
        this.state = {
            cartNum: this.props.cartNum
        }
    }
    componentWillReceiveProps(nextProps) {
        this.setState({
            cartNum: nextProps.cartNum,
            saleMode: nextProps.saleMode,
            downShelfStatus: nextProps.downShelfStatus,
            init: true
        })
    }
    genCartNumDiv = () => {
        return (
            <Link to="/app/mycart">
                <div className="cart-num">
                    <div className="inner">
                        <img src={cart} className="cart-img" alt="" />
                        {
                            this.state.cartNum === 0 ? null:
                            <span className="cart-num-span">{this.state.cartNum>99?'99+':this.state.cartNum}</span>
                        }
                    </div>
                </div>
            </Link>

        )
    }
    genCartBar = () => {
        let type
        if(!this.state.init) {
            // 接口未返回商品数据的时候
            type = 0
        } else {
            let {
                    saleMode,
                    downShelfStatus
                } 
                = this.state
            // 0 普通商品
            if(saleMode === 0) {
                if(downShelfStatus === 1) {
                    type = 0
                } else if(downShelfStatus === 2) {
                    type = 1
                } else if(downShelfStatus === 3) {
                    type = 2
                }
            } else if(saleMode === 1) {
                if(downShelfStatus === 1) {
                    type = 3
                } else if(downShelfStatus === 2) {
                    type = 4
                } else if(downShelfStatus === 3) {
                    type = 4
                }
            }
        }
        switch (type) {
            /* <div className="cart-bar normal">
                {this.genCartNumDiv()}
                <div className="cart-add" onClick={this.props.addCart}>加入购物车</div>
                <div className="cart-buy" onClick={this.props.buyNow}>立即购买</div>
            </div> */
            case 0:
                return (
                    <div className="cart-bar pre-sell-end">
                        {this.genCartNumDiv()}
                        <div className="pre-sell-text" onClick={this.props.addCart}>加入购物车</div>
                    </div>
                )
            case 1:
                return (
                    <div className="cart-bar off">
                        {this.genCartNumDiv()}
                        <div className="off-text">
                            已下架
                        </div>
                    </div>
                )
            case 2:
                return (
                    <div className="cart-bar sell-out">
                        {this.genCartNumDiv()}
                        <div className="off-text">
                            已售罄
                        </div>
                    </div>
                )
            case 3:
                return (
                    <div className="cart-bar pre-sell">
                        {this.genCartNumDiv()}
                        <div className="pre-sell-text" onClick={this.props.orderNow}>
                            立即预订
                        </div>
                    </div>
                )
            case 4:
                return (
                    <div className="cart-bar pre-sell-end">
                        {this.genCartNumDiv()}
                        <div className="pre-sell-text" onClick={this.props.lookOther}>
                            查看其他预售商品
                        </div>
                    </div>
                )
            default:
                return
        }


    }
    render() {
        return (
            <div className="cart-bar-container">
                {this.genCartBar()}
            </div>
        )
    }
}

CartBar.PropTypes = {
    /**
     * type 购物篮状态
     * 0 正常状态，非预售商品
     * 1 商品下架
     * 2 商品售罄
     * 3 预订中
     * 4 预订结束
     */
    // type: PropTypes.number.isRequired,
    cartDetail: PropTypes.func.isRequired, // 点击购物车商品数量的跳转函数
    downShelfStatus: PropTypes.number, // 商品下架状态 0未到上线时间 1正常上线 2已过下架时间 3售罄
    saleMode: PropTypes.number, // 商品预售模式 0普通商品 1预售商品
    addCart: PropTypes.func, // 添加到购物车
    buyNow: PropTypes.func, // 立即购买
    orderNow: PropTypes.func, // 立即预订
    lookOther: PropTypes.func // 查看其他预售商品
}