import React, { Component } from 'react'
import PropTypes from 'prop-types'
import RequestUtil from 'utils/request-util'
import URLUtil from 'utils/url-util'

import TopicDetailList from  'ui/topic-detail-list'
import LazyLoad from 'components/Lazyload'

import "./index.scss"
import ICON_PLAY from 'assets/home_play@3x.png'
import VideoComponent from 'components/video-react/index.jsx'

import WeixinUtil from 'utils/WeixinUtil'

export default class TopicDetail extends Component {
    constructor(props) {
        super(props)
        this.state = {
            ptmId: 0,
            ptmImages: '', //专题图片/视频，单图
            ptmBanner: '',
            ptmVideo: '',//视频
            ptmName: '', // 专题名
            puImage: '', // 作者头像
            ptmContent: '' , // 专题介绍 
            Intorduction: '', // 发布人简介
            Author:'', // 发布人名称
            show: false, // 是否显示调用特定主题商品信息 
            ptmReTime: '',
        }
    }
    
    weixinShare ()  {
        let self = this
        WeixinUtil.shareByPageOption({
            title: self.state.ptmName,
            desc: 'by ' + self.state.Author + " | " + self.state.Intorduction,
            link: window.location.href,
            imgUrl: self.state.ptmImages, 
            success: () => {
                console.log('share success')
            },
            cancel: () => {
                console.log('share cancel')
            }
        })
    }

    componentDidMount() {
        this.setState({
            show: true
        })

        this.getTopicDetail()
        
        
    }
    hideVideo() {
        document.querySelector('.m-video-modal').style.display = 'none';
    }
    handleClickVideo(picUrl, videoLink) {
        document.querySelector('.m-video-modal').style.display = 'block';
        // ptmImages: '', //专题图片/视频，单图
        //     ptmVideo: '',//视频
        this.setState({
            ptmImages: videoLink,
            ptmVideo : picUrl
        })

    }
    
    /**
     * [getTopicDetail 获取专题详情]
     * @return {[type]} [description]
     */
    getTopicDetail() {
        let param = {
                data: {
                    ptmId: URLUtil.fetchValueByURL("id"),
                },
                url: '/PartnerTask/PartnerTaskList',
                successFn: (data) => {
                    this.setState({
                        ptmImages: data.data[0].ptmImages,
                        ptmBanner: data.data[0].ptmBanner,
                        ptmName: data.data[0].ptmName,
                        ptmVideo: data.data[0].ptmVideo,
                        puImage: data.data[0].puImage,
                        ptmContent: data.data[0].ptmContent,
                        Intorduction: data.data[0].Intorduction,
                        Author: data.data[0].Author,
                        ptmId: data.data[0].ptmId,
                        ptmReTime: data.data[0].ptmReTime
                    }, () => {
                        document.title = this.state.ptmName.length > 10 ? (this.state.ptmName.substring(0,10) + '...') : this.state.ptmName
                        this.weixinShare()
                    })

                   
                },
                errorFn: (error) => {
                    console.log('请求失败的错误', error)
                }
            }
        RequestUtil.fetch(param)    
    }

    render() {
        let time = this.state.ptmReTime.split(' ')[0].split('/')
        return (
            <div className="m-topic-detail">
                <div className="header">

                    <img src={this.state.ptmBanner} alt={this.state.ptmName} className="img-bg"/>
                    {this.state.ptmVideo?<img src={ICON_PLAY} className="m-video_play" onClick={this.handleClickVideo.bind(this.state.ptmImages, this.state.ptmVideo)} />:null}
                    <img src={this.state.puImage} alt="头像" className="head-icon" />
                </div>
                <div className="info_wrap">
                    <p><span className="author">{this.state.Author}</span><span className='line'> | </span><span className="desc">{this.state.Intorduction}</span></p>
                    <p className="date">{time[0] + '.'+ time[1] + '.' +time[2]}</p>
                    <p className="title">
                        {this.state.ptmName}
                    </p>
                </div>
                <div className="desc">
                    <LazyLoad height={200} >
                        <div dangerouslySetInnerHTML={{__html: this.state.ptmContent}}></div>
                    </LazyLoad>
                    
                </div>
                <div className="line"></div>
                <div className="pro-list">
                    { 

                        this.state.show ? 
                            <TopicDetailList ptmId={this.state.ptmId}></TopicDetailList> 
                        : null
                    }
                </div>
                <VideoComponent hide={this.hideVideo.bind(this)} data={{
                    video_picUrl: this.state.ptmImages,
                    video_videoLink: this.state.ptmVideo
                }}></VideoComponent>
            </div>
        )
    }
}
