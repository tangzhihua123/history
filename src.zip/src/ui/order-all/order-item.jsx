import React, { Component } from 'react'
import PropTypes from 'prop-types'
import URLUtil from 'utils/url-util'
import './order-item.scss'

// 订单状态 1. 待支付 2. 配货中 3. 配送中 4. 已完成 5. 已取消
// 6. 已关闭 

// 退款售后状态
// 1. 平台审核中 2. 退回商品  3. 撤销售后 4. 协商处理
// 5. 完成退款 6. 完成退货

const statusBtnText = {
  1: {
    status: '订单待支付', // 待支付
    btns: [
      {
        btnCls: 'btn-ghost',
        btnText: '取消订单',
        action: 'cancel'
      }, {
        btnCls: 'btn-yellow',
        btnText: '去支付',
        action: 'pay'
      }
    ]
  },
  2: {
    status: '订单待配送', // 已支付， 配货中
    btns: [
      {
        btnCls: 'btn-ghost',
        btnText: '取消订单',
        action: 'cancel'
      }
    ]
  }, 
  3: {
    status: '订单配送中', // 已支付， 配送中
    btns: [
      {
        btnCls: 'btn-primary',
        btnText: '确认收货',
        action: 'confirm'
      }
    ]
  },
  4: {
    status: '订单已完成', // 已完成，未评价
    btns: [
      {
        btnCls: 'btn-ghost',
        btnText: '评价返积分',
        action: 'comment'
      }
    ]
  },
  41: {
    status: '订单已完成', // 已完成，已评价
    btns: [
      {
        btnCls: 'btn-ghost',
        btnText: '删除订单',
        action: 'delete'
      }
    ]
  },
  5: {
    status: '订单已取消', // 取消
    btns: [
      {
        btnCls: 'btn-ghost',
        btnText: '删除订单',
        action: 'delete'
      }
    ]
  },
  6: {
    status: '订单已关闭', // 关闭
    btns: [
      {
        btnCls: 'btn-ghost',
        btnText: '删除订单',
        action: 'delete'
      }
    ]
  }
}

function getStatusObj(status) {
  return statusBtnText[status]
}

// if hell TODO: 优化
function getStatus(item) {
  if (item.orderStatus === -1) { // 已关闭
    return 6
  } else if (item.payStatus === 1) { // 已支付， 开始校验配送状态
    if (item.shipStatus === 0) { // 分拣中
      return 3
    } else if (item.shipStatus === 1) { // 已出库  
      return 2
    } else if (item.shipStatus === 2) { // 配送中
      return 3
    } else if(item.shipStatus === 3) { // 已签收
      if (item.commentStatus === 0) { // 未评价
        return 4
      } 
      return 41
    }
  } 
  return 1 // 待支付
}

export default class OrderItem extends Component {
  constructor(props) {
    super(props)
    this.state = {
      closeOrderTime: props.item.closeOrderTime || 0
    }
  }
  componentDidMount() {
    if (this.state.closeOrderTime > 0) {
      this.countDown = setInterval(()=> {
        this.setState({
          closeOrderTime: this.state.closeOrderTime - 1
        })
      }, 1000)
    }
  }
  getCountDownText(seconds) {
    const hour = Math.floor(seconds / 3600)
    let minute = Math.floor((seconds % 3600) / 60)
    let sec = seconds - 3600 * hour - 60 * minute
    let str = ''
    if (minute < 10) {
      minute = '0' + minute
    }
    if (sec < 10) {
      sec = '0' + sec
    }
    if(hour > 0) {
      str += hour + ':'
    }
    return str + minute + ':' + sec
  }
  doAction=(item, action) => {
    // TODO:
    // action 写成常量会好一点, 组件内不发起请求
    // btn 最好也是传入的
    this.props.btnAction && this.props.btnAction(item, action)
  }
  render() {
    const { item, type, onItemClick } = this.props
    const statusObj = getStatusObj(getStatus(item))
    const imgContStyle = {
      width: (item.items && item.items.length) * 0.68 + 'rem'
    }
    
    if (this.state.closeOrderTime === 0) {
      clearInterval(this.countDown)
    }
    return (
      <div className="order-item">
        <div className="order-title" onClick={onItemClick}>
          <div className="title">
            <img className="shop-icon" src={item.storeLogo}/>
            <span>{item.storeName}</span>
          </div>
          <span className="tips">
            { this.state.closeOrderTime > 0 ? statusObj.status +' (' + this.getCountDownText(this.state.closeOrderTime) + ')' : statusObj.status }
          </span>
        </div>
        <div className="order-img" onClick={onItemClick}>
          <div className="items-img-cont">
            <div className="img-scroller" style={imgContStyle}>
              {
                item.items.map((good, index)=> {
                  return <div  key={index} className="img-warpper" >
                  <img className="item-img" src={good.imageUrl} />
                  <span className="count">{"x" + good.amount}</span>
                </div>
                })
              }
            </div>
          </div>
          <div className="total-num">共{item.goodsAmount}件</div>
        </div>
        <div className="order-total">
          <div className="total">合计：¥{item.payment}</div>
          <div className="order-btns">
            {
              statusObj.btns.map((btn, index) => {
                return <span key={index} onClick={() => this.doAction(item, btn.action)}>
                  <span className={btn.btnCls}>{btn.btnText}</span>
                </span>
              })
            }
          </div>
        </div>
      </div>
    )
  }
}