import React, { Component } from 'react'
import PropTypes from 'prop-types'
import './index.scss'

import OrderItem from './order-item'

export default class OrderAll extends Component {
  constructor(props) {
    super(props)
  }
  render() {
    const { items } = this.props
    return (
      <div className="order-all">
        {this.props.children}
      </div>
    )
  }
}