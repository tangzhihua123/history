import React, { Component } from 'react'
import Request from 'utils/request-util.js'
import PropTypes from 'prop-types'
import { Link } from 'react-router-dom'

import './index.scss'

import Bg from './bgm2@2x.png'
import StatusBg from './bgm@2x.png'
import Help from './help.png'

export default class PointsLogin extends Component {
    constructor(props) {
        super(props)
        this.state = {
            login: this.props.login,
            // points: undefined,
            data: this.props.data || {}
        }
    }
    componentDidMount() {
        
    }
    // 千分位数字
    milliFormat = (num) => {  
        return num && num.toString().replace(/(?=(?!^)(\d{3})+$)/g, ',')
    }
    componentWillReceiveProps(nextProps) {
        this.setState({
            data: nextProps.data,
            login: nextProps.login
        })
    }
    render() {
        let {data} = this.state
        return (
            <div className="points-login-div">
                <div className="points-login-bg-div">
                    <img className="points-login-bg" src={Bg} alt="" />
                </div>

                <div className="status-con">
                    <img src={StatusBg} alt="" className="status-bg" />

                    {this.state.login ?
                        <div className="login-status-div">
                            <Link to="/points/pointsdes">
                                <img src={Help} className="help-img" alt="" />
                            </Link>
                            <div className="title">我的积分</div>
                            {
                                this.state.data.totalScore?
                                    <div>
                                        <div className="points-num">
                                            <div className="num">
                                                {this.milliFormat(data.totalScore)}
                                            </div>
                                        </div>
                                        <div className="detail-num">
                                            <div className="use-num">
                                                <span className="text">可用积分</span>
                                                <span className="num">{this.milliFormat(data.usableScore)}</span>
                                            </div>
                                            <div className="freeze-num">
                                                <span className="text">冻结积分</span>
                                                <span className="num">{this.milliFormat(data.lockScore)}</span>
                                            </div>
                                        </div>
                                    </div>
                                    :
                                    <div className="no">暂无积分</div>
                            }

                        </div> :
                        <div className="logout-status-div">
                            <div className="des">
                                登录查看我的积分
                        </div>
                            <div className="login-btn" onClick={this.props.loginFn}>
                                登录
                        </div>
                        </div>
                    }
                </div>
            </div>
        )
    }
}