import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Store from 'store'
import RequestUtil from 'utils/request-util'
import URLUtil from 'utils/url-util'
import Util from 'utils/util.js'
import LoadingDiv from 'components/bottom-refresh/index.jsx'
import TopicDetailListOne from 'ui/topic-list-one'
import GoodsSkuSelect  from 'ui/goods-sku-select/goods-des'
import CartAndMenu from 'ui/cart-menu'
// import addSuc from './add_cart_suc.png'

import './index.scss'

export default class TopicDetailList extends Component {
    constructor(props) {
        super(props)
        this.state = {
            loading: true, // 是否正在加载
            hasMore: false, // 是否还有数据
            list: [
            ],
            cartNum:0, //购物车数量
            noLogin: false,
        }
    }
    
    /**
     * [loadMore 分页加载更多操作]
     * @return {[type]} [description]
     */
    loadMore() {
        this.getTopicProList()
    }
    
    /**
     * [componentDidMount 初始化渲染后]
     * @return {[type]} [description]
     */
    componentDidMount() {
        this.fetchCartNum()
        this.getTopicProList()
    }

    /**
     * [获取购物车数量]
     * @return {[type]} [description]
     */
    fetchCartNum = () => {
        let param = {
            data: {
            },
            url: '/shopping/getCartGoodsAmont',
            successFn: (data) => {
                if(data.resultCode !== 2000) {
                    this.enter('获取购物车数量失败')
                    return
                }
                this.setState({
                    cartNum: data.data.count
                })
            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }
        RequestUtil.fetch(param)
        
    }

    addCart_Comm(goodsId) {
        this.setState({
            specShow: true,
            goodsId
        })
    }

    hideSkuSelectDialog() {
        this.setState({
            specShow: false
        })
    }

    UpdataCartNum(addCartNum) {
        this.setState({
            cartNum:  this.state.cartNum + addCartNum
        })
    }
    
    /**
     * [getTopicProList 获取特定主题--对应商品列表]
     * @return {[type]} [description]
     */
    getTopicProList() {
        this.setState({
            loading: true
        })

        let self  = this
        let param = {
            data: {
                ptmId: URLUtil.fetchValueByURL("id"),
            },
            url: '/PartnerTask/PartnerTaskGoodsList',
            successFn: (data) => {
                if(data.data.length == 0) {
                        this.setState({
                            hasMore: false,
                            loading: false
                        })  
                } else {
                    self.setState({
                        list: data.data,
                        hasMore: true,
                        loading: false,
                    })
                }
               
            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }
        RequestUtil.fetch(param)    
    }
    

    enter = (message) => {
        this.setState({
            enter: true,
            message: message,
        });
        setTimeout(
            function() {
                this.leave();
            }.bind(this),
            2000
        );
    }

    leave = () => {
        this.setState({
            enter: false,
            message: "",
        });
    }

     /**
     * [获取购物车数量]
     * @return {[type]} [description]
     */
    fetchCartNum = () => {
        RequestUtil.fetchCartNum({
            noLogin: (num) => {
                this.setState({
                    noLogin: true,
                    cartNum: num
                })
            },
            Login: (num) => {
                this.setState({
                    cartNum: num
                })
            },
            ErrorFun: (msg) => {
                this.enter(msg)
            }
        })
    }

    
    /**
     * [遍历商品数据列表]
     * @return {[type]} [description]
     */
    genItem = () => {
        var arr = this.state.list
        if(!Util.isArray(arr)) return
        

        var list = arr.map( (item, i) => {
            let last = false;
            if(i == (arr.length - 1)) last = true
            return (
                <TopicDetailListOne data={item} key={i} last={last} addCartHandle={this.addCart_Comm.bind(this)} />
            )
        })
        return list
    }


    render() {
        return (
            <div className="topic-list">
                {this.genItem()}
                <LoadingDiv show={this.state.loading} hasMore={this.state.hasMore}/>
                {
                    this.state.specShow ? 
                    <GoodsSkuSelect 
                        AddCartSource={{
                            goodsSource: 9,
                            sourceId: URLUtil.fetchValueByURL("id")
                        }}
                        noLogin={this.state.noLogin}
                        isShow={this.state.specShow} 
                        goodsId={this.state.goodsId} 
                        hideDialog={this.hideSkuSelectDialog.bind(this)} 
                        UpdateCartNumHandle={this.UpdataCartNum.bind(this)}
                        ></GoodsSkuSelect>:''
                }
                <CartAndMenu cartNum={this.state.cartNum}></CartAndMenu>

            </div>
        )
    }
}

