import React, { Component } from 'react'
import PropTypes from 'prop-types'
import RequestUtil from 'utils/request-util'
import URLUtil from 'utils/url-util'
import './topic-item.scss'



export default class TopicList extends Component {
    constructor(props) {
        super(props)

        this.state = {
            data: this.props.data || {}
        }
    }

    /**
     * [GotoTopicDetail 跳转到专题详情页面]
     */
    GotoTopicDetail() {
        URLUtil.redirectPage({
            page: 'topic-detail',
            options: {
                id: this.state.data.specialId
            }
        })
    }

    render() {
        return (
            <div className='m-topic-item' style={{
                    background: this.props.last ? "#fff":"#F4F4F4"
                }}>
                <a onClick={this.GotoTopicDetail.bind(this)}>
                    <div className="m-topic-item-content">
                        <div className="info">
                            <img src={ this.state.data.userHeadImage } className='header' alt={this.state.data.userName} />
                            <div className="desc">
                                <span className='uname'>{this.state.data.userName}</span> 
                                <span className="udesc">{this.state.data.userIntroduce}</span>
                            </div>
                        </div>
                        <div className="banner">
                            <img src={this.state.data.imageUrl} alt={this.state.data.title} className="imgs"/>
                        </div>
                        <div className="title">{this.state.data.title}</div>
                    </div>
                </a>
            </div>
        )
    }
}