import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Util from 'utils/util.js'
import Load from 'utils/load.js'
import RequestUtil from 'utils/request-util'
import PullToRefresh from 'utils/pulltorefresh.js'
import LoadingDiv from 'components/bottom-refresh/index.jsx'

import TopicItem from './topic-item'

import CartAndMenu from 'ui/cart-menu'


export default class TopicList extends Component {
    constructor(props) {
        super(props)

        this.state = {
            pageIndex: 1,
            pageSize: 10,
            hasMore: true,
            list: [],
            cartNum: 0,
        }
    }
    
    componentWillMount() {
        let destoryFn = this.getTopicList()
        this.setState({
            destoryFn: destoryFn
        })
       
    }

    componentDidMount() {
        this.fetchCartNum()
        let destroyScroll = this.state.hasMore ? Load.bottomLoad(this.getTopicList) : null
        this.setState({
            destroyScroll: destroyScroll
        })
    }
    
    /**
     * [getTopicList 获取专题列表]
     * @return {[type]} [description]
     */
    getTopicList= () => {
        this.setState({
            loading: true
        })

        let param = {
            data: {
                pageIndex: this.state.pageIndex,
                pageSize: this.state.pageSize,
            },
            url: '/sys/getSpecialList',
            successFn: (data) => {
                if(data.resultCode == 2000) {
                    if(data.data.list.length == 0) {
                        this.setState({
                            hasMore: false,
                            loading: false
                        })
                    }

                    else if(data.data.list.length > 0) {
                        this.setState({
                            list: this.state.list.concat(data.data.list),
                            pageIndex: this.state.pageIndex + 1,
                            hasMore: true,
                            loading: false
                            
                        })
                    }
                    
                }else if(data.resultCode == 5000) {
                    alert("网络异常，请稍后再试")
                }

               
            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }
        RequestUtil.fetch(param)    
    }

     // 下拉刷新
    pullFetch = () => {
        return new Promise((resolve, reject) => {
            this.setState({
                pageIndex: 1,
                pageSize: this.state.pageSize
            }, () => {
                let param = {
                    data: {
                        goodsId: this.state.goodsId,
                        pageIndex: this.state.pageIndex,
                        pageSize: this.state.pageSize
                    },
                    url: '/sys/getSpecialList',
                    successFn: (data) => {
                        if(data.resultCode == 2000) { 
                            if(data.data.list.length == 0) {
                                this.setState({
                                    hasMore: false,
                                    loading: false
                                })
                            }
                        }
                        else if(data.data.list.length > 0) {
                            this.setState({
                                list: data.data.list,
                                pageIndex: this.state.pageIndex + 1,
                                loading: false,
                                hasMore: true
                            })
                        }
                        resolve()
                    },
                    errorFn: (error) => {
                        console.log('请求失败的错误', error)
                    }
                }
                RequestUtil.fetch(param)
            })
        })

    }

     /**
     * [获取购物车数量]
     * @return {[type]} [description]
     */
    fetchCartNum = () => {
        RequestUtil.fetchCartNum({
            noLogin: (num) => {
                this.setState({
                    noLogin: true,
                    cartNum: num
                })
            },
            Login: (num) => {
                this.setState({
                    cartNum: num
                })
            },
            ErrorFun: (msg) => {
                this.enter(msg)
            }
        })
    }

    genItem = () => {
        var arr = this.state.list
        if(!Util.isArray(arr)) return
        

        var list = arr.map(function (item, i) {
            let last = false;
            if(i == (arr.length - 1)) last = true

            return (
                <TopicItem data={item} key={i} last={last}/>
            )
        })
        return list
    }

    render() {
        return (
            <div className="m-topic-list">
                {this.genItem()}
                <LoadingDiv show={this.state.loading} hasMore={this.state.hasMore}/>
                <CartAndMenu cartNum={this.state.cartNum} isShowCart={false}></CartAndMenu>
            </div>
        )
    }
}