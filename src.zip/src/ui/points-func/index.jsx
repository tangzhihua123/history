import React, {Component} from 'react'
import PropTypes from 'prop-types'
import {Link} from 'react-router-dom'
import Util from 'utils/util'
import './index.scss'

import PointsCost from './points_cost.png'
import PointsEarn from './points_earn.png'
import PointsList from './points_list.png'
import Award from './award@2x.png'

// 积分页面中间的功能区域

export default class Coupon extends Component {
    constructor(props) {
        super(props)
        this.state = {
            
        }
    }
    componentWillReceiveProps(nextProps) {
        
    }
    checkLogin = (e) => {
        let login = this.props.login
        console.log('login', login)
        if(!login) {
            e.preventDefault()
            Util.gotoLogin()
            return
        }
    }

    render() {
        return (
            <div className="points-func-div" onClickCapture={this.checkLogin}>
                <div className="func-list">
                    <Link to="/points/details">
                        <div className="points-list">
                            <img src={PointsList} alt="" />
                            <div className="text">积分明细</div>
                        </div>
                    </Link>
                    <Link to="/points/earn">
                        <div className="points-earn">
                            <img src={PointsEarn} alt="" />
                            <div className="text">赚积分</div>
                        </div>
                    </Link>
                    <Link to="/points/cost">
                        <div className="points-cost">
                            <img src={PointsCost} alt="" />
                            <div className="text">花积分</div>
                        </div>
                    </Link>
                </div>
                <Link to="/points/getaward" >
                    <div className="points-award">
                        <img src={Award} className="award-img" alt="" />
                    </div>
                </Link>
            </div>
        )
    }
}
