import React, { Component } from 'react'
import PropTypes from 'prop-types'
import RequestUtil from 'utils/request-util'

import './index.scss'
import INTRO from './prointro.json'

export default class MainFloor extends Component { 
    constructor(props) {
        super(props)
    }

    render() {
        let data
        data = INTRO.data.map((item, i) => {
            let ques = item.ques;
            console.log(ques)
            return ques.map((data, j) => {
                return (
                    <div key={j}>
                        <div className="title">{data.title}</div>
                        <div className="ans">
                            {
                                data.ans.map((d, k) => {
                                    return (
                                        <p key={k}>
                                            {d}
                                        </p>
                                    )
                                })
                            }
                        </div>
                    </div>
                )
            })


        })
        return (
            <div className="invite-intro-wrap">
                {data}
            </div>
        )
    }
}