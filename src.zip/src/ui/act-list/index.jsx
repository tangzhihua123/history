import React, { Component } from 'react'
import PropTypes from 'prop-types'
import store from 'store'
import lodash from 'lodash'
import Util from 'utils/util.js'
import Load from 'utils/load.js'
import RequestUtil from 'utils/request-util'
import WeixinUtil from 'utils/WeixinUtil'
import URLUtil from 'utils/url-util'
import PullToRefresh from 'utils/pulltorefresh.js'
import LoadingDiv from 'components/bottom-refresh/index.jsx'

import ActivityProductItem from './item'
import GoodsSpec from 'ui/goods-spec/goods-spec.jsx'
import GoodsSkuSelect  from 'ui/goods-sku-select/goods-des'

import CartAndMenu from 'ui/cart-menu'

import Notification from "components/Notification/NotificationBlock.jsx"

import './index.scss'


export default class TopicList extends Component {
    constructor(props) {
        super(props)

        this.state = {
            pageIndex: 1,
            pageSize: 10,
            hasMore: true,
            bannerBig: '',// 活动主图
            title: '',//活动标题
            actdesc: '',//活动描述
            amColumn: '', // 是否设置栏目（0 不设置栏目;1 设置栏目;）
            banner: [],// 栏目banner
            couponList: [
            ],

            catName: '',
            activeCate: 1, // 选中类别
            catList: [],
            list: [],

            /*购买相关*/
            cartNum: 0, //购物车数量
            noLogin: false,

            enter: false,
            message: '',
          

        }
    }


    
    componentWillMount() {
        this.GetActivityInfo()
        this.GetAjaxCouponList()
        this.fetchCartNum()

        this.getCategoryList(() => {
            let destoryFn = this.getTopicList()
            this.setState({
                destoryFn: destoryFn
            })
        })
    }

    weixinShare ()  {
        let self = this
        WeixinUtil.shareByPageOption({
            title: self.state.title,
            desc: self.state.actdesc,
            link: window.location.href,
            imgUrl: self.state.bannerBig, 
            success: () => {
                console.log('share success')
            },
            cancel: () => {
                console.log('share cancel')
            }
        })
    }

    
    /**
     * [getCategoryList 获取栏目列表]
     * @return {[type]} [description]
     */
    getCategoryList(callback) {
        let param = {
            data: {
                amid: URLUtil.fetchValueByURL("amid")
            },
            url: '/Active/ActiveColumnList',
            successFn: (data) => {
                if(data.resultCode == 2000) {
                   if(data.data.length > 0) {
                        this.setState({
                            catList: this.state.catList.concat(data.data),
                            activeCate: data.data[0].ctId,
                            catName: data.data[0].ctName,
                            banner: data.data,
                        }, () => {
                            callback && callback()
                        })
                    }
                    
                }else if(data.resultCode == 5000) {
                    // alert("网络异常，请稍后再试")
                }

               
            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }
        RequestUtil.fetch(param)    
    }
    
    /**
     * [GetActivityInfo 获取活动信息]
     */
    GetActivityInfo() {
        let param = {
            data: {
                amid: URLUtil.fetchValueByURL("amid")
            },
            url: '/Active/ActiveList',
            successFn: (data) => {
                if(data.resultCode == 2000) {
                    this.setState({
                        bannerBig: data.data[0].amTImages,
                        title: data.data[0].amTitle,
                        actdesc: data.data[0].desc,
                        amColumn: data.data[0].amColumn,
                    },() => {
                        if(this.state.amColumn == 0) {
                            this.setState({
                                banner: [{
                                    ctImages: data.data[0].amImages
                                }]
                            })
                        }
                        document.title = this.state.title.length > 10 ? (this.state.title.substring(0,10) + '...') : this.state.title 
                        this.weixinShare()
                    })
                   
                }else if(data.resultCode == 5000) {
                    alert("网络异常，请稍后再试")
                }

               
            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }
        RequestUtil.fetch(param)    
    }

    componentDidMount() {
       
        let destroyScroll = this.state.hasMore ? Load.bottomLoad(this.getTopicList) : null
        this.setState({

            destroyScroll: destroyScroll
        })
    }
    
    /**
     * [getTopicList 获取主题活动下的’最佳拍档商品列表,接口还没提供，暂时注释掉.]
     * @return {[type]} [description]
     */
    getTopicList= () => {
        this.setState({
            loading: true
        })

        let data_params = {
            pageIndex: this.state.pageIndex,
            pageSize: this.state.pageSize,
            amId: URLUtil.fetchValueByURL("amid")
        }

        this.state.amColumn == 1 ? data_params.ctId = this.state.activeCate : ''

        let param = {
            data:data_params,
            url: this.state.amColumn == 1 ? '/Active/ActiveGoodsList' : '/Active/ActiveGoodsList2',
            successFn: (data) => {
                if(data.resultCode == 2000) {
                    if(data.data.length == 0) {
                        this.setState({
                            hasMore: false,
                            loading: false
                        })  
                    }

                    else if(data.data.length > 0) {
                        this.setState({
                            list: this.state.list.concat(data.data),
                            pageIndex: this.state.pageIndex + 1,
                            hasMore: true,
                            loading: false
                            
                        })
                    }
                    
                }else if(data.resultCode == 5000) {
                    // alert("网络异常，请稍后再试")
                }

               
            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }
        RequestUtil.fetch(param)    
    }


    /**
     * [获取购物车数量]
     * @return {[type]} [description]
     */
    fetchCartNum = () => {
        RequestUtil.fetchCartNum({
            noLogin: (num) => {
                this.setState({
                    noLogin: true,
                    cartNum: num
                })
            },
            Login: (num) => {
                this.setState({
                    cartNum: num
                })
            },
            ErrorFun: (msg) => {
                this.enter(msg)
            }
        })
    }
    
    /**
     * [遍历商品数据列表]
     * @return {[type]} [description]
     */
    genItem = () => {
        var arr = this.state.list
        if(!Util.isArray(arr)) return
        

        var list = arr.map( (item, i) => {
            let last = false;
            if(i == (arr.length - 1)) last = true
            return (
                <ActivityProductItem data={item} key={i} last={last} addCartHandle={this.addCart_Comm.bind(this)} />
            )
        })
        return list
    }
    
    /**
     * [selCat 选择分类]
     * @return {[type]} [description]
     */
    selCat(catId,catName) {
        this.setState({
            catId,
            catName,
            activeCate: catId,
            list: [],
            pageIndex: 1,
        }, () => {
            this.getTopicList()
        })
    }
    
    /**
     * [获取分类数据列表]
     * @return {[type]} [description]
     */
    getCatList = () => {
        let arr = this.state.catList
        if(!Util.isArray(arr)) return

        let list = arr.map((item, i) => {
            let cls = (item.ctId == this.state.activeCate) ? "active" : ''
            return (
                <li className={cls} key={i} onClick={this.selCat.bind(this,item.ctId, item.ctName)}>{item.ctName}</li>
            )
        })

        return list
    }
    
     /**
     * [领取优惠券]
     * @param  {[type]} id [优惠券id]
     * @return {[type]}    [description]
     */
    GetAjaxCouponList = () => {
        // console.log(URLUtil.fetchValueByURL("amid"), 'ttt') // 189
        let param = {
            data: {
                amid: URLUtil.fetchValueByURL("amid")
            },
            url: '/Active/ActiveCouponList',
            successFn: (data) => {
                if(data.resultCode == 2000) {
                    if(data.data.length > 0) {
                        let _d = data.data
                        for(let i = 0 ;i<_d.length;i ++ ) {
                            _d[i].countText = "满" + _d[i].FromMoney + '使用'
                            if(_d[i].pmtType == 8) {
                                _d[i].countText = _d[i].CpnsName
                            }
                            

                        }
                        this.setState({
                            couponList: _d,
                        })
                    }
                    
                }else if(data.resultCode == 5000) {
                    this.enter("网络异常，请稍后再试")
                }

               
            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }
        RequestUtil.fetch(param)    
    }

    GetCouoponAjax(id,index) {
        let self = this
        let param = {
            data: {
                couponId: id
            },
            url: '/user/getCoupon',
            successFn: (data) => {
                if(data.resultCode == 2000) {
                    self.enter("领取成功")
                    let _couponlist = lodash.cloneDeep(this.state.couponList)
                    _couponlist[index].status = 2
                   
                    self.setState({
                        couponList: _couponlist
                    })
                }else if(data.resultCode == 5017) {
                    self.enter('领取失败，优惠券已失效')
                }else if(data.resultCode == 3005) {
                    self.enter('已领取优惠卷')
                }else if(data.resultCode == 5000) {
                    self.enter("网络异常，请稍后再试")
                }else if(data.resultCode == 4005) {
                    URLUtil.redirectPage({
                        page: 'app/login',
                        options: {
                            redirect: "/" + window.location.href.split('/')[3]
                        }
                    })
                }

               
            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }
        RequestUtil.fetch(param)    
    }
    

    /**
     * [领取优惠券]
     * @param  {[type]} id [优惠券id]
     * @return {[type]}    [description]
     */
    GetCouopon(id,index) {
        let self = this
        if(Util.isCustomAgent()) {
            try{
                JSBridge.getData({
                    type: ['token', 'userId'],
                    success: function(data) {
                        let params = store.get('user')
                        params.userId = data.userId
                        params.token = data.token
                        store.set('user', params)
                        data.userId && self.GetCouoponAjax(id,index)
                    }
                })
            }catch (err) {
                console.log(err)
            } 
        }else {
            this.GetCouoponAjax(id, index)
        } 

        
    }
    
    /**
     * [获取优惠券数据列表]
     * @return {[type]} [description]
     */
    getCouponList = () => {
        let len = this.state.couponList.length
        let arr = this.state.couponList
        
        let list = null

        if(len == 1) {
            
            list = arr.map((item, i) => {
                
                return (
                    <div className='m-coupon-one' key={i} >
                        <span className="coupon-type">
                            {
                                item.pmtType != 8 ?
                                    <div><span className="money-flag">{item.pmtType == 7 ? "¥": "" }</span>{ item.FriendlyPmtValue }</div>
                                    
                                : <img src={item.FriendlyPmtValue} alt={item.countText} className="img_pro"/>

                            }

                        </span>
                        <span className='condition'>
                            <div className="con_wrap">
                                {
                                    item.pmtType == 8 ? <span className="main-color">商品兑换券</span> : ''
                                }
                                <span className='desc'>{ item.countText }</span>
                                <span className='date'>{item.BeginTime.split(' ')[0]} - {item.EndTime.split(' ')[0]}</span>
                            </div>
                        </span>
                        {
                            item.status == 2 ? 
                                <span className='do done'>
                                   已领取 
                                </span>
                            : <span className='do' onClick={this.GetCouopon.bind(this,item.CpnsId, i)}>点击领取</span>
                        }
                        
                    </div>
                )
            })
        } else {
            list = arr.map((item, i) => {
               
                return (
                    <div className='m-coupon-many' key={i} >
                        <div className='clearfix'>
                            <span className="coupon-type">
                                {
                                    item.pmtType != 8 ?
                                        <div><span className="money-flag">{item.pmtType == 7 ? "¥": "" }</span>{ item.FriendlyPmtValue }</div>
                                        
                                    : <img src={item.FriendlyPmtValue} alt={item.countText} className="img_pro"/>

                                }
                            </span>
                            <span className='desc'>{ item.pmtType == 8 ? '商品兑换券': item.countText }</span>

                        </div>
                        <div className='date'>
                            有效期<span className="f-fr">{item.BeginTime.split(' ')[0]} - {item.EndTime.split(' ')[0]}</span>
                        </div>
                        {
                            item.status == 2 ? 
                                <div className='do done'>
                                   已领取 
                                </div>
                            : <div className='do' onClick={this.GetCouopon.bind(this,item.CpnsId, i)}>领取</div>
                        }
                        
                    </div>
                )
            })
        }

        return list
           
    }
    

    enter = (message) => {
        this.setState({
            enter: true,
            message: message,
        });
        setTimeout(
            function() {
                this.leave();
            }.bind(this),
            2000
        );
    }

    leave = () => {
        this.setState({
            enter: false,
            message: "",
        });
    }

    addCart_Comm(goodsId) {
        this.setState({
            specShow: true,
            goodsId
        })
    }

    hideSkuSelectDialog() {
        this.setState({
            specShow: false
        })
    }

    UpdataCartNum(addCartNum) {
        this.setState({
            cartNum:  this.state.cartNum + addCartNum
        })
    }

    render() {
        let banner = ''
        let catName ='' 
      
        this.state.banner.map((item, i ) => {
            if(item.ctId == this.state.activeCate) {
                banner= item.ctImages
                catName = item.ctName
            }
        })
        return (
            <div className="m-activity-list">
                <div className="big-img"><img src={this.state.bannerBig} alt= {this.state.title} /></div>
                <div className="m-coupon">
                    {this.getCouponList()}
                </div>
                {   
                    this.state.amColumn == 1 ? 
                    <div className="cat-menu">
                        <ul>
                            {this.getCatList()}
                        </ul>
                    </div> : null
                }
               
                <div className="header">
                    
                   <img src={banner} alt={catName}  />
                    
                </div>
                <div className="m-list-flex">
                    {this.genItem()}
                </div>
                <LoadingDiv show={this.state.loading} hasMore={this.state.hasMore}/>
                {
                    this.state.specShow ? 
                    <GoodsSkuSelect 
                        AddCartSource={{
                            goodsSource: 10,
                            sourceId: URLUtil.fetchValueByURL("amid")
                        }}
                        noLogin={this.state.noLogin}
                        isShow={this.state.specShow} 
                        goodsId={this.state.goodsId} 
                        hideDialog={this.hideSkuSelectDialog.bind(this)} 
                        UpdateCartNumHandle={this.UpdataCartNum.bind(this)}
                        ></GoodsSkuSelect>:''
                }
                <CartAndMenu cartNum={this.state.cartNum}></CartAndMenu>
                <Notification
                                enter={this.state.enter}
                                leave={this.leave.bind(this)}
                            >
                                {this.state.message}
                </Notification>
            </div>
        )
    }
}