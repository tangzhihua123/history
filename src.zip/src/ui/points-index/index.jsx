import React, { Component } from 'react'
import Login from 'utils/login.js'
import Request from 'utils/request-util.js'
import ReactDOM from 'react-dom'

import 'style/base.scss'
import 'style/common.scss'

import './index.scss'

import PointsLogin from 'ui/points-login/index.jsx'
import PointsFunc from 'ui/points-func/index.jsx'
import PointsList from 'ui/points-goods-list/list.jsx'

export default class PointsIndex extends Component {
    constructor(props) {
        super(props)
        this.state = {
            pageSize: 8,
            pageIndex: 1,
            list: [],
            pointsData: {},
            login: true
        }
    }
    componentDidMount() {
        this.fetchPoints()
        this.fetchGoodsList()
    }
    loginFn = () => {
        Login.gotoLogin(window.location.pathname+window.location.search)
    }
    fetchPoints = () => {
        let param = {
            data: {},
            url: '/user/myScore',
            successFn: (res) => {
                console.log('请求成功的积分数据', res)
                if(res.resultCode === 4005) {
                    this.setState({
                        login: false
                    })
                    return
                }
                this.setState({
                    pointsData: res.data
                })
            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }

        Request.fetch(param)
    }
    fetchGoodsList = () => {
        let param = {
            data: {
                pageSize: this.state.pageSize,
                pageIndex: this.state.pageIndex
            },
            url: '/user/exchangeGoodsList',
            successFn: (res) => {
                console.log('请求成功的积分数据', res)
                this.setState({
                    list: res.data
                })
            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }

        Request.fetch(param)
    }
    render() {
        return (
            <div className="points-index-page">
                <PointsLogin data={this.state.pointsData} login={this.state.login}
                    loginFn={this.loginFn}
                />
                <PointsFunc login={this.state.login}/>
                <PointsList list={this.state.list} points={this.state.pointsData.usableScore}
                    exchangeFn={this.fetchPoints}
                />
            </div>
        )
    }
}
