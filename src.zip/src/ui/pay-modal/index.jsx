
import React, {Component} from 'react'

import './index.scss'
import Icon from 'components/Icon'
import Toast from 'components/toast'

import wxLogo from './wechat@2x.png'

export default class PayModal extends Component {
  constructor(props) {
    super(props)
    this.state = {
      modalVisible: props.modalVisible
    }
  }
  componentWillReceiveProps(nextProps) {
    this.setState({
      modalVisible: nextProps.modalVisible
    })
  }
  closeModal=()=> {
    this.setState({
      modalVisible: false
    })
    this.props.onClose()
  }
  render() {
    const { modalVisible } = this.state
    const { info, onPayClick } = this.props
    return (
      <div className="pay-modal">
        <div className="modal-mask" 
          style={{
            display: modalVisible? 'block' : 'none'
          }}
        >
          <div className="modal">
            <div className="modal-title">
              <div className="modal-close" onClick={this.closeModal}>
                <Icon type="close" size="xxs"/>
              </div>
            </div>
            <div className="modal-body">
              <div className="pay-tips">
                <p className="pay-confirm-tip">确认付款</p>
                <p>￥<span className="payment">{info.money}</span></p>
              </div>
              <div className="pay-type">
                <div className="pay-by-wx" onClick={()=>onPayClick(info.orderId, 1)}>
                  <img className="pay-type-logo" src={wxLogo} />
                  <span className="pay-type-name">微信支付</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}