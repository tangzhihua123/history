import React, {Component} from 'react'
import ModalChildren from 'components/modal/modal-children.jsx'

import './points-toast.scss'

import PointsBg from './award-get-points.png'
import Close from './points-toast-close.png'

export default class PointsToast extends Component {
    constructor(props) {
        super(props)
        this.state = {
            isShow: this.props.isShow
        }
    }

    componentWillReceiveProps(nextProps) {
        console.log('show' ,nextProps.isShow)
        this.setState({
            isShow: nextProps.isShow
        })
    }

    render() {
        return (
            <ModalChildren 
                isShow={this.state.isShow}
                clickBgHide={true}
                hideFn={this.props.hideFn}
            >
                <div className="points-toast-con">
                    <img src={Close} className="close-img" onClick={this.props.hideFn} alt=""/>
                    <div className="des">
                        <div className="p1">天空一声巨响</div>
                        <div className="p2">宝物已经落入袋中</div>
                    </div>
                    <div className="points-img-div">
                        <img src={PointsBg}  className="points-20" alt=""/>
                        <div className="points-num-div">
                            <div className="points-number">{this.props.points}</div>
                            <div className="points-text">积分</div>
                        </div>
                        
                    </div>
                </div>
            </ModalChildren>
            
        )
    }
    
}