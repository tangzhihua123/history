import React, {Component} from 'react'
import PropTypes from 'prop-types'
import './coupon-item.scss'

export default class CouponItem extends Component {
    constructor(props) {
        super(props)
        this.state = {
            img: this.props.img
        }
    }
    render() {
        return (
            <div className="points-toast-coupon">
                <div className="circle left-circle"></div>
                <div className="circle right-circle"></div>
                <div className="left">
                    {
                        this.props.img ?
                        <img className="left-img" src={this.props.data.left} alt=""/>:
                        this.props.money?
                        <div className="money-div">
                            <span className="rmb"></span>
                            <span className="num">¥{this.props.data.left}</span>
                        </div>:
                        <span className="text">{this.props.data.left}</span>
                    }
                </div>
                <div className="right">
                    {
                        this.props.data.title?
                        <div className="title">{this.props.data.title}</div>:null
                    }
                    <div className="des-text">{this.props.data.des}</div>
                    <div className="date">{this.props.data.date}</div>
                </div>
            </div>
        )
    }
}
CouponItem.propTypes = {
    img: PropTypes.bool, // 表示左侧是否是图片
    data: PropTypes.object, // 数据
    money: PropTypes.bool, // 是否是现金优惠券
    /**
     * data.left 左侧的文本或者图片链接, 如果是金额，不要带人民币符号
     * data.title 右侧第一行文本
     * data.des 右侧第二行文本
     * data.date 右侧第三行文本，代表日期
     */
}