import React, {Component} from 'react'
import ModalChildren from 'components/modal/modal-children.jsx'
import Coupon from './coupon-item.jsx'

import './coupon-toast.scss'

import Points20 from './points-20.png'
import Close from './points-toast-close.png'

export default class CouponToast extends Component {
    constructor(props) {
        super(props)
        this.state = {
            isShow: this.props.isShow
        }
        console.log('优惠券数据', this.props)
    }

    componentWillReceiveProps(nextProps) {
        console.log('show' ,nextProps.isShow)
        this.setState({
            isShow: nextProps.isShow
        })
    }
    getData = () => {
        let data = this.props.data
        let left
        switch(data.couponType) {
            case 4:
                left = '免邮券'
                break;
            case 6:
            case 2:
                left = data.awardTicketText
                break;
            case 7:
                left = data.awardTicketText
                break;
            case 8:
                left = data.awardTicketImg
                break;
        }
        let obj = {
            left: left,
            title: data.sence,
            des: data.awardTicketTag,
            date: data.awardTicketEfficient
        }
        return obj
    }
    lookCoupon = () => {
        location.href = '//'+location.host + '/app/couponlist'
    }
    render() {

        return (
            <ModalChildren 
                isShow={this.state.isShow}
                clickBgHide={true}
                hideFn={this.props.hideFn}
            >
                <div className="coupon-toast-con">
                    <img src={Close} onClick={this.props.hideFn} className="close-img" alt=""/>
                    <div className="des">
                        <div className="p1">恭喜你</div>
                        <div className="p2">成功获得优惠券</div>
                    </div>
                    <div className="coupon-list">
                        <Coupon 
                            img={this.props.data.couponType ===8}
                            money={(this.props.data.couponType === 7)}
                            /* data={{
                                left: 'https://www.baidu.com/img/bd_logo1.png',
                                title: '新人专享',
                                des: '全场6折',
                                date: '2017.01.01-2017.02.01'
                            }} */
                            data = {this.getData()}
                        />
                    </div>
                    
                    <div className="points-look-div" onClick={this.lookCoupon}>查看</div>
                </div>
            </ModalChildren>
            
        )
    }
    
}