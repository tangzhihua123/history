import React, {Component} from 'react'
import PropTypes from 'prop-types'
import ModalChildren from 'components/modal/modal-children.jsx'
import Notification from "components/Notification/NotificationBlock.jsx"
import Request from 'utils/request-util.js'
import BlankImg from 'assets/goods_default_300.jpg'
import './coupon-exchange.scss'

import Close from './points-toast-close.png'

export default class CouponToast extends Component {
    constructor(props) {
        super(props)
        this.state = {
            isShow: this.props.isShow,
            data: this.props.data
        }
    }

    componentWillReceiveProps(nextProps) {
        console.log('show' ,nextProps.isShow)
        this.setState({
            isShow: nextProps.isShow,
            data: nextProps.data
        })
    }
    enter = (message) => {
        this.setState({
            enter: true,
            message: message,
        });
        setTimeout(
            function() {
                this.leave();
            }.bind(this),
            2000
        );
    }

    leave = () => {
        this.setState({
            enter: false,
            message: "",
        });
    }
    
    exchange = () => {
        this.props.buyAjax && this.props.buyAjax()
    }
    render() {
        console.log('this.state', this.state)
        let {data} = this.state
        return (
            <ModalChildren 
                isShow={this.state.isShow}
                clickBgHide={true}
                hideFn={this.props.hideFn}
            >
                <div className="coupon-exchange-con">
                    <img src={Close} onClick={this.props.hideFn} className="close-img" alt=""/>
                    <div className="exchange-goods-div">
                        <img src={data.goodsImage || BlankImg} className="ex-goods-img" alt=""/>
                        <div className="ex-goods-title">{data.goodsName}</div>
                        <div className="ex-goods-date">{data.expiries}</div>
                    </div>
                    <div className="ex-des">
                        <div className="ex-des-con">
                            {data.desc}
                        </div>
                    </div>
                    <div className="ex-div">
                        <div className="points">{data.goodsScore}积分</div>
                        <div className="ex-btn" onClick={this.exchange}>立即兑换</div>
                        <div className="ex-suc-des">兑换成功后请去【我的优惠券】查看</div>
                    </div>
                    <Notification
                        enter={this.state.enter}
                        leave={this.leave.bind(this)}
                    >
                        {this.state.message}
                    </Notification>
                </div>
            </ModalChildren>
            
        )
    }
}
CouponToast.propTypes = {
    hideFn: PropTypes.func.isRequired,
    isShow: PropTypes.bool.isRequired,
    data: PropTypes.object.isRequired,
    buyAjax: PropTypes.func.isRequired
}