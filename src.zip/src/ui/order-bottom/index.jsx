import React, {Component} from 'react'
import classnames from 'classnames'
import './index.scss'
import Toast from 'components/toast'


export default class OrderBottom extends Component {
  onSummitClick=()=> {
    const { canSubmit, onSubmit, errorMsg } = this.props
    if (canSubmit) {
      onSubmit()
    } else {
      // 提示出错
        if(errorMsg!="") {
            Toast.show(errorMsg, 1.5, false)
        }
    }
  }
  render() {
    const { price, freightFee, canSubmit, onSubmit } = this.props
    const btncls = classnames({
        'submit-order-btn': true,
        'available': canSubmit,
        disable: !canSubmit
    })
    return (
        <div className="order-bottom">
            <div className="order-sum-info">
                <div className="order-fee-sum">
                    <div>应付总额:<span className="sum">¥{price}</span></div>
                    <div className="description">含配送费¥{freightFee}</div>
                </div>
            </div>
            <div className={btncls} onClick={this.onSummitClick}>
                提交订单
            </div>
        </div>
    ) 
    }
}