import React, { Component } from 'react'
import PropTypes from 'prop-types'
import store from 'store'
import URLUtil from 'utils/url-util'
import Util from 'utils/util'
import LazyLoad from 'components/Lazyload'
import JSBridge from 'utils/JSBridge'
import icon_cart from 'assets/Group_28@3x.png'
import './index.scss'

export default class TopicDetailListOne extends Component {
    constructor(props) {
        super(props)
        this.state = {
            goodsId: this.props.data.goodsId
        }
    }

    addCart(event) {
        let self = this
        event.stopPropagation();

        /*FIXED ME: 客户端打开购物用户打通处理*/
        if(Util.isCustomAgent()) {
            try{
                JSBridge.getData({
                    type: ['token', 'userId'],
                    success: function(data) {
                        // console.log(store.get('user'), 222222)
                        let params = store.get('user') ? store.get('user') : {}
                        params.userId = data.userId
                        params.token = data.token
                        store.set('user', params)
                        data.userId && self.props.addCartHandle(self.state.goodsId)
                        // console.log(store.get('user'),11111)
                    }
                })
            }catch (err) {
                console.log(err)
            }
            
        } else {
            self.props.addCartHandle(self.state.goodsId)
        }
        
    }
    
    /**
     * [RedirectDetail 跳转到商品详情页面，需要判断来源]
     * @param {[type]} event [description]
     */
    RedirectDetail(event) {
        URLUtil.RedirectDetail(this.state.goodsId, 9, URLUtil.fetchValueByURL("id") )
    }

    render() {
        let self = this
        let {
            mpId,
            productId,
            goodsId,
            ptmId,
            Thumbnail_Pic,
            GoodsName,
            mpTitle2,
            mpTitle,
            mpDesc,
            GoodsPrice,
        } = this.props.data

        return (
            <div className='m-topic-pro-one'>
                <div className="imgs">
                    <a onClick={this.RedirectDetail.bind(this)}>
                        <LazyLoad height={200}>
                            <img src={Thumbnail_Pic} alt=""/>
                        </LazyLoad>
                        <div className="price">
                            ¥{GoodsPrice}  |  查看详情
                        </div>
                        <div className='add-cart' onClick={this.addCart.bind(this)}>
                            <img src={icon_cart} alt="购物车" />
                        </div>
                    </a>
                </div>
                <div className='title'>{mpTitle}</div>
                <div className='one-desc'>{mpTitle2}</div>
                <div className='one-content' dangerouslySetInnerHTML={{__html: mpDesc}}></div>
            </div>
        )
    }
}