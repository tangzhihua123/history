import React, {Component} from 'react'
import PropTypes from 'prop-types'
import './rate-item.scss'

import {goodsStatus as rateData} from 'data/rate/rate-img.js'
import DefaultImg from 'assets/goods_default_170.png'

export default class RateItem extends Component {
    constructor(props) {
        super(props)
        this.state = {
            data: this.props.data || {}
        }
    }
    genImgList = () => {
        var arrStr = this.state.data.pictures
        if(!arrStr) return
        if(!arrStr) {
            return null
        }

        var arr = arrStr.split(',').filter((item) => {
            return !!item
        })
        
        var list = arr.map(function(item, i) {
            return (
                <img src={item} alt="" key={i}/>
            )
        })
        return (
            <div className="img-list">
                {list}
            </div>
        )
    }
    render() {
        let score = this.state.data.score
        return (
            <div className="rate-item">
                <div className="item-head">
                    <img src={this.state.data.userHeadImage || DefaultImg} alt="" className="head-img"/>
                    <div className="name-div">
                        <div className="name">{this.state.data.userNickName}</div>
                        <div className="date">{this.state.data.commentTime}</div>
                    </div>
                </div>
                <div className="main-rate-div">
                    <div className="rate-status">
                        <img src={rateData[score-1].img} alt="" className="status-img"/>
                        <div className="text">{rateData[score-1].text}</div>
                    </div>
                    <div className="rate-des-div">
                        <div className="des">
                            {this.state.data.content}
                        </div>
                        {this.genImgList()}
                    </div>
                </div>
            </div>
        )
    }
}
RateItem.propTypes = {
    data: PropTypes.object
}