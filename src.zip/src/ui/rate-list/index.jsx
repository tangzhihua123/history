import React, { Component } from 'react'
import PullToRefresh from 'utils/pulltorefresh.js'
import Request from 'utils/request-util.js'
import Util from 'utils/util.js'
import Load from 'utils/load.js'
import PropTypes from 'prop-types'
import RateItem from './rate-item'
import LoadingDiv from 'components/bottom-refresh/index.jsx'
import './index.scss'

import Loading from 'assets/main_loading.gif'
import NoRate from './no_rate@2x.png'


export default class RateList extends Component {
    constructor(props) {
        super(props)
        this.state = {
            pageIndex: 1,
            pageSize: 10,
            commentsData: [],
            goodsId: this.props.location.state.goodsId,
            hasMore: true
        }
    }

    componentWillMount() {
        console.log('test import')

    }
    componentWillUnmount() {
        this.state.destroyRefresh && this.state.destroyRefresh()
        this.state.destroyScroll && this.state.destroyScroll()
    }
    setHeight = (cla) => {
        let ele = document.querySelector(cla)
        if (ele) ele.style.minHeight = window.screen.availHeight + 'px'
    }
    componentDidMount() {
        this.setHeight('.rate-list')
        this.fetchCommentsList()

        let destroyRefresh = PullToRefresh.initWarp(this.pullFetch)
        let destroyScroll = Load.bottomLoad(this.fetchCommentsList)
        this.setState({
            destroyRefresh: destroyRefresh,
            destroyScroll: destroyScroll
        }, () => {
            console.log('初始化完成的state', this.state)
        })

        console.log('测试路由属性', this.props)
        

    }
    // 下拉刷新
    pullFetch = () => {
        return new Promise((resolve, reject) => {
            this.setState({
                pageIndex: 1,
            }, () => {
                let param = {
                    data: {
                        goodsId: this.state.goodsId,
                        pageIndex: this.state.pageIndex,
                        pageSize: this.state.pageSize
                    },
                    url: '/goods/commentsList',
                    successFn: (data) => {
                        console.log('请求成功的评论数据', data)
                        this.setState({
                            commentsData: data.data.list,
                            pageIndex: this.state.pageIndex + 1,

                        })
                        console.log('resolve 执行')
                        resolve()
                    },
                    errorFn: (error) => {
                        console.log('请求失败的错误', error)
                    }
                }
                Request.fetch(param)
            })
        })

    }
    fetchCommentsList = () => {
        console.log('加载评价列表页')
        if(this.state.loading) {
            return
        }
        if(!this.state.hasMore) {
            this.setState({
                loading: true
            })
            return
        }
        this.setState({
            loading: true
        })
        
        let param = {
            data: {
                goodsId: this.state.goodsId,
                pageIndex: this.state.pageIndex,
                pageSize: this.state.pageSize
            },
            url: '/goods/commentsList',
            successFn: (data) => {
                console.log('请求成功的评论数据', data)
                if(data.data.list.length < this.state.pageSize) {
                    this.setState({
                        hasMore: false
                    })
                }
                this.setState({
                    commentsData: this.state.commentsData.concat(data.data.list), // data.data.list,
                    pageIndex: this.state.pageIndex + 1,
                    loading: false
                })
            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }

        /* this.setState({
            commentsData: this.state.commentsData.concat(data),
            pageIndex: this.state.pageIndex + 1
        }) */
        Request.fetch(param)
    }

    genItem = () => {
        var arr = this.state.commentsData
        if (!Util.isArray(arr)) return


        var list = arr.map(function (item, i) {
            return (
                <RateItem data={item} key={i} />
            )
        })
        return list
    }

    render() {
        return (
            <div className="rate-list">
                {
                    this.state.commentsData.length === 0 ?
                    this.state.loading ? 
                        <div className="no-rate-div">
                            <img  className="blank_loading_img" src={Loading} alt=""/>
                        </div>:
                        <div className="no-rate-div">
                            <img src={NoRate} className="no-rate-img" alt="" />
                            <div className="no-rate-text">竟然一条评价都没有~</div>
                        </div> :

                        <div>
                            {this.genItem()}
                            {<LoadingDiv show={this.state.loading} hasMore={this.state.hasMore}/>}
                        </div>
                }

            </div>
        )
    }
}
// GoodsDes.PropTypes = {

// }