import React, { Component } from 'react'
import PropTypes from 'prop-types'
import { Link } from 'react-router-dom'
import classnames from 'classnames'
import './index.scss'


export default class CartBottom extends Component {
  constructor(props) {
    super(props)
  }
  render() {
    const { totalAmount, totalCheckedCount, totalPmtAmount } = this.props.sum
    const { freightPrice } = this.props.freight
    const { couponCode, onCheckClick, checked, isLogin } = this.props
    let link
    if (isLogin) {
      link = couponCode ? `/app/order-confirm?couponCode=${couponCode}` : 
      "/app/order-confirm"
    } else {
      link = '/app/login?redirect=' + location.pathname + location.search
    }

    const checkboxClass = classnames({
      'select-all': true,
      'selected': checked,
      'unselected': !checked
    })

    return (
      <div className="settlement">
        <div className="cart-info">
          <div className={checkboxClass} onClick={onCheckClick}>
            <p>全选</p>
          </div>
          <div className="cart-sum">
            <div>合计:<span className="sum">¥{totalAmount}</span></div>
            <div className="description">
              <span>已优惠:¥{totalPmtAmount}</span>
              <span>含配送费:¥{freightPrice}</span>
            </div>
          </div>
        </div>
        {
          totalCheckedCount > 0 ?
            <Link to={link}>
              <div className="settlement-btn available">
                结算<span>({totalCheckedCount})</span>
              </div>
            </Link> :
            <div className="settlement-btn disable">
              结算<span></span>
            </div>
        }
      </div>
    )
  }
}

CartBottom.propTypes = {

}