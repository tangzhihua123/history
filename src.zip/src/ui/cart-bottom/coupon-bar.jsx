import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import PropTypes from 'prop-types'
import classnames from 'classnames'

import './coupon-bar.scss'



export default class CouponBar extends Component {
  constructor(props) {
    super(props)
  }
  render() {
    const { couponList, isChecked, onCheckClick } = this.props
    const toCounponList = {
      pathname: '/app/couponselect',
      state: { couponList: couponList }
    }
    const checkboxClass = classnames({
      'select-coupon': true,
      'selected': isChecked, // 外部的isChecked按钮
      'unselected': !isChecked,
    })

    let checkedCoupon = {}
    if (couponList.length > 0) {
      couponList.map(function(item) {
        if (item.isChecked) {
          checkedCoupon = item
        }
      })
    }

    return couponList.length > 0 ? (
      <div className="coupon-bar">
        <div className="coupon-title">
          <i className={checkboxClass} onClick={onCheckClick}></i>
          <p>优惠券</p>
        </div>
        <Link to={toCounponList}>
          <div className="coupon-type">
            {
              isChecked ? <p>{checkedCoupon.title}</p> : <p className="coupon-count">{couponList.length}张可用</p>
            }
            <i className="icon-arrow-yellow"></i>
          </div>
        </Link>
      </div>
    ) : null
  }
}

CouponBar.propTypes = {}