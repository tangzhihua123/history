import React, { Component } from 'react'
import PropTypes from 'prop-types'
import { Link } from 'react-router-dom'
import './tips.scss'


// TODO: 改造成function 组件
export default class Tips extends Component {
  constructor(props) {
    super(props)
  }
  render() {
    const { freight, totalAmount } = this.props
    return (
      <div className="tips">
        {
          freight.freightPrice > 0 ? (<Link className="tips-content" to="/app/post-free">
            <p>再购￥{freight.freightFree -
              totalAmount}免配送费</p>
            <i className="icon-arrow-white"></i>
          </Link>) : (
              <p className="tips-content">{freight.freightFreeTipMsg}</p>
            )
        }
      </div>
    )
  }
}

Tips.propTypes = {}