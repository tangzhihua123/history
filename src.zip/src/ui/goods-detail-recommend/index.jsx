import React, { Component } from 'react'
import Line from './line-2.png'
import Util from 'utils/util.js'

import './index.scss'

import Default from 'assets/goods_default_170.png'

export default class GoodsRecommend extends Component {
    constructor(props) {
        super(props)
        this.state = {}
    }
    jumpGoodsDetail = (goodsId) => () => {
        Util.gotoPage({
            page: '/app/goodsDetail',
            options: {
                goodsId: goodsId
            }
        })
    }
    /* shouldComponentUpdate(nextProps) {
        console.log('equal', nextProps.list !== this.props.list)
        if(nextProps.list !== this.props.list) {
            return true
        } else {
            return false
        }
    } */
    genList = () => {
        let data = this.props.list,
            list = []
            /* data = [
                {
                    goodsId: 1234,
                    goodsTitle:"商品",
                    goodsImageUrl:"http://res.51flashmall.com/resource/images/photo/7031/small/20171027/201710271550302.jpg",
                    price:100
                },
                {
                    goodsId: 1234,
                    goodsTitle:"商品",
                    goodsImageUrl:"http://res.51flashmall.com/resource/images/photo/7031/small/20171027/201710271550302.jpg",
                    price:100
                },
                {
                    goodsId: 1234,
                    goodsTitle:"商品",
                    goodsImageUrl:"",
                    price:100
                }
            ] */
        if(Util.isArray(data)) {
            list = data.map((item, i) => {
                return (
                    <div className="recommend-item" onClick={this.jumpGoodsDetail(item.goodsId)}>
                        <img src={item.goodsImageUrl || Default} className="recommend-item_img" alt=""/>
                        <div className="recommend-item_title">{item.goodsTitle}</div>
                        <div className="recommend-item_price">¥{item.price}</div>
                    </div>
                )
            })
        }

        return list
    }

    render() {
        let isArray = Util.isArray(this.props.list) && this.props.list.length > 0
        if(isArray) {
            return (
                <div className="goods-recommend">
                    <div className="detail-title">
                        <span><img className="line-img" src={Line} alt="" /></span>
                        <span className="title-span">四季推荐</span>
                        <span><img className="line-img" src={Line} alt="" /></span>
                    </div>
                    <div className="recommend-list">
                        {this.genList()}
                    </div>
                </div>
                )
        } else {
            return null
        }
        
    }
}

// export default () => {
//     return <div>Hello</div>
// }