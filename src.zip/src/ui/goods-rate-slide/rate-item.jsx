import React, {Component} from 'react'
import PropTypes from 'prop-types'
import {goodsStatus as status} from 'data/rate/rate-img.js'

import './rate-item.scss'
import DefaultImg from './1-1@2x.png'
import pic1 from './1-1@2x.png'
import pic2 from './1-2@2x.png'
import pic3 from './1-3@2x.png'
import pic4 from './1-4@2x.png'
import pic5 from './1-5@2x.png'

import Default from 'assets/goods_default_170.png'

export default class RateItem extends Component {
    constructor(props) {
        super(props)
        this.state = {
            rate: this.props.data.score - 1,
            data: this.props.data || {}
        }
    }
    render() {
        let imgUrl = this.state.data.imgList.split(",")[0]
        
        return (
            

            <div className="goods-detail-rate-item">
                <div className="img-div">
                    <img src={imgUrl||Default} alt="" />
                </div>
                <div className="des-div">
                    <div className="title-div">
                        <div className="name-div">
                            <img src={this.state.data.userHeadImg} className="head-img" alt="" />
                            <div className="name">{this.state.data.userNickName}</div>
                        </div>
                        <div className="rate-div">
                            <div className="rate-img"><img src={status[this.state.rate].img} /></div>
                            <div className="rate-text">{status[this.state.rate].text}</div>
                        </div>
                    </div>
                    <div className="des">
                        {this.state.data.commentContent}
                    </div>
                </div>
            </div>
        )
    }
}
RateItem.propTypes = {
    isBlank: PropTypes.bool, // 是否是空白内容，在无评价的时候显示
    /**
     * data的key
     * @param {string} nick 用户昵称
     * @param {string} rateDes 评价的内容
     * @param {number} rate 评分
     * @param {string} headUrl 头像url
     * @param {string} rateImgUrl 评价图片url
     */
    data: PropTypes.object // 轮播的数据
    
}
