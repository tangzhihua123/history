import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Util from 'utils/util.js'
import {
    BrowserRouter as Router,
    Route,
    Link
} from 'react-router-dom'
import Slider from 'components/Slide'
import SliderItem from 'components/Slide/SliderItem'
import RateItem from './rate-item.jsx'

import './index.scss'
import Right from './right.png'






export default class GoodsRateSlider extends Component {
    constructor(props) {
        super(props)
        this.state = {
            data: this.props.data,
            goodsId: this.props.data.goodsId
        }
    }

    componentWillReceiveProps(nextProps) {
        this.setState({
            data: nextProps.data
        })
    }
    onAction = (index, direction) => {
        console.log('激活的幻灯片编号：', index, '，滚动方向：', direction);
    }
    genSlider = () => {
        let items = [],
            comments = this.state.data.comments
        if (Util.isArray(comments) && comments.length !== 0) {
            items = comments.map(function (item, i) {
                return (
                    <SliderItem>
                        <RateItem isBlank={true} data={item} />
                    </SliderItem>
                )
            })
        } else {
            return
        }
        return (
            <div className="rate-slider-container">
                <Slider onAction={this.onAction} autoPlay={false}>
                    {/* <SliderItem>
                        <RateItem isBlank={true}/>
                    </SliderItem>
                    <SliderItem>
                        <RateItem data={{nick: '123'}}/>
                    </SliderItem>
                    <SliderItem>
                        <RateItem data={{nick: '123'}}/>
                    </SliderItem> */}
                    {items}
                </Slider>
            </div>
        )


    }
    render() {
        let amount = this.state.data.amount
        return (
            <div className="goods-rate-slide">
                <div className="rate-slide-title">

                    <div className="title">买家评价{(amount || amount === 0) ? '(' + amount + ')' : ''}</div>

                    <Link to={{
                        pathname: "/app/ratelist",
                        state: { goodsId: this.state.goodsId }
                    }}>
                        <div className="look">
                            <span className="text">查看全部</span>
                            <img src={Right} alt="" />
                        </div>
                    </Link>
                </div>
                {this.genSlider()}
            </div>
        )
    }
}

GoodsRateSlider.PropTypes = {
    data: PropTypes.object // 数据
}