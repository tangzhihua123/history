import React, { Component } from 'react'
import PropTypes from 'prop-types'
import { Link } from 'react-router-dom'
import URLUtil from 'utils/url-util'
import './index.scss'
import Toast from 'components/toast'
import Icon from 'components/Icon'

const config = [
  {
    text: '地址管理',
    cls: 'address',
    'to': '/app/address-list',
    needLogin: true
  },
  {
    text: '邀请返现',
    cls: 'invite',
    'to': '../invite',
    needLogin: false
  },
  {
    text: '客服与帮助',
    cls: 'service',
    'to': '../help',
    needLogin: false
  },
  {
    text: '设置',
    cls: 'setting',
    'to': '/app/setting',
    needLogin: true
  }
]


export default class Setting extends Component {
  constructor(props) {
    super(props)
  }
  onItemClick=(index)=> {
    const { isLogin } = this.props
    const item = config[index]
    if (item.needLogin && !isLogin) {
      Toast.show('请先登录', 1, false)
      return 
    }
    window.location.href = item.to
  }
  render() {
    // 写死。。。
    const { inviteText = '' } = this.props
    return (
      <div className="setting-cont">
        {
          config.map((item, index)=> {
            return (
              <div key={index} className={"setting-item " + item.cls} onClick={() => this.onItemClick(index)}>
                <div>{item.text}</div>
                <Icon type="arrow" size="xxs"></Icon>
              </div>
            )
          }) 
        }
      </div>
    )
  }
}
