import React, {Component} from 'react'
import ModalChildren from 'components/modal/modal-children.jsx'
import './share-modal.scss'

export default class ShareModal extends Component {
    constructor(props) {
        super(props)
        this.state = {
            isUsed: false,
            isShow: this.props.isShow,
            data: this.props.data,
        }
    }
    componentWillReceiveProps(nextProps) {
        this.setState({
            isShow: nextProps.isShow,
        })
    }
    render() {
        return (
            <ModalChildren
                isShow={this.state.isShow}
                clickBgHide={true}
                canScroll={false}
                hideFn={this.props.hideFn}
            >
                <div className="visitShare-modal">
                    <div className="visitShare-modal-title">
                        注册成功!
                    </div>
                    <div className="visitShare-modal-list">
                        相应优惠奖励已到账
                    </div>
                    <div className="visitShare-modal-close">
                        可在"我的-优惠券"中查看
                    </div>
                    <div className="visitShare-modal-bottom">
                        <div className="flex1 goLook" onClick={this.props.goLook}>去看看</div>
                        <div className="flex1 isKnow" onClick={this.props.hideFn}>知道了</div>
                    </div>
                </div>
            </ModalChildren>
        )
    }
}
