import React, { Component } from 'react'
import qs from 'query-string'
import {
    Redirect
} from 'react-router-dom'
import PropTypes from 'prop-types'
import Util from 'utils/util.js'
import URLUtil from 'utils/url-util'
import Request from 'utils/request-util.js'
import NotificationBlock from 'components/Notification/NotificationBlock.jsx'
import VisitShareRegisterModal from 'ui/visit-share-register-modal/share-modal.jsx'


import './login.scss'
import Logo from './login_logo@2x.png'
import Agree from './login_agree@2x.png'
import Disagree from './login_disagree@2x.png'
import QQ from './login_qq@2x.png'
import Weibo from './login_weibo@2x.png'
import Weixin from './login_weixin@2x.png'
import Clear from './login_clear@2x.png'
import Bg from './bg.jpg'
import store from 'store'


export default class Login extends Component {
    constructor(props) {
        super(props)
        this.state = {
            agree: true,
            phone: '',
            // code: 123456,
            getCode: false,
            redirect: false,
            time: 60,
            totalTime: 10,
            init: true,
            code: '',
            validCode: false,
            isShow:false,//注册成功弹出框是否显示，默认不显示
        }
    }
    onPhoneChange = (e) => {
        let value = e.target.value
        if ((value + '').length >= 11) {
            value = (value + '').slice(0, 11)
        }
        this.setState({
            phone: value
        }, () => {
            if (/1[\d]{10}/.test(this.state.phone)) {
                this.setState({
                    validPhone: true
                })
            } else {
                this.setState({
                    validPhone: false
                })
            }
        })
    }
    onCodeChange = (e) => {
        let value = e.target.value
        if ((value + '').length >= 4) {
            value = (value + '').slice(0, 4)
        }
        this.setState({
            code: value
        }, () => {
            if (/[\d]{4}/.test(this.state.code)) {
                this.setState({
                    validCode: true
                })
            } else {
                this.setState({
                    validCode: false
                })
            }
        })
    }
    clearPhone = () => {
        this.setState({
            phone: ''
        })
    }
    clearCode = () => {
        this.setState({
            code: ''
        })
    }
    handleLogin = () => {
        // console.log('phone', this.state.phone)
        if (!this.state.phone) {
            this.enter('请输入手机号')
            return
        } else if (!this.state.validPhone) {
            this.enter('手机号不正确，请重新输入')
            return
        } else if (!this.state.code) {
            this.enter('请输入验证码')
            return
        } else if (!this.state.validCode) {
            this.enter('请输入正确的验证码')
            return
        } /* else if (!this.state.agree) {
            this.enter('请同意用户协议')
            return
        } */
        this.isNewUser();
        // LoginUtil.login({
        //     mobile: this.state.phone,
        //     verifyCode: this.state.code,
        //     successFn: (res) => {
        //         // console.log(res)
        //         if (res.resultCode === 2000) {
        //             store.set('user', {
        //                 userId: res.data.userId,
        //                 loginName: res.data.loginName,
        //                 token: res.data.token,
        //                 memberCode: res.data.code,
        //                 nickName: res.data.nickName
        //             })
        //             /* this.setState({
        //                 redirect: true
        //             }) */
        //             let redirect = qs.parse(location.search).redirect
        //             let loc = window.location
        //             if(redirect) {
        //                 window.location.href = loc.protocol + "//" + loc.host + redirect
        //             } else {
        //                 window.location.href = loc.protocol + "//" + loc.host + '/'
        //             }
        //         } else {
        //             this.enter('登录失败，请重试')
        //         }
        //
        //     },
        //     errorFn: (err) => {
        //         console.log(err)
        //         this.enter('登录失败')
        //     }
        // })

    }
    isNewUser = () => {
        let param = {
            data: {
                mobile: this.state.phone,//被邀请人登录名（手机号）
                verifyCode:this.state.code,//验证
                belongOne : URLUtil.fetchValueByURL("vid"),//邀请人id
                // byquser:0,//被邀请人id(测试)
                packageId : URLUtil.fetchValueByURL("imCpkId2"),//被邀请人礼包id
                belongpackageId :  URLUtil.fetchValueByURL("imCpkId"),//邀请人礼包id
                imid : URLUtil.fetchValueByURL("imid"),//邀请返现活动id

            },
            url: '/User/login',//判断是否是新用户接口
            successFn: (res) => {
                if (res.resultCode==2000) {
                        store.set('user', {
                            userId: res.data.userId,
                            loginName: res.data.loginName,
                            token: res.data.token,
                            memberCode: res.data.code,
                            nickName: res.data.nickName,
                            faceLink: res.data.faceLink,
                            gender:res.data.gender,
                            birthday:res.data.birthday
                        })
                        this.getNewUserList();
                }else {
                    this.enter(res.resultMsg)
                }

            },
            errorFn: (error) => {
                this.enter('请求失败的错误')
            }
        }
        Request.fetch(param)
    }
    getNewUserList = () =>{
        let param = {
            data: {
                cpkid : URLUtil.fetchValueByURL("imCpkId"),
                type: 1,
            },
            url: '/Active/NewUserReceiveCoupon',//判断是否是新用户接口
            successFn: (res) => {
                let data = res.data;
                if (data==2) {
                    //如果是新用户走下面接口，领取优惠券，否则提示不是新用户不能领取
                    this.setState({
                        isShow:true
                    })
                } else if (data==1) {
                    this.enter('已领取',true)
                }else if (data==3) {
                    this.enter('领取失败')
                } else {
                    this.enter('领取失败')
                }

            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
                this.enter('领取失败')
            }
        }
        Request.fetch(param)
    }
    getVerifyCodeAjax = () => {
        if (!this.state.validPhone) {
            if (!this.state.phone) {
                this.enter('请输入手机号')
                return
            }
            this.enter('手机号不正确，请重新输入')
            return
        }
        let param = {
            data: {
                mobile: this.state.phone,
                sceneType: 1
            },
            url: '/sys/sendVerifyCode',
            successFn: (data) => {
                if(data.resultCode === 2000) {
                    this.enter(<div>
                        <div>验证码已发送到您的手机</div>
                        <div>5分钟内有效</div>
                    </div>)
                    this.setState({
                        getCode: true,
                        init: false
                    })
                }
                
            },
            errorFn: (error) => {
                this.enter('登陆失败，请重试')
            }
        }
        this.setState({
            getCode: true,
            init: false
        })
        this.setTimeInterval()
        Request.fetch(param)

    }
    enter = (message,isGoHome) => {
        this.setState({
            enter: true,
            message: message
        });
        setTimeout(
            function () {
                this.leave(isGoHome);
            }.bind(this),
            2000
        );
    }

    leave = (isGoHome) => {
        this.setState({
            enter: false,
            message: ""
        });
        if(isGoHome) {
            setTimeout(URLUtil.redirectPage({
                page: 'home',
                options: { },
            }),5000000)
        }
    }
    setTimeInterval = () => {
        let time = this.state.time
        let interval = setInterval(() => {
            if (time <= 0) {
                clearInterval(interval)
                this.setState({
                    time: this.state.totalTime,
                    getCode: false
                })
            } else {
                time--
                this.setState({
                    time: time
                })
            }
        }, 1000)

    }
    genVerifyBtn = () => {
        if (!this.state.getCode && this.state.init) {
            return (
                <span className={"get-code"}
                    onClick={this.getVerifyCodeAjax}
                >获取验证码</span>
            )
        } else {
            if (this.state.getCode && this.state.time > 0) {
                console.log('大于0')
                return (
                    <span className={"get-code" + ' gray'}
                    >{'重新获取'}({this.state.time}s)</span>
                )
            } else {
                return (
                    <span className={"get-code"}
                        onClick={this.getVerifyCodeAjax}
                    >{'重新获取'}</span>
                )
            }
        }
    }
    /* triggerAgree = () => {
        this.setState({
            agree: !this.state.agree
        })
    } */
    hideModal = () => {
        console.log("hideModal----")
        this.setState({
            isShow: false
        })
        URLUtil.redirectPage({
            page: 'home',
            options: { },
        })
    }
    goLook = () => {
        console.log("goLook----")
        this.setState({
            isShow: false
        })
        URLUtil.redirectPage({
            page: 'app/couponlist',
            options: { },
        })
        // let redirect = qs.parse(location.search).redirect
        // let loc = window.location
        // if(redirect) {
        //     window.location.href = loc.protocol + "//" + loc.host + redirect
        // } else {
        //     window.location.href = loc.protocol + "//" + loc.host + '/'
        // }
    }
    render() {
        let inputType = Util.isIOS() ? "number" : "tel"
        // const { from } = this.props.location.state || { from: { pathname: '/' } }
        let phoneClear = { visibility: this.state.phone ? 'visible' : 'hidden' },
            codeClear = { visibility: this.state.code ? 'visible' : 'hidden' }
        // console.log('from', from)
        return (this.state.redirect ? <Redirect to={{ ...from, state: { login: true } }}></Redirect> :
            <div className="login-box">
                <img src={Bg} alt="" className="login-bg-img" />
                <div className="login-container-div">
                    <img src={Logo} alt="" className="logo-img" />
                    <div className="phone-input-div">
                        <input type="text"
                            type={inputType}
                            pattern="\d*"
                            className="phone-input"
                            onChange={this.onPhoneChange}
                            value={this.state.phone}
                            placeholder="请输入手机号" />
                        <div className="clear-con">
                            <img src={Clear}
                                style={phoneClear}
                                onClick={this.clearPhone}
                                className="clear-phone" alt="" />
                        </div>



                    </div>
                    <div className="ver-code-div">
                        <input type="text" className="ver-input"
                            onChange={this.onCodeChange}
                            type={inputType}
                            pattern="\d*"
                            value={this.state.code}
                            placeholder="请输入验证码" />
                        <img src={Clear}
                            style={codeClear}
                            className="clear-code"
                            onClick={this.clearCode}
                            alt="" />
                        {
                            this.genVerifyBtn()
                        }

                    </div>
                    <div className="submit-div" onClick={this.handleLogin}>确 定</div>
                    <div className="agreement-div">
                        {/* <div className="agree">
                            {
                                this.state.agree ?
                                    <img src={Agree} className="agree-img" alt="" /> :
                                    <img src={Disagree} className="disagree-img" alt="" />
                            }

                        </div>
                        <span className="s1" onClick={this.triggerAgree}>同意</span>
                        <span className="s2">用户协议</span> */}
                        <div className="agree">用户注册登录即表示同意《用户协议》</div>
                    </div>
                    {/* <div className="login_imgs">
                        <img src={Weixin} alt="" className="weixin" />
                        <img src={QQ} alt="" className="qq" />
                        <img src={Weibo} alt="" className="weibo" />
                    </div>*/}
                </div>

                <NotificationBlock enter={this.state.enter} leave={this.leave}>
                    {this.state.message}
                </NotificationBlock>
                {this.state.isShow?(
                    <VisitShareRegisterModal  isShow={true} hideFn={this.hideModal} goLook={this.goLook}></VisitShareRegisterModal>
                ):null}


            </div>
        )
    }
}

Login.propTypes = {
    // 重定向到/app/login后，如果带有?redirect=*，则登陆后跳转回去，否则跳到/根路径
    loginCb: PropTypes.func, //登录成功后执行的回调，控制路由跳转
    logoutCb: PropTypes.func, //注销后执行的回调，控制路由跳转
}