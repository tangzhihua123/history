import React, {Component} from 'react'
import Login from 'utils/login.js'
import Load from 'utils/load.js'
import Request from 'utils/request-util.js'
import PointsGoodsList from 'ui/points-goods-list/list.jsx'
import LoadingDiv from 'components/bottom-refresh/index.jsx'

import './index.scss'

export default class PointsCost extends Component {
    constructor(props) {
        super(props)
        this.state = {
            pageSize: 10,
            pageIndex: 1,
            list: [],
            end: false
        }
    }
    componentDidMount() {
        
    }
    componentWillMount() {
        this.fetchGoodsList()
        this.fetchPoints()

        let destroyScroll = Load.bottomLoad(() => {
            this.fetchGoodsList()
        })

        this.setState({
            destroyScroll: destroyScroll
        })
    }

    componentWillUnmount() {
        this.state.destroyScroll && this.state.destroyScroll()
    }

    fetchGoodsList = () => {

        if(this.state.end) {
            return
        }
        this.setState({
            loading: true
        })
        let param = {
            data: {
                pageSize: this.state.pageSize,
                pageIndex: this.state.pageIndex
            },
            url: '/user/exchangeGoodsList',
            successFn: (res) => {
                
                let stateObj = {
                    list: this.state.list.concat(res.data),
                    pageIndex: this.state.pageIndex + 1,
                    loading: false
                }
                if(res.data.length < this.state.pageSize) {
                    stateObj.end = true
                    stateObj.loading = true
                }

                this.setState(stateObj)
            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }

        Request.fetch(param)
    }
    fetchPoints = (type) => {
        
        let param = {
            data: {},
            url: '/user/myScore',
            successFn: (res) => {
                if(res.resultCode === 4005) {
                    Login.gotoLogin(window.location.pathname+window.location.search)
                    return
                }
                this.setState({
                    usableScore: res.data.usableScore,

                })
            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }

        Request.fetch(param)
    }

    render() {
        return (
            <div className="points-cost-container">
                <div className="list-title">
                    <span className="text">我的积分</span>
                    <span className="num">{this.state.usableScore}</span>
                </div>
                <PointsGoodsList list={this.state.list}
                    points={this.state.usableScore}
                    exchangeFn={this.fetchPoints}
                    showFooter={false}
                    />
                {<LoadingDiv show={this.state.loading} hasMore={!this.state.end}/>}
            </div>
        )
    }
}