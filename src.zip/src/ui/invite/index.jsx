import React, { Component } from 'react'
import PropTypes from 'prop-types'
import store from 'store'
import RequestUtil from 'utils/request-util'
import WeixinUtil from 'utils/WeixinUtil'
import URLUtil from 'utils/url-util'
import './index.scss'
import INVITE from './invite_bg@2x.png'
import Group_9 from './Group_9@3x.png'
import SHARE from 'assets/share.png'
import Util from 'utils/util.js'


export default class MainFloor extends Component { 
    constructor(props) {
        super(props)
        this.state = {
            imid: 0, //id
            imCpkd: 0,
            imCpkd2: 0,
            imContent: '',
            imyqDesc: '',
            imbyqDesc: '',
        }
    }
    
    weixinShare ()  {
        let self = this
      
        WeixinUtil.shareByPageOption({
            title: '送你一大波新人好礼',
            desc: '好友'+ store.get('user').loginName + '邀你注册可获得'+ self.state.imbyqDesc + '新人礼,点击马上开抢',
            link: '/visit-share?vid=' + store.get('user').userId + "&ut="+store.get('user').token,
            imgUrl: RequestUtil.getSharePagePrefix() + SHARE, // 分享图标
            success: () => {
                console.log('share success')
            },
            cancel: () => {
                console.log('share cancel')
            }
        })
    }

    componentDidMount() {
        this.GetIntro()
        
    }

    /**
     * [GetIntro 获取邀请返现基本信息]
     */
    GetIntro() {
        let param = {
            data: {},
            url: '/Active/InvitationList',
            successFn: (data) => {
                if(data.resultCode == 2000) {
                    this.setState({
                        imCpkd:data.data.imCpkId,
                        imCpkd2: data.data.imCpkd2,
                        imid:data.data.imid,
                        imContent: data.data.imContent,
                        imyqDesc: data.data.imyqDesc,
                        imbyqDesc: data.data.imbyqDesc
                    })
                    this.weixinShare()
                }else if(data.resultCode == 5000) {
                    alert("网络异常，请稍后再试")
                }

               
            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }
        RequestUtil.fetch(param)    
    }
    
    
    RediectIntro() {
        URLUtil.redirectPage({
            page: 'intro',
            options: {
                type: 'share'
            }
        })
    }
   
    render() {
        return (
            <div className="invite-wrap">
                <div className="intro" onClick={this.RediectIntro.bind(this)}>玩法介绍</div>
                <img src={INVITE} alt="邀请返现"  className="invite_logo"/>
                <div className="title">{this.state.imyqDesc}</div>
                <div className="desc">{this.state.imbyqDesc}</div>
                {Util.isWeixin() ?(
                    <div className="btn-share" onClick={this.RediectShare.bind(this)}>立即分享</div>
                ): null}

               {/* <div className="count-title"><img src={Group_9}  className="icon_group"/>本周累计获得<img src={Group_9} className="icon_group rotate"/></div>
                <div ><span className="count">230</span>元</div>
                <div className="btn-invite">邀请记录</div>*/}

            </div>
        )
    }
}