import React, { Component } from 'react'
import PropTypes from 'prop-types'
import './index.scss'


export default class OrderGoods extends Component {
  constructor(props) {
    super(props)
  }
  render() {
    const { item, status } = this.props
    const itemImgStyle = {
      'backgroundImage': `url(${item.pictureUrl})`
    }
    return (
      <div className="goods-item">
        <div className="goods-item-cont">
          <div className="img-cont" style={itemImgStyle}></div>
          <div className="item-detail">
            <p className="item-title">{item.title}</p>
            <p className="item-price">¥{item.price}</p>
            <div className="item-unit">{item.sku}</div>
            <p className="item-num">x{item.amount}</p>
            {this.props.children}
          </div>
        </div>
      </div>
    )
  }
}

OrderGoods.propTypes = {

};