import React from 'react'
import getStatus from './config.js'
import './index.scss'

export default function OrderProcess(props) {
  const status = props.status || ''
  const statusObj = getStatus(status)
  // <Steps current={-1} direction="horizontal" size="small" className="timeline">
  //   <Step title="Now" description="Buy" icon={<span className="fake-icon" />} />
  //   <Step title="Nov. 3rd" description="Buy success" icon={<span className="fake-icon" />} />
  //   <Step title="Nov. 4th" description="Profit arrival" icon={<span className="fake-icon" />} />
  // </Steps>

  return (
    <div className="order-process">
      <div className="order-status">
        <img className="status-pic" src={statusObj.img} />
        <div className="status-desc">
          <p className="title">{statusObj.title}</p>
            {statusObj.desc.indexOf('<br>')>-1?(
                statusObj.desc.split('<br>').map(function (el, index) {
                    return (<div key={index} className="content">
                            <p className="desc">{el}</p>
                        </div>
                    )
                })
            ):(<p className="desc">{statusObj.desc}</p>)}
        </div>
      </div>
      <div className="order-flowsheet">

      </div>

    </div>
  )
}