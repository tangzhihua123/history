
export default function getStatus(status)  {
  return orderStatus[status] || {
    title: '',
    desc: '',
  }
}

const orderStatus = {
  // 待支付
  unpay: {
    title: '订单待支付',
    desc: '',
    img: require('./img/order_unpay@2x.png')
  },
  // 已关闭
  closed: {
    title: '订单已关闭',
    desc: '订单未付款，超时自动关闭',
    img: require('./img/order_closed@2x.png')
  },
  // 配货
  prepare: {
    title: '订单配货中',
    desc: '店员正在努力为您准备商品',
    img: require('./img/order_unpay@2x.png')
  },
  shipping: {
    title: '订单配送中',
    desc: '骑手火速配送中',
    img: require('./img/order_unpay@2x.png')
  },
  complete: {
    title: '订单已完成',
    desc: '订单已为您送到，期待您再次光临',
    img: require('./img/order_unpay@2x.png')
  },
  // 已取消
  cancel: {
    title: '订单已取消',
    desc: '订单已取消，付款金额将原路退回'
  },
  // 审核中
  check: {
    title: '平台审核中',
    desc: '您的售后申请正在审核中<br>如过超过24小时未处理将自动通过审核',
    img: require('./img/order_unpay@2x.png')
  },
  // 换货
  exchange: {
    title: '完成换货',
    desc: '售后服务已完成<br>如有疑问请联系客服400-000-000'
  },
  // 退回
  return: {
    title: '退回商品',
    desc: '配送员将在2小时内上门取货，<br>请您准备好商品（含商品、赠品、完整包装）'
  },
  // 售后撤销
  after_sale_canel: {
    title: '售后撤销',
    desc: '您的售后申请已撤销',
img: require('./img/order_unpay@2x.png')
  },
  // 协商处理
  consult: {
    title: '协商处理',
    desc: '您的售后申请已协商处理'
  },
  // 退款
  refund: {
    title: '完成退款',
    desc: '售后服务已完成<br>如有疑问请联系客服400-000-000'
  },
    // 退款中
    refunding: {
        title: '退款中',
        desc: '正在退款中...',
        img: require('./img/order_unpay@2x.png')
    },
    refuse_sell_after: {
        title: '拒绝售后',
        desc: '商家拒绝售后',
        img: require('./img/order_unpay@2x.png')
    },
    refuse_sell_after_complete: {
        title: '售后完成',
        desc: '售后完成',
        img: require('./img/order_unpay@2x.png')
    },
    refuse_sell_after_close: {
        title: '售后关闭',
        desc: '售后关闭',
        img: require('./img/order_unpay@2x.png')
    },
    wait_buyers_returnGood: {
        title: '等待买家退货',
        desc: '等待买家退货',
        img: require('./img/order_unpay@2x.png')
    },
    wait_buyers_confirm: {
        title: '买家退货等待确认',
        desc: '买家退货等待确认',
        img: require('./img/order_unpay@2x.png')
    }
}
