import React from 'react'
import SplitLine from 'components/split-line'

import './index.scss'

export default function OrderFee(props) {
  const { fees = [], payment } = props
  return (
    <div className="apply-after-detail-info">
      <div>
        {
            // 售后申请中 = 0,退款中 = 1,拒绝售后 = 2,退款成功 = 3,售后已取消 = 4,等待买家退货 = 5,买家退货等待确认 = 6,售后完成 = 7,售后关闭 = 8
          fees.map(function (el, index) {
              let {applyType,pictureUrls,reason} = el
              let type= ""
              if(applyType ==1) {
                  type = '退货退款'
              }else {
                  type = '退货退款'
              }
              if(reason=='0') {
                  reason = "商品质量问题"
              }else if(reason=='1') {
                  reason = "商品与页面描述不符"
              }else if(reason=='1') {
                  reason = "收到商品损坏"

              }else if(reason=='1') {
                  reason = "发货错误"

              }else if(reason=='1') {
                  reason = "未收到货，不想要了"

              }
              let pictureArr = pictureUrls.split(",")
              return (<div key={index} >
                    <div className="fee-item">
                        <div className="content">
                            <div className="applydetailInfo">
                                <span className="title">售后方式:</span>
                                <span className="text">{type}</span>
                            </div>
                            <div className="applydetailInfo">
                                <span className="title">售后原因:</span>
                                <span className="text">{reason}</span>
                            </div>
                            <div className="applydetailInfo">
                                <span className="title">申请数量:</span>
                                <span className="text">{el.num}</span>
                            </div>
                            <div className="applydetailInfo">
                                <span className="title">申请金额:</span>
                                <span className="text">{el.price}</span>
                            </div>
                            <div className="applydetailInfo">
                                <span className="title">问题描述:</span>
                                <span className="text">{el.issue}</span>
                            </div>
                            <div className="applydetailInfo">
                                <div className="title">上传凭证:</div>
                                <div className="pic">
                                    {
                                        pictureArr.map((pic, i) => {
                                            return (
                                                <img key={i} src={pic} className="imgs" />
                                            )
                                        })
                                    }
                                </div>

                            </div>

                            {el.type==3?(
                                <div>
                                    <div className="applydetailInfo">
                                        <span className="title">实际退款金额:</span>
                                        <span className="text">{el.money}</span>
                                    </div>
                                    <div className="applydetailInfo">
                                        <span className="title">退款差额:</span>
                                        <span className="text">0</span>
                                    </div>
                                    <div className="applydetailInfo">
                                        <span className="title">差额原因:</span>
                                        <span className="text">无</span>
                                    </div>
                                    <div className="applydetailInfo">
                                        <span className="title">到账时间:</span>
                                        <span className="text">平台确认退款金额后，退款1-7个工作日退回原支付账户</span>
                                    </div>
                                </div>
                            ):null
                            }
                        </div>
                    </div>
                </div>
                )
          })
        }
      </div>
    </div>
  )
}