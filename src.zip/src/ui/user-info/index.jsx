import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import Util from 'utils/util'
import './index.scss'
import Icon from 'components/Icon'
import store from 'store'
import HeardImg from './img/my_Avatar@2x.png'
export default class Userinfo extends Component {
  constructor(props) {
    super(props)
    this.state = {
      heardImg: HeardImg,
    }
  }
  onCouponClick = () => {
    const { history } = this.props
    history.push('/app/couponlist')
  }
  onRateClick = () => {
    location.href = '../points'
  }

  gotoLogin = () => {
    Util.gotoLogin()
  }
  componentDidMount() {
    const user = store.get('user') || {}
    if (user.faceLink) {
      this.setState({
        heardImg: user.faceLink,
      })
    }
  }
  render() {
    const {
      couponCount,
      userScore
    } = this.props.info
    const loginFlag = this.props.nickName.length > 0
    console.log(this.props)
    console.log(loginFlag)
    const { cartCount, nickName } = this.props
    return (
      <div>
        <div className="user-info-cont">
          <div className="header-toolbar">
            <a href="../home">
              <div className="icon-go-index"> </div>
            </a>
            <div className="r-area">
              <Link to="/app/mycart">
                <div className="icon-shop-cart">
                  <div className="cart-count-cont">
                    {
                      cartCount ? <span className="cart-count">{cartCount > 99 ? '99+' : cartCount}</span> : null
                    }
                  </div>
                </div>
              </Link>
              <a href="../cate">
                <div className="icon-go-i"></div>
              </a>
            </div>
          </div>
          <div className="content">
            <div className="flex-cont">
              <div>
                <div className="avatar" style={{ backgroundImage: 'url(' + this.state.heardImg + ')' }}></div>
              </div>
              {
                loginFlag ? <div className="">
                  <div className="nick-name">
                    {nickName || ''}
                  </div>
                  <div className="vip-code" onClick={this.props.onMemberCodeClick}>
                    会员专属码
                </div>
                </div> : <div className="">
                    {/*<Link to="/app/login">*/}
                    <div className="btn-login" onClick={this.gotoLogin.bind(this)}>登录</div>
                    {/*</Link>*/}
                  </div>
              }
            </div>
          </div>
        </div>
        <div className="boons-cont">
          <div className="boon-item" onClick={this.onCouponClick}>
            <div>
              {
                couponCount ? <span><span className="number">{couponCount}</span>
                  <span>张</span></span> : null
              }
              <span>优惠券</span>
            </div>
            <Icon type="arrow" size="xxs"></Icon>
          </div>
          <div className="boon-item" onClick={this.onRateClick}>
            <div className="split">
              {
                userScore ? <span className="number">{userScore}</span> : null
              }
              <span>积分</span>
            </div>
            <Icon type="arrow" size="xxs"></Icon>
          </div>
        </div>
      </div>
    )
  }
}