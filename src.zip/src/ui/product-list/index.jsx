import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Util from 'utils/util.js'
import Load from 'utils/load.js'
import Store from 'store'
import RequestUtil from 'utils/request-util'
import PullToRefresh from 'utils/pulltorefresh.js'
import URLUtil from 'utils/url-util'
import LoadingDiv from 'components/bottom-refresh/index.jsx'
import GoodsSpec from 'ui/goods-spec/goods-spec.jsx'
import CartAndMenu from 'ui/cart-menu'
import addSuc from './add_cart_suc.png'
import ActivityProductItem from './item'

import './index.scss'


export default class TopicList extends Component {
    constructor(props) {
        super(props)

        this.state = {
            pageIndex: 1,
            pageSize: 10,
            hasMore: true,
            catId: this.props.id, // 父级栏目id
            catType:URLUtil.fetchValueByURL("catType"),
            catName: '', // 选择栏目名称
            activeCate: 0, // 选中类别
            catList: [ 
            ],
            list: [],
            cartNum:0, //购物车数量

            /*购买相关*/
            goodsId: 0,
            goodsData: {},
            specShow: false,
            skuSpecType: 'add',
            selectSkuData: {},//选择sku 数据

        }
    }
    
    componentWillMount() { 
        document.title = URLUtil.fetchValueByURL("title")
        this.GetCategoryData()
        this.fetchCartNum()
    }

    componentDidMount() {
        let destroyScroll = this.state.hasMore ? Load.bottomLoad(this.getTopicList) : null
        this.setState({
            destroyScroll: destroyScroll
        }, () => {
            // console.log('初始化加载完成的state', this.state)
        })

        console.log('测试路由属性', this.props)
    }
    
    /**
     * [getTopicList 获取主题活动下的’最佳拍档商品列表,接口还没提供，暂时注释掉.]
     * @return {[type]} [description]
     */
    getTopicList= () => {
        this.setState({
            loading: true
        })


        let param = {
            data: {
                pageIndex: this.state.pageIndex,
                pageSize: this.state.pageSize,
                catId: this.state.activeCate,
                catType: this.state.catType,
            },
            url: '/goods/goodsList',
            successFn: (data) => {
                if(data.resultCode == 2000) {
                    if(data.data.list.length == 0) {
                        this.setState({
                            hasMore: false,
                            loading: false
                        })  
                    }

                    else if(data.data.list.length > 0) {
                        this.setState({
                            list: this.state.list.concat(data.data.list),
                            pageIndex: this.state.pageIndex + 1,
                            hasMore: true,
                            loading: false
                            
                        })
                    }
                    
                }else if(data.resultCode == 5000) {
                    alert("网络异常，请稍后再试")
                }

               
            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }
        RequestUtil.fetch(param)    
    }
   
    /**
     * [遍历商品数据列表]
     * @return {[type]} [description]
     */
    genItem = () => {
        var arr = this.state.list
        if(!Util.isArray(arr)) return
        

        var list = arr.map( (item, i) => {
            let last = false;
            if(i == (arr.length - 1)) last = true

            return (
                <ActivityProductItem data={item} key={i} last={last}  index={i} addCartHandle={this.addCart.bind(this)}/>
            )
        })
        return list
    }
    
    /**
     * [selCat 选择分类]
     * @return {[type]} [description]
     */
    selCat(catId,catName) {
        this.setState({
            catName,
            activeCate: catId,
            list: [],
            pageIndex: 1,
        }, () => {
            this.getTopicList()
        })
       

    }
    
    GetCategoryData = () => {
        let param = {
            data: {
                catId: this.state.catId,
                catType: this.state.catType,
            },
            url: '/goods/goodsSubCategory',
            successFn: (data) => {
                if(data.resultCode == 2000) {
                   if(data.data.list.length > 0) {
                        this.setState({
                            catList: data.data.list,
                            catName: data.data.list[0].title,
                            activeCate: data.data.list[0].catId,

                        })
                        
                        
                    }else {
                        this.setState({
                            catList: data.data.list,
                            catName: '',
                            activeCate: this.state.catId,

                        })
                      
                    }
                      let destoryFn = this.getTopicList()
        
                        this.setState({
                            destoryFn: destoryFn
                        })
                    
                }else if(data.resultCode == 5000) {
                    alert("网络异常，请稍后再试")
                }

               
            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }
        RequestUtil.fetch(param)    
    }
    /**
     * [获取分类数据列表]
     * @return {[type]} [description]
     */
    getCatList = () => {
        let arr = this.state.catList
        if(!Util.isArray(arr)) return

        let list = arr.map((item, i) => {
            let cls = (item.catId == this.state.activeCate) ? "active" : ''
            return (
                <li className={cls} key={i} onClick={this.selCat.bind(this,item.catId, item.title)}>{item.title}</li>
            )
        })

        return list
    }
    
     /**
     * [获取购物车数量]
     * @return {[type]} [description]
     */
    fetchCartNum = () => {
        RequestUtil.fetchCartNum({
            noLogin: (num) => {
                this.setState({
                    noLogin: true,
                    cartNum: num
                })
            },
            Login: (num) => {
                this.setState({
                    cartNum: num
                })
            },
            ErrorFun: (msg) => {
                this.enter(msg)
            }
        })
       
        
    }

    /**
     * [addToCart 添加到购物车]
     */
    addCart(goodsId) {
        this.fetchGoodsData(goodsId, () => {
            this.setState({
                specShow: true,
                goodsId: goodsId,
            })
        })
    }

     /**
     * [获取商品详细数据]
     * @return {[type]} [description]
     */
    fetchGoodsData = (goodsId) => {
        let param = {
            data: {
                goodsId
            },
            url: '/goods/goodsInfo',
            successFn: (data) => {
                console.log('dtata', data)
                this.setState({
                    goodsId: goodsId,
                    goodsData: data.data,
                    specShow: true,
                })

                
            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }
        RequestUtil.fetch(param)
    }

    hideGoodsSpec = () => {
        this.setState({
            specShow: false,
            // goodsId: 0,
        })
    }
    enter = (message) => {
        this.setState({
            enter: true,
            message: message,
        });
        setTimeout(
            function() {
                this.leave();
            }.bind(this),
            2000
        );
    }

    leave = () => {
        this.setState({
            enter: false,
            message: "",
        });
    }

    addCartAjax = () => {
        let data = {
            goodsId: this.state.goodsId,
            productId: this.state.selectSkuData.productId,
            count: this.state.selectSkuData.num,
            isChecked: 1,
            goodsSource: 11,
            sourceId: 0,
        }

        if(this.state.noLogin) {
            // 未登陆
            let cartList = Store.get('cartList')
            if (!Util.isArray(cartList)) {
                cartList = []
            }

            let same
            cartList.some((item, i) => {
                if(item.productId === data.productId) {
                    cartList[i] = {
                        ...item,
                        count: item.count + data.count
                    }
                    same = true
                }
            })
            if(!same) {
                cartList.push(data)
            }
            
            Store.set('cartList', cartList)

            this.enter(
                <div className="add-cart-suc">
                    <img src={addSuc} className="add-cart-img" alt="" />
                    <p>加入购物车成功！</p>
                </div>
            )

            return

        }

        let self = this
        let param = {
            data: data,
            url: '/shopping/joinToCart',
            successFn: (data) => {
                // 没有登录，跳转到登录页面
                if(data.resultCode !== 2000) {
                    self.enter('加入购物车失败')
                }
                // self.enter(
                //     <div className="add-cart-suc">
                //         <img src={addSuc} className="add-cart-img" alt=""/>
                //         <p>加入购物车成功！</p>
                //     </div>
                // )
            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }

        RequestUtil.fetch(param)
    }
    
    selectSkuFn = (data) => {
        if(this.state.goodsData.downShelfStatus === 2) {
            this.enter('商品已下架，不能添加到购物车')
            return
        } else if(this.state.goodsData.downShelfStatus === 3) {
            this.enter('商品已售罄，不能添加到购物车')
            return
        }
        this.setState({
            cartNum: this.state.cartNum + data.num,
            selectSkuData: data
        }, () => {
            // console.log(this.state.cartNum)
            // console.log(this.state.selectSkuData)
           
            this.addCartAjax()
            
        })

    }


    render() {
        return (
            <div className="m-product-list">
               
                <div className="cat-menu">
                    <ul>
                        {this.getCatList()}
                    </ul>
                </div>
                <div className="m-list-flex">
                    {this.genItem()}
                </div>
                
                <LoadingDiv show={this.state.loading} hasMore={this.state.hasMore}/>
                <GoodsSpec isShow={this.state.specShow} 
                    hideFn={this.hideGoodsSpec}
                    submitFn={this.selectSkuFn}
                    type={this.state.skuSpecType}
                    data={{
                        goodsId: this.state.goodsId,
                        picUrl: this.state.goodsData.picUrl,
                        price: this.state.goodsData.price,
                        specDesc: this.state.goodsData.specDesc,
                        specs: this.state.goodsData.specs,
                        products: this.state.goodsData.products,
                        store: this.state.goodsData.store,
                    }}
                />
                <CartAndMenu cartNum={this.state.cartNum}></CartAndMenu>

            </div>
        )
    }
}