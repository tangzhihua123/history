import React, { Component } from 'react'
import PropTypes from 'prop-types'
import './index.scss'




export default class BottomTips extends Component {
    constructor(props) {
        super(props)
    }
    render() {
        return (
            <div className="bottom-tips">
                <div className="tip-content">
                    <span className="line"></span>
                    <span>我是有底线的</span>
                    <span className="line"></span>
                </div>               
            </div>
        )
    }
}

BottomTips.propTypes = {
    
};