

import React from 'react'
import './index.scss'

export default function PostFreeTipBar(props) {
    return (
      <div className="post-free-tip-bar">
          <p className="content">
              再购￥29.00免配送费
          </p>
      </div>
    )
}