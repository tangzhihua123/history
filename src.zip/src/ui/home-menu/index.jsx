import React, { Component } from 'react'
import PropTypes from 'prop-types'
import {
    Link
} from 'react-router-dom'
import Barcode from 'react-barcode'
import store from 'store'
import Util from 'utils/util'
import URLUtil from 'utils/url-util'

import RequestUtil from 'utils/request-util'
import CART from 'assets/home_Shopping cart@3x.png'
import HomeMenu from 'assets/home_unfold@3x.png'
import SHAOMA  from 'assets/home_Bar code@3x.png'
import USERCENTER from 'assets/home_mine@3x.png'
import CLOSE from 'assets/home_close@3x.png'
import './index.scss'

import USER_CENTER_LOGO from 'assets/center_logo.png'
import USER_DIALOG_CLOSE from 'assets/close.png'
import CATEGORY from 'assets/home_classify@3x.png'

export default class CartAndMenu extends Component {
    constructor(props) {
        super(props)
        this.state = {
            active: 0,
            menu: [
                '首页',
                '入店必买',
                '初见尝鲜',
                '预售',
                '不时不食',
                '节气餐桌',
                '达人食荐',
            ]
        }

    }
    RedirectCate() {
        URLUtil.redirectPage({
            page: 'cate',
            options: {}
        })
    }
    
    ShowMenu() {
        let list = this.state.menu.map((item, index) => {
            let map_str = '#map' + index
            let cls = index == this.state.active ? 'active' : ''
            return (
                 <span key={index}><a href={map_str} onClick={this.selMenu.bind(this, index)} className={cls} >{item}</a></span>
            )

        })
        return list
    }

    ClearActive() {
        console.log(222)
        let m  = document.querySelector('.home-menu-container').querySelectorAll('a')
        Array.prototype.slice.call(m).map((item,i) => {
            Util.removeClass(item, 'active')
        })
        // [].map.call(m, (item, i) => {
        //     // Util.removeClass(item, 'active')
        // })
    }

    componentDidMount() {
        let scrollFn = (e) => {
            let scrollTop = document.documentElement.scrollTop || document.body.scrollTop
            let f1_h = document.querySelector('.m-floor1').clientHeight
            let f2_h = document.querySelector('.m-floor2').clientHeight
            let f3_h = document.querySelector('.m-floor3').clientHeight
            let f4_h = document.querySelector('.m-floor4').clientHeight
            let f5_h = document.querySelector('.m-floor5').clientHeight
            let f6_h = document.querySelector('.m-floor6').clientHeight


            console.log(this)
            if(scrollTop >= (f1_h + f2_h + f3_h + f4_h + f5_h + f6_h)) {
                // 达人食荐
               this.ClearActive()
                Util.addClass(document.querySelector('.home-menu-container').querySelectorAll('a')[6], 'active')
            }else if(scrollTop >= (f1_h + f2_h + f3_h + f4_h + f5_h)) {
                // 节气餐桌
                this.ClearActive()
               
                Util.addClass(document.querySelector('.home-menu-container').querySelectorAll('a')[5], 'active')
            }else if(scrollTop >= (f1_h + f2_h + f3_h + f4_h  )) {
                // 不时不食
                // 
                this.ClearActive()
              
                Util.addClass(document.querySelector('.home-menu-container').querySelectorAll('a')[4], 'active')
            }else if(scrollTop >= (f1_h + f2_h + f3_h )) {
                // 预售
                this.ClearActive()
              
                Util.addClass(document.querySelector('.home-menu-container').querySelectorAll('a')[3], 'active')
            }else  if(scrollTop >= (f1_h + f2_h)) {
                // 滚动到初见尝鲜
                this.ClearActive()
               
                Util.addClass(document.querySelector('.home-menu-container').querySelectorAll('a')[2], 'active')
            }else if(scrollTop >= f1_h ) {
                // 滚动到入店必买
                this.ClearActive()
                Util.addClass(document.querySelector('.home-menu-container').querySelectorAll('a')[1], 'active')
            }
        }
        let wrap = Util.throttle(scrollFn, 100)
        window.addEventListener('scroll', wrap, false)
    }
    /**
     * [selMenu 选择主菜单]
     * @param  {[type]} index [description]
     * @return {[type]}       [description]
     */
    selMenu(index) {
        this.setState({
            active:index
        })
    }

    render() {    
        return (
            <div className="home-menu-container">
                <div>  
                   {this.ShowMenu()}
                </div>
                <img src={CATEGORY} alt="" className="icon_cat" onClick={this.RedirectCate.bind(this)}/>
                
            </div>
        )
    }
}

CartAndMenu.PropTypes = {
   
}