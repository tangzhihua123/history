import React, {Component} from 'react'
import PropTypes from 'prop-types'
import Util from 'utils/util.js'
import './goods-des-detail.scss'
import line from './line.png'
import detail from './2.png'
export default class GoodsDesDetail extends Component {
    constructor(props) {
        super(props)
        this.state = {
            imgUrls: this.props.imgUrls
        }
    }
    componentDidMount() {
        
    }
    componentWillReceiveProps(nextProps) {
        this.setState({
            imgUrls: nextProps.imgUrls
        })
    }
    genImgs = () => {
        if(Util.isArray(this.state.imgUrls)) {
            let urls = this.state.imgUrls
            let imgs = urls.map(function(item, i) {
                return (
                    <img key={i} src={item.pic} alt="" />
                )
            })
            return imgs
        }
    }
    render() {
        return (
            <div className="goods-des-detail">
                <div className="detail-title">
                    <span><img className="line-img" src={line} alt="" /></span>
                    <span className="title-span">商品详情</span>
                    <span><img className="line-img" src={line} alt="" /></span>  
                </div>
                {/* <div className="detail-des-list">
                    <div className="des-item">
                        <span className="item-key">产地：</span>
                        <span className="item-value">四川</span>
                    </div>
                    <div className="des-item">
                        <span className="item-key">配料表：</span>
                        <span className="item-value">纯牛奶、榴莲果肉、乳酸奶油、小麦粉纯牛奶、榴莲果肉、乳酸奶油、小麦粉、榴莲果肉、乳酸奶油</span>
                    </div>
                    <div className="des-item">
                        <span className="item-key">产地：</span>
                        <span className="item-value">四川</span>
                    </div>
                </div> */}
                <div className="detail-img-list">
                    {this.genImgs()}
                    {/* <img src={detail} alt="" />
                    <img src={detail} alt="" />
                    <img src={detail} alt="" />
                    <img src={detail} alt="" /> */}
                </div>
            </div>
        )
    }
}
GoodsDesDetail.PropTypes = {
    imgUrls: PropTypes.arrayOf(PropTypes.string).isRequired,
    basicDes: PropTypes.arrayOf(PropTypes.object).isRequired
}