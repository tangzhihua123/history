import React, { Component } from 'react'

import Icon from 'components/Icon'

import util from '../../utils/util'
import './index.scss'


export default class MapGaode extends Component {
  constructor(props) {
    super(props)
    this.state = {
      current: {
        address: ''
      }
    }
  }
  loadScript() {
    const _this = this
    let geocoder
    let placeSearch
    let auto
    let toolBar
    const _onMapClick = (e) => {
      const lng = e.lnglat.getLng()
      const lat = e.lnglat.getLat()
      const poi = [lng, lat]
      geocoder.getAddress(poi, function (status, result) {
        if (status === 'complete' && result.info === 'OK') {
          // console.log(result)
          _this.props.onSelected({
            lng,
            lat,
            address: result.regeocode.formattedAddress
          })
        } else {
          console.log('获取地址信息失败')
        }
      })
    }

    const throttleMapClick = util.throttle(_onMapClick, 0, 1000, this)
    const script = document.createElement('script')
    // key 为个人开发者
    script.src = '//webapi.amap.com/maps?v=1.4.0&key=46ef813d4667e4c0b2ce5c8a92f7a893'
    script.onload = function () {
      var map = new AMap.Map('container', {
        resizeEnable: true
      })
      map.plugin('AMap.Geolocation', function () {
        var geolocation = new AMap.Geolocation({
            enableHighAccuracy: true,//是否使用高精度定位，默认:true
            timeout: 10000,          //超过10秒后停止定位，默认：无穷大
            maximumAge: 0,           //定位结果缓存0毫秒，默认：0
            convert: true,           //自动偏移坐标，偏移后的坐标为高德坐标，默认：true
            showButton: true,        //显示定位按钮，默认：true
            buttonPosition: 'RB',    //定位按钮停靠位置，默认：'LB'，左下角
            buttonOffset: new AMap.Pixel(10, 20),//定位按钮与设置的停靠位置的偏移量，默认：Pixel(10, 20)
            showMarker: true,        //定位成功后在定位到的位置显示点标记，默认：true
            showCircle: true,        //定位成功后用圆圈表示定位精度范围，默认：true
            panToLocation: true,     //定位成功后将定位到的位置作为地图中心点，默认：true
            zoomToAccuracy:true      //定位成功后调整地图视野范围使定位位置及精度范围视野内可见，默认：false
        });
        map.addControl(geolocation);
        geolocation.getCurrentPosition();
        AMap.event.addListener(geolocation, 'complete', onComplete);//返回定位信息
        AMap.event.addListener(geolocation, 'error', onError);      //返回定位出错信息
        // 定位成功回调
        function onComplete(e) {
          console.log(e)
          if (e.info === 'SUCCESS' && e.addressComponent) {
            _this.setState({
              current: {
                address : e.addressComponent.street,
                detailAddress: e.formattedAddress,
                position: e.position
              }
            })
          }
        }
        function onError(e) {
          console.log(e)
        }
      })

      AMap.service('AMap.Geocoder', function() {//回调函数
        //实例化Geocoder
        geocoder = new AMap.Geocoder({
          city: "0579"//城市，义乌
        });
      })

      var autoOptions = {
        input: "tipinput"
      }

      
      AMap.service('AMap.PlaceSearch', function () {//回调函数
        placeSearch = new AMap.PlaceSearch({
          map: map
        })
      })

      AMap.service('AMap.Autocomplete', function () {//回调函数
        auto = new AMap.Autocomplete(autoOptions)
        AMap.event.addListener(auto, "select", select);//注册监听，当选中某条记录时会触发
      })

      function select(e) {
         console.log(e)
          _this.props.onSelected({
              lng: e.poi.location.lng,
              lat: e.poi.location.lat,
              address: e.poi.name
          })
          
          placeSearch.setCity(e.poi.adcode);
          placeSearch.search(e.poi.name);  //关键字查询

      }
      map.on('click', throttleMapClick)
      // 加载UI
      const scriptUI = document.createElement('script')
      // key 为个人开发者
      scriptUI.src = '//webapi.amap.com/ui/1.0/main.js?v=1.0.11'
      scriptUI.onload = function () {
        AMapUI.loadUI(['control/BasicControl'], function (BasicControl) {
          map.addControl(new BasicControl.Zoom({
            position: 'rb'
          }))
        })
      }
      document.body.appendChild(scriptUI)
      // map.plugin(["AMap.ToolBar"], function () {
      //   var toolBar = new AMap.ToolBar(); //设置地位
      //   map.addControl(toolBar);
      // })
    }
    document.body.appendChild(script)
  }
  componentDidMount() {
    this.loadScript()
  }
  render() {
    return <div className="map-container">
      <div>
        <div className="arrow-return"><Icon type="arrow-left" size="xss"></Icon></div>
        <input className="search-input" placeholder="请输入关键字" id="tipinput" />
      </div>
      <div id="container" className="map-gaode"></div>
      <div className="cur-location">
          <div className="cur-loc-left">
            <Icon type="location" size="xs"></Icon>
          </div>
          <div className="cur-short-loc">
            
            {
              this.state.current.address != '' ? <span><span className="current-tips">[当前]</span><span>{this.state.current.address}</span></span> : <span> 正在定位中...</span>
            }

          </div>
          <div>
            {this.state.current.detailAddress}
          </div>
      </div>
    </div>
  }
}