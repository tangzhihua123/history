import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Store from 'store'
import RequestUtil from 'utils/request-util'
import JSBridge from 'utils/JSBridge'
import URLUtil from 'utils/url-util'
import Util from 'utils/util'

import GoodsSpec from 'ui/goods-spec/goods-spec.jsx'
import CartAndMenu from 'ui/cart-menu'

export default class GoodsDes extends Component {
    constructor(props) {
        super(props)
        this.state = {
            cartNum: 0,
            goodsId: this.props.goodsId,
            goodsData: {},
            specShow: this.props.isShow ,
            skuSpecType: 'add',
            selectSkuData: {},
            noLogin: this.props.noLogin || false
        }
        
    }

    componentWillReceiveProps(nextProps) {
        this.setState({
            specShow: nextProps.isShow,
            goodsId:nextProps.goodsId,
            noLogin: nextProps.noLogin,
        })
    }

    hideGoodsSpec = () => {
        this.setState({
            specShow: false,
            // goodsId: 0,
        },() => {
            this.props.hideDialog()
        });
    }

    enter = (message) => {
        this.setState({
            enter: true,
            message: message,
        });
        setTimeout(
            function() {
                this.leave();
            }.bind(this),
            2000
        );
    }

    leave = () => {
        this.setState({
            enter: false,
            message: "",
        });
    }

    componentDidMount() {

        this.fetchGoodsData(this.state.goodsId)
       
    }

     /**
     * [获取商品详细数据]
     * @return {[type]} [description]
     */
    fetchGoodsData = (goodsId) => {
        let param = {
            data: {
                goodsId
            },
            url: '/goods/goodsInfo',
            successFn: (data) => {
                this.setState({
                    specShow: true,
                    goodsId: this.state.goodsId,
                    goodsData: data.data
                })
            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }
        RequestUtil.fetch(param)
    }

    addCartAjax = () => {
        let self = this

        let data = {
            goodsId: this.state.goodsId,
            productId: this.state.selectSkuData.productId,
            count: this.state.selectSkuData.num,
            isChecked: 1,
        }
        
        if(this.props.AddCartSource) {
            data.goodsSource = this.props.AddCartSource.goodsSource,
            data.sourceId = this.props.AddCartSource.sourceId 
        }
        
        if (this.state.noLogin) {
            // 未登陆
            let cartList = Store.get('cartList')
            if (!Util.isArray(cartList)) {
                cartList = []
            }

            let same
            cartList.some((item, i) => {
                if(item.productId === data.productId) {
                    cartList[i] = {
                        ...item,
                        count: item.count + data.count
                    }
                    same = true
                }
            })
            if(!same) {
                cartList.push(data)
            }
            
            Store.set('cartList', cartList)
            if(this.props.UpdateCartNumHandle) {
                this.props.UpdateCartNumHandle(this.state.cartNum)
            }

            this.hideGoodsSpec()
            return 
        }

        let param = {
            data: data,
            url: '/shopping/joinToCart',
            successFn: (data) => {
                // 没有登录，跳转到登录页面
                if(data.resultCode == 4005) {
                    URLUtil.redirectPage({
                        page: 'app/login',
                        options: {
                            redirect: "/" + window.location.href.split('/')[3]
                        }
                    })
                }else {
                    if(this.props.UpdateCartNumHandle) {
                        this.props.UpdateCartNumHandle(this.state.cartNum)
                    }
                    if(Util.isCustomAgent()) {
                        JSBridge.postData({
                            type: 'refreshShopCart',
                            data: {}
                        })
                    }
                   

                    
                    this.hideGoodsSpec()
                }
            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }

        RequestUtil.fetch(param)
    }

    selectSkuFn = (data) => {
        this.setState({
            cartNum: data.num,
            selectSkuData: data
        }, () => {
            this.addCartAjax()

        })

    }
   
    render() {
        return (
            <div>
                {
                    this.state.specShow ? 
                        <GoodsSpec isShow={this.state.specShow} 
                            hideFn={this.hideGoodsSpec.bind(this)}
                            submitFn={this.selectSkuFn.bind(this)}
                            type={this.state.skuSpecType}
                            type_source={2}
                            data={{
                                goodsId: this.state.goodsId,
                                picUrl: this.state.goodsData.picUrl,
                                price: this.state.goodsData.price,
                                specDesc: this.state.goodsData.specDesc,
                                specs: this.state.goodsData.specs,
                                products: this.state.goodsData.products,
                                store: this.state.goodsData.store,
                            }}
                        />:null
                }
                
                
            </div>
           
        )
    }
}
GoodsDes.PropTypes = {
    data: PropTypes.object, // 基本信息
}