import React from 'react'

import './index.scss'

export default function OrderOverview(props) {
  const {
    items = [],
    totalPrice = 0,
    totalQuantity = 0,
    onMemoChange
  } = props
  const width = (items.length * .8) + 1 + 'rem'
  const imgContObj = {
    width: width
  }
  return (
    <div className="order-overview">
      <div className="order-overview-wrapper">
        <div className="item-img-wrapper">
          <div className="img-container">
            <div className="img-scroller" style={imgContObj} >
              {
                 items.map(function(item) {
                   const styleObj = {
                     background: `url(${item.imgLink}) no-repeat`,
                     backgroundSize: 'contain'
                   }
                   return (
                   <div key={item.productId} className="item-img"
                    style={styleObj}
                   >
                    <span className="count">x{item.quantity}</span>
                   </div>)
                 })
              }
            </div>
          </div>
          <div className="item-count">
              共{ totalQuantity }件
          </div>
        </div>
        <div className="price-sum">商品合计:￥{totalPrice}</div>
        <div className="remark">
            <label className="label">备注(选填)：</label>
            <input className="base-input" onChange={onMemoChange}placeholder="对本次交易的说明"></input>
        </div>
      </div>
    </div>
  )
}