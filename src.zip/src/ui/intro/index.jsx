import React, { Component } from 'react'
import PropTypes from 'prop-types'
import RequestUtil from 'utils/request-util'
import URLUtil from 'utils/url-util.js'
import './index.scss'


export default class MainFloor extends Component { 
    constructor(props) {
        super(props)

        this.state = {
            desc: '',
        }
    }
    
    componentDidMount() {
        this.GetIntro()
    }

    /**
     * [GetIntro 获取玩法介绍]
     */
    GetIntro() {
        let param = {
            data: {},
            url: URLUtil.fetchValueByURL("type") =='share' ? '/Active/InvitationList' : '/Active/NewUserGiftList',
            successFn: (data) => {
                if(data.resultCode == 2000) {
                    this.setState({
                       desc: URLUtil.fetchValueByURL("type") =='share' ? data.data.imContent : data.data[0].ngContent
                    })
                   
                }else if(data.resultCode == 5000) {
                    alert("网络异常，请稍后再试")
                }

               
            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }
        RequestUtil.fetch(param)    
    }

    render() {
        return (
            <div className="intro-wrap">
                <div  dangerouslySetInnerHTML={{__html: this.state.desc}}></div>
            </div>
        )
    }
}