import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Util from 'utils/util.js'
import Load from 'utils/load.js'
import RequestUtil from 'utils/request-util'
import PullToRefresh from 'utils/pulltorefresh.js'
import URLUtil from 'utils/url-util'
import LoadingDiv from 'components/bottom-refresh/index.jsx'
import GoodsSpec from 'ui/goods-spec/goods-spec.jsx'
import CartAndMenu from 'ui/cart-menu'
import addSuc from './add_cart_suc.png'
import ActivityProductItem from './item'

import './index.scss'


export default class TopicList extends Component {
    constructor(props) {
        super(props)

        this.state = {
            pageIndex: 1,
            pageSize: 10,
            hasMore: true,
            catId: this.props.id, // 父级栏目id
            catName: '', // 选择栏目名称
            activeCate: 0, // 选中类别
            catList: [ 
            ],
            list: [],
            cartNum:0, //购物车数量

            /*购买相关*/
            goodsId: 0,
            goodsData: {},
            specShow: false,
            skuSpecType: 'add',
            selectSkuData: {},//选择sku 数据

        }
    }
    
    componentWillMount() {
        this.getTopicList()
        this.fetchCartNum()
    }

    componentDidMount() {
        let destroyScroll = this.state.hasMore ? Load.bottomLoad(this.getTopicList) : null
        this.setState({
            destroyScroll: destroyScroll
        })
    }
    
    /**
     * [getTopicList 获取主题活动下的’最佳拍档商品列表,接口还没提供，暂时注释掉.]
     * @return {[type]} [description]
     */
    getTopicList= () => {
        this.setState({
            loading: true
        })


        let param = {
            data: {
                pageIndex: this.state.pageIndex,
                pageSize: this.state.pageSize
            },
            url: '/goods/preSaleGoodsList',
            successFn: (data) => {
                if(data.resultCode == 2000) {
                    if(data.data.list.length == 0) {
                        this.setState({
                            hasMore: false,
                            loading: false
                        })  
                    }

                    else if(data.data.list.length > 0) {
                        this.setState({
                            list: this.state.list.concat(data.data.list),
                            pageIndex: this.state.pageIndex + 1,
                            hasMore: true,
                            loading: false
                            
                        })
                      
                    }
                    
                }else if(data.resultCode == 5000) {
                    alert("网络异常，请稍后再试")
                }

               
            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }
        RequestUtil.fetch(param)    
    }

  
    
   
    /**
     * [遍历商品数据列表]
     * @return {[type]} [description]
     */
    genItem = () => {
        var arr = this.state.list
        if(!Util.isArray(arr)) return
        

        var list = arr.map( (item, i) => {
            let last = false;
            if(i == (arr.length - 1)) last = true

            return (
                <ActivityProductItem data={item} key={i} last={last}  index={i} addCartHandle={this.addCart.bind(this)}/>
            )
        })
        return list
    }
    
    /**
     * [selCat 选择分类]
     * @return {[type]} [description]
     */
    selCat(catId,catName) {
        this.setState({
            catName,
            activeCate: catId,
            list: [],
            pageIndex: 1,
        }, () => {
            this.getTopicList()
        })
       

    }
    
    // GetCategoryData = () => {
        

    //     let param = {
    //         data: {
    //             catId: this.state.catId,
    //             catType: 0,
    //         },
    //         url: '/goods/goodsSubCategory',
    //         successFn: (data) => {
    //             if(data.resultCode == 2000) {
    //                if(data.data.list.length > 0) {
    //                     this.setState({
    //                         catList: data.data.list,
    //                         catName: data.data.list[0].title,
    //                         activeCate: data.data.list[0].catId,

    //                     })

    //                     let destoryFn = this.getTopicList()
        
    //                     this.setState({
    //                         destoryFn: destoryFn
    //                     })
    //                 }
                    
    //             }else if(data.resultCode == 5000) {
    //                 alert("网络异常，请稍后再试")
    //             }

               
    //         },
    //         errorFn: (error) => {
    //             console.log('请求失败的错误', error)
    //         }
    //     }
    //     RequestUtil.fetch(param)    
    // }
    /**
     * [获取分类数据列表]
     * @return {[type]} [description]
     */
    getCatList = () => {
        let arr = this.state.catList
        if(!Util.isArray(arr)) return

        let list = arr.map((item, i) => {
            let cls = (item.catId == this.state.activeCate) ? "active" : ''
            return (
                <li className={cls} key={i} onClick={this.selCat.bind(this,item.catId, item.title)}>{item.title}</li>
            )
        })

        return list
    }
    
    /**
     * [获取购物车数量]
     * @return {[type]} [description]
     */
    fetchCartNum = () => {
        RequestUtil.fetchCartNum({
            noLogin: (num) => {
                this.setState({
                    noLogin: true,
                    cartNum: num
                })
            },
            Login: (num) => {
                this.setState({
                    cartNum: num
                })
            },
            ErrorFun: (msg) => {
                this.enter(msg)
            }
        })
    }
    /**
     * [addToCart 添加到购物车]
     */
    addCart(goodsId) {
        this.fetchGoodsData(goodsId)
    }

     /**
     * [获取商品详细数据]
     * @return {[type]} [description]
     */
    fetchGoodsData = (goodsId) => {
        let param = {
            data: {
                goodsId
            },
            url: '/goods/goodsInfo',
            successFn: (data) => {
                this.setState({
                    specShow: true,
                    goodsId: goodsId, 
                    goodsData: data.data,
                })
            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }
        RequestUtil.fetch(param)
    }

    hideGoodsSpec = () => {
        this.setState({
            specShow: false,
            // goodsId: 0,
        })
    }
    enter = (message) => {
        this.setState({
            enter: true,
            message: message,
        });
        setTimeout(
            function() {
                this.leave();
            }.bind(this),
            2000
        );
    }

    leave = () => {
        this.setState({
            enter: false,
            message: "",
        });
    }

    
    selectSkuFn = (data) => {
        this.setState({
            // cartNum: this.state.cartNum + data.num,
            selectSkuData: data
        }, () => {
            // console.log(this.state.cartNum)
            // console.log(this.state.selectSkuData)
            location.href = '//' + location.host + '/app/order-confirm?tradingItems='
            + this.state.goodsId + '_' + data.productId + '_' + data.num
            
            
        })

    }


    render() {
        return (
            <div className="m-product-list">
               
                <div className="cat-menu">
                    <ul>
                        {this.getCatList()}
                    </ul>
                </div>
                <div className="m-list-flex">
                    {this.genItem()}
                </div>
                
                <LoadingDiv show={this.state.loading} hasMore={this.state.hasMore}/>
                <GoodsSpec 
                    noLogin={this.state.noLogin}
                    isShow={this.state.specShow} 
                    hideFn={this.hideGoodsSpec}
                    submitFn={this.selectSkuFn}
                    type={this.state.skuSpecType}
                    data={{
                        goodsId: this.state.goodsId,
                        picUrl: this.state.goodsData.picUrl,
                        price: this.state.goodsData.price,
                        specDesc: this.state.goodsData.specDesc,
                        specs: this.state.goodsData.specs,
                        products: this.state.goodsData.products,
                        store: this.state.goodsData.store,
                    }}
                />
                <CartAndMenu cartNum={this.state.cartNum}></CartAndMenu>

            </div>
        )
    }
}