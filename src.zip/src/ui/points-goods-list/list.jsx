import React, {Component} from 'react'
import Request from 'utils/request-util.js'
import Notification from "components/Notification/NotificationBlock.jsx"
import CouponToast from 'ui/points-toast/coupon-exchange.jsx'
import PropTypes from 'prop-types'
import PointsGoods from './item'
import PointsFooter from './footer'
import './list.scss'

export default class PointsGoodsList extends Component {
    constructor(props) {
        super(props)
        this.state = {
            list: this.props.list,
            points: this.props.points,
            nowData: {},
            isShow: false
        }
    }
    componentWillMount() {
        
    }
    componentWillReceiveProps(nextProps) {
        this.setState({
            list: nextProps.list,
            points: nextProps.points
        })
    }
    hideFn = () => {
        this.setState({
            isShow: false
        })
    }
    buyAjax = () => {
        let param = {
            data: {
                itemId: this.state.nowData.itemId
            },
            url: '/user/exchangeCoupon',
            successFn: (res) => {

                if(res.resultCode !== 2000) {
                    this.enter(res.resultMsg || '兑换失败')
                    
                } else {
                    this.enter('兑换成功')
                    this.props.exchangeFn && this.props.exchangeFn(true)
                }
                this.setState({
                    isShow: false
                })
                
            },
            errorFn: (error) => {
                this.enter('兑换失败，请重试')
            }
        }
        Request.fetch(param)
    }
    buyPointsGoods = (itemId) => () => {
        let nowData
        this.state.list.some((item) => {
            if(item.itemId === itemId) {
                nowData = item
            }
            return item.itemId === itemId
        })
        this.setState({
            nowData: nowData,
            isShow: true
        })
        
    }
    genGoodsList = () => {
        let array = []
        array = this.state.list.map((item, i) => {
            return (<PointsGoods 
                        data={item}
                        key={item.itemId}
                        buyAjax={this.buyPointsGoods(item.itemId)}
                        points={this.state.points}
                        />
            )
        })
        return array
    }
    enter = (message) => {
        this.setState({
            enter: true,
            message: message,
        });
        setTimeout(
            function() {
                this.leave();
            }.bind(this),
            2000
        );
    }

    leave = () => {
        this.setState({
            enter: false,
            message: "",
        });
    }
    render() {
        return (
            <div className="points-goods-list">
                <div className="points-goods-title">
                    <div className="line"></div>
                    <div className="text">热门兑换专区</div>
                    <div className="line"></div>
                </div>
                <div className="points-list-con">
                    {/* <PointsGoods />
                    <PointsGoods />
                    <PointsGoods />
                    <PointsGoods />
                    <PointsGoods /> */}
                    {this.genGoodsList()}
                </div>
                <div className="footer-div">
                    {
                        this.props.showFooter === false ?
                        null: <PointsFooter />
                    }
                    
                </div>
                <CouponToast isShow={this.state.isShow} data={this.state.nowData} hideFn={this.hideFn} buyAjax={this.buyAjax}/>
                <Notification
                    enter={this.state.enter}
                    leave={this.leave.bind(this)}
                >
                    {this.state.message}
                </Notification>
            </div>    
        )
    }
}

PointsGoodsList.propTypes = {
    showFooter: PropTypes.bool, // 是否显示底栏
    list: PropTypes.array, // 商品数组
    points: PropTypes.number, // 当前总可用积分
    exchangeFn: PropTypes.func, // 兑换之后的回调

}