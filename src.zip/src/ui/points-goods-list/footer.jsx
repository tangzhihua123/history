import React, {Component} from 'react'

import './footer.scss'

import FooterLogo from './footer-logo.png'

export default class PointsFooter extends Component {
    render() {
        return (
            <div className="points-footer-div">
                <img src={FooterLogo} className="footer-img" alt="" />
                <div className="tips-div">
                    <div className="line"></div>
                    <div className="text">更多美食敬请期待</div>
                    <div className="line"></div>
                </div>
            </div>
        )
    }
}