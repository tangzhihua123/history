import React, {Component} from 'react'
import PropTypes from 'prop-types'
import PointsGoods from './item'
import './item.scss'
import Goods from './goods.jpg'

import BlankImg from 'assets/goods_default_300.jpg'

export default class PointsGoodsItem extends Component {

    handleBuy = (e) => {
        console.log('dataset', e.currentTarget.dataset)
    }
    render() {
        return (
            <div className="points-goods-item" data-id={this.props.data.itemId}>
                {
                    this.props.data.limitNum ? 
                    <div className="points-goods-limit">
                        <div className="text">限购</div>
                        <div className="tri1"></div>
                        <div className="tri2"></div>
                    </div>:null
                }
                <img src={this.props.data.goodsImage || BlankImg} className="points-img" alt="" />
                <div className="points-goods-des">{this.props.data.goodsName}</div>
                <div className="points-goods-price">{this.props.data.goodsScore}积分</div>
                {
                    this.props.points >= this.props.data.goodsScore ? 
                    <div className="points-goods-buy" onClick={this.props.buyAjax}>我想兑换</div>:
                    <div className="points-goods-buy grey">积分不足</div>
                }
                
            </div>    
        )
    }
}

PointsGoodsItem.propTypes = {
    data: PropTypes.object // 商品数据
}