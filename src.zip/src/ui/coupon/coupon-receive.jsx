import React, {Component} from 'react'
import PropTypes from 'prop-types'

import './coupon-receive.scss'

export default class Coupon extends Component {
    constructor(props) {
        super(props)
        this.state = {
            data: this.props.data || {}
        }
    }
    componentWillReceiveProps(nextProps) {
        this.setState({
            data: nextProps.data
        })
    }
    
    render() {
        let des = this.state.data.desc,
            desDiv
        if(/^([\d]+)$/.test(des)) {
            desDiv = <div className="coupon-name">
                <span className="rmb">¥</span>
                <span className="number">{des}</span>
            </div>
        } else {
            desDiv = <div className="coupon-name">{des}</div>
        }
        
        return (
            <div className={'single-coupon-receive'+(this.state.data.status === 2?' used':'')}>
                <div className="coupon-info">
                    {desDiv}
                    
                    <div className="coupon-des-div">
                        <div className="coupon-des">{this.state.data.title}</div>
                        <div className="coupon-time">{this.state.data.expiries}</div>
                    </div>
                </div>
                <div className="coupon-status" onClick={this.state.data.status === 1?this.props.handleClick:''}>
                    {this.state.data.status === 1 ? 
                    <div className="status">领取</div> :
                    <div className="status">已领取</div>
                    }
                </div>
            </div>
        )
    }
}
Coupon.propTypes = {
    data: PropTypes.object,
    /**
     * data 格式
     * couponId:12,//优惠券ID
     * title:"￥300",//标题
     * expiries:"有效期至 2010-1-1",//有效期
     * desc:"满200使用",//描述 折扣、满减、免邮券
     * status:1,//状态 1=可领取 2=已领取
     */
    handleClick: PropTypes.func // 点击优惠券执行的函数
}