import React, { Component } from 'react'
import qs from 'query-string'
import Store from 'store'
import VideoComponent from 'components/video/index.jsx'
import LightBox from 'components/light-box/index.jsx'
import Util from 'utils/util.js'
import Login from 'utils/login.js'
import Request from 'utils/request-util.js'
import Notification from "components/Notification/NotificationBlock.jsx";
import GoodsDes from 'ui/goods-des/goods-des.jsx'
import GoodsDetailCells from 'ui/goods-detail-cells/goods-detail-cells.jsx'
import GoodsSpec from 'ui/goods-spec/goods-spec.jsx'
import CouponModal from 'ui/coupon-modal/coupon-modal.jsx'
import GoodsDesDetail from 'ui/goods-des-detail/goods-des-detail.jsx'
import GoodsRecommend from 'ui/goods-detail-recommend/index.jsx'
import GoodsRateSlider from 'ui/goods-rate-slide/index.jsx'
import CartBar from 'ui/cart-bar/cart-bar.jsx'
import BackTop from 'components/back-top/back-top.jsx'
import Slider from 'components/Slide'
import SliderItem from 'components/Slide/SliderItem'

import addSuc from './add_cart_suc.png'
import URLUtil from 'utils/url-util'

import './goods-detail.scss'

import { GoodsData } from 'adapter/GoodsDetailAdapter.js'


export default class GoodsDetail extends Component {

    constructor(props) {
        super(props)
        let id
        if (location.search) {
            id = qs.parse(location.search).goodsId
            if(URLUtil.fetchValueByURL("id")) {
                id = URLUtil.fetchValueByURL("id")
            }

        }
        this.state = {
            specShow: false,
            couponShow: false,
            cartNum: 0,
            goodsData: {},
            goodsId: id || 8376, // 8377, //this.props.goodsId,
            commentModel: {},
            selectSkuData: {},
            skuSpecType: '',
            backTop: false,
            noLogin: false,
            lightBoxObj: {}
        }

    }
    componentWillMount() {

        this.fetchGoodsData()
        this.fetchGoodsCoupon()
        this.fetchCommentsAmount()
        this.fetchCartNum()
        this.fetchRecommend()
    }
    componentDidMount() {
        this.showBackTop()
    }
    componentWillUnmount() {
        this.state.destoryShowBackTopFn && this.state.destoryShowBackTopFn()
    }
    showBackTop = () => {
        let height = parseInt(window.screen.availHeight / 3)
        let scrollFn = (e) => {

            if (window.scrollY > height) {
                if (!this.state.backTop) {
                    this.setState({
                        backTop: true
                    })
                }

            } else {
                if (this.state.backTop) {
                    this.setState({
                        backTop: false
                    })
                }

            }
        }
        this.setState({
            destoryShowBackTopFn: () => {
                window.removeEventListener('scroll', warp, false)
            }
        })
        let warp = Util.throttle(scrollFn, 100)
        window.addEventListener('scroll', warp, false)

    }
    modalInfo = (mes) => {
        this.enter(mes)
    }
    onAction = (index, direction) => {
        console.log('激活的幻灯片编号：', index, '，滚动方向：', direction);
    }
    lightBoxHandle = (data) => {
        this.setState({
            lightBoxObj: {
                show: true,
                ...data
            }
        })
        /* if(data.type === 'video') {
            this.setState({
                lightBoxObj: {
                    show: true,
                    ...data
                }
            })
        } else if(data.type === 'img') {
            this.setState({
                lightBoxObj: {
                    
                }
            })
        } */
    }
    hideLightBox = () => {
        this.setState({
            lightBoxObj: {
                ...this.state.lightBoxObj,
                show: false
            }
        })
    }
    genMainSlider = () => {
        let goodsData = this.state.goodsData

        let sliderImgs = goodsData.itemImages,
            newArray = []
        if(goodsData.videoAddr && goodsData.videoPic) {
            newArray.push({
                picUrl: goodsData.videoPic,
                videoAddr: goodsData.videoAddr
            }) 
        }
        if(sliderImgs) {
            newArray = newArray.concat(sliderImgs)
        }
        
        if (Util.isArray(newArray) && newArray.length > 0) {
            let items = newArray.map((item, i) => {
                if(i === 0 && item.videoAddr) {
                    return <SliderItem key={i} videoUrl={item.videoAddr}
                            urlCb={this.lightBoxHandle}
                        >
                            <VideoComponent
                                data={{
                                    picUrl: item.picUrl,
                                    videoAddr: item.videoAddr
                                }}
                            />
                        </SliderItem>
                }
                return (
                    <SliderItem key={i} imgUrl={item.picUrl}
                        urlCb={this.lightBoxHandle}
                    >
                        <img src={item.picUrl} alt="" />
                    </SliderItem>
                )
            })

            return (
                <Slider onAction={this.onAction} autoPlay={false}>
                    {items}
                </Slider>
            )
        }

    }
    cartDetail = () => {
        /* history.pushState({}, '购物车', '/app/mycart')
        location.href = '/app/mycart' */
    }
    addCartAjax = () => {
        let data = {
            goodsId: this.state.goodsId,
            productId: this.state.selectSkuData.productId,
            count: this.state.selectSkuData.num,
            isChecked: 1,
            goodsSource: URLUtil.fetchValueByURL("goodsSource") || 0,
            sourceId: URLUtil.fetchValueByURL("sourceId") || 0,
        }
        
        if (this.state.noLogin) {
            // 未登陆
            let cartList = Store.get('cartList')
            if (!Util.isArray(cartList)) {
                cartList = []
            }
            // data.imgLink = this.state.goodsData.picUrl
            // data.goodsName = this.state.goodsData.name
            // data.subTitle = this.state.selectSkuData.key.join(',')
            // data.storeCount = this.state.selectSkuData.store
            // data.goodsPrice = this.state.selectSkuData.price
            let same
            cartList.some((item, i) => {
                if(item.productId === data.productId) {
                    cartList[i] = {
                        ...item,
                        count: item.count + data.count
                    }
                    same = true
                }
            })
            if(!same) {
                cartList.push(data)
            }
            
            Store.set('cartList', cartList)
            this.setState({
                cartNum: this.state.cartNum + data.count
            })
            this.enter(
                <div className="add-cart-suc">
                    <img src={addSuc} className="add-cart-img" alt="" />
                    <p>加入购物车成功！</p>
                </div>
            )

            return
        }

        let param = {
            data: data,
            url: '/shopping/joinToCart',
            successFn: (res) => {

                if (res.resultCode === 2000) {
                    this.setState({
                        cartNum: this.state.cartNum + data.count
                    })
                    this.enter(
                        <div className="add-cart-suc">
                            <img src={addSuc} className="add-cart-img" alt="" />
                            <p>加入购物车成功！</p>
                        </div>
                    )
                } else {
                    this.enter('加入购物车失败')
                }

            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }

        Request.fetch(param)
    }
    addCart = () => {
        /* if(this.state.noLogin) {
            Login.gotoLogin(location.pathname+location.search)
            return
        } */
        let specs = this.state.goodsData.specDesc
        // 判断是否有多种规格
        if (Util.isArray(specs)) {
            this.clickCell1('add')
        }

    }
    buyNow = () => {
        let specs = this.state.goodsData.specDesc
        // 判断是否有多种规格
        // if(Util.isArray(specs)) {
        this.clickCell1('buy')
        // }

    }
    orderNow = () => {
        if (this.state.noLogin) {
            Login.gotoLogin(location.pathname + location.search)
            return
        }

        this.clickCell1('order')

    }
    lookOther = () => {
        location.href = '//' + location.host + '/book/'
    }
    clickCellCb = (data) => {
        if (data.el === 'cell1') {
            this.clickCell1()
        } else if (data.el === 'cell2') {
            this.clickCell2()
        } else if (data.el === 'cell3') {
            this.clickCell3()
        }
    }
    clickCell1 = () => {
        // type 暂时不用
        // type:add order ''三种状态
        // 区分打开sku选择框的类型，如果是一般的，则是加入到购物车，order则选好之后直接购买
        if(this.state.noLogin && this.state.goodsData.saleMode === 1) {
            Util.gotoLogin()
            return
        }
        this.setState({
            specShow: true,
        })
    }
    clickCell2 = () => {
        this.setState({
            couponShow: true
        })
    }
    clickCell3 = () => {
        console.log('click cell3')
    }
    hideGoodsSpec = () => {
        this.setState({
            specShow: false
        })
    }
    hideCouponModal = () => {
        this.setState({
            couponShow: false
        })
    }

    fetchGoodsData = () => {
        let param = {
            data: {
                goodsId: this.state.goodsId
            },
            url: '/goods/goodsInfo',
            successFn: (data) => {
                this.setState({
                    goodsData: data.data,
                    commentModel: data.data.commentModel,
                    skuSpecType: data.data.saleMode === 1?'order':''
                })
            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }
        // this.setState({
        //     goodsData: GoodsData
        // })
        Request.fetch(param)
    }
    fetchGoodsCoupon = () => {
        let param = {
            data: {
                goodsId: this.state.goodsId
            },
            url: '/goods/goodsCoupons',
            successFn: (data) => {
                if (data.resultCode !== 2000) {
                    this.enter('获取优惠券信息失败，请重试')
                    return
                }
                this.setState({
                    goodsCouponData: data.data.list
                })
            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }

        Request.fetch(param)
    }
    // 获取评论数量
    fetchCommentsAmount = () => {
        let param = {
            data: {
                goodsId: this.state.goodsId
            },
            url: '/goods/commentsAmount',
            successFn: (data) => {
                // data: {amount: 30}
                this.setState({
                    commentsAmount: data.data.amount
                })
            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }
        Request.fetch(param)

    }

    fetchCartNum = () => {

        let param = {
            data: {
            },
            url: '/shopping/getCartGoodsAmont',
            successFn: (data) => {
                if (data.resultCode === 4005) {
                    this.setState({
                        noLogin: true
                    }, () => {
                        let cartList = Store.get('cartList'),
                            num = 0
                        if(cartList && Util.isArray(cartList)) {
                            cartList.forEach((item) => {
                                num += item.count
                            })

                        } else {
                            num = 0
                        }
                        
                        this.setState({
                            cartNum: num
                        })
                    })
                } else if (data.resultCode !== 2000 && data.resultCode !== 4005) {
                    this.enter('获取购物车数量失败')
                    return
                } else {
                    this.setState({
                        cartNum: data.data.count
                    })
                }
                
            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }
        Request.fetch(param)

    }
    initSelectSkuFn = (data) => {
        if(data.init) {
            this.setState({
                selectSkuData: data
            })
            return
        }

    }
    selectSkuFn = (data) => {
        let {
            downShelfStatus,
            saleMode
        } = this.state.goodsData
        if(saleMode === 1) {
            if(downShelfStatus === 2 || downShelfStatus === 3) {
                this.enter('预售活动结束，不能添加到购物车')
                return
            }
        } else {
            if(downShelfStatus === 2) {
                this.enter('商品已下架，不能添加到购物车')
                return
            } else if(downShelfStatus === 3) {
                this.enter('商品已售罄，不能添加到购物车')
                return
            }
        }
        
        if(!this.state.skuSpecType === 'order') {
            this.setState({
                cartNum: this.state.cartNum + data.num,
            })
        }
        this.setState({
            selectSkuData: data
        }, () => {

            if (this.state.skuSpecType === 'order') {
                location.href = '//' + location.host + '/app/order-confirm?tradingItems='
                    + this.state.goodsId + '_' + data.productId + '_' + data.num

            } else {
                this.addCartAjax()
            }
        })

    }
    fetchRecommend = () => {
        // 获取推荐商品
        let param = {
            data: {
                goodsId: this.state.goodsId
            },
            url: '/goods/goodsSuggest',
            successFn: (data) => {
                console.log('推荐商品', data)
                this.setState({
                    recommendList: data.data.list
                })
            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }
        Request.fetch(param)
    }
    enter = (message) => {
        this.setState({
            enter: true,
            message: message,
        });
        setTimeout(
            function () {
                this.leave();
            }.bind(this),
            2000
        );
    }

    leave = () => {
        this.setState({
            enter: false,
            message: "",
        });
    }
    render() {


        let {
            memo,
            name: title,
            subTitle,
            arrivalTime,
            price,
            unit,
            saleMode,
            marketableTime,
            downShelfTime
        } = this.state.goodsData
        let goodsDesData = {
            memo,
            title,
            subTitle,
            arrivalTime,
            price,
            unit,
            saleMode,
            marketableTime,
            downShelfTime,
            skuPrice: this.state.selectSkuData.price
        }
        let specStr = this.state.selectSkuData.key ? this.state.selectSkuData.key.join(','):''
        return (
            <div className="goods-detail-page">
                <div className="goods-detail-slider">
                    {this.genMainSlider()}
                </div>
                <LightBox data={this.state.lightBoxObj}
                    hideFn={this.hideLightBox}
                />
                <GoodsDes
                    data={goodsDesData}
                />
                <GoodsDetailCells
                    clickCb={this.clickCellCb}
                    onClick={() => { console.log(123321) }}
                    data={{
                        specStr: specStr,
                        coupons: this.state.goodsCouponData,
                        activity: this.state.goodsData.activityTitle,
                        pmtId: this.state.goodsData.pmtId
                    }}
                />
                <CouponModal
                    noLogin={this.state.noLogin}
                    isShow={this.state.couponShow}
                    hideFn={this.hideCouponModal}
                    data={this.state.goodsCouponData}
                    modalInfo={this.modalInfo}
                />
                <GoodsRateSlider
                    data={{
                        amount: this.state.commentModel.commentNum,
                        comments: this.state.commentModel.commentItems,
                        goodsId: this.state.goodsId
                    }}
                />
                <GoodsDesDetail
                    imgUrls={this.state.goodsData.detailPic}

                />
                <GoodsRecommend list={this.state.recommendList}/>
                <CartBar
                    cartNum={this.state.cartNum}
                    downShelfStatus={this.state.goodsData.downShelfStatus}
                    saleMode={this.state.goodsData.saleMode}
                    // type={0}
                    addCart={this.addCart}
                    buyNow={this.buyNow}
                    cartDetail={this.cartDetail}
                    orderNow={this.orderNow}
                    lookOther={this.lookOther}
                />
                <GoodsSpec isShow={this.state.specShow}
                    hideFn={this.hideGoodsSpec}
                    initSubmit={this.initSelectSkuFn}
                    submitFn={this.selectSkuFn}
                    type={this.state.skuSpecType}
                    data={{
                        goodsId: this.state.goodsId,
                        picUrl: this.state.goodsData.picUrl,
                        price: this.state.goodsData.price,
                        specDesc: this.state.goodsData.specDesc,
                        specs: this.state.goodsData.specs,
                        products: this.state.goodsData.products,
                        store: this.state.goodsData.store,
                    }}
                />
                <BackTop topShow={this.state.backTop} />
                <Notification
                    enter={this.state.enter}
                    leave={this.leave.bind(this)}
                >
                    {this.state.message}
                </Notification>
            </div>
        )
    }
}
