
import React, { Component } from 'react'
import DOMScroller from 'zscroller/lib/DOMScroller'
import classnames from 'classnames'
import Icon from 'components/Icon'

import './index.scss'

export default class ForecastTime extends Component {
  constructor(props) {
    super(props)
    this.state = {
      index: 0,
      selectedValue: '',
    }
  }
  componentWillReceiveProps(nextProps) {
    if(nextProps.selectedTime.timeFormat || nextProps.time) {
      this.setState({
        selectedValue: nextProps.selectedTime.timeFormat || nextProps.time[0].timeFormat || ''
      })
    }
  }
  componentDidMount() {
    // 暂时写死，挂载到this
    this.itemHeight = Math.floor((document.documentElement.clientWidth / 3.75) * 0.55)
    const itemsHeight = (this.refs.timeItems).getBoundingClientRect().height
    this.domScroller = new DOMScroller(this.refs.timeItems, {
      scrollingX: false,
      snapping: true,
      locking: false,
      penetrationDeceleration: .1,
      minVelocityToKeepDecelerating: 0.5,
      scrollingComplete: this.scrollingComplete
    })
    this.domScroller.scroller.setSnapSize(0, this.itemHeight)
  }
  scrollingComplete = () => {
    const top = this.domScroller.scroller.getValues().top
    const index = Math.floor(top / this.itemHeight)
    this.setState({
      index,
      selectedValue: this.props.time[index].timeFormat
    })
  }
  render() {
    const { time = [], isToday, modalVisible, onClick, onCompleteClick, selectedTime } = this.props
    const selectedValue = this.state.selectedValue;
    const items = time.map((item, index)=> {
      const itemCls = classnames({
        'time-item': true,
        'time-selected': selectedValue === item.timeFormat
      })
      return <li className={itemCls} key={index}>
        {item.timeFormat}
      </li>
    })
    return (
      <div className="forecast-time">
        <div className="forecast-time-cont" onClick={onClick}>
          <p className="tip-text">预计送达时间</p>
          <div className="time">
            <span>{ isToday ?  '今天' : '明天'}</span>
            <span className="hour">{selectedTime.timeFormat}</span>
            <span className="edit-time">
              <Icon type="arrow" size="xxs"></Icon>
            </span>
          </div>
        </div>
        <div className="time-select-mask" style={{
          display: modalVisible? 'block' : 'none'
        }}>
          <div className="time-select-modal">
            <div className="time-select-title">
              选择送达时间
              <div className="time-modal-close" onClick={onClick}>
                <Icon type="close" size="sm"/>
              </div>
            </div>
            <div className="modal-main">
              <div className="day-list">
                <div className="time-selected">{
                  isToday ?  '今天' : '明天'
                }</div>
              </div>
              <div className="time-list">
                <ul className="time-items" ref="timeItems">
                  {items}
                </ul>
              </div>
              <div className="selected-area"></div>
            </div>
            <div className="time-modal-bottom">
              <div className="time-modal-btn" onClick={()=> {
                onCompleteClick(time[this.state.index])
              }} >完成</div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}