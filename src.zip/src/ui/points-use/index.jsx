
import React, {Component} from 'react'

import './index.scss'
import Icon from 'components/Icon'
import Switch from 'components/switch'
import Toast from 'components/toast'

export default class PointUse extends Component {
  constructor(props) {
    super(props)
    this.state = {
      inputValue: '',
      modalVisible: false
    }
  }
  onInputChange=(event)=> {
    // type="number时 输入非数字不触发onchange"
    // type= text 全触发，但是唤起的不是数字键盘，综合考虑，使用number
    let value = event.target.value
    const{ pointCanUse } = this.props
    
    if (value.length === 1) {
      value = value.replace(/[^1-9]/g, '')
    } else {
      value = value.replace(/\D/g,'')
    }
    value = parseInt(value) > pointCanUse ? pointCanUse : value
    this.setState({
      inputValue: value
    })
  }
  onBtnClick=()=> {
    this.switchModalVisible()
    this.props.onConfirm(this.state.inputValue)
  }
  switchModalVisible=() => {
    this.props.onConfirm(this.props.pointInputed || 0)
    this.setState({
      modalVisible: !this.state.modalVisible
    })
  }
  render() {
    const {
      userPoint = 0,
      pointCanUse = 0,
      exchangeRate = 0,
      pointInputed
    } = this.props
    const { modalVisible } = this.state
    return (
      <div className="points">
        <div className="point-bar">
          <div className="point-info">
            <p className="point-label">使用积分</p>
            <p className="point-will-use">
            {
              pointInputed ? `已使用${pointInputed}积分抵¥${(exchangeRate * pointInputed).toFixed(2)}` : `剩余${userPoint}积分，最多可使用${pointCanUse}积分抵¥${(exchangeRate * pointCanUse).toFixed(2)}`
            }
            </p>
          </div>
          <div className="switch">
            <Switch
              onClick={(value) =>{}}
              onChange={(value)=>{
                if (value) {
                  setTimeout(() => {
                    this.switchModalVisible()
                  }, 500)
                } else {
                  this.props.onConfirm('')
                }
              }}
            ></Switch>
          </div>
        </div>
        <div className="point-use-mask" 
          style={{
            display: modalVisible? 'block' : 'none'
          }}
        >
          <div className="point-use-modal">
            <div className="point-use-title">
              <p>使用积分</p>
              <div className="point-use-modal-close" onClick={this.switchModalVisible}>
                <Icon type="close" size="xxs"/>
              </div>
            </div>
            <div className="point-use-body">
              <div className="">
                <p className="point-can-us">剩余{userPoint}积分</p>
                <p className="point-use-tip">最多可使用{pointCanUse}积分抵¥{exchangeRate * pointCanUse}</p>
                <input ref="point-input"
                  className="point-input" type="number"
                  onChange={this.onInputChange}
                  value={this.state.inputValue}
                />
              </div>
            </div>
            <div className="point-use-bottom">
              <div className="point-use-btn" onClick={this.onBtnClick}>确认</div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}