
import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import './index.scss'
import payFailLogo from './pay_fail@2x.png'
import paySuccessLogo from './pay_sucesss@2x.png'
import URLUtil from 'utils/url-util'


export default class PayResult extends Component {
  constructor(props) {
    super(props)
  }
  RedirectToHome() {
    URLUtil.redirectPage({
      page: 'home',
      options: {}
    })
  }

  render() {
    const {
      status = 'success',
      time = '',
      point = 0,
      rePay= ()=>{},
      visible = false
    } = this.props
    
    return (
      visible ? <div className="pay-result">
        <div className="pay-result-tips">
          {
            status === 'success' ?
              <div className="success">
                <img className="pay-logo-success" src={paySuccessLogo} />
                <p className="pay-status">支付成功</p>
                { time !=='' ? <p>预计{time}送达</p> : null}
                { point > 0 && point !== '' ? <p className="pay-point">购物奖励{point}积分</p> : null}
              </div> :
              <div className="fail">
                <img className="pay-logo-fail" src={payFailLogo} />
                <p className="pay-status">支付失败</p>
                {point > 0 && point !== '' ? <p className="pay-point">去支付奖励{point}积分</p> : null}
              </div>
          }
        </div>
        <div className="action-btns">
          <Link to="/app/order">
            <div className="btn btn-ghost">查看订单</div>
          </Link>
          {
            status === 'success' ?
              <div className="btn btn-primary" onClick={this.RedirectToHome.bind(this)}>继续购物</div>
              : 
              <div onClick={rePay} className="btn btn-yellow">重新支付</div>
          }
        </div>
      </div> : null
    )
  }
}