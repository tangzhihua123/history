import React, {Component} from 'react'
import {Link} from 'react-router-dom'
import Request from 'utils/request-util.js'
import Util from 'utils/util'
import JSBridge from 'utils/JSBridge'
import store from 'store'
import qs from 'query-string'
import Login from 'utils/login.js'
import Notification from "components/Notification/NotificationBlock.jsx"
import PointsToast from 'ui/points-toast/points-toast.jsx'
import CouponToast from 'ui/points-toast/coupon-toast.jsx'

import ThanksImg from './award_no.png'
import FreeSend from './award_send.png'

import './index.scss'

import Bg from './points-award-bg.png'
import Circle from './points-circle.png'
import CircleBg from './award-bg.png'
import AwardCircle from './points-award.jpg'
import Btn from './get-btn.png'

export default class PointsAward extends Component {
    constructor(props) {
        super(props)
        this.state = {
            couponShow: false,
            pointsShow: false,
            noAward: false, // 是否没中奖
            nowRotate: 0,
            offsetRotate: 0,
            data: {
            },
            list: [],
            couponData: {},
            ActId: qs.parse(location.search).actId || 6,
            points: 0,
            awardPoints: 0,
            scoreOne: 10, // 单次积分
            JoinCount: -1, // 参与次数
            couponDataCompose: {},
            canClick: true, // 抽奖按钮绑定的事件
            resultCode: 0 
        }
    }

    componentDidMount() {
        let self = this
        document.title = '积分抽奖'
         /*FIXED ME: 客户端打开购物用户打通处理*/
        if(Util.isCustomAgent()) {
            try{
                JSBridge.getData({
                    type: ['token', 'userId'],
                    success: function(data) {
                        let params = store.get('user') ? store.get('user') : {}
                        params.userId = data.userId
                        params.token = data.token
                        store.set('user', params)
                        data.userId && self.fetchPoints()
                        
                    }
                })
            }catch (err) {
                console.log(err)
            }
            
        } else {
            self.fetchPoints()
        }
        
        this.fetchAwardList()
    }
    
    fetchPoints = (type) => {
        
        let param = {
            data: {},
            url: '/user/myScore',
            successFn: (res) => {
                if(res.resultCode === 4005) {
                    this.setState({
                        noLogin: true
                    }, () => {
                        Util.gotoLogin()
                    })
                    // Login.gotoLogin(window.location.pathname+window.location.search)
                    return
                }
                this.setState({
                    points: res.data.usableScore,

                })
            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }

        Request.fetch(param)
    }
    /**
     * [获取转盘角度]
     * @param [number] n 第几份奖品，从0开始
     * @param [number] total 总共几份
     */
    getRotateAngle = (n, total) => {
        let singleAngle = 360/total,
            first = -(singleAngle/2)
        let nStart = singleAngle * (n-0.5)
        // 旋转停止的位置，不能在分割线上，让其有4deg的偏差，比如0-60的角度，让指针停止在4-56的范围内
        let rand = Math.floor(Math.random()*(singleAngle-7))+4
        // 旋转是顺时针，相对指针是逆时针，用360减一下
        let offsetRotate = 360 - (nStart + rand)
        this.setState({
            offsetRotate: offsetRotate
        })
        return offsetRotate
    }
    fetchAward = (cb) => {
        this.setState({
            canClick: false
        })
        let param = {
            data: {
                ActId: this.state.ActId
            },
            url: '/LuckyDraw/GotoJion',
            successFn: (res) => {
                if (res.resultCode === 6101) {
                    this.enter('用户未登录')
                    return
                } else if(res.resultCode === 6102) {
                    this.enter('活动不存在')
                    return
                } else if(res.resultCode === 6103) {
                    this.enter('活动未开始')
                    return
                } else if(res.resultCode === 6104) {
                    this.enter('活动未开始')
                    return
                } else if(res.resultCode === 6105) {
                    this.enter('活动已结束')
                    return
                } else if(res.resultCode === 6106 || res.resultCode === 6109) {
                    this.setState({
                        resultCode: res.resultCode
                    }, () => {
                        cb && cb()
                    })
                    // 活动异常
                } else if(res.resultCode === 6107) {
                    this.enter('没有设置奖项')
                    return
                } else if(res.resultCode === 6108) {
                    this.enter('积分不足')
                    return
                } else {

                    this.setState({
                        resultCode: res.resultCode,
                        data: res.data
                    }, () => {
                        cb && cb()
                    }) 
                }
                
            },
            errorFn: (error) => {
                console.log(error)
            }
        }

        Request.fetch(param)
        
    }
    startClick = () => {
        if(!this.state.canClick) {
            return
        }
        if(this.state.points < this.state.scoreOne) {
            this.enter('积分不足～')
            return
        }
        if(this.state.JoinCount === 0) {
            this.enter('今天的次数用完了，明天再来吧～')
            enter
        }

        console.log()
        this.fetchAward(this.startHandle)
    }

    fetchAwardList = () => {
        let param = {
            data: {
                ActId: this.state.ActId
            },
            url: '/LuckyDraw/LuckyGoodsList',
            successFn: (res) => {
                if (res.resultCode !== 2000) {
                    this.enter('获取失败，请重试')
                    return
                } else {
                    this.setState({
                        list: res.data,
                        scoreOne: res.data[0].ScoreOne,
                        JoinCount: res.data[0].JoinCount
                    })
                }
            },
            errorFn: (error) => {
                console.log(error)
            }
        }

        Request.fetch(param)
    }
    genAwardList = () => {
        // awardType 0:积分 1 优惠券 2 线下商品 3 谢谢惠顾
        
        let data = this.state.list
        
        let awardDivs = data.map((item, i) => {
            let type = item.AwardType,
                text,
                unit,
                des,
                couponType = item.couponType,
                classN
                if(i%2 === 0) {
                    classN = "black"
                } else {
                    classN = "white"
                }
            if(type === 0) {
                // 积分券
                text = item.AwardScore
                des = '积分'
            } else if(type === 1) {
                // 优惠券 4 免运费 6满折券 7 满减券 8实物兑换券
                switch(couponType) {
                    case 4:
                        des = '免邮券'
                        text = <img src={FreeSend} className="gb-text-con-icon" alt=""/>
                        break;
                    case 6:
                    case 2:
                        text = item.FriendlyPmtValue
                        des = '折扣券'
                        break;
                    case 7:
                        text = item.FriendlyPmtValue
                        des = '满减券'
                        unit = 'RMB'
                        break;
                    case 8:
                        text = <img src={item.FriendlyPmtValue} className="gb-text-con-goods" alt=""/>
                        des = '兑换券'
                        break;
                }
            } else if(type === 3) {
                // 谢谢惠顾
                des = '谢谢参与'
                text = <img src={ThanksImg} className="gb-text-con-icon" alt=""/>
            }
            return (
                <div className="gb-wheel-item" key={i}>
                    <div className={"gb-wheel-icontent "+classN} style={{transform: "rotate("+i/6+"turn)"}}>
                        <div className="gb-unit">{unit}</div>
                        <div className="gb-text-con">
                            {
                                text
                            }
                        </div>
                        <div className="gb-des">{des}</div>
                    </div>
                </div>
            )
        })

        return awardDivs
    }
    startHandle = () => {

        if(this.state.noAward) {
            this.setState({
                noAward: false
            })
        }
        let rand
        let list = this.state.list
        let data = this.state.data
        if(this.state.resultCode === 6106 || this.state.resultCode === 6109) {
            list.forEach((item, i) => {
                if(item.AwardType === 3) {
                    rand = i
                }
            })
        } else {
            list.forEach((item, i) => {
                if(data.awardId === item.AwardId) {
                    rand = i
                }
            })
        }

        if(rand === undefined) {
            // 这种代表后台出错，需要把指针指到一个谢谢惠顾上，但是没有谢谢惠顾选项
            this.enter('系统异常，稍后再试～')
            this.setState({
                canClick: true
            })
            return
        }


        let preOffsetRotate = this.state.offsetRotate
        let offsetRotate = this.getRotateAngle(rand, 6)
        let nowRotate = this.state.nowRotate,
            postRotate = nowRotate + offsetRotate + (360*2) + (360 - preOffsetRotate)
        this.setState({
            nowRotate: postRotate
        })
        document.querySelector('.award-img-div').style['transform'] =  'rotate('+ postRotate +'deg)';
        let id = setTimeout(() => {
            
            let item = this.state.list[rand]
            if(item.AwardType === 3) {

                this.setState({
                    noAward: true,
                    couponShow: false,
                    pointsShow: false
                })
            } else if(item.AwardType === 0) {
                this.setState({
                    noAward: false,
                    couponShow: false,
                    pointsShow: true,
                    awardPoints: item.AwardScore,
                    points: this.state.points + item.AwardScore
                })
            } else if(item.AwardType === 1) {
                this.setState({
                    noAward: false,
                    couponShow: true,
                    pointsShow: false,
                    couponData: item
                }, () => {
                    this.setState({
                        couponDataCompose: {
                            couponType: item.couponType,
                            ...this.state.data
                        }
                    })

                    if(Util.isCustomAgent()) {
                        JSBridge.postData({
                            type: 'refreshCoupon',
                            data: {
                               count: 1
                            }
                        })
                    }
                })
            }
            if(this.state.JoinCount !== -1) {
                this.setState({
                    JoinCount: this.state.JoinCount-1
                })
            }
            this.setState({
                canClick: true,
                
            })
            if(this.state.resultCode === 2000) {
                this.setState({
                    points: this.state.points-this.state.scoreOne
                },() => {
                    if(Util.isCustomAgent()) {
                        JSBridge.postData({
                            type: 'refreshScore',
                            data: {
                               score: this.state.points
                            }
                        })
                    }
                })
            }
            clearTimeout(id)
        }, 6000)
        

       
    }

    hidePointsToast = () => {
        this.setState({
            pointsShow: false
        })
    }

    hideCouponToast = () => {
        this.setState({
            couponShow: false
        })
    }

    enter = (message) => {
        this.setState({
            enter: true,
            message: message,
        });
        setTimeout(
            function () {
                this.leave();
            }.bind(this),
            2000
        );
    }

    leave = () => {
        this.setState({
            enter: false,
            message: "",
        });
    }

    // 千分位数字
    milliFormat = (num) => {  
        return num && num.toString().replace(/(?=(?!^)(\d{3})+$)/g, ',')
    }
    render() {
        let visibility = this.state.noAward ? 'visible':'hidden'
        return (
            <div className="points-award-container">
                <img src={Bg} className="points-award-bg" alt=""/>
                <Link to="/points/awarddes">
                    <div className="help">规则说明</div>
                </Link>
                <div className="points-div">
                    <div className="text">积分余额</div>
                    <div className="num">{this.milliFormat(this.state.points)}</div>
                    <div className="des">
                        <span className="text">单次抽奖消耗</span>
                        <span className="single-num">{this.state.scoreOne}</span>
                        <span className="text">积分</span>
                    </div>
                </div>

                <div className="fail-tips" style={{visibility:visibility}}>很遗憾，没有中奖，再试试吧</div>
                <div className="circle-container">
                    {/* <img src={Circle} className="circle-img" alt=""/> */}
                    <div className="award-img-div">
                        <img src={CircleBg} className="award-img" alt=""/>
                        <div className="award-container">
                            {
                                this.genAwardList()
                            }
                        </div>
                    </div>
                    <img src={Btn} className="btn-img" onClick={this.startClick} alt=""/>
                </div>
                <PointsToast
                points={this.state.awardPoints}
                isShow={this.state.pointsShow} 
                hideFn={this.hidePointsToast}
                />
                <CouponToast isShow={this.state.couponShow}
                    data={this.state.couponDataCompose}
                    hideFn={this.hideCouponToast}
                />
                <Notification
                    enter={this.state.enter}
                    leave={this.leave.bind(this)}
                >
                    {this.state.message}
                </Notification>
            </div>
        )
    }
}