import requestUtil from './request-util'

const isWeixin = navigator.userAgent.indexOf('MicroMessenger') > -1

const jsApiList = [
  'onMenuShareTimeline', 'onMenuShareAppMessage', 'onMenuShareQQ',
  'onMenuShareWeibo', 'onMenuShareQZone', 'startRecord', 'stopRecord',
  'onVoiceRecordEnd', 'playVoice', 'pauseVoice', 'stopVoice', 'onVoicePlayEnd',
  'uploadVoice', 'downloadVoice', 'chooseImage', 'previewImage', 'uploadImage',
  'downloadImage', 'translateVoice', 'getNetworkType', 'openLocation', 'getLocation',
  'hideOptionMenu', 'showOptionMenu', 'hideMenuItems', 'showMenuItems', 'hideAllNonBaseMenuItem',
  'showAllNonBaseMenuItem', 'closeWindow', 'scanQRCode', 'chooseWXPay', 'openProductSpecificView',
  'addCard', 'chooseCard', 'openCard'
]

function loadWeixinSdkJs() {
  if (document.getElementById('wx-jsdk')) {
    return
  }
  var script = document.createElement('script')
  script.id = 'wx-jsdk'
  script.onload = function () {
    // 请求后台配置信息
    // window.wx || window.jWeixin
  }
  script.onerror = function () {
    console.error('微信jsdk加载失败')
  }
  script.src = 'http://res.wx.qq.com/open/js/jweixin-1.2.0.js'
  document.head.appendChild(script)
}

export default class Wx {
  static init() {
    console.log('111')
    loadWeixinSdkJs()
  }
  config() {

  }
}