
/**
 * 微信支付
 * @param {*} json 
 * @param {*} callback 
 */
function wxPay(json, callback) {
  let { payParam } = json;
  let onBridgeReady = function () {
    WeixinJSBridge.invoke(
      'getBrandWCPayRequest', {
        "appId": payParam.appId,     //公众号名称，由商户传入     
        "timeStamp": payParam.timeStamp,    //时间戳，自1970年以来的秒数     
        "nonceStr": payParam.nonceStr, //随机串     
        "package": payParam.packageStr,
        "signType": "MD5",         //微信签名方式：     
        "paySign": payParam.paySign //微信签名 
      },
      function (res) {
        let returnCode;
        if (res.err_msg == "get_brand_wcpay_request:ok") {
          // 使用以上方式判断前端返回,微信团队郑重提示：res.err_msg将在用户支付成功后返回ok，但并不保证它绝对可靠。 
          returnCode = 'SUCCESS';
        } else if (res.err_msg == 'get_brand_wcpay_request:cancel') {
          returnCode = 'CANCEL';
        } else {
          returnCode = 'FAILED';
        }
        callback && callback(returnCode, json);
      })
  }

  if (typeof WeixinJSBridge == "undefined") {
    if (document.addEventListener) {
      document.addEventListener('WeixinJSBridgeReady', onBridgeReady, false);
    } else if (document.attachEvent) {
      document.attachEvent('WeixinJSBridgeReady', onBridgeReady);
      document.attachEvent('onWeixinJSBridgeReady', onBridgeReady);
    }
  } else {
    onBridgeReady();
  }
}

export default {
  wxPay
}

