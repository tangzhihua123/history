// 几个输入参数
// 一. orderStatus 订单状态 0 活动  -1  死单（已关闭）1 已取消
// 二. payStatus 支付状态 0 未支付 1 已支付 3 部分付款 4 部分退款 5 全额退款 6 售后退款中
// 三. shipStatus 发货状态   0 分拣中, 1 已出库,2 配送中,3 已签收4配送异常

// 前端状态定义，英文更易理解, 已评价不在讨论范围, 写成常量最好
// unpay 未支付
// prepare 配货中
// shipping 配送中 
// complete 已完成
// closed 已关闭
// cancle 已取消
// 售后申请中 = 0,退款中 = 1,拒绝售后 = 2,退款成功 = 3,售后已取消 = 4,等待买家退货 = 5,买家退货等待确认 = 6,售后完成 = 7,售后关闭 = 8

export function getAfterSalesStatus(status) {

  if (status === 0 ) {// 售后申请中
    return 'check'
  }else if (status === 1)  {//退款中
      return 'refunding'
  }else if (status === 3)  {//退款成功
    return 'refund'
  } else if(status === 2)  {//拒绝售后
    return 'refuse_sell_after'
  } else if(status === 4) {//售后已取消
    return 'after_sale_canel'
  }else if(status === 5) {//等待买家退货
      return 'wait_buyers_returnGood'
  }else if(status === 6) {//买家退货等待确认
      return 'wait_buyers_confirm'
  }else if(status === 7) {//售后完成
      return 'refuse_sell_after_complete'
  }else if(status === 8) {//售后关闭
      return 'refuse_sell_after_close'
  }
}





