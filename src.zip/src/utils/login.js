import cookie from 'js-cookie'
import RequestUtil from './request-util'


class Login {

  /**
   * 登陆方法
   * @param {number} mobile
   * @param {number} verifyCode
   * @param {func} successFn
   * @param {func} errorFn
   */
  static login({ mobile, verifyCode, successFn, errorFn }) {
    RequestUtil.fetch({
      url: '/user/login',
      data: {
        mobile,
        verifyCode
      },
      successFn: successFn,
      errorFn: errorFn
    })
  }
  /**
   * 跳转到登录页面
   * @param {string} [redirectUrl]
   */
  static gotoLogin(redirectUrl) {
    let url
    if(!redirectUrl) {
      url = '?redirect=' + location.pathname + location.search
    } else {
      url = '?redirect=' + redirectUrl
    }
    
    window.location.href = window.location.protocol + "//" + window.location.host + '/app/login' + url
  }
  /**
   * 只检查前端的登录状态， 不能检测token失效
   */
  static checkLogin() {
    const user = localStorage.getItem('user')
    return !!user
  }
}
export default Login


