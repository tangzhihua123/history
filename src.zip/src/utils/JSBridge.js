!(function (window) {
    function isIOS() {
        var __userAgent = navigator.userAgent;
        return !!__userAgent.match(/(iPhone|iPod|iPad)/i);
    }
    function isAndroid() {
        var __userAgent = navigator.userAgent;
        return !!__userAgent.match(/Android/i);
    }
    function isArray(array) {
        return Object.prototype.toString.call(array) === "[object Array]"
    }

    function injectPostMessage() {
        if(isIOS()) {
            /* window[publicKeys.JSBridge]['postMessage'] = function (data) {
                console.log(JSON.parse(data))
            }*/

            // window[publicKeys.JSBridge]['postMessage'] = window.webkit.messageHandlers.XGJSBCommonJSAPI.postMessage
        }else {
            try {
                // console.log(publicKeys.JSBridge,"publicKeys.JSBridge")
                window[publicKeys.JSBridge].postMessage = window.android.postMessage
            }catch (err) {
                console.log(err)
            }
           /* window[publicKeys.JSBridge]['postMessage'] = function (data) {
                console.log(JSON.parse(data))
            }*/
        }
    }

    var getInfoKeys = [
        'getDeviceInfo',
        'getNetworkType',
        'getUserInfo',
        'getLocation',
        'getData'
    ]

    var shareKeys = [
        'onShareTimeline',
        'onShareWXMessage',
        'onShareQQ',
        'onShareQZone',
        'onShareWeibo',
        'onShareMulti'
    ]


    function checkShareMulti(array) {
        var shareList = [
            'timeline',
            'wxmessage',
            'weibo',
            'qq',
            'qzone'
        ]

        for(var i = 0, l = array.length; i < l; i++) {
            if(shareList.indexOf(array[i]) === -1) {
                return false
            }
            return true
        }
    }
    
    var methodMap = {
        checkJsApi: 'checkJsApi',
        showLoading: 'showLoading',
        hideLoading: 'hideLoading',
        toast: 'toast',
        alert: 'alert',
        confirm: 'confirm',
        getData: '',
        getDeviceInfo: 'deviceInfo',
        getNetworkType: 'networkType',
        getUserInfo: 'userInfo',
        getLocation: 'location',
        onShareTimeline: 'timeline',
        onShareWXMessage: 'wxmessage',
        onShareQQ: 'qq',
        onShareQZone: 'qzone',
        onShareWeibo: 'weibo',
        onShareMulti: '',
        postData: 'postData',
        uploadImage: 'uploadImage',
        gotoNative: 'gotoNative',
        gotoWebView: 'gotoWebView',
        closeWebView: 'closeWebView',
        refreshPage: 'refreshPage',
        disablePullRefresh: 'disablePullRefresh',
        disableSlideSwipe: 'disableSlideSwipe',
        setTitle: 'setTitle',
        showOptionMenu: 'showOptionMenu',
        hideOptionMenu: 'hideOptionMenu',
        showMenuItems: 'showMenuItems',
        hideMenuItems: 'hideMenuItems',
        showAllNonBaseMenuItem: 'showAllNonBaseMenuItem',
        hideAllNonBaseMenuItem: 'hideAllNonBaseMenuItem',
        openKeyboard: 'openKeyboard'
    }

    var publicKeys = {
        JSBridge: '__JSBridge'
    }

    var jsBridgeObj = window[publicKeys.JSBridge] = {}
    jsBridgeObj.callbackObj = {}
    jsBridgeObj.cid = 0
    jsBridgeObj.cb = 'cb'
    injectPostMessage()
    // console.log(window[publicKeys.JSBridge])
    // var postMessage
    // if(typeof window[publicKeys.JSBridge]['postMessage'] === 'function') {
    //     postMessage = jsBridgeObj['postMessage']
    // } else {
    //     throw 'window.' + publicKeys.JSBridge + '.postMessage is not a function.'
    // }
    
   
    window.JSBridge = {}

    // 方法改成放在对象上
    injectProto(window.JSBridge)
    // console.log(window.JSBridge)

    if ( typeof module === "object" && typeof module.exports === "object" ) {
        module.exports = JSBridge
    }

    function translateApiList(array) {
        var list = array.map(function (item) {
            if(shareKeys.indexOf(item) != -1 && item !== 'onShareMulti') {
                return 'share_' + item.slice(7).toLowerCase()
            }else if(getInfoKeys.indexOf(item) != -1 && item !== 'getData') {
                return 'getData_' + item.slice(3).replace(/(\w)/,function(v) {return v.toLowerCase()});
            }else if(item == 'onShareMulti' || item == 'getData') {
                throw 'You can\'t check' + item + 'api by checkJsApi.'
            }else {
                return item
            }
        })
        return list
    }


    function wrap(type) {
        return function (opt) {
            var temp_type
            if(shareKeys.indexOf(type) != -1) {
                temp_type = 'share'
                if(type == 'onShareMulti') {
                    if(!checkShareMulti(opt.type)) {
                        throw 'onShareMulti\'s type list has a wrong type. Only item in "[timeline", "wxmessage", "weibo", "qq", "qzone"] can be passed.'
                    }
                    // 分享多个时，使用者会传入一个下划线分割的type，不用设置
                }else{
                    opt = opt ? opt : {}
                    opt.type = methodMap[type]
                }
            }else if(getInfoKeys.indexOf(type) != -1) {
                temp_type = 'getData'
                if(type == 'getData') {
                    // getData传入自定义数据，本身有type，不需再设置
                }else {
                    opt = opt ? opt : {}
                    opt.type = methodMap[type]
                }
            }else if(type == 'checkJsApi') {
                try {
                    var apiList = opt.api
                    if(isArray(apiList)) {
                        opt.api =  translateApiList(apiList)
                    }else {
                        throw 'checkJsApi\'s api property must be array.'
                    }
                }catch (err) {
                    throw err
                }

                temp_type = type
            }else if(type == 'showMenuItems' || type == 'hideMenuItems') {
                var list = translateApiList(opt.menuList)
                opt.menuList = list
                temp_type = type
            }else if(type == 'confirm') {
                temp_type = type
                opt.confirm = opt.confirm ? opt.confirm : '确定'
                opt.cancel = opt.cancel ? opt.cancel : '取消'
            }else {
                temp_type = type
            }

            // 只有有回调时，才会生成会成回调函数
            if(typeof opt === 'object' && (typeof opt.success === 'function' || typeof opt.fail === 'function' || typeof opt.cancel === 'function' || typeof opt.complete === 'function')) {
                var id = jsBridgeObj.cid
                var cbName = jsBridgeObj.cb
                jsBridgeObj.callbackObj[cbName+id] = function (res) {
                    var resData = JSON.parse(res)
                    console.log('resData', resData)
                    if(resData.type === 'success') {
                        opt.success && opt.success(resData.data)
                    }else if(resData.type === 'fail') {
                        opt.fail && opt.fail(resData.data)
                    }else if(resData.type === 'cancel') {
                        opt.cancel && opt.cancel(resData.data)
                    }
                    // 成功与否，都执行complete
                    opt.complete && opt.complete(resData.data)
                    // 执行完删除回调
                    // delete jsBridgeObj['callbackObj'][cbName+ ''+id]
                }
                jsBridgeObj.cid++

                if(isIOS()) {
                    // jsBridgeObj.postMessage(JSON.stringify({id: cbName+''+id, type: temp_type, option: opt}))
                    window.webkit.messageHandlers.XGJSBCommonJSAPI.postMessage(JSON.stringify({id: cbName+''+id, type: temp_type, option: opt}))
                }else {
                    // jsBridgeObj.postMessage(JSON.stringify({id: cbName+''+id, type: temp_type, option: opt}))
                    window.android.postMessage(JSON.stringify({id: cbName+''+id, type: temp_type, option: opt}))
                }

            }else {
                opt = opt || {}
                if(isIOS()) {
                    // jsBridgeObj.postMessage(JSON.stringify({type: temp_type, option: opt}))
                    window.webkit.messageHandlers.XGJSBCommonJSAPI.postMessage(JSON.stringify({type: temp_type, option: opt}))
                }else {
                    // console.log('打印jsbridge',JSON.stringify({type: temp_type, option: opt}))
                    window.android.postMessage(JSON.stringify({type: temp_type, option: opt}))
                    // jsBridgeObj.postMessage(JSON.stringify({type: temp_type, option: opt}))
                }
            }
        }
    }
    function injectProto(proto) {
        var keys = Object.keys(methodMap)
        // console.log(keys,'keys')

        keys.forEach(function (key) {
            // console.log(key,"key")
            proto[key] = wrap(key)
        })

    }


})(window)

