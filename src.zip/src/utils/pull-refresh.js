const Hammer = require('hammerjs')
/**
 * 下拉刷新，暂时废弃，HammerJS有点问题
 * @module PullToRefresh
 * @class
 */
class Pull {
    /**
     * 下拉刷新
     * 
     */
    static status = {
        enable: false,
        hasInsert: false,
        loadEl: '.m-load-div',
        loadInnerEl: '.m-load-inner-div',
        contentEl: '#app',
        loadDivHeight: 50,
        feedback: 200,
        curStage: 0,
        offset: 0,// 下拉偏移量
        x1: 0,// 手指按下的位置
        y1: 0,
        y2: 0,
        offsetY: 0,
        loadStatus: {
            stage0: '<div>继续下拉刷新</div>',// 继续下拉刷新
            stage1: '<div>松手即可刷新</div>',// 松手即可刷新
            stage2: '<div>正在刷新</div>',// 正在刷新
            stage3: '<div>刷新成功</div>',// 刷新成功
            stage4: '<div>刷新失败</div>',// 刷新成功
        }
    }
    static statusCopy = {}
    static init({el, load}) {
        Pull.statusCopy = {...Pull.status} //reset用
        var ele
        if(el) {
            ele = typeof el == 'string' ? document.querySelector(el) : el
        }else {
            ele = document.querySelector('body')
        }
        var loadDivString = `
        <div class='m-load-div' style="display:block;">下拉加载</div>
        `
        var hammer = new Hammer.Manager(ele, {
            // touchAction: 'pan-y',
            domEvents: true
        })
        hammer.add(new Hammer.Pan({
            direction: Hammer.DIRECTION_VERTICAL
        }))

        hammer.on('pan', function(e) {
            if(Pull.status.enable) {
                var offsetY = e.center.y - Pull.status.y1
                console.log('y2: ', e.center.y, 'y1: ',Pull.status.y1)
                if(offsetY > Pull.status.loadDivHeight) {
                    return 
                }else {
                    // Pull.status.offsetY = offsetY
                    if(offsetY>0&&offsetY<=30) {
                        Pull.status.curStage = 0
                        Pull.setLoadInnerHTML()
                    }else if(offsetY>30&&offsetY<=50) {
                        Pull.status.curStage = 1
                        Pull.setLoadInnerHTML()
                    }
                }
            }
        })
        hammer.on('panstart', function(e) {
            console.log('start', e)
            console.log('panstart scrollTop',document.body.scrollTop)
            if(document.body.scrollTop === 0) {
                Pull.status.enable = true
                Pull.status.x1 = e.center.x
                Pull.status.y1 = e.center.y
                console.log('e.center.x', e.center.x, 'e.center.y',e.center.y)
            }
        })



        hammer.on('pandown', function(e) {
            

            
            // if(Pull.status.enable) {

            var offsetY = e.center.y - Pull.status.y1
            Pull.insertLoadDiv(document.querySelector('body'))
            console.log('高度',e,Pull.status.loadDivHeight, offsetY)
            
            var contentEl = document.querySelector(Pull.status.contentEl)
            var loadDiv = document.querySelector(Pull.status.loadEl)

            Pull.setElTransformY(contentEl, '-'+(Pull.status.loadDivHeight-offsetY)+'px')
            Pull.setElTransformY(loadDiv, '-'+(Pull.status.loadDivHeight-offsetY)+'px')
            console.log('transformY', '-'+(Pull.status.loadDivHeight-offsetY)+'px')
            // }    
        })

        hammer.on('panend', function(e) {
            console.log('end', e)
            console.log('end enable',Pull.status.enable)
            if(Pull.status.enable) {
                if(Pull.status.curStage === 1) {
                    console.log('执行刷新操作')
                    Pull.status.curStage = 2
                    Pull.setLoadInnerHTML()

                    // promise
                    load().then(function(res) {
                        console.log('刷新成功')
                        Pull.status.curStage = 3
                        Pull.setLoadInnerHTML()
                        setTimeout(function() {
                            // Pull.resetTransformY()
                            Pull.resetStatus()
                        }, Pull.status.feedback)
                    })
                    .catch(function(err) {
                        console.log('刷新失败')
                        Pull.status.curStage = 4
                        Pull.setLoadInnerHTML()
                        setTimeout(function() {
                            // Pull.resetTransformY()
                            Pull.resetStatus()
                        }, Pull.status.feedback)
                    })

                }else if(Pull.status.curStage === 0) {
                    // Pull.resetTransformY()
                    Pull.resetStatus()
                }   
            }
        })
        hammer.on('panup', function(e) {
            if(Pull.status.enable) {
                var offsetY = e.center.y - Pull.status.y1

                var contentEl = document.querySelector(Pull.status.contentEl)
                var loadDiv = document.querySelector(Pull.status.loadEl)

                Pull.setElTransformY(contentEl, '-'+(Pull.status.loadDivHeight-offsetY)+'px')
                Pull.setElTransformY(loadDiv, '-'+(Pull.status.loadDivHeight-offsetY)+'px')
            }
        })
    }


    static insertLoadDiv(el) {
        
        if(Pull.status.hasInsert) {
            return
        }else {
            var newDiv = document.createElement('div')
            var innerDiv = document.createElement('div')
            
            Pull.setLoadInnerHTML(innerDiv)
            newDiv.appendChild(innerDiv)
            el.insertBefore(newDiv, el.firstChild)
            newDiv.className = newDiv.className + ' m-load-div'
            innerDiv.className = Pull.status.loadInnerEl.replace('.', '')
            innerDiv.style.lineHeight = Pull.status.loadDivHeight + 'px'
            newDiv.style.height = Pull.status.loadDivHeight + 'px'
            //var el_h = parseInt(getComputedStyle(newDiv).height)
            Pull.status.hasInsert = true
            //Pull.status.loadDivHeight = el_h

        }
        
    }
    static setElTransformY(el, value) {
        el.style.transform = "translate3D(0,"+value+",0)"
    }
    static setLoadInnerHTML(el) {
        var ele = el ? el : document.querySelector(Pull.status.loadInnerEl)
        console.log('ele',ele,el)
        ele.innerHTML = Pull.status.loadStatus['stage'+Pull.status.curStage]
    }
    static resetTransformY() {
        var contentEl = document.querySelector(Pull.status.contentEl)
        var loadDiv = document.querySelector(Pull.status.loadEl)

        Pull.setElTransformY(contentEl, '-'+Pull.status.loadDivHeight+'px')
        Pull.setElTransformY(loadDiv, '-'+Pull.status.loadDivHeight+'px')
    }
    static resetStatus() {
        Pull.status = {...Pull.statusCopy}
        var body = document.querySelector('body')
        var loadDiv = document.querySelector(Pull.status.loadEl)
        body.removeChild(loadDiv)
        var contentEl = document.querySelector(Pull.status.contentEl)
        Pull.setElTransformY(contentEl, 0)
    }

}
export default Pull