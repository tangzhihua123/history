import Loadable from 'react-loadable'
import React from 'react'
function Loading() {
    return null;
}

function Load(opts) {
    return Loadable(Object.assign({
        loading: Loading
    }, opts))

}


export {
    Load
}