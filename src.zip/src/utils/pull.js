/**
 * @module Pull
 */

/**
 * @name Pull
 * @example
 * var handleRefresh = () => {
 *   return new Promise(function(resolve, reject) {
 *     setTimeout(resolve, 2000, 'I\'m OK' )
 *   })
 * }
 * var pull = new Pull({load: handleRefresh})
 * @param {object} $0 $0为解构赋值的写法
 * @param {string|HTMLElement} [$0.el] 可以传入一个dom元素或者类名、id,类名需要加.,id需要加#，表示加载提示的dom元素插入的容器，默认为body[暂时只支持body，所以此处不要填写]
 * @param {function} $0.load 加载的函数，此函数必须返回一个Promise对象，用来设置加载成功和失败的提示，必填
 * @param {number} [$0.showTime] 加载结束后，加载状态显示的时间，单位为毫秒，默认500ms，选填
 * @param {number} [$0.distance] 加载提示元素显示完全需要的手指移动的距离，单位为px，默认为300
 */

(function() {
    
    function Pull({el, load, showTime, distance}) {

        this.el = typeof el == 'string' ? document.querySelector(el) : el
        this.load = load
        this.currentStage = 0
        this.showTime = this.initState.showTime
        this.transformTop = this.initState.loadHeight
        this.transformCurTop = this.initState.loadHeight
        this.loadHeight = this.initState.loadHeight
        this.distance = this.initState.distance
        this.preDate = +new Date()
        this.body = document.querySelector('body')
        this.start = this.start.bind(this);
        this.move = this.move.bind(this);
        this.end = this.end.bind(this);
        this.cancel = this.cancel.bind(this);
        this.el.addEventListener('touchstart', this.start, false)
        this.el.addEventListener('touchmove', this.move, false)
        this.el.addEventListener('touchcancel', this.cancel, false)
        this.el.addEventListener('touchend', this.end, false)

        this.init()
    }
    Pull.prototype = {
        start: function(e) {
            if (!e.touches) return;
            this.now = Date.now();
            this.x1 = this.preX = e.touches[0].pageX;
            this.y1 = this.preY = e.touches[0].pageY;
            if(document.body.scrollTop === 0) {
                this.enable = true
            }
        },
        move: function(e) {

            var date = +new Date()
            if(date - this.preDate < 100) {
                return
            }
            this.direction = this._swipeDirectionUpDown(this.preX, this.preY, e.changedTouches[0].pageX, e.changedTouches[0].pageY)
            // console.log(this.direction)
            if(!this.body.scrollTop > 0) {
                if(this.direction === 'Down') {
                    if(this.getTranslateY(this.body.style.transform) > 0) {
                        var offset1 = Math.abs(parseInt((e.changedTouches[0].pageY-this.y1)/this.distance * this.loadHeight))
                        if(offset1 > this.transformCurTop) {
                            offset1 = this.transformCurTop
                        }
                        this.transformCurTop -= offset1
                        this.body.style.transform = this.genTranslateY(this.transformCurTop)
                    }
                }else if(this.direction === 'Up') {
                    // 页面上移事件有问题，暂时注释
                    /* console.log('curTop',this.transformCurTop,'top',this.transformTop)
                    if(this.transformCurTop < this.transformTop) {
                        var offset2 = Math.abs(parseInt((e.changedTouches[0].pageY-this.y1)/this.distance * this.loadHeight))
                        if(offset2+this.transformCurTop > this.transformTop) {
                            offset2 = this.transformTop - this.transformCurTop
                        }
                        this.transformCurTop += offset2
                        this.body.style.transform = this.genTranslateY(this.transformCurTop)
                    } */
                }
            }
            this.setInner()
            this.preX = e.changedTouches[0].pageX
            this.preY = e.changedTouches[0].pageY

            this.preDate = date
        },
        cancel: function(e) {
            console.log('cancel')
        },
        end: function(e) {
            if(this.currentStage === 0) {
                this.reset()
            }else if(this.currentStage === 1) {
                this.setInner(2)
                this.executeCb()
            }
        },
        _swipeDirection: function (x1, y1, x2, y2) {
            return Math.abs(x1 - x2) >= Math.abs(y1 - y2) ? (x1 - x2 > 0 ? 'Left' : 'Right') : (y1 - y2 > 0 ? 'Up' : 'Down')
        },
        _swipeDirectionUpDown: function (x1, y1, x2, y2) {
            return y1 - y2 > 0 ? 'Up' :y1 -y2 <0 ? 'Down' : 'Equal'
        },
        clean: function() {
            this.x1 = undefined
            this.y1 = undefined
        },
        init: function() {
            var divStr = `
                <div>
                    <div class="load-text-div" style="font-size:30px;">下拉刷新</div>
                </div>
            `
            var loadDiv = document.createElement('div')
            loadDiv.innerHTML = divStr
            var body = document.querySelector('body')
            body.insertBefore(loadDiv, body.firstChild)
            loadDiv.style.display = 'block'
            loadDiv.style.height = '50px'
            loadDiv.style.padding = '10px 0'
            loadDiv.style.fontSize = '30px'
            loadDiv.style.textAlign = 'center'
            loadDiv.className = 'm-load-div'
            body.style.transform = this.genTranslateY(50)
        },
        initState: {
            stage0: '<div>继续下拉刷新</div>',// 继续下拉刷新
            stage1: '<div>松手即可刷新</div>',// 松手即可刷新
            stage2: '<div>正在刷新</div>',// 正在刷新
            stage3: '<div>刷新成功</div>',// 刷新成功
            stage4: '<div>刷新失败</div>',// 刷新成功
            loadHeight: 50,
            distance: 300,
            showTime: 500// 成功或失败提示语显示的时间

        },
        genTranslateY: function(num) {
            return 'translate3D(0,-'+num+'px,0)'
        },
        getTranslateY: function(str) {
            var arr = str.split(',')
            var n = Math.abs(parseInt(arr[1]))
            return n
        },
        setInner: function(stage) {
            var stg
            if(stage === undefined) {
                var translatey = this.getTranslateY(document.body.style.transform)
                if(translatey<this.transformTop/2) {
                    stg = 1
                }else {
                    stg = 0
                }
            }else {
                stg = stage
            }
            if(this.currentStage !== stg) {
                this.currentStage = stg
                var div = document.querySelector('.load-text-div')
                div.innerHTML = this.initState['stage'+this.currentStage]
            }
        },
        reset: function() {
            this.body.style.transform = this.genTranslateY(this.transformTop)
            this.body.scrollTop = 0
            this.currentStage = 0
            this.transformCurTop = this.initState.loadHeight
        },
        executeCb: function() {
            var _this = this
            this.load().then(function(res) {
                _this.setInner(3)
                setTimeout(function() {
                    _this.reset()
                }, _this.showTime)
            }).catch(function(err) {
                _this.setInner(4)
                setTimeout(function() {
                    _this.reset()
                }, _this.showTime)
            })
        },
        preventWXScroll: function() {
            var overscroll = function(el) {
                el.addEventListener('touchstart', function() {
                    var top = el.scrollTop,
                        totalScroll = el.scrollHeight,
                        currentScroll = top + el.offsetHeight;
                    // If we're at the top or the bottom of the containers
                    // scroll, push up or down one pixel.
                    //
                    // this prevents the scroll from "passing through" to
                    // the body.
                    if(top === 0) {
                        el.scrollTop = 1;
                    } else if(currentScroll === totalScroll) {
                        el.scrollTop = top - 1;
                    }
                });
                el.addEventListener('touchmove', function(evt) {
                    // if the content is actually scrollable, i.e. the content is long enough
                    // that scrolling can occur
                    if(el.offsetHeight < el.scrollHeight)
                        evt._isScroller = true;
                });
            }
            overscroll(document.querySelector('.scroll'));
            document.body.addEventListener('touchmove', function(evt) {
                // In this case, the default behavior is scrolling the body, which
                // would result in an overflow.  Since we don't want that, we preventDefault.
                if(!evt._isScroller) {
                    evt.preventDefault();
                }
            });
              
            /* 
            链接：http://www.jianshu.com/p/2eddee561971
             */
        }

    }
    if (typeof module !== 'undefined' && typeof exports === 'object') {
        module.exports = Pull;
    } else {
        window.Pull = Pull;
    }
})();