import Util from './util.js'
var _ = require('lodash');
/**
 * 加载工具
 * @module Load
 * @class
 */

class Load {
    /**
     * @private
     */
    static bottomLoadInner = (cb) => (t1) => {
        // Fix 用户体验预加载处理
        if(document.body.scrollHeight - window.screen.availHeight - 100 <= window.scrollY) {
            cb && cb()
        }
    }
    /**
     * 到达页面最底部执行函数，用以上拉加载，已用节流函数包装，100ms内至少执行一次
     * @memberof Load
     * @static
     * @example
     * Load.bottomLoad(()=>{console.log(123)})
     * @param {function} [cb] 到达底部执行的回调，选填
     * 结束后需要执行清理工作
     */
    static bottomLoad(cb) {

        let load = _.throttle(Load.bottomLoadInner(cb), 2000)

        // window.onscroll = () => {
        //     /* let t1 = +new Date()
        //     if(document.body.scrollHeight - window.screen.availHeight <= document.body.scrollTop) {
        //         t1 =  +new Date()
        //     } */
        //     // console.log('到达底部的原始时间', t1)
        //     load()
        // }
        window.addEventListener('scroll', load, false)
        return () => {
            window.removeEventListener('scroll', load, false)
        }
        
    }
}

export default Load