// 几个输入参数
// 一. orderStatus 订单状态 0 活动  -1  死单（已关闭）1 已取消
// 二. payStatus 支付状态 0 未支付 1 已支付 3 部分付款 4 部分退款 5 全额退款 6 售后退款中
// 三. shipStatus 发货状态   0 分拣中, 1 已出库,2 配送中,3 已签收4配送异常

// 前端状态定义，英文更易理解, 已评价不在讨论范围, 写成常量最好
// unpay 未支付
// prepare 配货中
// shipping 配送中 
// complete 已完成
// closed 已关闭
// cancle 已取消


export function getOrderStatus(orderStatus, payStatus, shipStatus) {
  if (orderStatus === -1) {
    return 'closed'
  } else if (orderStatus === 1) {
    return 'cancel'
  }

  if (payStatus === 0 ) {
    return 'unpay'
  }
  if (shipStatus === 0 ) {
    return 'prepare'
  } else if (shipStatus === 1)  { // 已出库也算配送中
    return 'shipping'
  } else if(shipStatus === 2)  {
    return 'shipping'
  } else if(shipStatus === 3) {
    return 'complete'
  }
}





