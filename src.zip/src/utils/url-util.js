/**
 * URL common util.
 * @module URLUtil
 * @class
 */

const qs = require('query-string')
import store from 'store'
import JSBridge from 'utils/JSBridge'
import Util from 'utils/util'


class URLUtil {
    /**
     * redirect page in the same origin. 
     * @param {Object} $0
     * @param {string} $0.page page name
     * @param {Object} [$0.options] optional query object
     */
    static redirectPage({page, options}) {
        let url,
            qstring
        if(options && (typeof options === 'object')) {
            qstring = qs.stringify(options)
        }
        location.href = qstring ? '/'+page +'?'+qstring : '/'+page
    }

    /**
     * get param's value from current URL
     * @param {string} key the key of query object
     * @return {*} the value of the query object's key 
     */ 
    static fetchValueByURL(key) {
        let parsed = qs.parse(location.search)
        return parsed[key]
    }

    static fetchValueByURL2(url,key) {
        let parsed = qs.parse('?'+ url.split('?')[1])
        return parsed[key]
    }

    static RedirectDetail(goodsId, goodsSource, sourceId) {
        if(Util.isCustomAgent()) {
            JSBridge.gotoNative({
                    type: [''],
                    page: 'productDetails',
                    data: {
                        goodsIds: goodsId,
                    },
                    success: function(data) {
                        let params = store.get('user') ? store.get('user') : {}
                        params.userId = data.userId
                        params.token = data.token
                        store.set('user', params)
                    }
            })
        }else {
            let params = {}

            goodsSource && (params.goodsSource = goodsSource)
            sourceId && (params.sourceId = sourceId)
            
            URLUtil.redirectPage({
                page: 'app/goodsdetail',
                options: {
                    goodsId: goodsId,
                    ...params
                }
            })
        }
    }
}

export default URLUtil