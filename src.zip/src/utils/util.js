import qs from 'query-string'

/**
 * common util
 * @module Util
 * @class
 */

class Util {
    /**
     * 节流函数
     * @memberof Util
     * @example
     * 给页面添加滚动事件，若滚动事件执行一次，则50ms后打印233
     * 若滚动事件一直在触发，则100ms后打印233
     * var test = () => {console.log(233)}
     * var warp = Util.throttle(test, 50, 100)
     * window.onscroll = warp
     * @param {function} fn 需要包装的函数
     * @param {number} delay 延迟执行时间，单位为毫秒
     * @param {number} mustRunDelay 必须执行的时间，例如拖动事件中，若不加限制，函数一直不会被触发，此参数规定必须触发函数的时间
     * @param {object} [context] 函数的上下文对象
     * @static
     * 
     */
    static throttle(fn, delay, mustRunDelay, context) {
        let timer = null;
        let t_start;

        return function () {
            let args = arguments,
                t_curr = +new Date();
            clearTimeout(timer);

            if (!t_start) {
                t_start = t_curr;
            }

            if (t_curr - t_start >= mustRunDelay) {
                fn.apply(context, args);
                t_start = t_curr;
            } else {
                timer = setTimeout(function () {
                    fn.apply(context, args);
                }, delay);
            }
        };
    }
    /**
     * 判断当前设备是否为Android
     * @static
     * @memberof Util
     * @return {boolean}
     */
    static isAndroid() {
        let __userAgent = navigator.userAgent;
        return !!__userAgent.match(/Android/i);
    }

    static isWeixin() {
        var ua = navigator.userAgent.toLowerCase();
        var isWeixin = ua.indexOf('micromessenger') != -1;
        if (isWeixin) {
            return true;
        }else{
            return false;
        }
    }

    /**
     * 判断当前设备是否为特定客户端打开
     * @static
     * @memberof Util
     * @return {boolean}
     */
    static isCustomAgent() {
        // console.log(navigator.userAgent,'userAgent')
        let __userAgent = navigator.userAgent;
        return !!__userAgent.match(/sjyx/i);
    }
    
    /**
     * 判断当前设备是否为iOS
     * @static
     * @memberof Util
     * @return {boolean}
     */
    static isIOS() {
        let __userAgent = navigator.userAgent;
        return !!__userAgent.match(/(iPhone|iPod|iPad)/i);
    }
    /**
     * 判断是不是数组
     * @param {array} arr
     * @return {Boolean}
     */
    static isArray(arr) {
        return arr && Object.prototype.toString.call(arr) === "[object Array]"
    }
    /**
     * 设置元素最小高度为100%，cla为类名或者id, 类似'.app'或者'#app'
     * @param {string} cla 
     */
    static setFullHeight(cla) {
        let ele = document.querySelector(cla)
        if (ele) ele.style.minHeight = window.screen.availHeight + 'px'
    }

    /**
     * [isArray 判断是否是数组]
     * @return {Boolean} [description]
     */
    static isArray_x(arr) {
        if ((typeof Array.isArray) != 'function') {
            Array.isArray = function (arg) {
                return Object.prototype.toString.call(arg) === '[object Array]'
            }
        }
        else {
            return Array.isArray(arr)
        }
    }

    /**
     * [preloadImg 图片预加载]
     * @param  {[type]} src [description]
     * @return {[type]}     [description]
     */
    static preloadImg(srcArr = []) {
        if (Util.isArray(srcArr)) {

            for (let i = 0; i < srcArr.length; i++) {
                let oImg = new Image()
                oImg.src = srcArr[I]
            }
        }

    }
    /**
     * 生成随机字符串，默认8位
     * @param {number} [length=8] 
     */
    static makeID(length = 8) {
        var text = "";
        var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

        for (var i = 0; i < length; i++)
            text += possible.charAt(Math.floor(Math.random() * possible.length));

        return text;
    }

    /**
   * 跳转到登录页面
   * @param {string} [redirectUrl]
   */
    static gotoLogin(redirectUrl) {
        let url
        if (!redirectUrl) {
            url = '?redirect=' + location.pathname + location.search
        } else {
            url = '?redirect=' + redirectUrl
        }

        window.location.href = window.location.protocol + "//" + window.location.host + '/app/login' + url
    }

    static gotoPage({page, options}) {
        let search
        if(options) {
            search = qs.stringify(options)
        }
        window.location.href = "//" + window.location.host + page + (search?'?'+search:'')
    }

    static addClass(obj, cls) {
        let obj_class = obj.className
        let blank = (obj_class != '') ? ' ' : '' 
        let added = obj_class + blank + cls;
        obj.className = added;
    }
    static removeClass(obj, cls) {
        let obj_class = ' '+obj.className+' '
        obj_class = obj_class.replace(/(\s+)/gi, ' ')
        let removed = obj_class.replace(' '+cls+' ', ' ')
        removed = removed.replace(/(^\s+)|(\s+$)/g, '');
        obj.className = removed;
    }
    static hasClass(obj, cls) {
        var obj_class = obj.className
        let obj_class_lst = obj_class.split(/\s+/)
        let x = 0;
        for(x in obj_class_lst) {
            if(obj_class_lst[x] == cls) {
                return true;
            }
        }
        return false;
    }
}

export default Util