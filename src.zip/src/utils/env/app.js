var app = {};
var ua = window.navigator.userAgent;
var matched;

if ((matched = ua.match(/MicroMessenger\/([\d\.]+)/))) {
    app = {
        name: 'Weixin',
        isWeixin: true,
        version: matched[1]
    }
} else if ((matched = ua.match(/QQ\/?([\d\.]+)/))) {
    app = {
        name: 'QQ',
        isQQ: true,
        version: matched[1]
    }
} else if ((matched = ua.match(/__weibo__([\d\.]+)/))) {
    app = {
        name: 'Weibo',
        isWeibo: true,
        version: matched[1]
    }
} else {
    app = {
        name: 'unknown',
        version: '0.0.0'
    }
}

app.version = require('./version.js')(app.version);

module.exports = app;