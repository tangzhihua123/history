
var env = {
    app: require('./app.js'),
    browser: require('./browser.js'),
    os: require('./os.js'),
    version: require('./version.js')
};

module.exports = env;
