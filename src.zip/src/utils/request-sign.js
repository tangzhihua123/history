var md5 = require('md5');

const RequestSign = ({params, secretKey}) => {
    var params_new = {},
        str = '',
        key,
        kV,
        value
    if(params && Object.prototype.toString.call(params) === '[object Object]') {
        params.timestamp = +new Date()
        for(var k in params) {
            if(params[k] !== '' && params[k] !== null) {
                params_new[k] = params[k]
            }
        }
        var keys = Object.keys(params_new)
        keys.sort()
        for(var i = 0, l = keys.length; i < l; i++) {
            key = keys[i]
            value = params_new[key]
            if(typeof value === 'object') {
                value = JSON.stringify(value)
            }
            kV = key.toLowerCase() + '' + value
            str += kV
        }
    }
    str = str + secretKey
    return md5(str).toUpperCase()
}

export default RequestSign