import RequestUtil from 'utils/request-util'
import qs from 'query-string'



export default class WeixinUtil {
    static initWeixinJSBridge(readyCallback) {
        function onBridgeReady(fn) {
            WeixinUtil.configWeixinSDK(function (config) {
                fn && fn(config);
            });
        }

        if (typeof WeixinJSBridge === "undefined") {
            if (document.addEventListener) {
                document.addEventListener('WeixinJSBridgeReady', function () {
                    onBridgeReady(readyCallback);
                }, false);
            }
        } else {
            onBridgeReady(readyCallback);
        }
    }
    static configWeixinSDK(callback) {
        let param = {
            data: {
                callUrl: location.href.split('#')[0]
            },
            url: '/sys/getWxRegConfig',
            successFn: (data) => {
                if (data.resultCode == 2000) {
                    var json = data.data
                    try {
                        wx.config({
                            debug: false,
                            appId: json.appId,
                            timestamp: json.timestamp,
                            nonceStr: json.nonceStr,
                            signature: json.signature,
                            jsApiList: [
                                "onMenuShareTimeline",
                                "onMenuShareAppMessage",
                                "onMenuShareQQ",
                                "onMenuShareWeibo",
                                "onMenuShareQZone",
                                "startRecord",
                                "stopRecord",
                                "onVoiceRecordEnd",
                                "playVoice",
                                "pauseVoice",
                                "stopVoice",
                                "onVoicePlayEnd",
                                "uploadVoice",
                                "downloadVoice",
                                "chooseImage",
                                "previewImage",
                                "uploadImage",
                                "downloadImage",
                                "translateVoice",
                                "getNetworkType",
                                "openLocation",
                                "getLocation",
                                "hideOptionMenu",
                                "showOptionMenu",
                                "hideMenuItems",
                                "showMenuItems",
                                "hideAllNonBaseMenuItem",
                                "showAllNonBaseMenuItem",
                                "closeWindow",
                                "scanQRCode",
                                "chooseWXPay",
                                "openProductSpecificView",
                                "addCard",
                                "chooseCard",
                                "openCard"
                            ]
                        });

                        wx.error(function () {
                            // 报错信息还是不要给用户看见,应给常见的提示
                            // alert('error in weixin jssdk:' + JSON.stringify(arguments));
                            console.log('error in weixin jssdk:' + JSON.stringify(arguments));
                        });

                        wx.ready(function () {
                            setTimeout(function () {
                                callback(json);
                            }, 50);
                        });
                    } catch (e) {
                        // if (__ENV__ !== 'production') {
                        //     console.log('目前不是微信环境')
                        // }
                        // alert(e.toString())
                    }
                } else if (data.resultCode == 5000) {
                    alert("网络异常，请稍后再试")
                }
            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }
        RequestUtil.fetch(param)
    }

    static share2Weixin(options) {
        wx.onMenuShareAppMessage({
            title: options.title,
            desc: options.desc,
            link: options.link, // 分享链接
            imgUrl: options.imgUrl, // 分享图标
            success: options.success,
            cancel: options.cancel,
        });
    }

    static share2Timeline(options) {
        wx.onMenuShareTimeline({
            title: options.title, // 分享标题
            link: options.link, // 分享链接
            imgUrl: options.imgUrl, // 分享图标
            success: options.success,
            cancel: options.cancel
        });
    }

    static hideWeixinMenu() {
        WeixinUtil.initWeixinJSBridge(function () {
            WeixinUtil.hideOptionMenu();
        });
    }

    static showWeixinMenu() {
        WeixinUtil.initWeixinJSBridge(function () {
            WeixinUtil.showOptionMenu();
        });
    }

    static hideOptionMenu() {
        wx.hideOptionMenu();
    }


    static showOptionMenu() {
        wx.showOptionMenu();
    }

    static hideMenuItems(options) {
        wx.hideMenuItems({
            menuList: options.menuList,
            success: options.success,
            fail: options.fail
        });
    }

    static getWXShareOption(option) {
        let { data = {}, callback } = option;
        let param = {
            url: 'item/shareSku',
            method: 'GET',
            data,
            successFn: function (result) {
                callback(result);
            },
            errorFn: function () {
                // alert('网络异常，请检查网络');
            }
        };
        RequestUtil.fetch(param);
    }

    static shareByRemoteOption(opt) {
        let { targetLink: { pageName, options }, data = {}, successFn, cancelFn } = opt;

        WeixinUtil.initWeixinJSBridge(function () {
            WeixinUtil.getWXShareOption({
                data: data,
                callback: (result) => {
                    if (RequestUtil.isResultSuccessful(result)) {
                        let data = result.result;
                        data.link = Util.getNewUrlByPageName(pageName, options);
                        data.success = successFn;
                        data.cancel = cancelFn;

                        WeixinUtil.share2Friends(data);
                        WeixinUtil.share2FriendCircle(data);
                        WeixinUtil.showOptionMenu();
                    }
                }
            })
        })
    }

    static shareByPageOption(opt) {
        WeixinUtil.initWeixinJSBridge(() => {
            WeixinUtil.share2Weixin(opt);
            WeixinUtil.share2Timeline(opt);
            WeixinUtil.showOptionMenu();
        })
    }
    
    static shareByPageOption2(opt) {
        WeixinUtil.share2Weixin(opt);
        WeixinUtil.share2Timeline(opt);
        WeixinUtil.showOptionMenu();
    }

    /**
     * 
     * @param {*} redirect 
     * @param {*} scope  
     * @param {*} state 
     */
    static getAuthorizeURL({
        appid = 'wx1634717d7c990175',
        redirect = location.href,
        scope = 'snsapi_base',
        state = ''
    } = {
        appid: 'wx1634717d7c990175',
        redirect: location.href,
        scope: 'snsapi_base',
        state: ''
    }) {
        console.log(appid,
            redirect,
            scope,
            state)
        // 微信网页授权
        // https://mp.weixin.qq.com/wiki?t=resource/res_main&id=mp1421140842
        const wxUrl = 'https://open.weixin.qq.com/connect/oauth2/authorize?'
        redirect = redirect.replace(/[&\?]code=[\s\S^&]+/, '')
        const params = {
            appid,
            redirect_uri: redirect,
            response_type: 'code',
            scope,
            state
        }
        return wxUrl + qs.stringify(params) + '#wechat_redirect'
    }
}