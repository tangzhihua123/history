import CONFIG from 'utils/hmt-config.json'

export default
class StatisticUtil {
    /**
     * [Hmt_TrackEvent 百度事件跟踪]
     * @param {[type]} options [description]
     */
    static Hmt_TrackEvent(options) {
        let { CATEGORY, ACTION, OPT_LABEL, OPT_VALUE } = options
        let CATEGORY_TITLE = ''

        CONFIG.CONF.map((item) => {
            if(item.TYPE == CATEGORY ) {
                CATEGORY_TITLE = item.TYPE_TITLE

            }
        })

        console.log(CATEGORY_TITLE,"CATEGORY_TITLE")
        
        _hmt.push(['_trackEvent', CATEGORY_TITLE, ACTION, OPT_LABEL, OPT_VALUE]);
    }
}
