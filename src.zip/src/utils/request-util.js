import qs from 'qs'
import store from 'store'
import URLUtil from 'utils/url-util'
import Util from 'utils/util'
import config from '../config/config.js'
import { RequestHeader, RequestConfig } from '../config/request-config.js'
import RequestSign from './request-sign.js'

/**
 * Send HTTP request.
 * @module RequestUtil
 * @class
 */
class RequestUtil {
    /**
     * 缓存接口数据
     * @private
     */
    static cacheAjaxData = Object.create(null)

    /**
     * @private
     * @return {object} 接口数据
     */
    static getCacheAjaxData() {
        return RequestUtil.cacheAjaxData
    }

    /**
     * 获取url接口的缓存数据
     * @private
     * @param {object} $0
     * @param {string} $0.host 主机名
     * @param {string} $0.path 接口路径
     * @param {object} $0.params 参数对象
     * @param {string} $0.method 请求方法
     * @return {object|boolean|undefined} 接口数据
     */
    static getUrlCacheAjaxData({ host, path, params, method }) {
        let paramsStr,
            cacheData = RequestUtil.getCacheAjaxData()
        if (!cacheData[host]) {
            return false
        } else {
            if (!cacheData[host][path]) {
                return false
            } else {
                paramsStr = RequestUtil.getSortsKeyString(params)
                if (!cacheData[host][path][paramsStr]) {
                    return false
                } else {
                    return cacheData[host][path][paramsStr][method]
                }
            }
        }
    }
    /**
     * 设置url接口的缓存数据
     * @private
     * @param {object} $0
     * @param {string} $0.host 主机名
     * @param {string} $0.path 接口路径
     * @param {object} $0.params 参数对象
     * @param {object} $0.method 请求方法
     * @param {object} $0.data 接口数据
     */
    static setUrlCacheAjaxData({ host, path, params, method, data }) {

        let cacheData = RequestUtil.getCacheAjaxData(),
            cacheHostData,
            paramsStr = RequestUtil.getSortsKeyString(params)

        cacheHostData = cacheData[host] = cacheData[host] || Object.create(null)
        cacheHostData[path] = cacheHostData[path] || Object.create(null)

        cacheHostData[path][paramsStr] = cacheHostData[path][paramsStr] || Object.create(null)
        cacheHostData[path][paramsStr][method] = data
    }
    /**
     * 获取host
     * @private
     * @param {string} url url的完整路径
     * @return {string} 返回host
     */
    static getHost(url) {
        let hostRe = /\/\/([^/]+)/
        if (!url || typeof url !== 'string') {
            throw 'url\'s format error'
        }
        return url.match(hostRe)[1]
    }
    /**
     * 获取接口的path
     * @private
     * @param {string} url url完整路径
     * @return {string} 返回path 
     */
    static getPath(url) {
        let pathRe = /.+(\/.*)/
        if (!url || typeof url !== 'string') {
            throw 'url\'s format error'
        }
        return url.match(pathRe)[1]
    }
    /**
     * 返回正序排序后的对象JSON字符串
     * @static
     * @private
     * @param {object} keysObj 接口的输入参数对象
     * @return {string} 返回排序格式化后的字符串
     */
    static getSortsKeyString(keysObj) {
        const nullKey = '__null'
        if (!keysObj) {
            return nullKey
        }
        let keys = Object.keys(keysObj),
            sortsParams = {}
        keys.sort()
        if (keys.length === 0) {
            return nullKey
        } else {
            for (let i = 0, l = keys.length; i < l; i++) {
                sortsParams[keys[i]] = keysObj[keys[i]]
            }
            return JSON.stringify(sortsParams)
        }
    }
    /**
     * 设置缓存数据, 没有把host和path分开，暂时废弃
     * @deprecated
     * @private
     * @param {object} $0
     * @param {string} url url路径，为绝对路径
     * @param {object} params 接口请求的数据
     * @param {object} data 接口对应的数据 
     */
    static setCacheAjaxData({ url, params, data }) {
        let cacheData = RequestUtil.getCacheAjaxData(),
            paramsStr = RequestUtil.getSortsKeyString(params),
            host,
            cacheHostData
        host = RequestUtil.getHost(url)
        cacheHostData = cacheData[host] = cacheData[host] || {}
        cacheHostData[url] = cacheHostData[url] || {}

        cacheHostData[url][paramsStr] = data
    }

    /**
     * @private
     * @memberof RequestUtil
     * @static
     * @return {string} api url prefix.
     */
    static getPrefix() {
        let env = __ENV__
        return config['api'][env]
    }

    /**
     * [getImgPrefix 获取图片服务器地址]
     * @return {[type]} [description]
     */
    static getImgPrefix() {
        let env = __ENV__
        return config['images'][env]
    }
    
    /**
     * [getSharePagePrefix 获取域名地址]
     * @return {[type]} [description]
     */
    static getSharePagePrefix() {
        let env = __ENV__
        return config['page'][env]
    }

    /**
     * fetch data function
     * @example
     * let params = {
     *      method: 'post',
     *      url: '/user',
     *      data: {
     *          user: 'Aly',
     *          id: '123456'
     *      },
     *      successFn: (data) => {
     *          console.log('returned data: ', data)
     *      },
     *      errorFn: (err) => {
     *          console.log('err: ', err)
     *      }
     * }
     * RequestUtil.fetch(params)
     * @memberof RequestUtil
     * @static
     * @param {object} $0
     * @param {object} $0.headers headers object 
     * @param {string} $0.method HTTP method
     * @param {string} $0.url HTTP request's url
     * @param {obejct} $0.data HTTP request's data, if is get request, will append the data to url
     * @param {function} $0.successFn success callback, pass a response data object to argument
     * @param {function} $0.errorFn fail callback, pass a error object to argument
     * @param {boolean} $0.isAbsolute describe that whether url is an absolute url or not
     */
    static fetch({
        headers,
        method = 'post',
        url,
        data,
        successFn,
        errorFn,
        isAbsolute
    }) {
        let fullURL,
            userObj = store.get('user') || {}
        fullURL = isAbsolute ? url : RequestUtil.getPrefix() + url
        const userInfo = {
            userToken: userObj.token || '',
            userId: userObj.userId || '',
        }
        let params = {
            method: method.toLowerCase(),
            url: fullURL,
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/x-www-form-urlencoded',
                ...RequestHeader,
                ...headers,
                ...userInfo
            }
        }

        console.log(params,"获取请求头信息打印")
        if (method.toLowerCase() === 'get') {
            params.params = data
        } else {
            // 全部为post请求
            data.sign = RequestSign({ params: data, secretKey: RequestConfig.secretKey })
            params.data = qs.stringify(data)
        }
        console.log('params:', params)
        axios(params)
            .then((response) => {
                // console.log('res', response)
                // 仍需要修复，如果是在客户端打开对应页面跳转登录适配处理.需要和产品和客户端确认.
                // if(response.data.resultCode == 4005 ) {
                //     //  URLUtil.redirectPage({
                //     //     page: 'app/login',
                //     //     options: {
                //     //         redirect: "/" + window.location.href.split('/')[3]
                //     //     }
                //     // })
                // } else 
                //{
                    // successFn && successFn(response.data)
                //}
                console.log('response', response)
                if(response.data.resultCode == 2000 || response.data.resultCode == 2001) {
                    let res = {
                        resultCode: 2000,
                        resultMsg: response.data.resultMsg,
                        data: response.data.data
                    }
                    successFn && successFn(res)
                }else {
                    successFn && successFn({
                        ...response.data
                    })
                }
                
                
            })
            .catch((error) => {
                errorFn && errorFn(error)
            })
    }
    /**
     * 上传图片
     * @param {*} param0 
     */
    static uploadImg({
        headers,
        method = 'post',
        url,
        data,
        successFn,
        errorFn,
        isAbsolute
    }) {
        let fullURL,
            userObj = store.get('user') || {}
        fullURL = isAbsolute ? url : RequestUtil.getPrefix() + url
        const userInfo = {
            userToken: userObj.token || '',
            userId: userObj.userId || '',
        }
        let params = {
            method: method.toLowerCase(),
            url: fullURL,
            headers: {
                'Accept': 'application/json',
                ...RequestHeader,
                ...headers,
                ...userInfo
            }
        }
        if (method.toLowerCase() === 'get') {
            params.params = data
        } else {
            // 全部为post请求
            data.append('sign', RequestSign({ params: data, secretKey: RequestConfig.secretKey }))
            params.data = data
        }
        // console.log('params:', params)
        axios(params)
            .then((response) => {
                // console.log('res', response)
                
                successFn && successFn(response.data)
            })
            .catch((error) => {
                errorFn && errorFn(error)
            })
    }

    // fetch promise 返回promise ，#TODO 公共部分可抽离
    static fetchPromise({
        headers,
        method = 'post',
        url,
        data = {},
        isAbsolute
    }) {
        let fullURL,
            userObj = store.get('user') || {}
        fullURL = isAbsolute ? url : RequestUtil.getPrefix() + url
        const userInfo = {
            userToken: userObj.token || '',
            userId: userObj.userId || ''
        }
        let params = {
            method: method.toLowerCase(),
            url: fullURL,
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/x-www-form-urlencoded',
                ...RequestHeader,
                ...headers,
                ...userInfo
            }
        }
        if (method.toLowerCase() === 'get') {
            params.params = data
        } else {
            // 全部为post请求
            data.sign = RequestSign({ params: data, secretKey: RequestConfig.secretKey })
            params.data = qs.stringify(data)
        }
        return axios(params)
            .then((response) => {
                if (response.data.resultCode === 4005) {
                    store.remove('user')
                }
                return Promise.resolve(response.data)
            })
            .catch((error) => {
                console.log(error)
            })
    }

    /**
     * 用法同fetch，增加了接口数据的缓存，
     * 对于同一个接口，且请求方法和参数相同时，若缓存中已有对应内容，则不再进行请求，
     * 缓存有效时间：目前仅为当前页面打开时有效，用以单页应用。
     * 注意：获取数据的时候可以用此方法，提交数据时请勿使用
     * @memberof RequestUtil
     * @static
     * @param {object} $0
     * @param {object} $0.headers headers object 
     * @param {string} $0.method HTTP method
     * @param {string} $0.url HTTP request's url
     * @param {obejct} $0.data HTTP request's data, if is get request, will append the data to url
     * @param {function} $0.successFn success callback, pass a response data object to argument
     * @param {function} $0.errorFn fail callback, pass a error object to argument
     * @param {boolean} $0.isAbsolute describe that whether url is an absolute url or not
     */
    static fetchWithCache({
        headers,
        method = 'get',
        url,
        data,
        successFn,
        errorFn,
        isAbsolute
    }) {

        let host,
            path
        if (isAbsolute) {
            host = RequestUtil.getHost(url)
            path = RequestUtil.getPath(url)
        } else {
            host = RequestUtil.getHost(RequestUtil.getPrefix())
            path = url
        }

        let cacheUrlData = RequestUtil.getUrlCacheAjaxData({
            host,
            path,
            params: data,
            method: method.toLowerCase()
        })

        // 缓存中有数据
        if (cacheUrlData) {
            successFn && successFn(cacheUrlData)
            return
        }

        let fullURL
        fullURL = isAbsolute ? url : RequestUtil.getPrefix() + url


        let params = {
            method: method.toLowerCase(),
            url: fullURL,
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/x-www-form-urlencoded',
                ...headers
            }
        }
        if (method.toLowerCase() === 'get') {
            params.params = data
        } else {
            params.data = data
        }

        axios(params)
            .then((response) => {
                // console.log('res', response)

                RequestUtil.setUrlCacheAjaxData({
                    host,
                    path,
                    params: data,
                    data: response.data,
                    method: method.toLowerCase()
                })

                successFn && successFn(response.data)
            })
            .catch((error) => {
                errorFn && errorFn(error)
            })
    }

    static fetchCartNum(options) {
        let { noLogin, Login, ErrorFun } = options
        let param = {
            data: {},
            url: '/shopping/getCartGoodsAmont',
            successFn: (data) => {
                console.log(data.resultCode, "获取购物车数量接口获取情况测试")

                if (data.resultCode === 4005) {
                        let cartList = store.get('cartList'),
                            num = 0
                        if(cartList && Util.isArray(cartList)) {
                            cartList.forEach((item) => {
                                if(item.count) {
                                    num += item.count
                                }
                            })

                        } else {
                            num = 0
                        }

                        noLogin && noLogin(num)
                    
                } else if(data.resultCode !== 2000 && data.resultCode !== 4005) {
                    ErrorFun && ErrorFun('获取购物车数量失败')
                    return
                } else {
                    Login && Login(data.data.count)
                    
                }
               
            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
            }
        }
        RequestUtil.fetch(param)
    }
}

export default RequestUtil