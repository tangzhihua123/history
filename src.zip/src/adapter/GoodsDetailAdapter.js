var a = {
    data: {
        "itemImages": [//商品图片列表
            {
                "imageId": 198817,
                "picUrl": "http://res.xingzhuangmall.com/resource/images/photo/7583/20170906/201709061454080.jpg"
            },
            {
                "imageId": 198818,
                "picUrl": "http://res.xingzhuangmall.com/resource/images/photo/7583/20170906/201709061454080.jpg"
            },
            {
                "imageId": 198819,
                "picUrl": "http://res.xingzhuangmall.com/resource/images/photo/7583/20170906/201709061454080.jpg"
            }
        ],
        "products": [//货品列表
            {
                "productId": 398239,//货品Id
                "bn": "6955528795768",//货号
                "price": 699.000,//价格
                "weight": 580.000,//重量
                "store": 10,//库存
                "unit": "双",//计量单位
                "pdtDesc": "黑色,36,女",//商品规格描述
                "props": [//该货品对应的规格信息
                    {
                        "specId": 4145,//规格类型Id
                        "specValueId": 21619,//规格值id
                        "specValue": "黑色"//规格值
                    },
                    {
                        "specId": 4091,
                        "specValueId": 18734,
                        "specValue": "36"
                    }
                ]
            },
            {
                "productId": 398239,//货品Id
                "bn": "6955528795768",//货号
                "price": 699.000,//价格
                "weight": 580.000,//重量
                "store": 10,//库存
                "unit": "双",//计量单位
                "pdtDesc": "黑色,36,男",//商品规格描述
                "props": [//该货品对应的规格信息
                    {
                        "specId": 4145,//规格类型Id
                        "specValueId": 21619,//规格值id
                        "specValue": "黑色"//规格值
                    },
                    {
                        "specId": 4091,
                        "specValueId": 18734,
                        "specValue": "36"
                    }
                ]
            },
            {
                "productId": 398239,//货品Id
                "bn": "6955528795768",//货号
                "price": 699.000,//价格
                "weight": 580.000,//重量
                "store": 5,//库存
                "unit": "双",//计量单位
                "pdtDesc": "黑色,37,男",//商品规格描述
                "props": [//该货品对应的规格信息
                    {
                        "specId": 4145,//规格类型Id
                        "specValueId": 21619,//规格值id
                        "specValue": "黑色（女）"//规格值
                    },
                    {
                        "specId": 4091,
                        "specValueId": 18734,
                        "specValue": "36"
                    }
                ]
            },
            {
                "productId": 398239,//货品Id
                "bn": "6955528795768",//货号
                "price": 699.000,//价格
                "weight": 580.000,//重量
                "store": 5,//库存
                "unit": "双",//计量单位
                "pdtDesc": "军绿色,37,女",//商品规格描述
                "props": [//该货品对应的规格信息
                    {
                        "specId": 4145,//规格类型Id
                        "specValueId": 21619,//规格值id
                        "specValue": "军绿色"//规格值
                    },
                    {
                        "specId": 4091,
                        "specValueId": 18734,
                        "specValue": "36"
                    }
                ]
            },
            {
                "productId": 398239,//货品Id
                "bn": "6955528795768",//货号
                "price": 699.000,//价格
                "weight": 580.000,//重量
                "store": 5,//库存
                "unit": "双",//计量单位
                "pdtDesc": "军绿色,38,女",//商品规格描述
                "props": [//该货品对应的规格信息
                    {
                        "specId": 4145,//规格类型Id
                        "specValueId": 21619,//规格值id
                        "specValue": "军绿色"//规格值
                    },
                    {
                        "specId": 4091,
                        "specValueId": 18734,
                        "specValue": "36"
                    }
                ]
            },
        ],
        "specs": [{//规格类型
            keyId: 4145,//规格类型Id
            values: "颜色分类" //规格类型名称
        }, {
            keyId: 4091,
            values: "运动鞋尺码"
        }, {//规格类型
            keyId: 4092,//规格类型Id
            values: "性别分类" //规格类型名称
        },],

        "specDesc": [//规格描述(内有规格ID，表现方式，规格值ID，个性化名，关联的商品图片等信息)
            {
                "specId": 4145,//规格类型Id
                "showType": "text",//规格显示方式(text/image)
                "specValue": "黑色",//规格值
                "specValueId": 21619,//规格值ID
                "specImage": null,//规格值对应的图片,showtype=image时有效
                "goodsImageIds": [//规格值对应的商品图片
                    "/resource/images/photo/7583/20170906/201709061454091.jpg"
                ]
            },
            {
                "specId": 4145,
                "ShowType": "text",
                "specValue": "军绿色",
                "specValueId": 21689,
                "SpecImage": null,
                "GoodsImageIds": [
                    "/resource/images/photo/7583/20170906/201709061453321.jpg"
                ]
            },
            {
                "specId": 4091,
                "showType": "text",
                "specValue": "36",
                "specValueId": 18734,
                "specImage": null,
                "goodsImageIds": [

                ]
            },
            {
                "specId": 4091,
                "showType": "text",
                "specValue": "37",
                "specValueId": 18672,
                "specImage": null,
                "goodsImageIds": [

                ]
            },
            {
                "specId": 4091,
                "showType": "text",
                "specValue": "38",
                "specValueId": 18739,
                "specImage": null,
                "goodsImageIds": [

                ]
            },
            {
                "specId": 4092,
                "showType": "text",
                "specValue": "男",
                "specValueId": 10002,
                "specImage": null,
                "goodsImageIds": [

                ]
            },
            {
                "specId": 4092,
                "showType": "text",
                "specValue": "女",
                "specValueId": 10001,
                "specImage": null,
                "goodsImageIds": [

                ]
            },
        ],
        "customerId": 4886,//商户Id
        "goodsId": 53268,//商品Id
        "name": "RAX2017秋冬徒步鞋男 女防滑户外鞋 爬山鞋保暖登山鞋 防滑鞋",//商品标题
        "catId": 1427,//分类ID
        "picUrl": "/resource/images/photo/7583/20170906/201709061454080.jpg",//商品主图片
        "store": 268,//数量
        "price": 699.000,//价格
        "bn": "73-5C423",//货号
        "weight": 580.000,//重量
        "unit": "双",//计量单位
        "limitBuyNum": 0,//限购数量，0或负数没有限制
        "subTitle": "我是商品副标题我是商品副标题我是副标题",//副标题（商品描述）
        "salesCount": 0,//销量
        "marketableTime": "2017-09-08T11:09:00",//上线时间
        "downShelfTime": "2047-09-08T11:09:00",//下架时间
        "downShelfStatus": 1,//商品下架状态 0-->未到上线时间 1-->正常上线 2-->已过下架时间 3售罄 
        "isBuy": 1,//能否购买 1允许购买0不允许购买
        "minBuyCount": 1,//最低起售数量（即购买数量）
        "videoPic": "/resource/images/photo/4421/small/20170913/201709131622480.jpg",//视频图片
        "videoAddr": "/resource/Video/4421/mp420170914143408.mp4",//视频地址
        "detailPic": [//详情图片
            {
                "pic": "/resource/images/photo/4421/small/20170814/201708141315500.jpg",
                "lnk": ""
            }
        ],
        saleMode: 1,//0普通商品 1预售商品
        "commentModel": {//商品评论
            "commentNum": 2,//评论总数
            "commentScore": 9,//评论总分数
            "commentItems": [
                {
                    "userNickName": "",//用户昵称
                    "commentContent": "12",//评论内容
                    "imgList": "/resource/images/Comment/4421/img20170817183311.jpg,",//评论图片列表 ,分割
                    "addTime": "2017-08-17T18:33:15",//评论时间
                    "userHeadImg": "",//用户头像地址
                    "score": 5,//分数
                }
            ]
        },
        activityTitle: "满50减10",
        arrivalTime: "现在下单，最快今天13:00-15:00到达"
    }
}

export const GoodsDetailAdapter = (data) => {

}
export const GoodsData = a.data