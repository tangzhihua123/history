import store from 'store'

import {
  FETCH_CART,
  RECEIVE_CART,
  INCREASE_COUNT,
  DECREASE_COUNT,
  DEL_CART_ITEM,
  TRIGGER_CHECK_STATUS,
  TRIGGER_ALL_CHECK_STATUS,
  TRIGGER_COUPON_CHECK_STATUS,
  RECEIVE_CART_GOODS_COUNT,
  FETCH_LOCAL_CART,
  DEL_LOCAL_CART_ITEM,
  INCREASE_LOCAL_COUNT,
  DECREASE_LOCAL_COUNT,
  TRIGGER_LOCAL_CHECK_STATUS,
  REMOVE_LOCAL_CART
} from '../actions/cart'

const initialState = {
  items: [],
  sum: {},
  freightConfig: {},
  couponList: [],
  allCheckStatus: false,
  couponCheckStatus: true,
  count: 0,
  local: [] // 本地购物车数据
}

export function getCartState(state) {
  return state.cart
}

function operCart(state, actionType, productId) {
  const items =  state
  let newState = {}
  if (items) {
    return items.map(group => {
      const newGroup = group.items.map(item => {
        // 这么写也是不好的
        if (productId === item.productId) {
          if (actionType === INCREASE_COUNT) {
            item['count'] = item['count'] + 1
          } else if(actionType === DECREASE_COUNT) {
            if(item['count']>=2) {
                item['count'] = item['count'] - 1
            }else {
                item['count'] = 1
            }
          } else if(actionType === TRIGGER_CHECK_STATUS) {
            item.isChecked = item.isChecked ? 0 : 1
          }
        }
        return item
      })
      return {
        ...group,
        items: newGroup
      }
    })
  }
  return state
}

/**
 * 操作本地localStorage
 * @param {*} type 
 * @param {*} productId 
 */
function operLocalCart(actionType, productId, state) {
  const localCart = store.get('cartList')
  if (localCart) {
    let delIndex = -1
    const newLocalCart = localCart.map((item, index) => {
      if (productId === item.productId) {
        if (actionType === INCREASE_COUNT) {
          item['count'] = item['count'] + 1
        } else if(actionType === DECREASE_COUNT) {
          if(item['count']>=2) {
              item['count'] = item['count'] - 1
          }else {
              item['count'] = 1
          }

        } else if(actionType === TRIGGER_CHECK_STATUS) {
          item.isChecked = item.isChecked ? 0 : 1
        } else if(actionType === DEL_CART_ITEM) {
          delIndex = index
        }
      }
      // 全选 state违规操作
      
      if (actionType === TRIGGER_ALL_CHECK_STATUS) {
        if (state.allCheckStatus) {
          item.isChecked = 0
        } else {
          item.isChecked = 1
        }
      }
      return item
    })
    if (delIndex > 0 || delIndex === 0) {
      newLocalCart.splice(delIndex, 1)
    }

    store.set('cartList', newLocalCart)
  }
}

function getLocalCartCount(cartList) {
  return cartList.reduce((prev, item) => {
    return prev + item.count
  }, 0)
}

function removeLocalCart(cartData) {
  let localCart = store.get('cartList')
  let cartRemove = []

  function removeFilter(productId) {
    localCart = localCart.filter(lc => {
      return lc.productId !== productId
    })
  }

  if(cartData && JSON.parse(cartData)) {
    cartRemove = JSON.parse(cartData)
    // 两层循环, 降低复杂度？1.使用filter、 includes, 2.先排序在删除？
    cartRemove.map((cr) => {
      removeFilter(cr.productId)
    })
  }
  store.set('cartList', localCart)
}

/**
 * 如何保证reducer的纯度？
 * @param {*} state 
 * @param {*} action 
 */
const cart = (state = initialState, action) => {
  switch (action.type) {
    case RECEIVE_CART: {
      const { cartInfo } = action
      const { data } = cartInfo
      if (data) {
        const { cartsList, TotalAmount = 0, TotalPmtAmount = 0, 
        totalCheckedCount = 0, totalCount = 0, freightConfig, couponList } = data
        return {
          ...state,
          items: cartsList || [],
          sum: {
            totalAmount: TotalAmount , // 总价
            totalPmtAmount: TotalPmtAmount, // 已优惠金额
            totalCheckedCount // 已选个数
          },
          freightConfig: freightConfig || {}, //运费配置
          couponList: couponList || [] //优惠券列表
        }
      }
      return state
    }
    case INCREASE_COUNT: {
      const { product } = action
      const { productId } = product
      const newState = Object.assign({}, state)
      const items = operCart(newState.items, INCREASE_COUNT, productId)
      // 操作本地cart
      operLocalCart(INCREASE_COUNT, productId)
      return {
        ...state,
        items
      }
    }
    case DECREASE_COUNT: {
      const { product } = action
      const { productId } = product
      const newState = Object.assign({}, state)
      const items = operCart(newState.items, DECREASE_COUNT, productId)
      operLocalCart(DECREASE_COUNT, productId)
      return {
        ...state,
        items
      }
    }
    case TRIGGER_CHECK_STATUS: {
      const { product } = action
      const { productId } = product
      const newState = Object.assign({}, state)
      const items = operCart(newState.items, TRIGGER_CHECK_STATUS, productId)
      operLocalCart(TRIGGER_CHECK_STATUS, productId)
      return {
        ...state,
        items
      }
    }
    case TRIGGER_ALL_CHECK_STATUS: {
      operLocalCart(TRIGGER_ALL_CHECK_STATUS, null, state)
      return {
        ...state,
        allCheckStatus: !state.allCheckStatus
      }
    }
    case TRIGGER_COUPON_CHECK_STATUS: {
      return {
        ...state,
        couponCheckStatus: !state.couponCheckStatus
      }
    }
    case RECEIVE_CART_GOODS_COUNT: {
      const cartList = store.get('cartList')
      return {
        ...state,
        count: action.count || (cartList && getLocalCartCount(cartList)) || 0
      }
    }
    case DEL_CART_ITEM: { // 在saga中调用删除并重新拉取
      // 操作本地cart
      const { product } = action
      const { productId } = product
      operLocalCart(DEL_CART_ITEM, productId)
      return {
        ...state
      }
    }
    // TODO: reducer拆分， reducer 静态
    case FETCH_LOCAL_CART: {
      const cartList = store.get('cartList')
      const local = []
      if(cartList) {
        local.push({
          items: cartList
        })
      }
      return {
        ...state,
        local
      }
    }
    case REMOVE_LOCAL_CART: {
      removeLocalCart(action.cartData)
      return {
        ...state
      }
    }
    default:
      return state
  }
}

export default cart