import { combineReducers } from 'redux'
import { default as cart } from './cart'
import { default as i } from './i'
import { default as order } from './order'
import { default as address } from './address'
import { default as goods } from './goods'

const rootReducer = combineReducers({
  cart,
  i,
  order,
  address,
  goods
})

export default rootReducer