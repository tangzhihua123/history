import {
  RECEIVE_USERINFO, RECEIVE_MEMBER_CODE, TOKEN_INVALID
} from '../actions/i'

const initialState = {
  userInfo: {},
  memberCode: '',
  tokenValid: true
}

const i = (state = initialState, action) => {
  switch (action.type) {
    case RECEIVE_USERINFO: {
      const { userInfo } = action
      return {
        ...state,
        userInfo
      }
    }
    case RECEIVE_MEMBER_CODE: {
      return {
        ...state,
        memberCode: action.membercode
      }
    }
    case TOKEN_INVALID: {
      return {
        ...state,
        tokenValid: false
      }
    }
    default:
      return state
  }
}

export default i