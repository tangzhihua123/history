import {
  RECEIVE_SHIPPING_ADDRESS_LIST,
  SELECT_ADDRESS
} from '../actions/address'

const initialState = {
  list: [],
  selected: {}
}

const address = (state = initialState, action) => {
  switch (action.type) {
    case RECEIVE_SHIPPING_ADDRESS_LIST: {
      const { list } = action
      return {
        ...state,
        list
      }
    }
    case SELECT_ADDRESS: {
      const { selected } = action
      return {
        ...state,
        selected
      }
    }
    default:
      return state
  }
}

export default address