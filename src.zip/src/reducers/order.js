import {
  RECEIVE_ORDER_LIST,
  RECEIVE_ORDER_UNCREATE,
  RECEIVE_ORDER_DETAIL,
  CREATE_ORDER_SUCCESS, 
  CHANGE_ORDER_STATUS_SUCCESS,
  CHANGE_ORDER_STATUS_FAIL,
  RECEIVE_APPLY_AFTER_SALE,
  RECEIVE_AFTER_SALE_INFO,
  RECEIVE_CANCEL_APPLY_AFTER_SALE
} from '../actions/order'

// 订单与、订单详情、订单列表 要不要分开呢？

const initialState = {
  // 扁平化
  data: {}, // 订单信息
  list: [], // 订单列表
  detail: {}, // 订单详情
  unPaidOrderInfo: {}, // 未支付订单信息
  
}

const order = (state = initialState, action) => {
  switch (action.type) {
    case RECEIVE_ORDER_UNCREATE: {
      return {
        ...state,
        data: action.data
      }
    }
    case RECEIVE_ORDER_LIST: {
      return {
        ...state,
        list: action.data
      }
    }
    case RECEIVE_ORDER_DETAIL: {
      return {
        ...state,
        detail: action.data
      }
    }
    case RECEIVE_APPLY_AFTER_SALE: {
       return {
          ...state,
          applyaftersuccess: action.resultMsg
       }
    }
    case RECEIVE_CANCEL_APPLY_AFTER_SALE: {
        return {
            ...state,
            cancleapplyaftersuccess: action.resultMsg
        }
    }
    case RECEIVE_AFTER_SALE_INFO: {
      return {
          ...state,
          applyafterInfo: action.data.data
      }
  }

    case CREATE_ORDER_SUCCESS: {
      return {
        ...state,
        unPaidOrderInfo: action.data
      }
    }
    case CHANGE_ORDER_STATUS_SUCCESS: {
      return {
        ...state
      }
    }
    default:
      return state
  }
}

export default order