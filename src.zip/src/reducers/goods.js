import {
  RECEIVE_ACTIVITY_GOODS
} from '../actions/goods'

const initialState = {
  activityList: []
}

const goods = (state = initialState, action) => {
  switch (action.type) {
    case RECEIVE_ACTIVITY_GOODS: {
      const { data } = action
      return {
        ...state,
        activityList: data
      }
    }
    default:
      return state
  }
}

export default goods