 /**
  * 项目路径配置
  */
 
export default {
    api: {
        development: 'http://api.caijigaoshou.com',
        testing: 'http://api.caijigaoshou.com',
        production: 'http://api.neosjyx.com'        
    },
    images: {
        development: 'http://api.caijigaoshou.com',
        testing: 'http://api.caijigaoshou.com',
        production: 'http://api.neosjyx.com'
    },
    page: {
        development: 'http://new-retail-h5.dev.ops.com',
        testing: 'http://newh5test.yiqiguang.com',
        production: 'http://m.neosjyx.com'
    }
}