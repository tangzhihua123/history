let _config = {
    appId: '',
    token: '',
    secretKey: '',
    shopid: ''
}

__ENV__ === 'production' ?  _config = {
    appId: 'jayql3sxuy',
    token: 'a7dd6fb549b1479890025f6f7bbb52',
    secretKey: 'op957ikb',
    shopid: '7044'
} : _config = {
    appId: 'tcxe6l3447',
    token: '8662452542f243fc8c26ebea86aeb4',
    secretKey: '1j68kk79',
    shopid: '7040'
}

console.log("环境变量： " + __ENV__ + "appId" + _config.appId)

const RequestHeader = {
    appVersion: '1.0.0', //APP版本
    hwid: 'mobile', //设备号
    mobileType: 'mobile', //设备类型
    osType: 'H5', // 系统类型
    osVersion: '10.3.0', // 系统版本
    ttid: 'cc', // 渠道信息
    userToken: '', //登录信息
    userId: '', // 用户ID
    appId: _config.appId, // 接入码，每个商家都有对应独立的接入码
    token: _config.token, // 每个商家自己在商城后台生成的随机编码
    shopid: _config.shopid, //门店ID
}
const RequestConfig = {
    secretKey: _config.secretKey
}
export  {
    RequestHeader,
    RequestConfig
}