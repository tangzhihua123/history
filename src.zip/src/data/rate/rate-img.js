import pic1 from './1-1@2x.png'
import pic2 from './1-2@2x.png'
import pic3 from './1-3@2x.png'
import pic4 from './1-4@2x.png'
import pic5 from './1-5@2x.png'

import grey_pic1 from './1@2x.png'
import grey_pic2 from './2@2x.png'
import grey_pic3 from './3@2x.png'
import grey_pic4 from './4@2x.png'
import grey_pic5 from './5@2x.png'
let goodsStatus = [
    {   img: pic1,
        text: '很气'
    },
    {   img: pic2,
        text: '生气'
    },
    {   img: pic3,
        text: '一般'
    },
    {   img: pic4,
        text: '开心'
    },
    {   img: pic5,
        text: '很棒'
    },
]
let greyImgs = [
    grey_pic1,
    grey_pic2,
    grey_pic3,
    grey_pic4,
    grey_pic5,
]

export {
    goodsStatus,
    greyImgs
}