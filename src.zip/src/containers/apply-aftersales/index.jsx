import React, { Component } from 'react'
import { connect } from 'react-redux'
import { withRouter } from 'react-router-dom'
import { fetchAfterSaleInfo, fetchApplyAfterSale,fetchOrderDetail } from '../../actions/order'
import qs from 'query-string'
import './index.scss'
import URLUtil from 'utils/url-util'

import WhiteSpace from 'components/white-space'
import SplitLine from 'components/split-line'
import ImagePicker from 'components/image-picker'
import Icon from 'components/Icon'

import AddressBar from '../../ui/address-bar'
import ForecastReson from '../../ui/forecast-reson'
import OrderProcess from '../../ui/order-process'
import OrderGoods from '../../ui/order-goods'
import NotificationBlock from 'components/Notification/NotificationBlock.jsx'

import OrderFee from '../../ui/order-fee'

import OrderDetailBottom from '../../ui/order-detail-bottom'

const images =  [{
  url: 'https://img.yzcdn.cn/upload_files/2017/05/08/149421656829915091.jpg?imageView2/2/w/200/h/200/q/75/format/jpg',
  id: '2121',
}, {
  url: 'https://img.yzcdn.cn/upload_files/2017/05/08/149421656829915091.jpg?imageView2/2/w/200/h/200/q/75/format/jpg',
  id: '2122',
}, {
  url: 'https://img.yzcdn.cn/upload_files/2017/05/08/149421656829915091.jpg?imageView2/2/w/200/h/200/q/75/format/jpg',
  id: '2123',
}, {
  url: 'https://img.yzcdn.cn/upload_files/2017/05/08/149421656829915091.jpg?imageView2/2/w/200/h/200/q/75/format/jpg',
  id: '2124',
}, {
  url: 'https://img.yzcdn.cn/upload_files/2017/05/08/149421656829915091.jpg?imageView2/2/w/200/h/200/q/75/format/jpg',
  id: '2125',
}];

class AfterSale extends Component {
  componentDidMount() {
      const urlParams = qs.parse(window.location.search)
      const params = {}
      if (urlParams.orderid) {
          params.orderId = urlParams.orderid
          this.setState({
              orderId:urlParams.orderid
          })
      }
      if(urlParams.orderitemid) {
          this.setState({
              orderItemId:urlParams.orderitemid
          })
      }
      if (urlParams.type) {
          this.setState({
              type:urlParams.type//0 仅换货 1退货退款 4仅退款
          })
      }
      this.props.fetchOrderDetail(params)
  }
  constructor(props) {
    super(props)
    this.state = {
      files: images,
      images: 'https://img.yzcdn.cn/upload_files/2017/05/08/149421656829915091.jpg?imageView2/2/w/200/h/200/q/75/format/jpg,https://img.yzcdn.cn/upload_files/2017/05/08/149421656829915091.jpg?imageView2/2/w/200/h/200/q/75/format/jpg',
      modalVisible: false,
      orderId:"",
      applyAfterReson:"商品质量问题",
      applyAfterResonKey:0,
      orderItemId:"",
      type:"",
      count:0,
      afterId:"",
    }
  }
    componentWillReceiveProps(nextProps) {
        if(nextProps.applyaftersuccess=='请求成功') {
            URLUtil.redirectPage({
                page: 'app/apply-aftersales-detail',
                options: {
                    orderitemid:this.state.afterId,
                    type:this.state.type
                }
            })
        }
    }
  onImagesChange= (files) => {
    this.setState({
      files
    })
  }
    switchModalVisible=() => {
        this.setState({
            modalVisible: !this.state.modalVisible
        })
    }
    showReson() {
      this.setState({
          modalVisible: true
      })
    }
    enter = (message) => {
        this.setState({
            enter: true,
            message: message
        });
        setTimeout(
            function () {
                this.leave();
            }.bind(this),
            2000
        );
    }

    leave = () => {
        this.setState({
            enter: false,
            message: ""
        });
    }
    textareaChange(e) {
        let value = e.target.value
        if ((value + '').length >= 199) {
            value = (value + '').slice(0, 199)
        }
        this.setState({
            count:e.target.textLength,
            desc:value
        })
    }
    onModalCompleteClick= (item)=> {
        this.setState({
            // timeSelected: item,
            applyAfterReson:item.aftersales_reson,
            applyAfterResonKey:item.key,
            modalVisible: !this.state.modalVisible
        })
    }
    applyAfterSale () {
        if(!this.state.desc) {
            this.enter('请输入问题描述')
            return
        }else if(this.state.files.length==0) {
            this.enter('请上传凭证')
            return
        }
      let imagesFile = this.state.files;
      let images = ""
        imagesFile.map((item)=> {
            if(images == "") {
                images = images+item.url
            }else {
                images = images+','+item.url
            }
        })
        const { detail } = this.props
        let afterId = ''
        if(detail) {
            if(detail.goodsList) {
                detail.goodsList.map((item, index) => {
                    if(item.orderItemId == this.state.orderItemId) {
                        afterId=item.afterId
                        this.setState({
                            afterId:item.afterId
                        })

                    }
                })
            }
        }
        const params = {
            orderItemId:this.state.orderItemId,//订单子ID
            reason:this.state.applyAfterResonKey,//售后原因
            type:this.state.type,//0 仅换货 1退货退款 4仅退款
            issue:this.state.desc,//问题描述
            pictureUrls:images,//凭证图片地址 多个用,分割

        }
        if(afterId) {
            params.afterId = afterId
        }

        this.props.fetchApplyAfterSale(params)
    }
  render() {
      const { detail } = this.props
      let count = 0
      let price = 0
      if(detail) {
          if(detail.goodsList) {
              detail.goodsList.map((item, index) => {
                  if(item.orderItemId == this.state.orderItemId) {
                      count = count+item.amount;
                      price = item.price;
                  }
              })
          }
      }


      const apply_reson = [{
          key : 0,
          aftersales_reson:  "商品质量问题"
      },{
          key : 1,
          aftersales_reson:  "商品与页面描述不符"
      },{
          key : 2,
          aftersales_reson:  "收到商品损坏"
      },{
          key : 3,
          aftersales_reson:  "发货错误"
      },{
          key : 4,
          aftersales_reson:  "未收到货，不想要了"
      }
      ]
    return (
      <div className="apply-aftersale">
          {
              detail.goodsList ?
                  detail.goodsList.map((item, index) => {
                      if(item.orderItemId == this.state.orderItemId) {
                          return <OrderGoods key={index} item={item}></OrderGoods>
                      }else {
                          null
                      }
                  }) : null
          }

        <WhiteSpace size=".08rem"></WhiteSpace>
        <div onClick={this.showReson.bind(this)} className="form-item">
          <div >售后原因</div>
          <div>
              {this.state.applyAfterReson}
            <Icon type="arrow" size="xxs"></Icon>
          </div>
        </div> 
        <WhiteSpace size=".08rem"></WhiteSpace>
        <div className="form-item">
          <div>申请数量</div>
          <div>{count}</div>
        </div> 
        <WhiteSpace size=".08rem"></WhiteSpace>
        <div className="form-item">
          <div>退款金额</div>
          <div className="emphasize">{price}</div>
        </div>
        <WhiteSpace size=".08rem"></WhiteSpace>
        <div className="text-item">
            <div className="title" >问题描述 <span className="required">※</span> </div>
            <div className="problem-desc">
              <textarea className="desc" name="desc" value={this.state.desc}  onChange={this.textareaChange.bind(this)} placeholder="请输入问题描述" />
              <span className="text-len">{this.state.count}/200</span>
            </div>
        </div>
        <WhiteSpace size=".08rem"></WhiteSpace>
        <div className="upload-proof">
            <p className="title">上传凭证</p>
            <ImagePicker
              files={this.state.files}
              onChange={this.onImagesChange}
              onImageClick={(index, fs) => console.log(index, fs)}
            />
        </div>
        <WhiteSpace size=".63rem"></WhiteSpace>
        {/*<OrderDetailBottom onClick={this.applyAfterSale.bind(this)}></OrderDetailBottom>*/}
        <div className="detail-bottom" onClick={this.applyAfterSale.bind(this)}>提交</div>
        <ForecastReson
                        reson={apply_reson}
                        onClick={this.switchModalVisible}
                        onCompleteClick={this.onModalCompleteClick}
                        modalVisible={this.state.modalVisible}
        />
          <NotificationBlock enter={this.state.enter} leave={this.leave}>
              {this.state.message}
          </NotificationBlock>
      </div>
    )
  }
}

const mapStateToProps = state => ({
    detail: state.order.detail,
    applyaftersuccess:state.order.applyaftersuccess
})

export default withRouter(connect(mapStateToProps, {
  fetchAfterSaleInfo,
  fetchOrderDetail,
  fetchApplyAfterSale
})(AfterSale)) 