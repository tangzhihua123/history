import React, { Component } from 'react'

import './index.scss'
import Logo from './about_logo@3x.png'

export default class MainFloor extends Component { 
    constructor(props) {
        super(props)
        this.state = {

        }
    }



    componentDidMount() {

    }

    render() {

        return (

            <div className="aboutApp">

                <div className="content">
                    <div className="flexCenter">
                            <img src={Logo} alt="" className="logo-img" />
                    </div>
                    <div className="flexCenter">
                        <div className="appB app_top"></div>
                        <div className="abhoutApp_Verison">
                            版本号  V1.0.0
                        </div>
                        <div className="appB app_bottom"></div>

                    </div>
                    <div className="flexCenter">
                        <div className="fiex_content">
                            <div className="contentType">
                                © COPYRIGHT NEOGLORY 2017.ALL RIGHTS RESERVED
                            </div>
                            <div className="contentType company">
                                新光控股集团有限公司
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        )
    }
}