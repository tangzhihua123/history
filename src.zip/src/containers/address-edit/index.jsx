import React, { Component } from 'react'
import { connect } from 'react-redux'
import { withRouter } from 'react-router-dom'
import { addOrEditShippingAddress, selectAddress } from '../../actions/address'
import { saveShippingAddress } from '../../api/address'
import queryString from 'query-string'

import './index.scss'
import Toast from 'components/toast'

import AddressItem from 'ui/address-item'
import MapGaode from 'ui/map-gaode'
import Amap from 'ui/amap'

import SwipeAction from 'components/swipe-action'
import Icon from 'components/Icon'

class addressEdit extends Component {
  constructor(props) {
    super(props)
    const { location } = this.props
    const serach = queryString.parse(window.location.search)
    const { state = {
      address: '',  //详细地址
      name: '',
      mobile: '',
      shippingId: '',
      province: '',
      city: '',
      area: '', // 滨江区
      street: '' // 街道
    }} = location
    state.poidata = location.state && JSON.parse(location.state.poidata)
    this.state = state
    this.state.mapVisiable = false
    this.state.type = serach.type
    document.title = serach.type === 'edit' ? '编辑收货地址' : '添加收货地址'
  }
  onFormItemChange = (event) =>{
    const name = event.target.name
    this.setState({
      [name]: event.target.value
    })
  }
  validateSubmit(params) {
    // 可以换一种验证方式，观察者模式
    if (!params.province) {
      Toast.show('收货地址未选择')
      return false
    }
    if (params.address === '') {
      Toast.show('详细地址未填写')
      return false
    }
    if (params.name === '') {
      Toast.show('收货人未填写')
      return false
    }
    if (!/^1[\d]{10}$/.test(params.mobile)) {
      Toast.show('联系电话填写有误')
      return false
    }
    return true
  }
  onSaveClick= ()=> {
    const state = this.state
    const _this = this
    const { history } = this.props

    
    const params = {
      shippingId: state.type === 'edit' ? state.shippingId : 0,
      mobile: state.mobile,
      name:  state.name,
      province: state.province,
      city: state.city,
      street: state.street,
      address: state.address, // 详细地址
      area: state.area, // 滨江区
      poidata: JSON.stringify(
        {
         lat: state.poidata && state.poidata.lat,
         lng: state.poidata && state.poidata.lng,
         poiName: state.poidata && state.poidata.poiName
        }
      ) // 定位数据POI
    }
    
    // 验证
    if (!this.validateSubmit(params)) {
      return
    }
    // 简单起见
    saveShippingAddress(params).then(function(res) {
      const { data } = res
      const serach = queryString.parse(window.location.search)
      if (res.resultCode === 2000) { //成功
        // TODO: 返回上一页s
        if (serach.redirect) {
          params.shippingId = res.data.shippingId
          _this.props.selectAddress(params)
          history.push(serach.redirect)
        } else {
          history.goBack()
        }
      } else {
        Toast.show('保存收货地址失败')
      }
    }, function(error) {
      Toast.show('网络错误')
    }) 
  }
  onMapAddressClick=()=> {
    this.setState({
      mapVisiable: true
    })
  }
  handleMapSelected=(res) =>{
    this.setState({
      province: res.province,
      city: res.city,
      area: res.adname,
      street: res.street + res.name,
      poidata: {
        lat: res.lat,
        lng: res.lng,
        poiName: res.name || '未知地址'
      },
      mapVisiable: false
    })
  }
  handleMapReturn=() => {
    this.setState({
      mapVisiable: false
    })
  }
  render() {
    const { location } = this.props
    const state = this.state
    return state.mapVisiable? 
      <Amap selectedCb={this.handleMapSelected}
      returnCb={this.handleMapReturn}
      ></Amap> :
      <div>
        <div className="input-items">
          <div className="input-item-warpper">
            <div className="input-item" onClick={this.onMapAddressClick}>
              <label>收货地址</label>
              <input defaultValue={state.province + state.city + state.area + state.street} 
              placeholder="省，市，区, 街道" name="address"/>
              <Icon type="arrow" size="xxs"></Icon>
            </div>
          </div>
          <div className="input-item-warpper">
          <div className="input-item">
            <label>详细地址</label>
            <input value={state.address} name="address" onChange={this.onFormItemChange}  placeholder="如楼号，楼层，门牌号等"/>
          </div>
          </div>
          <div className="input-item-warpper">
          <div className="input-item">
            <label>收货人</label>
            <input value={state.name}  name="name" onChange={this.onFormItemChange}  placeholder="姓名"/>
          </div>
          </div>
          <div className="input-item-warpper">
          <div className="input-item">
            <label>联系电话</label>
            <input value={state.mobile} type="number" name="mobile" onChange={this.onFormItemChange}  placeholder="手机号码"/>
          </div>
          </div>
        </div>
        <div className="btn-save" onClick={this.onSaveClick}>
          保存
        </div>
      </div>
  }
}

const mapStateToProps = state => ({
  
})

export default withRouter(connect(mapStateToProps, {
  addOrEditShippingAddress,
  selectAddress
})(addressEdit))