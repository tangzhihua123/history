import React, { Component } from 'react'
import qs from 'query-string'
import {
    Redirect
} from 'react-router-dom'
import store from 'store'
import PropTypes from 'prop-types'
import Util from 'utils/util.js'
import Request from 'utils/request-util.js'
import URLUtil from 'utils/url-util'
import LoginUtil from 'utils/login'

import NotificationBlock from 'components/Notification/NotificationBlock.jsx'


import './login.scss'
import Clear from './login_clear@2x.png'


export default class Login extends Component {
    constructor(props) {
        super(props)
        this.state = {
            agree: true,
            phone: '',
            // code: 123456,
            getCode: false,
            redirect: false,
            time: 60,
            totalTime: 10,
            init: true,
            code: '',
            validCode: false,
            messageInfo:"",
            validPhone:true,
            sceneType:3//更新手机
            // backgroundColor:'#CCCCCC'
        }
    }
    componentDidMount() {
        const user = store.get('user') || {}
        if(JSON.stringify(user) != "{}") {
            this.setState({
                phone: user.loginName,
            }, () => {
                document.title = "绑定手机号"
                if (!this.state.phone) {
                    this.setState({
                        valueName: "绑定",
                        sceneType:2
                    })
                } else {
                    document.title = "更换手机号"
                    this.setState({
                        valueName: "确定",
                        sceneType:3
                    })
                }
            })

        }
    }
    onPhoneChange = (e) => {
        let value = e.target.value
        if ((value + '').length >= 11) {
            value = (value + '').slice(0, 11)
        }
        this.setState({
            messageInfo:'',
            phone: value
        }, () => {
            if (/1[\d]{10}/.test(this.state.phone)) {
                this.setState({
                    validPhone: true
                })
            } else {
                this.setState({
                    validPhone: false
                })
            }
        })
    }
    onCodeChange = (e) => {
        let value = e.target.value
        if ((value + '').length >= 4) {
            value = (value + '').slice(0, 4)
        }
        this.setState({
            code: value,
            messageInfo:'',
            // backgroundColor:'#333333 ',
        }, () => {
            if (/[\d]{4}/.test(this.state.code)) {
                this.setState({
                    validCode: true
                })
            } else {
                this.setState({
                    validCode: false
                })
            }
        })
    }
    clearCode = () => {
        this.setState({
            code: '',
            // backgroundColor:'#CCCCCC'
        })
    }
    clearPhone = () => {
        this.setState({
            phone: ''
        })
    }
    handleLogin = () => {
        // console.log('phone', this.state.phone)
        if (!this.state.phone) {
            // this.enter('请输入手机号')
            this.setState({
                messageInfo:'请输入手机号',
            })
            return
        } else if (!this.state.validPhone) {
            // this.enter('手机号不正确，请重新输入')
            this.setState({
                messageInfo:'手机号不正确，请重新输入',
            })
            return
        } else if (!this.state.code) {
            // this.enter('请输入验证码')
            this.setState({
                messageInfo:'请输入验证码',
            })
            return
        } else if (!this.state.validCode) {
            // this.enter('请输入正确的验证码')
            this.setState({
                messageInfo:'请输入正确的验证码',
            })
            return
        }
        this.changeMobilePhone();
    }
    changeMobilePhone = () => {
        let param = {
            data: {
                mobile:this.state.phone,
                verifyCode:this.state.code
            },
            url: '/user/bindMobile',
            successFn: (res) => {
                if (res.resultCode === 2000) {
                    const user = store.get('user') || {}
                    if(JSON.stringify(user) != "{}") {
                        store.set('user', {
                            loginName: this.state.phone,
                            token: user.token,
                            memberCode: user.code,
                            nickName: user.nickName,
                            faceLink: user.faceLink,
                            gender:user.gender,
                            birthday:user.birthday
                        })
                    }

                    this.enter('修改成功',true)
                }else {
                    if(res.resultMsg == '验证码输入有误') {
                        this.setState({
                            messageInfo:'验证码错误，请重新输入',
                        })
                    }
                    // this.enter(res.resultMsg)
                }

            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
                this.enter(res.resultMsg)
            }
        }
        Request.fetch(param)
    }
    getVerifyCodeAjax = () => {
        if (!this.state.validPhone) {
            if (!this.state.phone) {
                // this.enter('请输入手机号')
                this.setState({
                    messageInfo:"请输入手机号"
                })
                return
            }
            // this.enter('手机号不正确，请重新输入')
            this.setState({
                messageInfo:"手机号不正确，请重新输入"
            })
            return
        }
        let param = {
            data: {
                mobile: this.state.phone,
                sceneType: this.state.sceneType
            },
            url: '/sys/sendVerifyCode',
            successFn: (data) => {
                if (data.resultCode === 2000) {
                    this.enter(<div>
                        <div>验证码已发送到您的手机</div>
                        <div>5分钟内有效</div>
                    </div>)
                    this.setState({
                        getCode: true,
                        init: false
                    })
                }else {
                    if(data.resultMsg == '手机号码输入有误') {
                        this.setState({
                            messageInfo:"手机号不正确，请重新输入"
                        })
                    }
                }

            },
            errorFn: (error) => {
                this.enter('登陆失败，请重试')
            }
        }
        this.setState({
            getCode: true,
            init: false
        })
        this.setTimeInterval()
        Request.fetch(param)

    }
    enter = (message,isGoPage) => {
        this.setState({
            enter: true,
            message: message
        });
        setTimeout(
            function () {
                this.leave(isGoPage);
            }.bind(this),
            2000
        );
    }

    leave = (isGoPage) => {
        this.setState({
            enter: false,
            message: ""
        });
        if(isGoPage) {
            setTimeout(URLUtil.redirectPage({
                page: 'app/personSeting',
                options: { },
            }),5000000)
        }
    }
    setTimeInterval = () => {
        let time = this.state.time
        let interval = setInterval(() => {
            if (time <= 0) {
                clearInterval(interval)
                this.setState({
                    time: this.state.totalTime,
                    getCode: false
                })
            } else {
                time--
                this.setState({
                    time: time
                })
            }
        }, 1000)

    }
    genVerifyBtn = () => {
        if (!this.state.getCode && this.state.init) {
            return (
                <span className={"get-code"}
                    onClick={this.getVerifyCodeAjax}
                >获取验证码</span>
            )
        } else {
            if (this.state.getCode && this.state.time > 0) {
                console.log('大于0')
                return (
                    <span className={"get-code" + ' gray'}
                    >{'重新获取'}({this.state.time}s)</span>
                )
            } else {
                return (
                    <span className={"get-code"}
                        onClick={this.getVerifyCodeAjax}
                    >{'重新获取'}</span>
                )
            }
        }
    }
    /* triggerAgree = () => {
        this.setState({
            agree: !this.state.agree
        })
    } */
    render() {
        let inputType = Util.isIOS() ? "number" : "tel"
        const { from } = this.props.location.state || { from: { pathname: '/' } }
        let phoneClear = { visibility: this.state.phone ? 'visible' : 'hidden' },
            backgroundColor = { visibility: this.state.code ? '#333333' : '#CCCCCC' },
            codeClear = { visibility: this.state.code ? 'visible' : 'hidden' }
        // console.log('from', from)
        return (this.state.redirect ? <Redirect to={{ ...from, state: { login: true } }}></Redirect> :
            <div className="changeMobile-box">
                {/*<img src={Bg} alt="" className="login-bg-img" />*/}
                <div className="login-container-div">
                    {/*<img src={Logo} alt="" className="logo-img" />*/}
                    <div className="phone-input-div">
                        <input type="text"
                            type={inputType}
                            pattern="\d*"
                            className="phone-input"
                            onChange={this.onPhoneChange}
                            value={this.state.phone}
                            placeholder="请输入手机号" />
                        <div className="clear-con">
                            <img src={Clear}
                                style={phoneClear}
                                onClick={this.clearPhone}
                                className="clear-phone" alt="" />
                        </div>
                        {
                            this.genVerifyBtn()
                        }
                    </div>
                    <div className="ver-code-div">
                        <input type="text" className="ver-input"
                            onChange={this.onCodeChange}
                            type={inputType}
                            pattern="\d*"
                            value={this.state.code}
                            placeholder="请输入验证码" />
                        <img src={Clear}
                            style={codeClear}
                            className="clear-code"
                            onClick={this.clearCode}
                            alt="" />


                    </div>
                    <div className="mainDiv">
                        <div className="message-div">
                            <div className="message">{this.state.messageInfo}</div>
                        </div>
                        {this.state.code&&this.state.phone?(
                            <div className="submit-div sub"  onClick={this.handleLogin}>{this.state.valueName}</div>
                        ):(
                            <div className="submit-div" >{this.state.valueName}</div>
                        )}

                        <div className="agreement-div">
                            <div className="agree">一个手机只能作为一个账号的登陆名，最多可以被一个账号绑定</div>
                        </div>
                    </div>


                </div>

                <NotificationBlock enter={this.state.enter} leave={this.leave}>
                    {this.state.message}
                </NotificationBlock>
            </div>
        )
    }
}

Login.propTypes = {
    // 重定向到/app/login后，如果带有?redirect=*，则登陆后跳转回去，否则跳到/根路径
    loginCb: PropTypes.func, //登录成功后执行的回调，控制路由跳转
    logoutCb: PropTypes.func, //注销后执行的回调，控制路由跳转
}