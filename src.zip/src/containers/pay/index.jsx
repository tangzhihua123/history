import React, { Component } from 'react'
import PropTypes from 'prop-types'
import { withRouter } from 'react-router-dom'
import { connect } from 'react-redux'
import qs from 'query-string'
import './index.scss'
import PayModal from 'ui/pay-modal'
import PayResult from 'ui/pay-result'

import payUtil from 'utils/payUtil'
import weixinUtil from 'utils/WeixinUtil'

import { fetchOpenid } from '../../api/i'

import { fetchOrderDetail, fetchPayConfig } from '../../api/order'

class Pay extends Component {
  constructor(props) {
    super(props)
    document.title = '支付页面'
    this.state = {
      orderid: '',
      payType: '',
      openid: '',
      money: '',
      payTypeModalVisible: false,
      payResultVisible: false,
      payStatus: 'unpay'
    }
  }
  
  componentWillMount() {
    // 获取url参数
    // 获取openid 
    this.getOpenId()
    this.getOrderInfo()
  }
  getOpenId() {
    weixinUtil.initWeixinJSBridge()
    const openid = localStorage.getItem('sjyx_openid')
    const urlParams = qs.parse(window.location.search)
    if(!openid) {
      if(!urlParams.code) {
        location.href = weixinUtil.getAuthorizeURL()
      } else {
        // 获取openid
        // 存在code 过期 TODO: 
        fetchOpenid(
          urlParams.code
        ).then(function(res) {
          if (res.resultCode === 2000) {
            const openid = (JSON.parse(res.data)).openid
            localStorage.setItem('sjyx_openid', openid)
          } else {
            alert('获取微信授权失败')
          }
        })
      }
    }
  }
  getOrderInfo() {
    const urlParams = qs.parse(window.location.search)
    const params = {}
    const _this = this
    if (urlParams.orderid) {
      params.orderId = urlParams.orderid 
      this.setState({
        orderid: urlParams.orderid
      })
      fetchOrderDetail(params).then((res)=> {
        if (res.resultCode === 2000) {
          if (res.data.payStatus !== 0) {
            alert('订单已支付或部分付款')
            return
          } else if(res.data.orderStatus !== 0) {
            alert('订单已关闭或已取消')
            return
          }
          _this.setState({
            money: res.data.payment,
            payTypeModalVisible: true
          })
        } else {
          alert('获取订单信息失败')
        }
      })
    } else {
      alert('缺少订单号参数')
    }
  }
  componentDidMount() {
    // 校验登录， 获取openid ， 发起支付请求
    // 弹出modal
    // modal参数 money
  }

  onPayClick=(orderId, payType)=>{
    const _this = this
    // 目前只有微信支付
    fetchPayConfig({
      orderId,
      isWxPay: payType,
      openid: localStorage.getItem('sjyx_openid')
    }).then(function(res) {
      const { data } = res
      if (res.resultCode === 2000) { //成功
        payUtil.wxPay({
          payParam: {
            appId: data.wxAppId,
            timeStamp: data.timestamp,
            nonceStr: data.noncestr,
            packageStr: `prepay_id=${data.prepayId}`,
            paySign: data.sign
          }
        }, function(res, json) {
          if (res === 'SUCCESS') {
            _this.setState({
              payStatus: 'success',
              payResultVisible: true,
              payTypeModalVisible: false
            })
          } else {
            // 支付失败逻辑
            _this.setState({
              payStatus: 'fail',
              payResultVisible: true,
              payTypeModalVisible: false
            })
          }
        })
      }
    }, function(error) {
      // 支付失败逻辑
      _this.setState({
        payStatus: 'fail',
        payResultVisible: true,
        payTypeModalVisible: false
      })
      console.log(error)
    }) 
  }
  onPayModalClose=()=> {
    this.setState({
      payStatus: 'fail',
      payResultVisible: true,
      payTypeModalVisible: false
    })
  }
  render() {
    const info = {
      orderId: this.state.orderid,
      money: this.state.money
    }
    return (
      <div className="pay">
        <PayModal
        info={info} 
        onPayClick={this.onPayClick}
        modalVisible={this.state.payTypeModalVisible}
        onClose={this.onPayModalClose}
        />
        <PayResult
          visible={this.state.payResultVisible}
          status={this.state.payStatus}
          rePay={()=> {
            this.onPayClick(this.state.orderid, 1)
          }}
          >
        </PayResult>
    </div>
    )
  }
}

const mapStateToProps = state => ({
  orderinfo: state.order.detail
})

export default withRouter(connect(mapStateToProps, {

})(Pay))