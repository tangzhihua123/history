import React, { Component } from 'react'
import { connect } from 'react-redux'
import { withRouter } from 'react-router-dom'
import Modal from 'components/modal'
import URLUtil from 'utils/url-util'
import store from 'store'

import { tokenIvalid } from '../../actions/i'
import './index.scss'
import ARROW from './Group_Copy_8@3x.png'
import HeardImg from './my_Avatar@2x.png'


class PersonSeting extends Component {
    constructor(props) {
        super(props)

        this.state = {
            loginName:"",
        }
    }
    componentDidMount() {
        document.title = "手机号"
        const user = store.get('user') || {}
        if(JSON.stringify(user) != "{}") {
            this.setState({
                loginName: user.loginName,
            })
            if(user.loginName) {
                this.setState({
                    loginName:(user.loginName).replace(/(\d{3})\d{4}(\d{4})/, "$1****$2")
                })
            }
        }
    }
    RedirectUrl() {
        URLUtil.redirectPage({
            page: 'app/changeMobileDetail',
        })
    }

    render() {
        return (
            <div className="changeMobile">
                <div className="items" >手机 <span>{this.state.loginName}</span></div>
                <div className="buttonOK" onClick={this.RedirectUrl.bind(this)}>更换手机号</div>
            </div>
        )
    }
}

const mapStateToProps = state => ({

})

export default withRouter(connect(mapStateToProps, {
    tokenIvalid
})(PersonSeting))