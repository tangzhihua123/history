import React, { Component } from 'react'
import { connect } from 'react-redux'
import { withRouter } from 'react-router-dom'
import { fetchActivityGoods } from '../../actions/goods'
import qs from 'query-string'
import './index.scss'

import GoodsList from 'ui/goods-list'
import PostFreeTipBar from 'ui/postfree-tip-bar'
import BottomTips from 'ui/bottom-tips'
import URLUtil from 'utils/url-util'


class Activity extends Component {
  constructor(props) {
    super(props)
    this.state = {
      activeCate: 1, // 选中类别
      selectId: 1,
    }
  }
  getListData(type, selectId, pageIndex, pageSize) {
    const urlParams = qs.parse(window.location.search)
    const params = {
      promotionId: urlParams.activityid,
      type: type,
      selectId: selectId,
      pageIndex: pageIndex,
      pageSize: pageSize
    }
    if (urlParams.activityid === undefined) {
      alert('参数错误')
    }
    this.props.fetchActivityGoods(params)
  }
  componentDidMount() {
    document.title = URLUtil.fetchValueByURL("activityname")
    this.getListData(1, this.state.selectId, 1, 40)
  }
  selCat(catId, title) {
    this.setState({
      selectId: catId,
      activeCate: catId, // 选中类别
    })
    this.getListData(1, catId, 1, 40)
  }
  /**
   * [获取分类数据列表]
   * @return {[type]} [description]
   */
  getCatList = () => {
    // let arr = this.state.catList
    let arr = [
      {
        catId: 1,
        title: '销量'
      },
      {
        catId: 2,
        title: '价格由低到高'
      },
      {
        catId: 3,
        title: '价格由高到低'
      }
    ]
    // if(!Util.isArray(arr)) return
    //onClick={this.selCat.bind(this,item.catId, item.title)}
    let list = arr.map((item, i) => {
      let cls = (item.catId == this.state.activeCate) ? "active" : ''
      return (
        <li className={cls} key={i} onClick={this.selCat.bind(this, item.catId, item.title)}>{item.title}</li>
      )
    })

    return list
  }
  render() {
    const { list } = this.props
    // <PostFreeTipBar></PostFreeTipBar>
    return (
      <div className="catpos-content">
        <div className="catpos-title">
          {/*一下商品满100减20*/}
          以下商品{URLUtil.fetchValueByURL("activityname")}
        </div>
        <div className="catpos-menu">
          <ul>
            {this.getCatList()}
          </ul>
        </div>
        <GoodsList list={list}></GoodsList>
        <BottomTips></BottomTips>
      </div>
    )
  }
}


const mapStateToProps = state => ({
  list: state.goods.activityList
})

export default withRouter(connect(mapStateToProps, {
  fetchActivityGoods
})(Activity)) 