
import React, { Component } from 'react'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import { withRouter } from 'react-router-dom'
import Login from 'utils/login'
import store from 'store'

import { fetchCart, decreaseCount, increaseCount, delCartItem, 
  triggerCheckStatus, triggerAllCheckStatus, triggerCouponCheckStatus, removeCart,
  fetchLocalCart,
  batchJoinToCart
} from '../../actions/cart'

import { checkToken, tokenIvalid } from '../../actions/i'

import Toast from 'components/toast'
import CartList from 'ui/cart'
// import eruda from 'eruda'
import CartItem from 'ui/cart/cart-item'
import CartNull from 'ui/cart/cart-null'

import CartBottom from 'ui/cart-bottom'
import CouponBar from 'ui/cart-bottom/coupon-bar'
import Tips from 'ui/cart-bottom/tips'
import SwipeAction from 'components/swipe-action'
import WhiteSpace from 'components/white-space'

import './index.scss'

let toastIsShow= false
class Cart extends Component {

  couponCode= ''
  constructor(props) {
    super(props)
  }
  componentDidMount() {
    document.title = '购物车'
    // eruda.init()
    const cartData = localStorage.getItem('cartList')
    const params = {}
    const locationState = this.props.location.state
    // cartData 在saga中处理 ?
    if (cartData) { // 如果本地有数据，发起加入购物车请求 如果返回4005，则调用本地数据发起fetchCart
      this.props.batchJoinToCart(cartData) 
    } else { // 无数据
      if (locationState && locationState.couponNo) { 
        params.couponNo = locationState.couponNo
        
        this.props.fetchCart(params)
        if (!this.props.couponCheckStatus) {
          this.props.triggerCouponCheckStatus(!this.props.couponCheckStatus) // 改变按钮为选中状态
        }
        // 设置选中购物券
        this.couponCode = locationState.couponNo
      } else {
        this.props.fetchCart()
      }
    }
    // 检查token有效性
    setTimeout(() => {
      this.props.checkToken()
    }, 10)
  }
  renderCartList= (arr = []) => {
    return arr.map((cart, index) => {
      return (
        <CartList key={index} cartList={cart} clearInvaild={this.props.removeCart}>
          {this.renderItem(cart.items, index, cart.groupType)}
          <WhiteSpace size=".1rem"></WhiteSpace>
        </CartList>
      )
    })
  }
  operCart=(item, type) => {
    const { decreaseCount, increaseCount, delCartItem, triggerCheckStatus } = this.props

    if (item.gift) {
      Toast.show('这是赠品, 请收下吧~', 1.5, false)
      return
    }
    switch(type) {
      case 'dec':
        return decreaseCount(item)
        break
      case 'inc': 
        return increaseCount(item)
        break
      case 'del': 
        return delCartItem(item)
        break
      case 'check': 
        return triggerCheckStatus(item)
        break
      default: break
    }
  }
  renderItem= (items=[], index, type='') => {
    const { decreaseCount, increaseCount, delCartItem, triggerCheckStatus } = this.props
    return (
      <div className="cart-items" key={index}>
        {
          items.map((item, i) => {
            return type !== 2 ? <SwipeAction key={i} 
              onPress={() => this.operCart(item, 'del')}>
                <CartItem
                  onDecrease={()=> this.operCart(item, 'dec')}
                  onIncrease={()=> this.operCart(item, 'inc')}
                  onCheckClick={()=> this.operCart(item, 'check')}
                  onDelete={()=> this.operCart(item, 'del')}
                  key={i} item={item}
                  type={type}
                />
              </SwipeAction> : <CartItem
                onDecrease={()=> this.operCart(item, 'dec')}
                onIncrease={()=> this.operCart(item, 'inc')}
                onCheckClick={()=> this.operCart(item, 'check')}
                onDelete={()=> this.operCart(item, 'del')}
                key={i} item={item}
                type={type}
               />
          })
        }
      </div>
    )
  }
  showCouponToast=() =>{
    if (!toastIsShow) {
      setTimeout(() => {
        Toast.show('已为您选用最高面额优惠券可自行更换优惠券', 2, false)
      }, 1000)
      toastIsShow = true
    }
  }
  render() {
    const { items, sum, freightConfig, couponList, 
      triggerAllCheckStatus, allCheckStatus,
      couponCheckStatus, triggerCouponCheckStatus, local, tokenValid } = this.props
    let newSum = sum
    const _this = this
    /**
     * 三种状态
     * 1. 已登录 => 将本地购物车数据发送至后端拉取新购物车数据、成功后清除本地购物车数据
     * 2. 未登录、本地购物车有数据 => 展示本地购物车数据
     * 3. 未登录、本地购物车无数据 => 展示购物车为空页面
     */
    let newItems = items
    if(!Login.checkLogin() && local.length > 0) { 
      newItems = local
      newSum = this.computedLocalSum(local[0].items)
    }
    if(couponList && couponList.length > 0) {
      couponList.map((c)=> {
        if (c.isChecked) {
           // 有券，且未展示过 且 已登录
          if (Login.checkLogin() && tokenValid) {
            _this.showCouponToast()
          }
          // if (!couponCheckStatus) {
          //   triggerCouponCheckStatus(!couponCheckStatus)
          // }
          this.couponCode = c.couponNo
        } 
      })
    }

    const bottomStyle = {
      position: 'fixed',
      bottom: 0,
      left: 0,
      width: '100%',
      zIndex: 999
    }
    const cartItemsStyle = {
      paddingBottom: '1.35rem'
    }
    return newItems.length > 0 ? <div>
      <div style={cartItemsStyle}>
        {this.renderCartList(newItems)}
      </div>
      <div style={bottomStyle}>
        {
          freightConfig.freightPrice !== undefined ?<Tips 
          freight={freightConfig}
          totalAmount={newSum.totalAmount}
         /> : null
        }
        <CouponBar 
         onCheckClick={() => triggerCouponCheckStatus(!couponCheckStatus) }
         isChecked={couponCheckStatus} 
         couponList={couponList}
         />
        <CartBottom
          isLogin={this.props.tokenValid}
          sum={newSum} freight={freightConfig}
          couponCode={this.couponCode}
          couponList={couponList}
          onCheckClick={ () => triggerAllCheckStatus(!allCheckStatus)}
          checked={allCheckStatus}
        />
      </div>
    </div> : <CartNull action={{}}/>
  }
}

const mapStateToProps = state => ({
  items: state.cart.items,
  sum: state.cart.sum,
  freightConfig: state.cart.freightConfig,
  couponList: state.cart.couponList,
  allCheckStatus: state.cart.allCheckStatus,
  couponCheckStatus: state.cart.couponCheckStatus,
  local: state.cart.local,
  tokenValid: state.i.tokenValid
})

export default withRouter(connect(mapStateToProps, {
  fetchCart,
  decreaseCount,
  increaseCount,
  delCartItem,
  triggerCheckStatus,
  triggerAllCheckStatus,
  triggerCouponCheckStatus,
  removeCart,
  fetchLocalCart,
  checkToken,
  batchJoinToCart
})(Cart))
