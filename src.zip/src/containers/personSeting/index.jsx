import React, { Component } from 'react'
import { connect } from 'react-redux'
import { withRouter } from 'react-router-dom'

import Modal from 'components/modal'
import URLUtil from 'utils/url-util'
import store from 'store'
import RequestUtil from 'utils/request-util'

import { tokenIvalid } from '../../actions/i'
import './index.scss'
import ARROW from './Group_Copy_8@3x.png'
import HeardImg from './my_Avatar@2x.png'
import ChangeGenderModal from '../changeGenderModal/changeGender-modal.jsx'
const Loading = 'data:image/gif;base64,R0lGODlhUABQANU4AH5+fjExMYCAgOTk5Orq6oGBge3t7fz8/PX19dfX19nZ2fj4+MPDw6KiooqKipGRkfPz87q6uqampqSkpJ6enpaWlqOjo1RUVDIyMjMzM83NzT8/P1FRUTk5OVVVVff397+/v6ioqO7u7ubm5tPT0+Hh4XFxcURERExMTFBQULKysvHx8UVFRXNzc8XFxcbGxoyMjFdXV1lZWfDw8Pv7+9ra2ktLS1NTU////wAAAAAAAAAAAAAAAAAAAAAAAAAAACH/C05FVFNDQVBFMi4wAwEAAAAh/wtYTVAgRGF0YVhNUDw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTMyIDc5LjE1OTI4NCwgMjAxNi8wNC8xOS0xMzoxMzo0MCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTUuNSAoTWFjaW50b3NoKSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDoyOTNDODM5NEMzOUUxMUU3QThFOEJFMjcyQzgwNTczNCIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDoyOTNDODM5NUMzOUUxMUU3QThFOEJFMjcyQzgwNTczNCI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOkZBMzdCREZGQzJEMTExRTdBOEU4QkUyNzJDODA1NzM0IiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOkZBMzdCRTAwQzJEMTExRTdBOEU4QkUyNzJDODA1NzM0Ii8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+Af/+/fz7+vn49/b19PPy8fDv7u3s6+rp6Ofm5eTj4uHg397d3Nva2djX1tXU09LR0M/OzczLysnIx8bFxMPCwcC/vr28u7q5uLe2tbSzsrGwr66trKuqqainpqWko6KhoJ+enZybmpmYl5aVlJOSkZCPjo2Mi4qJiIeGhYSDgoGAf359fHt6eXh3dnV0c3JxcG9ubWxramloZ2ZlZGNiYWBfXl1cW1pZWFdWVVRTUlFQT05NTEtKSUhHRkVEQ0JBQD8+PTw7Ojk4NzY1NDMyMTAvLi0sKyopKCcmJSQjIiEgHx4dHBsaGRgXFhUUExIREA8ODQwLCgkIBwYFBAMCAQAAIfkEBQQAOAAsAAAAAFAAUAAABv9AnHBILBqPyKRyyWw6n9CodEqtWq/YrHbL7Xq/4LB4TC6bz+i0es1uu9/wuHxOr9vv+Lx+z+/7/4CBdgEBgkYJDESERAIWgQMAAgRDi0IaGAEggRIADZSFQhwBHoIGBQAKQpUhARkkfgNEEQAPBzgnJzgfGwEmRJp4CQASBkILDhMIRCMXHSJCJB4BjncMAgAFEQs4EEglOCImGQEYBXkEDQAADt1JJR2EMTV8Cg8TTBcpL38HyksrtgwJHKKuYAUnFAqqs6MQwMEmCRUOnNiPCYKAferdWzLhQao96NSxUwLBgboGk/BYw6aNG5JuCyKcEpDojjBixpD5E4JggoNebTgMcEqQJ9aQWbVwUKCA48ADABGIGOVjCpWQhTgUYCu2qRNBAEPSSXgUKSUOrDgIXJvqBxERtDgYEJ14Fizdu3jz6t3Lt6/fv4ADCx5MuLDhw4gTK17MuLHjx1uCAAAh+QQFBAA4ACwnABsADgAOAAAGMEAAAEcsGonCoxKXXBqbTuQQp4pWKjha1GjYenECL0ez3YS8o893TUQF3m/nDf4OAgAh+QQFBAA4ACwqABwACgAUAAAGSUCckJEQGoUEAWBwFDYAkiZOASgYmocHICJFTBwLYfEIwSFaUhwhzW6731IUXDr6sC+bkHTGCgQ4Gk0fMBkBGAJSAzIBFmwuOEEAIfkEBQQAOAAsKgAgAAoAFAAABkpAnHAoHBCHBgkgQVxECgABYwhxAAANwnHyUByFiMN3TC6bz2hiqTMu4UQm4urSEQlJnmEqEB+ChC8BGSRjMQF5XzUYAX9fBRZHQQAh+QQFBAA4ACwnACcADgAOAAAGMUCccCikAI5HItGIBCif0KGBFn2qqtiscoS9oXCfTTUQEIbGZSEnSh5q2GmhANrOBgEAIfkEBQQAOAAsIAAqABQACgAABkhAnHBIJCIOxaRy8lAonziIAwBoEIiz53URKQAEDOGHdRkpEUKDBJAQwgKbDw5VbBEHwkEmEIK2izIBHFBKLgEYGoRKFgKKSUEAIfkEBQQAOAAsHAAqABQACgAABkpAnFC4GhqPx1fqgmwKa7FAoFNyHguYQMYkwlWbkKEl4CEJRR0kYuJYDEFGU/PwAESaZqcCUDAgPVY4DQASR3CBBAIAA4FNDAk4QQAh+QQFBAA4ACwbACcADgAOAAAGL8CAUGjDGY/GofCEbDqfzc8IegxtqDgNB4sTcLmGL46Go1CoKiMA8F232Vx3HBAEACH5BAUEADgALBwAIAAKABQAAAZJQJwLRywSLQHZwEgUYAIZ2Iep4QQCrBkTF9pctsTPCEwunsrotLpMALcQOAgzQVw4JnBmBPA4MA0FAApbEgANWwMAAm1bCQxFQQAh+QQFBAA4ACwcABwACgAUAAAGSECcUGgpDI+gAKZ2HHoCsaaQlAm8hKCjKZBykoSizmWlFeFKUlwHnW673/C4+4BIKx6TJqEBADggQwwCAAURC0cJABIGaQNtQQAh+QQFBAA4ACwbABsADgAOAAAGMkCccEgUBgJFoYB4TAo1w6aTE0U6cSGj1bn54E62q3AkLpuLqrOQZlBfAXB45R0HzJ1BACH5BAUEADgALBwAHAAUAAoAAAZJQJxwSCwKBRajkqjBBFzLJScgMyaioUBmIOQOW8UT7rMJwIQJgMQgRChHF9ZHyBAACpEFjrCcEQkNAAAOEFFKCg8ThksHbotCQQA7'
import ImageCompressor from '@xkeshi/image-compressor';

import FileUpload from 'react-fileupload'
// import ImagesUploader from 'react-images-uploader'
// import 'react-images-uploader/styles.css';
// import 'react-images-uploader/font.css';

class PersonSeting extends Component {
    constructor(props) {
        super(props)

        this.state = {
            heardImg: HeardImg,//头像
            nickName:"",
            loginName:"",
            gender:"",
            birthday:"",
            isShow:false,//是否显示修改性别弹出框,
            isShowImg:true,
            theClassName:"changeGender-modal"
        }
    }
  onLogout= () => {
    // 清除 storage
    // 本地token状态置为false
    // 然并卵啊，还是要后端session 退出
    Modal.alert('退出登录', [
      {
        text: '取消',
        onPress: () => {}
      }, {
        text: '确定',
        onPress: () => {
          this.props.tokenIvalid()
          localStorage.removeItem('user')
          this.props.history.push('/app/i')
        }
      }
  ])

  }
    componentDidMount() {
        document.title = "个人信息"
        const user = store.get('user') || {}
        if(JSON.stringify(user) != "{}") {
            this.setState({
                heardImg: user.faceLink,
                nickName: user.nickName,
                loginName: user.loginName,
                gender: user.gender,
                birthday: user.birthday,
            })
            if(!user.faceLink) {
                this.setState({
                    heardImg: HeardImg,
                })
            }
            if(user.loginName) {
                this.setState({
                    loginName:(user.loginName).replace(/(\d{3})\d{4}(\d{4})/, "$1****$2")
                })
            }
        }
    }
    onchangeDate(e) {
        let date = e.target.value;
        this.setState({
            birthday: date,
        })
        this.changeValueSeting(date);

    }
    RedirectUrl(t) {
        let pageUrl = "";
        if(t==3) {
            pageUrl =  'app/address-list'
        }else if(t==1) {
            pageUrl =  'app/changeNickName'
        }else if(t==2) {
            pageUrl =  'app/changeMobilePhone'
        }
        URLUtil.redirectPage({
            page: pageUrl,
        })
    }
    changeGender() {
        this.setState({
            isShow:true,
        })
    }
    cancleChangeGender(value) {
        if(value) {
            const user = store.get('user') || {}
            if(JSON.stringify(user) != "{}") {
                // user.gender == value?
                if(user.gender == value) {
                    this.setState({
                        gender:value,
                    })
                }
            }

        }
        this.setState({
            isShow:false,
            theClassName:"changeGenderCancle"
        })

    }
    changeValueSeting(value) {
        let param = {
            data: {
                content:encodeURI(value),
                type:3
            },
            url: '/user/updateUserInfo',
            successFn: (res) => {
                if(res.resultCode === 2000) {
                    // this.enter('修改成功')
                    const user = store.get('user') || {}
                    if(JSON.stringify(user) != "{}") {
                            store.set('user', {
                                loginName: user.loginName,
                                token: user.token,
                                memberCode: user.code,
                                nickName: user.nickName,
                                faceLink: user.faceLink,
                                gender:user.gender,
                                birthday:value
                            })

                    }
                }else {
                    // this.enter('修改失败')

                }
            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
                // this.enter('修改失败')
            }
        }
        // Request.fetch(param)
        RequestUtil.fetch(param)
    }
    isShowImg() {
        this.setState({
            isShowImg:false,
        })
    }
    
    /**
     * [RedirectHead 选择头像]
     */
    RedirectHead() {
        
    }

    compress = (file) => {
        let _this = this
        let quality
        if(file.size < 500 * 1000) {
          quality = 0.8
        } else if(file.size < 2000 * 1000) {
          quality = 0.6
        } else if(file.size < 5000 * 1000) {
          quality = 0.4
        } else {
          quality = 0.3
        }
        
        new ImageCompressor(file, {
          quality: quality,
          convertSize: 500000,
          success: (result) => {
            _this.blob2DataURL(result)
          },
          error: (e) => {
            console.log(e.message);
          },
        });
    }

    blob2DataURL = (blob) => {
        const reader = new FileReader()
        const fileSelectorEl = this.fileSelectorInput
        reader.onload = (e) => {
          const dataURL = e.target.result
          this.uploadImg({
            url: dataURL,
            blob: blob,
          })
          fileSelectorEl.value = ''
        }
        reader.readAsDataURL(blob)
    }

    makeid = (length) => {
        var text = "";
        var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

        for (var i = 0; i < length; i++)
            text += possible.charAt(Math.floor(Math.random() * possible.length));

        return text;
    }
    
    uploadImg = (imgItem) => {

        // if(imgItem.loading) return
        let blob = imgItem.blob  
        
        let fd = new FormData()
        fd.append("file", blob, this.makeid(10) + '.png')
        let param = {
            data: fd,
            url: '/user/updateFace',
            successFn: (res) => {
                if (res.resultCode !== 2000) {
                    // this.uploadImgFail(index)
                    return
                }

                this.setState({
                    heardImg: res.data.url
                })

            },
            errorFn: (error) => {
                // this.uploadImgFail(index)
            }
        }

        RequestUtil.uploadImg(param)
    }



    onFileChange = () => {
        const fileSelectorEl = this.fileSelectorInput
        if(fileSelectorEl && fileSelectorEl.files && fileSelectorEl.files.length) {
            const file = fileSelectorEl.files[0]
            this.compress(file)
        }
    }

    render() {
        // var options={
        //     baseUrl:'http://api.caijigaoshou.com/user/updateFace',
        //     param:{},
        //     requestHeaders: 
        // }
        return (
          <div className="personSetting">
                <div className="items" onClick={this.RedirectHead.bind(this)}>头像 <img src={this.state.heardImg} alt="" className="heard_icon"/> <img src={ARROW} alt="" className="arrow_icon"/>
                     <input type="file"  
                        ref={(input) => { this.fileSelectorInput = input; }} 
                        accept="image/jpg,image/jpeg,image/png,image/gif"
                        onChange={this.onFileChange.bind(this)} 
                        className="header_upload"
                    />
                </div>
            
               
              
             
              <div className="items" onClick={this.RedirectUrl.bind(this,1)}>昵称 <span className="span_conent">{this.state.nickName}</span><img src={ARROW} alt="" className="arrow_icon"/></div>
              <div className="items" onClick={this.changeGender.bind(this)}>性别 <span className="span_conent">{this.state.gender}</span><img src={ARROW} alt="" className="arrow_icon"/></div>
              <div className="items" >生日
                  <span className="span_conent_birthday">
                  <input className="PersonBirthday" type="date" onClick={this.isShowImg.bind(this)} onChange={this.onchangeDate.bind(this)} value={this.state.birthday}/>
                  </span>

                      <img src={ARROW} alt="" className="arrow_icon"/>

              </div>
              <div className="tiems_content"></div>
              <div>
                  <div className="items iphoneDiv" onClick={this.RedirectUrl.bind(this,2)}>手机 <span className="span_conent">{this.state.loginName}</span><img src={ARROW} alt="" className="arrow_icon iphone_icon"/></div>
                  <div className="items" onClick={this.RedirectUrl.bind(this,3)}>收货地址<span className="span_conent"></span><img src={ARROW} alt="" className="arrow_icon"/></div>
              </div>
              <div className="changeGenderModal">
                  <ChangeGenderModal theClassName={this.state.theClassName}  isShow={this.state.isShow} changeGenderValueSeting={this.changeValueSeting.bind(this)} cancleChangeGender={this.cancleChangeGender.bind(this)} isGender={this.state.gender} hideFn={this.hideModal} goLook={this.goLook}></ChangeGenderModal>
              </div>



          </div>
        )
    }
}

const mapStateToProps = state => ({

})

export default withRouter(connect(mapStateToProps, {
  tokenIvalid
})(PersonSeting))