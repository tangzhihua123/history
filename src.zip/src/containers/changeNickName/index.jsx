import React, { Component } from 'react'
import { connect } from 'react-redux'
import { withRouter } from 'react-router-dom'
import NotificationBlock from 'components/Notification/NotificationBlock.jsx'
import Modal from 'components/modal'
import URLUtil from 'utils/url-util'
import Util from 'utils/util.js'
import store from 'store'

import { tokenIvalid } from '../../actions/i'
import './index.scss'
import Request from 'utils/request-util.js'
import Clear from './login_clear@2x.png'


class changeNickName extends Component {
    constructor(props) {
        super(props)

        this.state = {
            nickName:"",

        }
    }
    componentDidMount() {
        document.title = "个人信息"
        const user = store.get('user') || {}
        if(JSON.stringify(user) != "{}") {
            this.setState({
                nickName: user.nickName,
            })

        }
    }
    changeName(e) {
        let name = e.target.value;
        this.setState({
            nickName:name
        }, () => {
            if (/^[0-9a-zA_Z]+$/.test(this.state.nickName)) {
                this.setState({
                    validNickName: true
                })
            } else {
                this.setState({
                    validNickName: false
                })
            }
        })
    }
    handleSave()  {
        // console.log('phone', this.state.phone)
        if (!this.state.nickName) {
            this.enter('请输入昵称')
            // this.setState({
            //     messageInfo:'请输入手机号',
            // })
            return
        }
        // } else if (!this.state.validNickName) {
        //     this.enter('昵称只能输入英文或者数字，请重新输入')
        //     // this.setState({
        //     //     messageInfo:'手机号不正确，请重新输入',
        //     // })
        //     return
        // }
        this.save();
    }
    clearNickName() {
        this.setState({
            nickName:"",
        })
    }
    RedirectUrl() {
        URLUtil.redirectPage({
            page: pageUrl,
        })
    }
    save() {
        // this.handleSave();
        let param = {
            data: {
                content:this.state.nickName,
                type:1
            },
            url: '/user/updateUserInfo',//判断是否是新用户接口
            successFn: (res) => {
                if(res.resultCode === 2000) {
                    const user = store.get('user') || {}
                    if(JSON.stringify(user) != "{}") {
                        store.set('user', {
                            loginName: user.loginName,
                            token: user.token,
                            memberCode: user.code,
                            nickName: this.state.nickName,
                            faceLink: user.faceLink,
                            gender:user.gender,
                            birthday:user.birthday
                        })
                    }
                    this.enter('修改成功',true)
                }else {
                    this.enter('修改失败')
                }

            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
                this.enter('修改失败')
            }
        }
        Request.fetch(param)
    }
    enter = (message,isGoPage) => {
        this.setState({
            enter: true,
            message: message
        });
        setTimeout(
            function () {
                this.leave(isGoPage);
            }.bind(this),
            2000
        );
    }

    leave = (isGoPage) => {
        this.setState({
            enter: false,
            message: ""
        });
        if(isGoPage) {
            setTimeout(URLUtil.redirectPage({
                page: 'app/personSeting',
                options: { },
            }),5000000)
        }
    }

  render() {
      let nickNameClear = { visibility: this.state.nickName ? 'visible' : 'hidden' };
    return (
      <div className="changeNick">
          <div className="mainDiv">
              <input type="text"
                     onChange={this.changeName.bind(this)}
                     value={this.state.nickName}
                     placeholder="请输入昵称" />
              <div className="clear-con-nickNam">
                  <img src={Clear}
                       style={nickNameClear}
                       onClick={this.clearNickName.bind(this)}
                       className="clear-nickName" alt="" />
              </div>
          </div>

          <div className="buttonOK" onClick={this.handleSave.bind(this)}>保存</div>
          <NotificationBlock enter={this.state.enter} leave={this.leave}>
              {this.state.message}
          </NotificationBlock>
      </div>
    )
  }
}

const mapStateToProps = state => ({

})

export default withRouter(connect(mapStateToProps, {
  tokenIvalid
})(changeNickName))