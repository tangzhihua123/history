import React, { Component } from 'react'
import { connect } from 'react-redux'
import { withRouter } from 'react-router-dom'
import Modal from 'components/modal'
import URLUtil from 'utils/url-util'

import { tokenIvalid } from '../../actions/i'
import './index.scss'
import ARROW from './Group_Copy_8@3x.png'


class Setting extends Component {
  componentDidMount() {
    document.title = '个人设置'
  }
  onLogout = () => {
    // 清除 storage
    // 本地token状态置为false
    // 然并卵啊，还是要后端session 退出
    Modal.alert('退出登录', [
      {
        text: '取消',
        onPress: () => { }
      }, {
        text: '确定',
        onPress: () => {
          this.props.tokenIvalid()
          localStorage.removeItem('user')
          this.props.history.push('/app/i')
        }
      }
    ])
  }
  RedirectUrl(t) {
    let pageUrl = 'app/personSeting';
    if (t == 2) {
      pageUrl = 'app/aboutApp';
    }
    URLUtil.redirectPage({
      page: pageUrl,
    })
  }
  render() {
    return (
      <div className="settingA">
        <div className="items" onClick={this.RedirectUrl.bind(this, 1)} >个人设置<img src={ARROW} alt="" className="arrow_icon" /></div>
        <div className="items" onClick={this.RedirectUrl.bind(this, 2)}>关于四季严选<img src={ARROW} alt="" className="arrow_icon" /></div>
        {/*<div className="items" >清除本地缓存<img src={ARROW} alt="" className="arrow_icon"/></div>*/}
        <div className="bottom-btn">
          <div className="btn-ghost" onClick={this.onLogout}>
            <span className="btn-text">退出登录</span>
          </div>
        </div>
      </div>
    )
  }
}

const mapStateToProps = state => ({

})

export default withRouter(connect(mapStateToProps, {
  tokenIvalid
})(Setting))