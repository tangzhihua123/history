import React, { Component } from 'react'
import qs from 'query-string'
import { connect } from 'react-redux'
import { withRouter } from 'react-router-dom'
import { fetchOrderDetail,fetchAfterSaleInfo,fetchCancelAfterSale} from '../../actions/order'

import './index.scss'

import WhiteSpace from 'components/white-space'
import SplitLine from 'components/split-line'
import SuspensionFrame from 'components/suspension-frame'
import URLUtil from 'utils/url-util'
import AddressBar from 'ui/address-bar'
// import ForecastTime from 'ui/forecast-time'
import OrderProcess from 'ui/order-process'
import OrderGoods from 'ui/order-goods'

import ApplyafterInfo from 'ui/applyafter-info'
import ApplyafterDetailInfo from 'ui/applyafter-detail-info'

import OrderDetailBottom from 'ui/order-detail-bottom'

import * as aftersalesStatus from '../../utils/aftersales-status.js'
import NotificationBlock from 'components/Notification/NotificationBlock.jsx'
import Request from 'utils/request-util.js'
import Modal from 'components/modal'

// 状态对应按钮
// 未支付： 联系客服、取消订单、去支付
// 配货中： 联系客服、取消订单
// 配送中： 联系客服、取消订单
// 已完成： 联系客服、评价
// 已取消： 联系客服
// 已关闭： 联系客服

// 按钮组
// 带按钮的联系客服
const iconContact = {
  icon: 'contact',
  text: '联系客服',
  action: 'contact'
}
// 存文字
const concact = {
  text: '联系客服',
  action: 'contact'
}

const cancel = {
  text: '取消订单'
}

const unpay = {
  text: '去支付'
}




class ApplyAfterSalesDetail extends Component {
    constructor(props) {
        super(props)
        this.state = {
            activeCate: 1, // 选中类别
            selectId: 1,
            applyType:""
        }
    }
    componentWillReceiveProps(nextProps) {
        console.log('nextProps-----'+nextProps)
        if(nextProps.cancleapplyaftersuccess=='请求成功') {
            const params = {}
            params.afterId = this.state.afterId
            nextProps.applyafterInfo(params)
        }
    }
  componentDidMount() {
    const urlParams = qs.parse(window.location.search)
    const params = {}
    if (urlParams.orderitemid) {
      params.afterId  = urlParams.orderitemid
        this.setState({
            afterId:urlParams.orderitemid
        })
    }
    if(urlParams.type) {
        this.setState({
            applyType:urlParams.type
        })
    }
      this.props.fetchAfterSaleInfo(params)
  }
    cancelAfterSale() {
        //走redux方式，props改变但是不知为何没有进入componentWillReceiveProps方法中，暂时不用redux方式
        // const params = {}
        // params.afterId = this.state.afterId
        // this.props.fetchCancelAfterSale(params)
        let param = {
            data: {
                afterId:this.state.afterId,
            },
            url: '/user/cancelAfterSale',
            successFn: (res) => {
                if(res.resultCode === 2000) {
                    this.enter('撤销成功',true)
                    let params = {
                        afterId : this.state.afterId
                    }
                    this.props.fetchAfterSaleInfo(params)
                }else {
                    this.enter('撤销失败')
                }

            },
            errorFn: (error) => {
                console.log('请求失败的错误', error)
                this.enter('修改失败')
            }
        }
        Request.fetch(param)
    }
    enter = (message) => {
        this.setState({
            enter: true,
            message: message
        });
        setTimeout(
            function () {
                this.leave();
            }.bind(this),
            2000
        );
    }

    leave = () => {
        this.setState({
            enter: false,
            message: ""
        });
    }
    selCat(catId, title) {
        this.setState({
            selectId: catId,
            activeCate: catId, // 选中类别
        })
        // this.getListData(1, catId, 1, 40)
    }
    connectPerson() {
        Modal.alert('联系客服400-632-1827', [
            {
                text: '取消',
                onPress: () => {
                    console.log('左侧按钮')
                }
            }, {
                text: '拨打',
                onPress: () => {
                    console.log('右侧按钮')
                    window.location.href="tel://4006321827"
                }
            }
        ])
    }
    goSellAfter() {
        URLUtil.redirectPage({
            page: 'sell-after',
            options: {
            }
        })
    }
    getCatList = () => {
        // let arr = this.state.catList
        let arr = [
            {
                catId: 1,
                title: '售后信息'
            },
            {
                catId: 2,
                title: '处理记录'
            }
        ]
        // if(!Util.isArray(arr)) return
        //onClick={this.selCat.bind(this,item.catId, item.title)}
        let list = arr.map((item, i) => {
            let cls = (item.catId == this.state.activeCate) ? "active" : ''
            return (
                <li className={cls} key={i} onClick={this.selCat.bind(this, item.catId, item.title)}>{item.title}</li>
            )
        })

        return list
    }
  render() {
    const { applyafterInfo,detail } = this.props
    // 订单状态
    // const status = orderStatus.getOrderStatus(detail.orderStatus,  detail.payStatus, detail.shipStatus)
      // 售后申请中 = 0,退款中 = 1,拒绝售后 = 2,退款成功 = 3,售后已取消 = 4,等待买家退货 = 5,买家退货等待确认 = 6,售后完成 = 7,售后关闭 = 8
      let status = "";
    let serviceNo = "";
    let applyTime = "";
    let fees = []
    let applydetailInfo =[];
    if(applyafterInfo) {
        status =  aftersalesStatus.getAfterSalesStatus(applyafterInfo.status)
        serviceNo = applyafterInfo.serviceNo
        applyTime = applyafterInfo.applyTime
        fees = applyafterInfo.list
        let obj = {
            type : applyafterInfo.type,
            reason : applyafterInfo.reason,
            num : applyafterInfo.num,
            price : applyafterInfo.price,
            issue: applyafterInfo.issue,
            applyType: this.state.applyType,
            // pictureUrls: applyafterInfo.pictureUrls,
            pictureUrls:'https://img.yzcdn.cn/upload_files/2017/05/08/149421656829915091.jpg?imageView2/2/w/200/h/200/q/75/format/jpg,https://img.yzcdn.cn/upload_files/2017/05/08/149421656829915091.jpg?imageView2/2/w/200/h/200/q/75/format/jpg,https://img.yzcdn.cn/upload_files/2017/05/08/149421656829915091.jpg?imageView2/2/w/200/h/200/q/75/format/jpg,https://img.yzcdn.cn/upload_files/2017/05/08/149421656829915091.jpg?imageView2/2/w/200/h/200/q/75/format/jpg,https://img.yzcdn.cn/upload_files/2017/05/08/149421656829915091.jpg?imageView2/2/w/200/h/200/q/75/format/jpg,https://img.yzcdn.cn/upload_files/2017/05/08/149421656829915091.jpg?imageView2/2/w/200/h/200/q/75/format/jpg,https://img.yzcdn.cn/upload_files/2017/05/08/149421656829915091.jpg?imageView2/2/w/200/h/200/q/75/format/jpg',
            money: applyafterInfo.money
        }
        applydetailInfo.push(obj)
    }
    return (
      <div className="applyaftersales-detail">
        <OrderProcess 
          status={status}>
        </OrderProcess>
        <WhiteSpace size=".08rem"></WhiteSpace>
        {
            applyafterInfo ?
             <OrderGoods  item={applyafterInfo}></OrderGoods>
           : null
        }
        <WhiteSpace size=".08rem"></WhiteSpace>
        <div className="catpos-menu">
          <ul>
              {this.getCatList()}
          </ul>
        </div>
          {this.state.selectId ==2?<ApplyafterInfo
              fees={fees}
          ></ApplyafterInfo>:<ApplyafterDetailInfo
              fees={applydetailInfo}
          ></ApplyafterDetailInfo>}

        <WhiteSpace size=".08rem"></WhiteSpace>
        <div className="order-info">
          <div className="text-item-cont">
            <p className="text-item">
              <span>服务编号</span>
              <span>{serviceNo}</span>
            </p>
            <SplitLine size="1" color="#e5e5e5"></SplitLine>
          </div>
          <div className="text-item-cont">
            <p className="text-item">
              <span>申请时间</span>
              <span>{applyTime}</span>
            </p>
          </div>
            {status=='check'?(
                <div>
                    <div className="detail-bottom" onClick={this.cancelAfterSale.bind(this)}>撤销</div>
                </div>

            ):<div>
                <div className="connectPerson" onClick={this.connectPerson.bind(this)}>
                    <div className="btn-primary">
                        <i className="service"></i>
                        <span>联系客服</span>
                    </div>

                </div>
            </div>}
        </div>
          <WhiteSpace size=".63rem"></WhiteSpace>
          <SuspensionFrame text="售后说明" onClick={this.goSellAfter.bind(this)}></SuspensionFrame>
          <NotificationBlock enter={this.state.enter} leave={this.leave}>
              {this.state.message}
          </NotificationBlock>

      </div>
    )
  }
}

const mapStateToProps = state => ({
  detail: state.order.detail,
  applyafterInfo :state.order.applyafterInfo

})

export default withRouter(connect(mapStateToProps, {
  fetchOrderDetail,
  fetchAfterSaleInfo,
  fetchCancelAfterSale
})(ApplyAfterSalesDetail))