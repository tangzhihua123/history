import React, { Component } from 'react'
import { connect } from 'react-redux'
import { withRouter } from 'react-router-dom'
import { fetchOrderList, changeOrderStatus } from '../../actions/order'
import Tab from "components/Tab/Tab"
import OrderAll from 'ui/order-all'
import OrderItem from 'ui/order-all/order-item'

import './index.scss'

class OrderList extends Component {
  handleTopTabChange=() => {
    
  }
  componentDidMount() {
   this.props.fetchOrderList({
    type: 0,
    pageIndex: 1,
    pageSize: 1000
   })
  }
  onItemClick=(item)=> {
    this.props.history.push({
      pathname: '/app/order-detail',
      search: `?orderid=${item.orderId}`
    }) 
  }
  doAction=(item, action)=> {
    const { changeOrderStatus, history } = this.props
    
    // 目前order-item里的状态
    // pay, cancel，confirm, commment, delete
    // 如何省略switch， 可以放在对象属性里
    // status 1. 取消订单 2. 删除订单 3. 确认收货
    switch(action) {
      case 'pay': {
        history.push({
          pathname: '/app/pay',
          search: '?orderid=' + item.orderId
        }) 
        break
      }
      case 'cancel': {
        changeOrderStatus({
          orderId: item.orderId,
          status: 1
        })
        break
      }
      case 'confirm': {
        changeOrderStatus({
          orderId: item.orderId,
          status: 3
        })
        break
      }
      case 'comment': {
        history.push({
          pathname: '/app/orderrate',
          search: '?orderid=' + item.orderId
        }) 
        break
      }
      case 'delete': {
        changeOrderStatus({
          orderId: item.orderId,
          status: 2
        })
        break
      }
    }
  }
  render() {
    let topTabStatus = [ '全部订单', '退款/售后'],
    activeIndex = 0
    const { list } = this.props
    return (
      <div className="order">
      <Tab
          ref="topTab"
          isTopTab={true}
          display={true}
          tabs={topTabStatus}
          activeIndex={activeIndex}
          context={this}
          handleItemClick={this.handleTopTabChange}
      />
      <OrderAll items={list} type={0}>
        {
          list.map((item, index)=> {
            return <OrderItem 
            onItemClick={() => this.onItemClick(item)}  key={index} item={item}
            btnAction={this.doAction}
            ></OrderItem>
          })
        }
      </OrderAll>
      </div>
    )
  }
}

const mapStateToProps = state => ({
  list: state.order.list
})

export default withRouter(connect(mapStateToProps, {
  fetchOrderList,
  changeOrderStatus
})(OrderList))
