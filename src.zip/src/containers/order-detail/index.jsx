import React, { Component } from 'react'
import qs from 'query-string'
import { connect } from 'react-redux'
import { withRouter } from 'react-router-dom'
import { fetchOrderDetail, changeOrderStatus } from '../../actions/order'

import './index.scss'

import WhiteSpace from 'components/white-space'
import SplitLine from 'components/split-line'
import AddressBar from 'ui/address-bar'
import OrderProcess from 'ui/order-process'
import OrderGoods from 'ui/order-goods'
import OrderFee from 'ui/order-fee'

import Modal from 'components/modal'

import OrderDetailBottom from 'ui/order-detail-bottom'
import AftersalesModal from 'ui/aftersales-modal'

import * as orderStatus from '../../utils/order-status.js'

// api 直接暴力
import * as orderApi from '../../api/order.js'





// 状态对应按钮
// 未支付： 联系客服、取消订单、去支付
// 配货中： 联系客服、取消订单
// 配送中： 联系客服、取消订单
// 已完成： 联系客服、评价
// 已取消： 联系客服
// 已关闭： 联系客服

// 按钮组
// 带按钮的联系客服
const btns = {
  iconContact: {
    type: 'icon',
    action: 'contact'
  },
  iconTextContact: {
    type: 'icon_text',
    text: '联系客服',
    action: 'contact'
  },
  concact: {
    type: 'text',
    text: '联系客服',
    action: 'contact'
  },
  cancel: {
    type: 'black',
    text: '取消订单',
    action: 'cancel'
  },
  unpay: {
    type: 'yellow',
    text: '去支付',
    action: 'unpay'
  }
}

// 映射表 orderStatus.getOrderStatus 内状态对应
const statusbtn = {
  unpay: 'iconContact_cancel_unpay',
  prepare: 'concact_cancel',
  shipping: 'concact_cancel',
  complete: 'iconTextContact',
  cancel: 'iconTextContact',
  closed: 'iconTextContact'
}

function getStatusBtns(status) {
  const sbtns = statusbtn[status].split('_')
  return sbtns.map((i)=> {
    return btns[i]
  })
}

class OrderDetail extends Component {
  constructor(props) {
    super(props)
    this.state = {
      orderid: '',
      aftersalesModalVisiable: false,
      afterid: '',
      orderitemid: ''
    }
  }
  componentDidMount() {
    const urlParams = qs.parse(window.location.search)
    const params = {}
    if (urlParams.orderid) {
      params.orderId = urlParams.orderid 
      this.setState({
        orderid: urlParams.orderid
      })
    }
    this.props.fetchOrderDetail(params)
  }
  handleApplyAfterSale=(item)=> {
    this.setState({
      aftersalesModalVisiable: true,
      afterid: item.afterid,
      orderitemid: item.orderItemId
    })
  }
  applyAfterSale=(type)=> {
    // 弹出选择框
    this.props.history.push({
      pathname: '/app/apply-aftersales',
      search: `?orderid=${this.state.orderid}&type=${type}&applyid=${this.state.afterid}&orderitemid=${this.state.orderitemid}`
    })
  }
  getOrderFee(detail) {
    const fees = []
    fees.push({
      text: '配送费',
      value: `¥${detail.deliveryFee || 0}`
    })
    fees.push({
      text: '满减优惠',
      value : `-¥${detail.discount || 0}`
    })
    fees.push({
      text: '优惠券',
      value: `-¥${detail.coupon || 0}`
    })
    fees.push({
      text: '积分抵扣',
      value: `-¥${detail.scoreDeduction || 0}`
    })
    return fees
  }
  getOrderDetail(detail) {
    const orderDetail = []
    if (detail.orderId) {
      orderDetail.push({
        text: '订单编号',
        value: detail.orderId
      })
    }

    if (detail.orderTime) {
      orderDetail.push({
        text: '下单时间',
        value: detail.orderTime
      })
    }

    if (detail.payMode) {
      orderDetail.push({
        text: '支付方式',
        value: detail.payMode
      })
    }
    return orderDetail
  }

  handleCall() {
    Modal.alert('联系客服400-632-1827', [
      {
        text: '取消',
        onPress: () => {
          console.log('左侧按钮')
        }
      }, {
        text: '拨打',
        onPress: () => {
          console.log('右侧按钮')
          window.location.href="tel://4006321827"
        }
      }
    ])
  }
  handleCancelOrder=()=> {
    orderApi.fetchChangeOrderStatus({
      orderId: this.props.detail.orderId,
      status: 1
    }).then((res)=> {
      console.log(res)
    })
  }
  onBottomBtnClick=(action)=>{

    if (action === 'contact') {
      this.handleCall()
    } else if (action === 'cancel') {
      // 取消订单
      this.handleCancelOrder()
    } else if(action === 'unpay') {
      // 去支付
      
    }
  }
  render() {
    const { detail } = this.props
    // 订单状态
    const status = orderStatus.getOrderStatus(detail.orderStatus,  detail.payStatus, detail.shipStatus)
    let btnActions
    if (status) {
      btnActions = getStatusBtns(status)
    }
    
    const address = {
      name: detail.receiver,
      mobile: detail.mobile,
      address: detail.address,
      province: '',
      city: '',
      area: detail.area,
      street: ''
    }
    const fees = this.getOrderFee(detail)
    const orderDetail = this.getOrderDetail(detail)
    // 按钮组
    // afterSaleStatus:0,//申请售后 0无 1申请售后 2查看售后  
    return (
      <div className="order-detail">
        <OrderProcess 
          status={status}>
        </OrderProcess>
        <div className="arrival-time">
          {detail.arrivalTime}
        </div>
        <WhiteSpace size=".08rem"></WhiteSpace>
        <AddressBar address={ address }></AddressBar>
        <WhiteSpace size=".08rem"></WhiteSpace>
        {
          detail.goodsList ? 
          detail.goodsList.map((item, index) => {
            return <OrderGoods key={index} item={item}
              status={status}
            >
            {status === 'complete'? <div className="action-btn" onClick={()=>this.handleApplyAfterSale(item)}>申请售后</div> : null }
            </OrderGoods>
          }) : null
        }
        {
          detail.memo? <div className="remark">
          <p>{detail.memo}</p>
          <SplitLine size="1" color="#e5e5e5"></SplitLine>
        </div> : null
        }
        <OrderFee
          fees={fees}
          payment={detail.payment}
        ></OrderFee>
        <WhiteSpace size=".08rem"></WhiteSpace>
        <div className="order-info">
          {
            orderDetail.map((item, index, array)=> {
              return <div key={index} className="text-item-cont">
              <p className="text-item">
                <span>{item.text}</span>
                <span>{item.value}</span>
              </p>
              {
                index < array.length - 1 ? <SplitLine size="1" color="#e5e5e5"></SplitLine>: null
              }
            </div>
            })
          }
        </div>
        <WhiteSpace size=".63rem"></WhiteSpace>
        <OrderDetailBottom
          btns={btnActions}
          onClick={this.onBottomBtnClick}
        ></OrderDetailBottom>

        <AftersalesModal
          title={"选择服务类型"}
          onItemClick={this.applyAfterSale}
          modalVisible={this.state.aftersalesModalVisiable}
        />
      </div>
    )
  }
}

const mapStateToProps = state => ({
  detail: state.order.detail
})

export default withRouter(connect(mapStateToProps, {
  fetchOrderDetail,
  changeOrderStatus
})(OrderDetail)) 