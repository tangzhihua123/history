import React, { Component } from 'react'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import { withRouter, Link } from 'react-router-dom'
import Barcode from 'react-barcode'
import store from 'store'


import { fetchUserInfo, checkMemberCode, refreshMemberCode } from '../../actions/i'
import { fetchCartGoodsCount } from '../../actions/cart'

import request from 'utils/request-util'
import UserInfo from 'ui/user-info'
import OrderItem from 'ui/order-all/order-item'
import Setting from 'ui/setting'
import Toast from 'components/toast'
import Modal from 'components/modal'
import Icon from 'components/Icon'
import WhiteSpace from 'components/white-space'

import './index.scss'

import logo from './bobo.png'
import closeImg from './close.png'
// import WxUtil from 'utils/wx'

class App extends Component {
  constructor(props) {
      super(props)
      this.state = {
        modalVisiable: false
      }
      // WxUtil.init()
  }
  onMemberCodeClick=() =>{
    this.setState({
      modalVisiable: true
    })
  }
  onMemberCodeCloseClick= () =>{
    this.setState({
      modalVisiable: false
    })
  }
  getLoginName() {
    const user = store.get('user') || {}
    if(user.nickName) {
      return user.nickName
    } else if(user.loginName) {
      return (user.loginName).replace(/(\d{3})\d{4}(\d{4})/, "$1****$2")
    }
    return ''
  }
  componentDidMount() {
    this.props.fetchUserInfo()
    this.props.fetchCartGoodsCount()
    let memberCode = '111111111111111'
    if (store.get('user')) {
      memberCode = (store.get('user')).memberCode
    }
    this.props.refreshMemberCode(memberCode)
  }
  render() {
    const {
      userInfo,
      history,
      cartCount,
      refreshMemberCode,
      memberCode,
      tokenValid
    } = this.props
    let lastOrderInfo = void 0
    if (userInfo) {
      lastOrderInfo = userInfo.lastOrderInfo
    }
    let newUserInfo = userInfo ? userInfo : {}
    const nickname = this.getLoginName()
    return (
      <div className="i-cont">
        <UserInfo cartCount={cartCount} 
          info={newUserInfo} 
          onMemberCodeClick={this.onMemberCodeClick}
          history={history}
          nickName={nickname}
        ></UserInfo>
        <WhiteSpace size=".08rem"/>
        <div className="order-cont">
            <div className="order-all-cont">
              <div className="order-all">
                <div className="order-title">我的订单</div>
                <Link to="/app/order">
                  <div className="go-order">
                      <span className="view-all">查看全部订单</span>
                      <Icon type="arrow" size="xxs"></Icon>
                  </div>
                </Link>
              </div>
            </div>
            {
              lastOrderInfo ? <div className="order-unpay">
                <OrderItem item={lastOrderInfo} />
              </div> : null
            }
        </div>
        <WhiteSpace size=".08rem"/>
        <Setting 
          actions={[]} inviteText={newUserInfo.inviteText}
          isLogin={tokenValid}
        ></Setting>
        { this.state.modalVisiable ? 
          (<div className="membercode-modal">
          <div className="member-code-warpper">
              <div className="member-code">
              <div className="member-code-tips">
                  <p className="main-tip">会员专属码</p>
                  <p className="sub-tip">门店结账时出示,自动享受会员价并获取积分</p>
              </div>
              <div className="barcode-warpper" onClick={()=> refreshMemberCode(memberCode)}>
                <Barcode className="barcode"
                  value={memberCode} 
                  fontSize={13}
                  textMargin={8}
                  marginLeft={24}
                  marginTop={32}
                  marginBottom={24}
                  ></Barcode>
              </div>
              <div className="">
                <img className="logo" src={logo}></img>
              </div>
            </div>
            <div className="tips-bottom">
                <img className="icon-close" src={closeImg} onClick={this.onMemberCodeCloseClick}></img>
            </div>
          </div>
        </div>) : null
        }
      </div>
    )
  }
}

const mapStateToProps = state => ({
  userInfo: state.i.userInfo,
  memberCode: state.i.memberCode,
  tokenValid: state.i.tokenValid,
  cartCount: state.cart.count
})

export default withRouter(connect(mapStateToProps, {
  fetchUserInfo,
  fetchCartGoodsCount,
  refreshMemberCode,
  checkMemberCode
})(App)) 