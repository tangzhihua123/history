import React, {Component} from 'react'
import ModalChildren from 'components/modal/modal-children.jsx'
import './changeGender-modal.scss'
import Util from 'utils/util.js'
import Request from 'utils/request-util.js'
import store from 'store'


export default class ChangeGenderModal extends Component {
    constructor(props) {
        super(props)
        this.state = {
            isUsed: false,
            isShow: this.props.isShow,
            data: this.props.data,
            isGender:this.props.isGender,
        }
    }
    componentWillReceiveProps(nextProps) {
        this.setState({
            isShow: nextProps.isShow,
        })
    }
    changeGenderValue(t,value) {
        if(t==2) {
            this.props.cancleChangeGender();
        }else {
            let param = {
                data: {
                    content: value,
                    type: 2

                },
                url: '/user/updateUserInfo',
                // contentType: 'application/json',
                successFn: (res) => {

                    if(res.resultCode === 2000) {
                        // this.enter('修改成功')
                        const user = store.get('user') || {}
                        if(JSON.stringify(user) != "{}") {
                            store.set('user', {
                                loginName: user.loginName,
                                token: user.token,
                                memberCode: user.code,
                                nickName: user.nickName,
                                faceLink: user.faceLink,
                                gender:value,
                                birthday:user.birthday
                            })
                        }
                        this.props.cancleChangeGender(value);
                    }else {
                        // this.enter('修改失败')
                    }
                },
                errorFn: (error) => {
                    console.log('请求失败的错误', error)
                    // this.enter('修改失败')
                }
            }
            Request.fetch(param)
        }
    }
    getGenderList = () => {
        var arr = [
            {   id:0,
                value:'男'
            },
            {
                id:1,
                value:'女'
            },
            {
                id:2,
                value:'取消'
            }
        ];

        if(!Util.isArray(arr)) return


        var list = arr.map( (item, i) => {
            let last = false;
            if(i == (arr.length - 1)) last = true
            // onClick={this.selCat(item.catId, item.title)}
            let map_str = '#map' + i
            let cls = item.value == this.state.isGender ? 'items active' : 'items'
            return (
                //onClick={this.RedirectCate.bind(this, item.catId, item.title)}
                <div key={i} onClick={this.changeGenderValue.bind(this,item.id,item.value)} className={cls}>{item.value}</div>

            )
        })
        return list
    }
    render() {
        return (
            <ModalChildren
                isShow={this.state.isShow}
                clickBgHide={true}
                canScroll={false}
                hideFn={this.props.cancleChangeGender}
            >
                <div className="changeGender-modal">
                        {this.getGenderList()}
                </div>
            </ModalChildren>
        )
    }
}
