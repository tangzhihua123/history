import React, { Component } from 'react'
import PropTypes from 'prop-types'
import { withRouter } from 'react-router-dom'
import { connect } from 'react-redux'
import qs from 'query-string' 
import { fetchOrderUncreate, fetchCreateOrder } from '../../actions/order'
import { fetchShippingAddressList } from '../../actions/address'

import { fetchOrderCreate } from '../../api/order'
import Login from 'utils/login'

import './index.scss'

import WhiteSpace from 'components/white-space'
import Toast from 'components/toast'
import DateTimePicker from 'components/date-time-picker'
import AddressBar from 'ui/address-bar'
import ForecastTime from 'ui/forecast-time'
import OrderOverview from 'ui/order-overview'
import Points from 'ui/points-use'
import OrderFee from 'ui/order-fee'
import OrderBottom from 'ui/order-bottom'

// TODO: 梳理状态数据流

class OrderConfirm extends Component {
  constructor(props) {
    super(props)
    document.title = '确认订单'
    this.state = {
      timeSelected: {},
      modalVisible: false,
      pointInputed: 0,
      memo: '',
      isNoConfirm:false
    }
  }
  componentDidMount() {
    const urlParams = qs.parse(window.location.search)
    const params = {}
    if (urlParams.couponCode) {
      params.couponCode = urlParams.couponCode
    }
    // mock 8432_33237_1
    if (urlParams.tradingItems) {
      params.tradingItems = urlParams.tradingItems
    }
    this.props.fetchOrderUncreate(params)
    // 后端返回的lastshippinginfo 有可能为空， 但是地址列表有数据的情况
    this.props.fetchShippingAddressList()
  }
  getFees(data) {
    const { pmtActivityAmount, pmtCouponAmount, freightFee } = data
    const fees = []
    const pointFee = (this.state.pointInputed * (this.props.data && this.props.data.exchangeRate)).toFixed(2)
    fees.push({
      text: '配送费',
      value: `¥${freightFee || 0}`
    })
    fees.push({
      text: '满减优惠',
      value : `-¥${pmtActivityAmount || 0}`
    })
    fees.push({
      text: '优惠券',
      value: `-¥${pmtCouponAmount || 0}`
    })
    fees.push({
      text: '积分抵扣',
      value: `-¥${pointFee || 0}`
    })
    return fees
  }
  onAddressClick=() => {
    const { data, history, addresslist }  = this.props
    const { lastShipAddrInfo } = data
    if (lastShipAddrInfo) {
      history.push({
        pathname: '/app/address-list',
        search: '?redirect=' + encodeURIComponent(location.pathname + location.search)
      })
    } else {
      if (addresslist.length > 0) {
        history.push({
          pathname: '/app/address-list',
          search: '?redirect=' + encodeURIComponent(location.pathname + location.search)
        })
      } else {
        history.push({
          pathname: '/app/address-edit',
          search: '?type=add&redirect=' + encodeURIComponent(location.pathname + location.search)
        })
      }
    }
  }
  switchModalVisible=() => {
    this.setState({
      modalVisible: !this.state.modalVisible
    })
  }
  onModalCompleteClick= (item)=> {
    this.setState({
      timeSelected: item,
      modalVisible: !this.state.modalVisible
    })
  }
  onPointInputed=(value)=> {
    this.setState({
      pointInputed: value
    })
  }
  // 验证
  submitValidate=() => {
    // 地址不能为空
    let shipAddrId = this.props.data.lastShipAddrInfo && this.props.data.lastShipAddrInfo.shippingId
    if (this.props.addressSelected.shippingId) {
      shipAddrId = this.props.addressSelected.shippingId
    }
    if (!shipAddrId) {
      Toast.show('地址不能为空', 1.5, false)
      return false
    }
    return true
  }
  onOrderSubmit=()=> {
    // 验证
    if (!this.submitValidate()) {
      return
    }
    const { data } = this.props
    const _this = this
    const { arrivalTimes } = data
    const selectedTime = this.state.timeSelected.beginTime? this.state.timeSelected : (arrivalTimes? arrivalTimes[0] : {})
    let shipAddrId = this.props.data.lastShipAddrInfo && this.props.data.lastShipAddrInfo.shippingId
    if (this.props.addressSelected.shippingId) {
      shipAddrId = this.props.addressSelected.shippingId
    }
    if(!shipAddrId) {
      return
    }
    const params = {
      cashScore: parseInt(this.state.pointInputed),
      shipAddrId: shipAddrId,
      arrivalBeginTime: selectedTime.beginTime,
      arrivalEndTime: selectedTime.endTime,
    }
    const urlParams = qs.parse(window.location.search)
    if (urlParams.tradingItems) {
      params.tradingItems = urlParams.tradingItems
    }

    if (urlParams.couponCode) {
      params.couponCode = urlParams.couponCode
    }
    if (this.state.memo) {
      params.memo= this.state.memo
    }
    // mock return orderId: 20171121833510039114
    // 订单已创建不能再刷新当前页面
    fetchOrderCreate(params).then((res)=> {
      if (res.resultCode === 2000) {
        // 跳转支付页面
        _this.props.history.push({
          pathname: '/app/pay',
          search:`?orderid=${res.data.orderId}`
        })
      } else {
        Toast.show(res.resultMsg, 1.5, false)
      }
    })
  }
  onMemoChange=(e)=> {
    this.setState({
      memo: e.currentTarget.value
    })
  }
  render() {
    const { data, tokenValid, history } = this.props
    if (!tokenValid) { // token失效
      Login.gotoLogin()
    }
    
    let {
      items,
      totalPrice,
      totalQuantity, 
      finalAmount,
      freightFee, 
      lastShipAddrInfo, 
      arrivalTimes, 
      isToday,
      totalCashScoreEnabled, // 可兑换积分
      exchangeRate, 
      account,
      submitValidateFlag,
      submitValidateMsg,
      totalGainScore
    } = data
      let shipAddrId = this.props.data.lastShipAddrInfo && this.props.data.lastShipAddrInfo.shippingId
      if (this.props.addressSelected.shippingId) {
          shipAddrId = this.props.addressSelected.shippingId
      }
      if(!shipAddrId) {
           submitValidateFlag = false
      }else {
          submitValidateFlag = true
      }

    const fees = this.getFees(data)
    const pointFee = (this.state.pointInputed * (this.props.data && this.props.data.exchangeRate)).toFixed(2)
    const finalFee = finalAmount - pointFee > 0? (finalAmount - pointFee).toFixed(2) : 0
    const selectedTime = this.state.timeSelected.beginTime? this.state.timeSelected : (arrivalTimes? arrivalTimes[0] : {})
    let newAddress = lastShipAddrInfo
    if (this.props.addressSelected.shippingId) {
      newAddress = this.props.addressSelected
    }
    let formatSelectedTime = ''
    if (selectedTime.beginTime) {
      formatSelectedTime = selectedTime.beginTime.split(" ")[0] + " " + selectedTime.timeFormat
    }
    return (
      <div className="order-confirm">
        <AddressBar 
          address={newAddress}
          onClick={this.onAddressClick} />
        <ForecastTime 
          selectedTime={selectedTime} 
          time={arrivalTimes} 
          isToday={isToday}
          onClick={this.switchModalVisible}
          onCompleteClick={this.onModalCompleteClick}
          modalVisible={this.state.modalVisible}
        />
        <WhiteSpace size=".08rem"/>
        <OrderOverview
          items={items} totalPrice={totalPrice} 
          totalQuantity={totalQuantity}
          onMemoChange={this.onMemoChange}
        />
        <WhiteSpace size=".08rem"/>
        <Points 
          userPoint={account && account.usefulIntegral}
          pointCanUse={totalCashScoreEnabled}
          exchangeRate={exchangeRate}
          onConfirm={this.onPointInputed}
          modalVisible={this.state.modalVisible}
          onClose={this.switchModalVisible}
          pointInputed={this.state.pointInputed}
        />
        <WhiteSpace size=".08rem"/>
        <OrderFee fees={fees}/>
        <OrderBottom
          canSubmit={submitValidateFlag} 
          price={finalFee} 
          freightFee={freightFee}
          onSubmit={this.onOrderSubmit}
          errorMsg={submitValidateMsg}
        />
      </div>
    )
  }
}

const mapStateToProps = state => ({
  data: state.order.data,
  tokenValid: state.i.tokenValid,
  addressSelected: state.address.selected,
  addresslist: state.address.list
})

export default withRouter(connect(mapStateToProps, {
  fetchOrderUncreate,
  fetchCreateOrder,
  fetchShippingAddressList
})(OrderConfirm))