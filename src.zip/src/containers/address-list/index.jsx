import React, { Component } from 'react'
import { connect } from 'react-redux'
import { withRouter } from 'react-router-dom'
import queryString from 'query-string'
import { fetchShippingAddressList, delShippingAddress, selectAddress } from '../../actions/address'
// 简单起见
import './index.scss'
import AddressItem from 'ui/address-item'
import SwipeAction from 'components/swipe-action'

class addressList extends Component {
  componentWillMount() {
    this.props.fetchShippingAddressList()
    // 获取redirect 参数
    this.urlParams = queryString.parse(location.search)
  }
  componentDidMount() {
    document.title = '收货地址列表'
    // const clientHeight = document.documentElement.clientHeight
    // const rootFontSize = document.documentElement.style.fontSize.replace('px', '')
    // this.refs.warpper.style.height = (clientHeight - parseFloat(rootFontSize) * 0.82) + 'px'
  }
  onAddClick= () => {
    const { history } = this.props
    history.push({
      pathname: '/app/address-edit',
      search: '?type=add'
    })
  }
  onEditClick=(item)=> {
    const { history } = this.props
    history.push({
      pathname: '/app/address-edit',
      search: '?type=edit',
      state: item
    })
  }
  onItemClick=(item) => {
    this.props.selectAddress(item)
    const { history } = this.props
    if (this.urlParams.redirect) {
      setTimeout(() => {
        history.push(this.urlParams.redirect)
      }, 100)
    }
  }
  onDelClick=(item) =>{
    this.props.delShippingAddress(item.shippingId)
  }
  renderAddressList= (list) => {
    return list.map((item) => {
      let status = ''
      if (item.selected) {
        status = 'current'
      }
      return (<SwipeAction key={item.shippingId} onPress={()=>{ this.onDelClick(item)}}>
        <AddressItem  
        address={item} status={status} onItemClick={()=> this.onItemClick(item)} onEditClick={() => this.onEditClick(item)}>
      </AddressItem></SwipeAction>)
    })
  }
  render() {
    const { list } = this.props
    return (
      <div className="address-list">
        <div className="address-items-warpper" ref="warpper">
          <div className="address-items">
            {this.renderAddressList(list)}
          </div>
        </div>
        <div className="bottom-btn">
          <div className="add-address-btn" onClick={this.onAddClick}>
            <i className="btn-icon cross"></i>
            <span className="btn-text">添加新地址</span>
          </div>
        </div>
      </div>
    )
  }
}

const mapStateToProps = state => ({
  list: state.address.list,
  tokenValid: state.i.tokenValid
})

export default withRouter(connect(mapStateToProps, {
  fetchShippingAddressList,
  delShippingAddress,
  selectAddress
})(addressList))