import React from 'react'
import PropTypes from 'prop-types'
import { Provider } from 'react-redux'
import { Route } from 'react-router-dom'

import {Load} from 'utils/load-module.js'


const RateList = Load({ loader: () => import('ui/rate-list/index.jsx')})
const OrderRate = Load({loader: () => import('ui/order-rate/index.jsx')})
const Login = Load({loader: () => import('ui/login/login.jsx')})
const ConponList = Load({loader: () => import('ui/coupon-list/list.jsx')})
const CouponSelect = Load({loader: () => import('ui/coupon-list/select-list.jsx')})
const GoodsDetail = Load({loader: () => import('ui/goods-detail/goods-detail.jsx')})
const My = Load({ loader: () => import('./i')})
const MyCart = Load({ loader: () => import('./cart')})
const AboutApp = Load({ loader: () => import('./aboutApp')})
const AddressEdit = Load({ loader: () => import('./address-edit')})
const AddressList = Load({ loader: () => import('./address-list')})
const ApplyAftersales = Load({ loader: () => import('./apply-aftersales')})
const ApplyAftersalesDetail = Load({ loader: () => import('./apply-aftersales-detail')})
const Order = Load({ loader: () => import('./order')})
const OrderConfirm = Load({ loader: () => import('./order-confirm')})
const OrderDetail = Load({ loader: () => import('./order-detail')})
const PostFree = Load({ loader: () => import('./postfree')}) 
const Setting = Load({ loader: () => import('./setting')})
const PersonSeting = Load({ loader: () => import('./personSeting')})
const ChangeNickName = Load({ loader: () => import('./changeNickName')})
const ChangeMobilePhone = Load({ loader: () => import('./changeMobilePhone')})
const ChangeMobileDetail = Load({ loader: () => import('./changeMobileDetail')})

const Pay = Load({ loader: () => import('./pay')})

/* import OrderRate from 'ui/order-rate/index.jsx'
import RateList from 'ui/rate-list/index.jsx'
import Login from 'ui/login/login.jsx'
import ConponList from 'ui/coupon-list/list.jsx'
import CouponSelect from 'ui/coupon-list/select-list.jsx'
import GoodsDetail from 'ui/goods-detail/goods-detail.jsx'
import My  from './i'
import MyCart  from './cart'
import AboutApp from './aboutApp'
import AddressEdit  from './address-edit'
import AddressList  from './address-list'
import ApplyAftersales  from './apply-aftersales'
import Order  from './order'
import OrderConfirm  from './order-confirm'
import OrderDetail  from './order-detail'
import PostFree  from './postfree'
import Setting from './setting'
import PersonSeting from './personSeting'
import ChangeNickName from './changeNickName'
import ChangeMobilePhone from './changeMobilePhone'
import ChangeMobileDetail from './changeMobileDetail' */



const Root = ({ store }) => (
  <Provider store={store}>
    <div>
      <Route exact path="/" component={GoodsDetail}/>
      <Route exact path="/app" component={My}/>
      <Route path="/app/mycart" component={MyCart}/>
      <Route path="/app/i" component={My}/>
      <Route path="/app/login" component={Login}/>
      <Route path="/app/ratelist" component={RateList}/>
      <Route path="/app/couponselect" component={CouponSelect}/>
      <Route path="/app/couponlist" component={ConponList}/>
      <Route path="/app/goodsdetail" component={GoodsDetail}/>
      <Route path="/app/address-edit" component={AddressEdit}/>
      <Route path="/app/address-list" component={AddressList}/>
      <Route path="/app/apply-aftersales" component={ApplyAftersales}/>
      <Route path="/app/apply-aftersales-detail" component={ApplyAftersalesDetail}/>
      <Route path="/app/order" component={Order}/>
      <Route path="/app/orderrate" component={OrderRate}/>
      <Route path="/app/order-confirm" component={OrderConfirm}/>
      <Route path="/app/order-detail" component={OrderDetail}/>
      <Route path="/app/post-free" component={PostFree}/>
      <Route path="/app/addon" component={PostFree}/>
      <Route path="/app/setting" component={Setting}/>
      <Route path="/app/personSeting" component={PersonSeting}/>
      <Route path="/app/changeNickName" component={ChangeNickName}/>
      <Route path="/app/changeMobilePhone" component={ChangeMobilePhone}/>
      <Route path="/app/changeMobileDetail" component={ChangeMobileDetail}/>
      <Route path="/app/aboutApp" component={AboutApp}/>
      <Route path="/app/pay" component={Pay}/>
    </div>
  </Provider>
)

Root.propTypes = {
  store: PropTypes.object.isRequired,
}
export default Root