import React, { Component } from 'react'
import ReactDOM from 'react-dom'
import  {
  BrowserRouter,
  Route
} from 'react-router-dom'

import 'style/base.scss'
import 'style/common.scss'
import './index.scss'
import InviteUI from 'ui/intro'


class Invite extends Component {
    render() {
        return (
            <div className="m-invite">
                <InviteUI></InviteUI>
            </div>
        )
    }
}


function doRender() {
    ReactDOM.render((
    <BrowserRouter>
        <Route path="/" component={Invite}></Route>
    </BrowserRouter>), document.getElementById("app"))
}

setTimeout(doRender, 16)