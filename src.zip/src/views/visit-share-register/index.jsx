import React, { Component } from 'react'
import ReactDOM from 'react-dom'
import  {
  BrowserRouter,
  Route
} from 'react-router-dom'

import 'style/base.scss'
import 'style/common.scss'
import './index.scss'
import VisitShareRegisterUI from 'ui/visit-share-register'
//visit-share-register

class VisitShareRegister extends Component {
    render() {
        return (
            <div className="m-invite">
                <VisitShareRegisterUI></VisitShareRegisterUI>
            </div>
        )
    }
}


function doRender() {
    ReactDOM.render((
    <BrowserRouter>
        <Route path="/" component={VisitShareRegister}></Route>
    </BrowserRouter>), document.getElementById("app"))
}

setTimeout(doRender, 10)