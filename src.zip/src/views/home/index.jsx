import React, { Component } from 'react'
import ReactDOM from 'react-dom'
import  {
    BrowserRouter,
    Route,
    Link
} from 'react-router-dom'

import 'style/base.scss'
import 'style/common.scss'
import './index.scss'

import eruda from 'eruda'

import MainFloor from 'ui/main-floor'
import RateList from 'ui/rate-list/index.jsx'

class ActivityList extends Component {
    constructor(props) {
        super(props)

        this.state = {
            id: 1 // 活动id
        }

    }
    componentDidMount() {
        eruda.init()
    }
    render() {
        return (
            <div className="home-list">
                <MainFloor></MainFloor>
            </div>
        )
    }
}


function doRender() {
    ReactDOM.render((
    <BrowserRouter 
        basename="/home"
        forceRefresh={false}
        keyLength={12}
    >
        <div>
            <Route exact path="/" component={ActivityList}></Route>
            <Route exact path="/ratelist" component={RateList}/>
        </div>
    </BrowserRouter>), document.getElementById("app"))
}


setTimeout(doRender, 10)