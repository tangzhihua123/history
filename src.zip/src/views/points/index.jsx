import React, { Component } from 'react'
import ReactDOM from 'react-dom'
import  {
  BrowserRouter,
  Route
} from 'react-router-dom'
import {Load} from 'utils/load-module.js'


const PointsAward = Load({ loader: () => import('ui/points-award/index.jsx')})
const PointsEarn = Load({ loader: () => import('ui/points-earn/index.jsx')})
const PointsCost = Load({ loader: () => import('ui/points-cost/index.jsx')})
const PointsDetails = Load({ loader: () => import('ui/points-details-list/index.jsx')})
import 'style/base.scss'
import 'style/common.scss'

import './index.scss'

import PointsIndex from 'ui/points-index/index.jsx'
// import PointsDetails from 'ui/points-details-list/index.jsx'
// import PointsEarn from 'ui/points-earn/index.jsx'
// import PointsCost from 'ui/points-cost/index.jsx'
// import PointsAward from 'ui/points-award/index.jsx'
import PointsDes from 'ui/points-text/points-des.jsx'
import AwardDes from 'ui/points-text/award-des.jsx'

class App extends Component {
    render() {
        return (
            <div>
                <PointsIndex />
            </div>
        )
    }
}

function doRender() {
    ReactDOM.render((
    <BrowserRouter>
    <div>
        <Route path="/points/" exact component={App}></Route>
        <Route path="/points/details" exact component={PointsDetails}></Route>
        <Route path="/points/earn" exact component={PointsEarn}></Route>
        <Route path="/points/cost" exact component={PointsCost}></Route>
        <Route path="/points/getaward" exact component={PointsAward}></Route>
        <Route path="/points/pointsdes" exact component={PointsDes}></Route>
        <Route path="/points/awarddes" exact component={AwardDes}></Route>

    </div>
        
    </BrowserRouter>), document.getElementById("app"))
}

setTimeout(doRender, 16)