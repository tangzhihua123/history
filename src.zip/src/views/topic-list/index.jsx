import React, { Component } from 'react'
import ReactDOM from 'react-dom'
import  {
  BrowserRouter,
  Route
} from 'react-router-dom'

import 'style/base.scss'
import 'style/common.scss'
import './index.scss'

import TopicListUI from 'ui/topic-list'


class TopicList extends Component {
    render() {
        return (
            <div className="topic-list">
                <TopicListUI></TopicListUI>
            </div>
        )
    }
}


function doRender() {
    ReactDOM.render((
    <BrowserRouter>
        <Route path="/" component={TopicList}></Route>
    </BrowserRouter>), document.getElementById("app"))
}

setTimeout(doRender, 10)