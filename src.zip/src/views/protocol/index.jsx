import React, { Component } from 'react'
import ReactDOM from 'react-dom'
import  {
  BrowserRouter,
  Route
} from 'react-router-dom'

import 'style/base.scss'
import 'style/common.scss'
import './index.scss'
import ProtocolUI from 'ui/protocol'


class Protocol extends Component {
    render() {
        return (
            <div className="m-invite">
                <ProtocolUI></ProtocolUI>
            </div>
        )
    }
}


function doRender() {
    ReactDOM.render((
    <BrowserRouter>
        <Route path="/" component={Protocol}></Route>
    </BrowserRouter>), document.getElementById("app"))
}

setTimeout(doRender, 10)