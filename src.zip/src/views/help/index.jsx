import React, { Component } from 'react'
import ReactDOM from 'react-dom'
import  {
  BrowserRouter,
  Route
} from 'react-router-dom'

import 'style/base.scss'
import 'style/common.scss'
import './index.scss'
import HelpUI from 'ui/help'


class Help extends Component {
    render() {
        return (
            <div className="m-invite">
                <HelpUI></HelpUI>
            </div>
        )
    }
}


function doRender() {
    ReactDOM.render((
    <BrowserRouter>
        <Route path="/" component={Help}></Route>
    </BrowserRouter>), document.getElementById("app"))
}

setTimeout(doRender, 10)