import React, { Component } from 'react'
import ReactDOM from 'react-dom'

import  {
  BrowserRouter,
  Route
} from 'react-router-dom'

import 'style/base.scss'
import 'style/common.scss'
import './index.scss'

import CategoryUI from 'ui/cate'
import ProductListUI from 'ui/product-list'



class Category extends Component {
    constructor(props) {
        super(props)
    }
    render() {
        return (
            <div className="activity-list">
                <CategoryUI></CategoryUI>
            </div>
        )
    }
}


function doRender() {
    ReactDOM.render((
    <BrowserRouter>
            <Route path="/" component={Category}></Route>
    </BrowserRouter>), document.getElementById("app"))
}

setTimeout(doRender, 10)