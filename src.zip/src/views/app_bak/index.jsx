import React, { Component } from 'react'
import ReactDOM from 'react-dom'
import {
    BrowserRouter,
    Redirect,
    Route
} from 'react-router-dom'
import URLUtil from 'utils/url-util'
import RateList from 'ui/rate-list/index.jsx'
import Login from 'ui/login/login.jsx'
import ConponList from 'ui/coupon-list/list.jsx'
import CouponSelect from 'ui/coupon-list/select-list.jsx'

import 'style/base.scss'
import 'style/common.scss'

import './index.scss'

import GoodsDetail from 'ui/goods-detail/goods-detail.jsx'
import MyCart from 'ui/my-cart'

class App extends Component {
    render() {
        return (
            <GoodsDetail goodsId={URLUtil.fetchValueByURL('id')}></GoodsDetail>
        )
    }
}

const fakeAuth = {
    isAuthenticated: false,
    authenticate(cb) {
        console.log('登陆')
        this.isAuthenticated = true
        console.log('登陆状态', this.isAuthenticated)
        // console.log('cb', cb)
        cb && cb() // fake async
    },
    signout(cb) {
        this.isAuthenticated = false
        // setTimeout(cb, 100)
    }
}
 
const AppRoute = ({ component: Component, ...rest }) => (
    <Route {...rest} render={props => {
        // console.log('fakeAuth.isAuthenticated', fakeAuth.isAuthenticated)
        // console.log('props', props)
        props.location.state = props.location.state || {}
        return (
            /**props.location.state.login */ props ? (
                <Component {...props} />
            ) : (
                    <Redirect to={{
                        pathname: '/app/login',
                        state: { from: props.location }
                    }} />
                )
        )    
    }} />
)

const LoginRoute = ({ component: Component, loginCb, ...rest }) => (
    <Route {...rest} render={props => (
        (
            <Component {...props} loginCb={loginCb}/>
        )
    )} />
)
function doRender() {
    ReactDOM.render((
        <BrowserRouter>
            <div>
                <AppRoute path="/app/" exact component={App}></AppRoute>
                <Route path="/app/couponlist" exact component={ConponList}></Route>
                
                <LoginRoute path="/app/login" exact component={Login} loginCb={fakeAuth.authenticate.bind(this)}></LoginRoute>
                <Route path="/app/home" exact component={App}></Route>
                <Route path="/app/ratelist" component={RateList} />
                <Route path="/app/mycart" exact component={MyCart}></Route>
                <Route path="/app/couponselect" exact component={CouponSelect}></Route> 
            </div>

        </BrowserRouter>), document.getElementById("app"))
}

setTimeout(doRender, 16)