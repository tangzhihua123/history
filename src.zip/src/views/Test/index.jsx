import React, {Component} from 'react'
import PropTypes from 'prop-types'
import ReactDOM from 'react-dom'
import {
  BrowserRouter,
  Route,
  Link
} from 'react-router-dom'
// import eruda from 'eruda'
import URLUtil from 'utils/url-util.js'
import Pull from 'utils/pull.js'
// import PullToRefresh from 'utils/pull-refresh.js'
import Load from 'utils/load.js'

import 'style/base.scss'
import 'style/common.scss'
import './index.scss'

import Slider from 'components/Slide'
import SliderItem from 'components/Slide/SliderItem'

import TopBar from 'components/top-bar'


function onAction(index, direction) {
    console.log('激活的幻灯片编号：', index, '，滚动方向：', direction);
}


const sliderIntance = (
    <div>
        <Slider onAction={onAction} autoPlay={false}>
              <SliderItem>
                  <img src="http://s.amazeui.org/media/i/demos/bing-1.jpg" />
              </SliderItem>
               <SliderItem>
                  <img src="http://s.amazeui.org/media/i/demos/bing-2.jpg" />
              </SliderItem>
              <SliderItem>
                  <img src="http://s.amazeui.org/media/i/demos/bing-3.jpg" />
              </SliderItem>
               <SliderItem>
                  <img src="http://s.amazeui.org/media/i/demos/bing-4.jpg" />
              </SliderItem>
        </Slider>
        
    </div>
 
);



class App extends Component {
    componentDidMount() {
        // eruda.init()
        var pull = new Pull({el: 'body', load: this.handleRefresh})
        Load.bottomLoad(function() {
            console.log(123)
        })
        // PullToRefresh.init({load: this.handleRefresh})
    }
    handleRefresh = () => {
        return new Promise(function(resolve, reject) {
            setTimeout(resolve, 2000, 'I\'m OK' )
        })
    }
    render() {
        return (
            <div>
                <h1>App</h1>
                {/* <div id="ptr">
                    <span className="genericon genericon-next">I am arrow</span>
                    <div className="loading">
                        <span id="l1">loading</span>
                        <span id="l2">load</span>
                        <span id="l3">l</span>
                    </div>
                </div>
                <div id="content">
                    <div style={{width: '50px', height: '50px',backgroundColor:'#ccc'}}>content</div>
                </div> */}
                <ul>
                    <li><Link to="/about">About</Link></li>
                    <li><Link to="/inbox">Inbox</Link></li>
                    <TopBar/>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                    <div>123</div>
                </ul>
                {sliderIntance}
            </div>
        )
    }
}
class App1 extends Component {
    render() {
        return (
            <div>哈哈哈哈哈</div>
        )
    }
}

function doRender() {
    ReactDOM.render((
        <BrowserRouter>
            <div>
                <Route path="/test/" exact component={App}></Route>
                <Route path="/test/about" component={App1}></Route>
            </div>
        </BrowserRouter>), document.getElementById("app"));
}

setTimeout(doRender, 16);