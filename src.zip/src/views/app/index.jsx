import React from 'react'
import { render } from 'react-dom'
import { BrowserRouter as Router } from 'react-router-dom'
import Root from '../../containers/Root'
import configureStore from '../../store/configureStore'
import rootSagas from '../../sagas'

import 'style/base.scss'
import 'style/common.scss'

// 可设置初始状态，这里传{}
const store = configureStore({})

// 非官方文档的run 方法，而是configureStore 中定义的runSaga
store.runSaga(rootSagas)

render(
  <Router>
    <Root store={store}/>
  </Router>,
  document.getElementById('app')
)
