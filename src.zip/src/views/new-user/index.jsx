import React, { Component } from 'react'
import ReactDOM from 'react-dom'
import  {
  BrowserRouter,
  Route
} from 'react-router-dom'

import 'style/base.scss'
import 'style/common.scss'
import './index.scss'

import NewUserUI from 'ui/new-user'


class NewUser extends Component {
    constructor(props) {
        super(props)
    }
    render() {
        return (
            <div className="activity-list">
                <NewUserUI></NewUserUI>
            </div>
        )
    }
}


function doRender() {
    ReactDOM.render((
    <BrowserRouter>
        <Route path="/" component={NewUser}></Route>
    </BrowserRouter>), document.getElementById("app"))
}

setTimeout(doRender, 10)