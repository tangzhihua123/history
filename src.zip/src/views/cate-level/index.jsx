import React, { Component } from 'react'
import ReactDOM from 'react-dom'
import  {
  BrowserRouter,
  Route
} from 'react-router-dom'
import URLUtil from 'utils/url-util'

import 'style/base.scss'
import 'style/common.scss'
import './index.scss'

import ProductListUI from 'ui/product-list'


class ProductList extends Component {
    constructor(props) {
        super(props)

        this.state = {
            id: URLUtil.fetchValueByURL('catId') // 常规活动id
        }
    }
    render() {
        return (
            <div className="product-list">
                <ProductListUI id={this.state.id} ></ProductListUI>
            </div>
        )
    }
}


function doRender() {
    ReactDOM.render((
    <BrowserRouter>
        <Route path="/" component={ProductList}></Route>
    </BrowserRouter>), document.getElementById("app"))
}

setTimeout(doRender, 10)