import React, { Component } from 'react'
import ReactDOM from 'react-dom'
import  {
  BrowserRouter,
  Route
} from 'react-router-dom'

import 'style/base.scss'
import 'style/common.scss'
import './index.scss'

import ActivityListUI from 'ui/act-list'


class ActivityList extends Component {
    constructor(props) {
        super(props)

        this.state = {
            id: 1 // 常规活动id
        }
    }
    render() {
        return (
            <div className="activity-list">
                <ActivityListUI id={this.state.id}></ActivityListUI>
            </div>
        )
    }
}


function doRender() {
    ReactDOM.render((
    <BrowserRouter>
        <Route path="/" component={ActivityList}></Route>
    </BrowserRouter>), document.getElementById("app"))
}

setTimeout(doRender, 10)