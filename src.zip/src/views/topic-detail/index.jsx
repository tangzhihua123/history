import React, { Component } from 'react'
import ReactDOM from 'react-dom'
import  {
  BrowserRouter,
  Route
} from 'react-router-dom'

import 'style/base.scss'
import 'style/common.scss'
import './index.scss'

import TopicDetailWrap from 'ui/topic-detail'

class TopicDetail extends Component {
    render() {
        return (
            <div className="topic-detail">
                <TopicDetailWrap> </TopicDetailWrap>
            </div>
        )
    }
}


function doRender() {
    ReactDOM.render((
    <BrowserRouter>
        <Route path="/" component={TopicDetail}></Route>
    </BrowserRouter>), document.getElementById("app"))
}

setTimeout(doRender, 16)