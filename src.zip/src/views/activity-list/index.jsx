import React, { Component } from 'react'
import ReactDOM from 'react-dom'
import qs from 'query-string'
import  {
  BrowserRouter,
  Route
} from 'react-router-dom'

import RequestUtil from 'utils/request-util'
import 'style/base.scss'
import 'style/common.scss'
import './index.scss'

import ActivityListUI from 'ui/activity-list'
import SpecialList from 'ui/special-list'
import CartAndMenu from 'ui/cart-menu'

class ActivityList extends Component {
    constructor(props) {
        super(props)

        this.state = {
            id: qs.parse(location.search).pmtId || 1, // 活动id
            cartNum: 0,
            noLogin: false,
        }
    }

    componentDidMount() {
        this.fetchCartNum()
    }

     /**
     * [获取购物车数量]
     * @return {[type]} [description]
     */
    fetchCartNum = () => {
        RequestUtil.fetchCartNum({
            noLogin: (num) => {
                this.setState({
                    noLogin: true,
                    cartNum: num
                })
            },
            Login: (num) => {
                this.setState({
                    cartNum: num
                })
            },
            ErrorFun: (msg) => {
                this.enter(msg)
            }
        })
    }
    
    UpdataCartNum(addCartNum) {
        this.setState({
            cartNum:  this.state.cartNum + addCartNum
        })
    }
    
    
    
    render() {
        return (
            <div className="activity-list">
                <SpecialList id={this.state.id} UpdateCartNumHandle={this.UpdataCartNum.bind(this)} noLogin={this.state.noLogin}></SpecialList>
                {/*<ActivityListUI id={this.state.id} UpdateCartNumHandle={this.UpdataCartNum.bind(this)} noLogin={this.state.noLogin}></ActivityListUI>*/}
                <CartAndMenu cartNum={this.state.cartNum}></CartAndMenu>

            </div>
        )
    }
}


function doRender() {
    ReactDOM.render((
    <BrowserRouter>
        <Route path="/" component={ActivityList}></Route>
    </BrowserRouter>), document.getElementById("app"))
}

setTimeout(doRender, 10)