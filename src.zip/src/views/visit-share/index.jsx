import React, { Component } from 'react'
import ReactDOM from 'react-dom'
import  {
  BrowserRouter,
  Route
} from 'react-router-dom'

import 'style/base.scss'
import 'style/common.scss'
import './index.scss'
import VisitShareUI from 'ui/visit-share'


class VisitShare extends Component {
    render() {
        return (
            <div className="m-invite">
                <VisitShareUI></VisitShareUI>
            </div>
        )
    }
}


function doRender() {
    ReactDOM.render((
    <BrowserRouter>
        <Route path="/" component={VisitShare}></Route>
    </BrowserRouter>), document.getElementById("app"))
}

setTimeout(doRender, 10)