import config from './config';
import Vue from 'vue';
import { Message } from 'element-ui';

var countryCode;
var vhttp = {
  get: function(url, params, successCallback, errorCallback) {
    Vue.http.get(config.api + url, { params: params, headers: { countrycode: countryCode } })
      .then(function (res) {
        return res.json();
      })
      .then(function (res) {
        if (res.code == 0) {
          successCallback(res);
        } else {
          Message.warning(res.msg);
        }
      }, function (err) {
        Message.error('发生错误,请检查网络设置或联系技术人员');
        if (errorCallback && errorCallback instanceof Function) {
          errorCallback(err);
        }
      })
  },
  postbody: function (url, params, successCallback, errorCallback) {
    Vue.http.post(config.api + url, params, {
        emulateJSON: true,
        headers: { countrycode: countryCode }
      })
      .then(function (res) {
        return res.json();
      })
      .then(function (res) {
        if (res.code == 0) {
          successCallback(res);
        } else {
          Message.warning(res.msg);
        }
      }, function (err) {
        Message.error('发生错误,请检查网络设置或联系技术人员');
        if (errorCallback && errorCallback instanceof Function) {
          errorCallback(err);
        }
      })
  },
  post: function (url, params, successCallback, errorCallback) {
    Vue.http.post(config.api + url, params, {
        emulateJSON: true,
        headers: { countrycode: countryCode }
      })
      .then(function (res) {
        return res.json();
      })
      .then(function (res) {
        if (res.code == 0) {
          successCallback(res);
        } else {
          Message.warning(res.msg);
        }
      }, function (err) {
        Message.error('发生错误,请检查网络设置或联系技术人员');
        if (errorCallback && errorCallback instanceof Function) {
          errorCallback(err);
        }
      })
  },
  put: function (url, params, successCallback, errorCallback) {
    Vue.http.post(config.api + url, Object.assign(params, { _method: 'put' }), {
        emulateJSON: true,
        headers: { countrycode: countryCode }
      })
      .then(function (res) {
        return res.json();
      })
      .then(function (res) {
        if (res.code == 0) {
          successCallback(res);
        } else {
          Message.warning(res.msg);
        }
      }, function (err) {
        Message.error('发生错误,请检查网络设置或联系技术人员');
        if (errorCallback && errorCallback instanceof Function) {
          errorCallback(err);
        }
      })
  },
  delete: function (url, params, successCallback, errorCallback) {
    Vue.http.post(config.api + url, Object.assign(params, { _method: 'delete' }), {
        emulateJSON: true,
        headers: { countrycode: countryCode }
      })
      .then(function (res) {
        return res.json();
      })
      .then(function (res) {
        if (res.code == 0) {
          successCallback(res);
        } else {
          Message.warning(res.msg);
        }
      }, function (err) {
        Message.error('发生错误,请检查网络设置或联系技术人员');
        if (errorCallback && errorCallback instanceof Function) {
          errorCallback(err);
        }
      })
  },
  setCountryCode: function (code) {
    this.setCookie('countrycode', code);
  },
  getCountryCode: function () {
    return countryCode;
  },
  setCookie: function (k, v) {
    var Days = 30;
    var exp = new Date();
    exp.setTime(exp.getTime() + Days * 24 * 60 * 60 * 1000);
    document.cookie = k + "=" + v + ";expires=" + exp.toGMTString();
  },
  getCookie: function (k, v) {
    var arr, reg = new RegExp("(^| )" + k + "=([^;]*)(;|$)");
    if (arr = document.cookie.match(reg))
      return arr[2];
    else
      return v;
  },
  copy: function (obj) {
    var no;
    if (obj instanceof Array) {
      no = new Array(obj.length);
      for (var index = 0; index < obj.length; index++) {
        if (typeof obj[index] === 'object') {
          no[index] = this.copy(obj[index]);
        } else {
          no[index] = obj[index];
        }
      }
    } else if (typeof obj === 'object') {
      no = {};
      for (var key in obj) {
        if (typeof obj[key] === 'object') {
          no[key] = this.copy(obj[key]);
        } else {
          no[key] = obj[key];
        }
      }
    }
    return no;
  }
}
countryCode = vhttp.getCookie('countrycode', '1');
export default vhttp;
