<template>
    <el-col :span="24">
        <el-menu default-active="1" class="m-menu" theme="dark" @open="handleOpen">
            <template v-for="(m,index) in menu">
                <el-submenu :index="''+index" v-if="m.hasSubmenu">
                    <template slot="title"><i class="u-menu-icon" :class="['u-menu-icon-'+(index+1)]"></i>{{m.title}}</template>
                    <el-menu-item class="item" :index="index+'-'+i" v-for="(n,i) in m.children" :key="i" v-on:click="handleOpen(n)">{{n.title}}</el-menu-item>
                </el-submenu>
                <el-menu-item class="subitem" :index="''+index" v-if="!m.hasSubmenu" v-on:click="handleOpen(m)"><i class="u-menu-icon" :class="['u-menu-icon-'+(index+1)]"></i>{{m.title}}</el-menu-item>
            </template>
        </el-menu>
    </el-col>
</template>
<script>
export default {
    name: 'leftMenu',
    data: function() {
        return {
            curRouter: '',
            menuHeight: 300,
            curMenu: 'search'
        }
    },
    props: {
        menu: {
            type: Array,
            require:true
        },
    },
    updated: function() {
        this.calculateMenuHeight(); 
    },
    methods: {
        handleOpen:function(item) {
            this.$router.push({
                name: item.goto
            });
        },
        calculateMenuHeight:function() {
            var window_ht = window.innerHeight || 600,
                body_ht = document.body.clientHeight || 600;
            this.menuHeight = Math.max(window_ht, body_ht) - 63;
        }
    }
}
</script>
