<template>

</template>


<script>

import ueditor from ueditor;
	
export default {

	data:function(){},
	mounted:function(){
		
	}

}




</script>