import Vue from 'vue'
import Router from 'vue-router'
import LeftMenu from '@/components/LeftMenu'
import Index from '@/page/Index'
import AdminList from '@/page/AdminList'
import SystemroleManagement from '@/page/Administrator/SystemroleManagement'
import RoleManagement from '@/page/Administrator/RoleManagement'
import UserList from '@/page/user/UserList'
import Feedback from '@/page/user/Feedback'
import ProgramManagement from '@/page/content/ProgramManagement'
import CommentsManagement from '@/page/content/CommentsManagement'
import ArticleManagement from '@/page/content/ArticleManagement'
import TopManagement from '@/page/content/TopManagement'
import ServiceManagement from '@/page/apprun/ServiceManagement'
import BannerManagement from '@/page/apprun/BannerManagement'
import StartManagement from '@/page/apprun/StartManagement'
import MsgManager from '@/page/apprun/MsgManager'
import PromotionStat from '@/page/apppromotion/PromotionStat'
import PromotionSet from '@/page/apppromotion/PromotionSet'
import PromotionDetail from '@/page/apppromotion/PromotionDetail'
import ActivityManagement from '@/page/activitymanagement/ActivityManagement'
import ArticleStat from '@/page/datastat/ArticleStat'
import LanmuManage from '@/page/datastat/LanmuManage'
import VersionManagement from '@/page/versionmanagement/VersionManagement'

Vue.use(Router)

export default new Router({
  routes: [{
    path: '/',
    redirect: '/index',
    name: 'Main'
  }, {
    path: '/index',
    name: 'Index',
    component: Index,
    redirect:'/index/adminList',
    children: [{
      path: 'adminList',
      name: 'AdminList',
      component: AdminList
    },{
      path: 'systemrolemanagement',
      name: 'SystemroleManagement',
      component: SystemroleManagement
    },{
      path: 'rolemanagement',
      name: 'RoleManagement',
      component: RoleManagement
    },{
      path: 'userlist',
      name: 'UserList',
      component: UserList
    },{
      path: 'feedback',
      name: 'Feedback',
      component: Feedback
    },{
      path: 'programmanagement',
      name: 'ProgramManagement',
      component: ProgramManagement
    },{
      path: 'commentsmanagement',
      name: 'CommentsManagement',
      component: CommentsManagement
    },{
      path: 'articlemanagement',
      name: 'ArticleManagement',
      component: ArticleManagement
    },{
      path: 'topmanagement',
      name: 'TopManagement',
      component: TopManagement
    },{
      path: 'servicemanagement',
      name: 'ServiceManagement',
      component: ServiceManagement
    },{
      path: 'bannermanagement',
      name: 'BannerManagement',
      component: BannerManagement
    },{
      path: 'startmanagement',
      name: 'StartManagement',
      component: StartManagement
    },{
      path: 'msgmanager',
      name: 'MsgManager',
      component: MsgManager
    },{
      path: 'promotionstat',
      name: 'PromotionStat',
      component: PromotionStat
    },{
      path: 'promotionset',
      name: 'PromotionSet',
      component: PromotionSet
    },{
      path: 'promotiondetail',
      name: 'PromotionDetail',
      component: PromotionDetail
    },{
      path: 'activitymanagement',
      name: 'ActivityManagement',
      component: ActivityManagement
    },{
      path: 'articlestat',
      name: 'ArticleStat',
      component: ArticleStat
    },{
      path: 'lanmumanage',
      name: 'LanmuManage',
      component: LanmuManage
    },{
      path: 'versionmanagement',
      name: 'VersionManagement',
      component: VersionManagement
    }]
  }]
}) 