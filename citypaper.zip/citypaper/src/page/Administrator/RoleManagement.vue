<!-- 系统角色管理组件 -->
<template>
    <el-row>
        <h4 class="moduleTitle">角色管理</h4>
        <div class="g-main">
            <div class="fixleft">
                <el-input placeholder="输入角色名称以搜索" icon="search" v-model="roleName">
                </el-input>
                <div class="mt">
                    <el-card class="tablelike-card">
                        <div slot="header" class="cardheader clearfix">
                            <span>选择角色</span>
                            <el-button class="pull-right" type="primary" icon="plus" @click="toAddRole"
                            v-if="checkAuth(authKeyMap.addcommonrole)"> </el-button>
                        </div>
                        <div v-for="role in filteredRoleList" :key="role.id" class="item" :class="{'active':currentRole.id==role.id}" @click="handleRoleChange(role)">
                            {{role.roleName}}
                            <el-button class="pull-right" type="text" icon="close" @click="deleteRole(role.id)" v-if="checkAuth(authKeyMap.deletecommonrole)"> </el-button>
                        </div>
                    </el-card>
                </div>
            </div>
            <div class="content">
                <div>
                    <el-button-group class="btn-group">
                        <el-button type="default" :class="{ active: activeName=='roleSubmit' }" size="small" @click="switchActivePanel('roleSubmit')" v-if="checkAuth(authKeyMap.editcommonrole)">角色编辑</el-button>
                        <el-button type="default" :class="{ active: activeName=='auths' }" size="small" @click="switchActivePanel('auths')"  v-if="checkAuth(authKeyMap.authedit)">权限分配</el-button>
                        <el-button type="default" :class="{ active: activeName=='useroper' }" size="small" @click="switchActivePanel('useroper')" v-if="checkAuth(authKeyMap.user)">用户管理</el-button>
                    </el-button-group>
                    <el-button-group class="btn-group">
                        <el-button type="default" v-show="activeName=='useroper'" :class="{ active: activeName=='useroper' }" size="small" @click="toAddUser" v-if="checkAuth(authKeyMap.adduser)">新增用户</el-button>
                    </el-button-group>
                </div>
                <div class="mt">
                    <el-card class="tablelike-card " v-show="activeName=='roleSubmit' || activeName=='createRole'">
                        <div slot="header" class="cardheader clearfix">
                            <span>{{titleName}}角色</span>
                            <el-button class="pull-right" type="primary" @click="saveRole">保存</el-button>
                        </div>
                        <el-form :model="newrole" ref="roeForm" :rules="rules">
                            <el-form-item label="角色名称" :label-width="formLabelWidth" prop="roleName">
                                <el-input placeholder="请输入角色名称" v-model="newrole.roleName"></el-input>
                            </el-form-item>
                            <el-form-item label="角色描述" :label-width="formLabelWidth" prop="desp">
                                <el-input type="textarea" placeholder="请输入角色描述" v-model="newrole.desp" :autosize="{ minRows: 8, maxRows: 10}"></el-input>
                            </el-form-item>
                        </el-form>
                    </el-card>
                    <el-card class="tablelike-card " v-show="activeName=='auths'">
                        <div slot="header" class="cardheader clearfix">
                            <span>权限分配</span>
                            <el-button class="pull-right" type="primary" @click="saveAuth">保存权限</el-button>
                        </div>
                        <el-tree :data="authList" show-checkbox node-key="authkey" ref="authTree" highlight-current :props="defaultProps">
                        </el-tree>
                    </el-card>
                    <div v-show="activeName=='useroper'">
                        <el-table :data="userList">
                            <el-table-column prop="roleName" label="选择" width="60" v-if="checkAuth(authKeyMap.deleteuser)">
                                <template scope="scope">
                                    <el-checkbox v-model="userList[scope.$index].checked" v-on:change="switchCheck"></el-checkbox>
                                </template>
                            </el-table-column>
                            <el-table-column label="序号">
                                <template scope="scope">
                                    {{scope.$index | fixno(pageParams.pageNo,pageParams.pageSize)}}
                                </template>
                            </el-table-column>
                            <el-table-column prop="nickName" label="用户名">
                            </el-table-column>
                            <el-table-column prop="trueName" label="真实姓名">
                            </el-table-column>
                            <el-table-column label="操作" v-if="checkAuth(authKeyMap.deleteuser)">
                                <template scope="scope">
                                    <el-button type="text" size="mini" v-on:click="deleteUser(scope.row.id)">删除
                                    </el-button>
                                </template>
                            </el-table-column>
                            <tr class="el-table__row" slot="append" v-show="userList.length" v-if="checkAuth(authKeyMap.deleteuser)">
                                <td class="el-table_1_column_1">
                                    <div class="cell">
                                        <span class="Selectall">全选</span>
                                        <el-checkbox v-model="checkAll" @change="switchAllcheck" :indeterminate="isIndeterminate"></el-checkbox>
                                    </div>
                                </td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td class="el-table_1_column_1">
                                    <div class="cell">
                                        <el-button type="text" @click="alldelete" class="via">删除</el-button>
                                    </div>
                                </td>
                            </tr>
                        </el-table>
                        <el-col :span="24" class="u-padding-vertical-sm u-text-right">
                            <el-pagination @size-change="handleSizeChange" @current-change="handlePageChange" :current-page="pageParams.pageNo" :page-sizes="[10, 20, 50, 100]" :page-size="pageParams.pageSize" layout="total, sizes, prev, pager, next, jumper" :total="pageParams.total">
                            </el-pagination>
                        </el-col>
                    </div>
                </div>
            </div>
        </div>
        <el-dialog title="添加用户" :visible.sync="dialog4addUser" class="u-dialog u-dialog-sm">
            <el-transfer v-model="users2add" filterable :data="allUser" :titles="['待选用户', '已选用户']" :footer-format="{
              noChecked: '共${total}人',
              hasChecked: '已选${checked}/${total}人'
            }">
            </el-transfer>
            <div slot="footer" class="dialog-footer">
                <el-button @click="dialog4addUser= false">取 消</el-button>
                <el-button type="primary" @click="doAddUser">确 定</el-button>
            </div>
        </el-dialog>
    </el-row>
</template>
<script>
import vhttp from '@/vhttp'
import config from '@/config'
import dateUtil from 'element-ui/src/utils/date';
export default {
    name: 'SystemroleManagement',
    data: function() {
        return {
            authKeyMap:{
                addcommonrole:'sysmenu.commonrole.add',
                deletecommonrole:'sysmenu.commonrole.delete',
                editcommonrole:'sysmenu.commonrole.edit',
                authedit:'sysmenu.commonrole.authedit',
                user:'sysmenu.commonrole.user',
                adduser:'sysmenu.commonrole.user.add',
                deleteuser:'sysmenu.commonrole.user.delete',
            },
            activeName: 'roleSubmit',
            roleName: '',
            roleList: [],
            currentRole: {},
            userList: [],
            allUser: [],
            dialog4addUser: false,
            users2add: [],
            checkAll: false,
            isIndeterminate: false,
            pageParams: {
                pageNo: 1,
                pageSize: 10,
                total: 1
            },
            newrole: {
                roleName: '',
                desp: ''
            },
            rules: {
                roleName: [{
                    required: true,
                    message: '角色名称不能为空',
                    trigger: 'blur,change'
                }],
                desp: [{
                    required: true,
                    message: '角色描述不能为空',
                    trigger: 'blur'
                }]
            },
            formLabelWidth: '80px',
            defaultProps: {
                children: 'children',
                label: 'title'
            },
            authList: config.menu
        }
    },
    computed: {
        titleName: function() {
            return (this.newrole.id ? '编辑' : '新建');
        },
        filteredRoleList: function() {
            var rolename = this.roleName;
            return this.roleList.filter(function(item) {
                return item.roleName.indexOf(rolename) >= 0;
            })
        }
    },
    created: function() {
        this.initRoleList();
    },
    methods: {
        checkAuth: function(authKey) {
            var auth = this.$root.myauth;
            var hasauth = false;
            auth.forEach(function(a) {
                if (a.indexOf(authKey) >= 0) {
                    hasauth = true;
                }
            })
            return hasauth;
        },
        initRoleList: function(ischeckrole) {
            var vm = this;
            vhttp.get('/web/autho/roles/', {
                pageNo: 1,
                pageSize: 999
            }, function(res) {
                vm.roleList = res.data.array;
                vm.checkRole(ischeckrole);
            })
        },
        checkRole: function(ischeckrole) {
            var vm = this;
            if (ischeckrole && vm.currentRole.id) {
                var idx = 0;
                vm.roleList.forEach(function(r, i) {
                    if (r.id == vm.currentRole.id) {
                        idx = i;
                    }
                });
                vm.handleRoleChange(vm.roleList[idx]);
            } else {
                vm.handleRoleChange(vm.roleList[0])

            }

        },
        initUserList: function() {
            var vm = this;
            vm.pageParams.pageNo = 1;
            vm.getUserList();

        },
        getUserList: function() {
            var vm = this;
            vhttp.get('/web/autho/role/users', {
                roleId: vm.currentRole.id,
                pageNo: vm.pageParams.pageNo,
                pageSize: vm.pageParams.pageSize
            }, function(res) {
                vm.userList = res.data.array.map(function(u) {
                    u.checked = false;
                    return u;
                });
                vm.pageParams.total = res.data.total;
            })

        },
        handlePageChange: function(currentPage) {
            this.pageNum.pageNo = currentPage; //第几页     
            this.getcomments();
        },
        handleSizeChange: function(size) {
            this.pageNum.pageSize = size; //每页几条
            this.getcomments();
        },
        handleRoleChange: function(role) {
            this.currentRole = role;
            this.switchActivePanel('roleSubmit')
            if (this.currentRole) {
                this.pageParams.pageNo = 1;
                this.initUserList()
                this.getAllAuth();
                this.newrole = {
                    id: this.currentRole.id,
                    roleName: this.currentRole.roleName,
                    desp: this.currentRole.description,
                };
            }
        },
        switchActivePanel: function(name) {
            this.activeName = name;
            switch (name) {
                case 'createRole':
                    this.newrole = {
                        roleName: '',
                        desp: ''
                    };
                    break;
                case 'roleSubmit':
                    this.newrole = {
                        id: this.currentRole.id,
                        roleName: this.currentRole.roleName,
                        desp: this.currentRole.description,
                    };
                    break;
            }
        },
        toAddRole: function() {
            this.switchActivePanel('createRole');
        },
        saveRole: function() {
            var vm = this;
            if (vm.newrole.id) {
                vhttp.put('/web/autho/role/' + vm.newrole.id, {
                    id: vm.newrole.id,
                    roleName: vm.newrole.roleName,
                    description: vm.newrole.desp
                }, function(res) {
                    vm.initRoleList(true)
                    vm.$message({
                        type: 'success',
                        message: '保存成功'
                    });
                })

            } else {
                vhttp.post('/web/autho/role/c', {
                    roleName: vm.newrole.roleName,
                    description: vm.newrole.desp
                }, function(res) {
                    vm.initRoleList()
                    vm.$message({
                        type: 'success',
                        message: '保存成功'
                    });
                })
            }
        },
        deleteRole: function(id) {
            var vm = this;
            vm.$confirm('确认删除该角色吗?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(function() {
                vhttp.put('/web/autho/role/del/' + id, {}, function(res) {
                    vm.$message({
                        type: 'success',
                        message: '删除成功!'
                    });
                    vm.initRoleList();
                })
            }, function() {
                vm.$message({
                    type: 'info',
                    message: '取消删除'
                });
            }).catch(function(err) {
                vm.$message({
                    type: 'info',
                    message: '删除失败'
                });
            });
        },
        toAddUser: function() {
            this.dialog4addUser = true;
            this.getAllUser();
        },
        doAddUser: function() {
            var vm = this;
            vhttp.post('/web/autho/role/' + vm.currentRole.id + '/users', {
                roleId: this.currentRole.id,
                userIds: vm.users2add.join(';')
            }, function(res) {
                vm.dialog4addUser = false;
                vm.$message.success('添加用户成功')
                vm.initUserList();
            })
        },
        deleteUser: function(ids) {
            var vm = this;
            vm.$confirm('确认删除该用户吗?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(function() {
                vhttp.delete('/web/autho/role/' + vm.currentRole.id + '/r/user', {
                    roleId: vm.currentRole.id,
                    userIds: ids
                }, function(res) {
                    vm.$message({
                        type: 'success',
                        message: '删除成功!'
                    });
                    vm.initUserList();
                })
            }, function() {
                vm.$message({
                    type: 'info',
                    message: '取消删除'
                });
            }).catch(function(err) {
                vm.$message({
                    type: 'info',
                    message: '删除失败'
                });
            });
        },
        getAllUser: function() {
            var vm = this;
            vhttp.get('/web/autho/reporters', {
                roleId: this.currentRole.id,
                type: this.currentRole.type,
                pageNo: 1,
                pageSize: 999,
            }, function(res) {
                vm.allUser = res.data.array.map(function(u) {
                    var disabled = false;
                    vm.userList.forEach(function(user) {
                        if (user.id === u.id) {
                            disabled = true;
                        }
                    })
                    return {
                        key: u.id,
                        label: u.trueName,
                        disabled: disabled
                    }
                });
            })

        },
        switchAllcheck: function() {
            var vm = this;
            vm.userList.forEach(function(item) {
                item.checked = vm.checkAll;
            })
        },
        switchCheck: function(e) {
            var vm = this;
            var checkedCount = 0;
            vm.userList = vm.userList.map(function(item) {
                if (item.checked) checkedCount = checkedCount + 1;
                return item;
            });
            vm.checkAll = checkedCount === vm.userList.length;
            vm.isIndeterminate = checkedCount > 0 && checkedCount < vm.userList.length;
        },
        alldelete: function() {
            var vm = this;
            var idsList = [];
            vm.userList.forEach(function(item) {
                if (item.checked) {
                    idsList.push(item.id);
                }
            });
            vm.deleteUser(idsList.join(';'));
        },
        saveAuth: function() {
            var vm = this;
            var auth = this.$refs.authTree.getCheckedKeys();
            vhttp.postbody('/web/autho/role/' + vm.newrole.id + '/perms', {
                roleId: vm.newrole.id,
                perms: auth.join(';')
            }, function(res) {
                vm.$message({
                    type: 'success',
                    message: '保存成功'
                });
            })
        },
        getAllAuth: function() {
            var vm = this;
            vhttp.get('/web/autho/role/' + vm.currentRole.id + '/perms', {
                roleId: vm.currentRole.id
            }, function(res) {
                var authArr = res.data.array.map(function(a) {
                    return a.perm;
                });
                vm.$refs.authTree.setCheckedKeys(authArr);
            })

        }
    }
}
</script>
<style>
.tablelike-card {
    border-radius: 0;
}

.tablelike-card .el-card__header {
    height: 40px;
    padding: 0;
    min-width: 0;
    text-overflow: ellipsis;
    vertical-align: middle;
    background-color: #eef1f6;
}

.tablelike-card .el-card__header .cardheader {
    height: 40px;
    padding: 5px 10px;
    line-height: 30px;
    font-weight: normal;
    font-size: 12px;
    text-align: center;
}

.tablelike-card .el-card__body {
    padding: 0;
}

.tablelike-card .el-card__body .item {
    height: 40px;
    padding: 6px 10px;
    line-height: 26px;
    cursor: pointer;
}

.tablelike-card .el-card__body .item.active {
    background-color: #edf7ff;
}
</style>
