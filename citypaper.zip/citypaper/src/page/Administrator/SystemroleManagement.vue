<!-- 系统角色管理组件 -->
<template>
    <el-row>
        <h4 class="moduleTitle">系统角色管理</h4>
        <div class="g-main">
            <div class="fixleft">
                <el-input placeholder="输入角色名称以搜索" icon="search" v-model="roleName">
                </el-input>
                <el-table :data="filteredRoleList" ref="roleTable" class="mt" highlight-current-row @current-change="handleRoleChange">
                    <el-table-column prop="roleName" label="选择">
                    </el-table-column>
                </el-table>
            </div>
            <div class="content">
                <el-button type="primary" @click="toAddUser" v-if="authList.indexOf('sysmenu.sysrole.add')>=0">添加用户</el-button>
                <el-table :data="userList" class="mt">
                    <el-table-column prop="roleName" label="选择" width="60" v-if="authList.indexOf('sysmenu.sysrole.delete')>=0">
                        <template scope="scope">
                            <el-checkbox v-model="userList[scope.$index].checked" v-on:change="switchCheck"></el-checkbox>
                        </template>
                    </el-table-column>
                    <el-table-column label="序号">
                        <template scope="scope">
                            {{scope.$index | fixno(pageParams.pageNo,pageParams.pageSize)}}
                        </template>
                    </el-table-column>
                    <el-table-column prop="nickName" label="用户名">
                    </el-table-column>
                    <el-table-column prop="trueName" label="真实姓名">
                    </el-table-column>
                    <el-table-column label="操作" v-if="authList.indexOf('sysmenu.sysrole.delete')>=0">
                        <template scope="scope">
                            <el-button type="text" size="mini" v-on:click="deleteUser(scope.row.id)">删除
                            </el-button>
                        </template>
                    </el-table-column>
                    <tr class="el-table__row" slot="append" v-if="authList.indexOf('sysmenu.sysrole.delete')>=0" v-show="userList.length">
                        <td class="el-table_1_column_1">
                            <div class="cell">
                                <span class="Selectall">全选</span>
                                <el-checkbox v-model="checkAll" @change="switchAllcheck" :indeterminate="isIndeterminate"></el-checkbox>
                            </div>
                        </td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td class="el-table_1_column_1">
                            <div class="cell">
                                <el-button type="text" @click="alldelete" class="via">删除</el-button>
                            </div>
                        </td>
                    </tr>
                </el-table>
                <el-col :span="24" class="u-padding-vertical-sm u-text-right">
                    <el-pagination @size-change="handleSizeChange" @current-change="handlePageChange" :current-page="pageParams.pageNo" :page-sizes="[10, 20, 50, 100]" :page-size="pageParams.pageSize" layout="total, sizes, prev, pager, next, jumper" :total="pageParams.total">
                    </el-pagination>
                </el-col>
            </div>
        </div>
        <el-dialog title="添加用户" :visible.sync="dialog4addUser" class="u-dialog u-dialog-sm">
            <el-transfer v-model="users2add" filterable :data="allUser" :titles="['待选用户', '已选用户']" :footer-format="{
              noChecked: '共${total}人',
              hasChecked: '已选${checked}/${total}人'
            }">
            </el-transfer>
            <div slot="footer" class="dialog-footer">
                <el-button @click="dialog4addUser= false">取 消</el-button>
                <el-button type="primary" @click="doAddUser">确 定</el-button>
            </div>
        </el-dialog>
    </el-row>
</template>
<script>
import vhttp from '@/vhttp'
import dateUtil from 'element-ui/src/utils/date';
export default {
    name: 'SystemroleManagement',
    data: function() {
        return {
            roleName: '',
            roleList: [],
            currentRole: {},
            userList: [],
            allUser: [],
            dialog4addUser: false,
            users2add: [],
            checkAll: false,
            isIndeterminate: false,
            pageParams: {
                pageNo: 1,
                pageSize: 10,
                total: 1
            }
        }
    },
    computed: {
        filteredRoleList: function() {
            var rolename = this.roleName;
            return this.roleList.filter(function(item) {
                return item.roleName.indexOf(rolename) >= 0;
            })
        },
        authList: function() {
            return this.$root.myauth;
        }
    },
    created: function() {
        this.initRoleList();
    },
    methods: {
        handlePageChange: function(currentpage) {
            this.pageParams.pageNo = currentpage;
            this.initUserList();
        },
        handleSizeChange: function(pagesize) {
            this.pageParams.pageSize = pageSize;
            this.initUserList();
        },
        initRoleList: function() {
            var vm = this;
            vhttp.get('/web/autho/system/role/list', {}, res => {
                vm.roleList = res.data;
                vm.$nextTick(function() {
                    vm.$refs.roleTable.setCurrentRow(vm.roleList[0]);
                })
            })
        },
        initUserList: function() {
            var vm = this;
            vhttp.get('/web/autho/role/users', {
                roleId: vm.currentRole.id,
                pageNo: vm.pageParams.pageNo,
                pageSize: vm.pageParams.pageSize
            }, res => {
                vm.userList = res.data.array.map(function(u) {
                    u.checked = false;
                    return u;
                });
                vm.pageParams.total = res.data.total;
            })

        },
        handleRoleChange: function(role) {
            this.currentRole = role;
            if (this.currentRole) {
                this.pageParams.pageNo = 1;
                this.initUserList()
            }
        },
        submitUserIntoRole: function() {

        },
        switchAllcheck: function() {
            var vm = this;
            vm.tableData = vm.tableData.map(function(item) {
                item.checked = vm.checkAll;
                return item;
            })
        },
        toAddUser: function() {
            this.dialog4addUser = true;
            this.getAllUser();
        },
        doAddUser: function() {
            var vm = this;
            vhttp.post('/web/autho/role/' + vm.currentRole.id + '/users', {
                roleId: this.currentRole.id,
                userIds: vm.users2add.join(';')
            }, res => {
                vm.dialog4addUser = false;
                vm.$message.success('添加用户成功')
                vm.initUserList();
            })
        },
        deleteUser: function(ids) {
            var vm = this;
            vm.$confirm('确认删除该用户吗?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(function() {
                vhttp.delete('/web/autho/role/' + vm.currentRole.id + '/r/user', {
                    roleId: vm.currentRole.id,
                    userIds: ids
                }, res => {
                    vm.$message({
                        type: 'success',
                        message: '删除成功!'
                    });
                    vm.initUserList();
                })
            }, function() {
                vm.$message({
                    type: 'info',
                    message: '取消删除'
                });
            }).catch(function(err) {
                vm.$message({
                    type: 'info',
                    message: '删除失败'
                });
            });
        },
        getAllUser: function() {
            var vm = this;
            vhttp.get('/web/autho/reporters', {
                roleId: this.currentRole.id,
                type: this.currentRole.type,
                pageNo: 1,
                pageSize: 999,
            }, res => {
                vm.allUser = res.data.array.map(function(u) {
                    var disabled = false;
                    vm.userList.forEach(function(user) {
                        if (user.id === u.id) {
                            disabled = true;
                        }
                    })
                    return {
                        key: u.id,
                        label: u.trueName,
                        disabled: disabled
                    }
                });
            })

        },
        switchAllcheck: function() {
            var vm = this;
            vm.userList.forEach(function(item) {
                item.checked = vm.checkAll;
            })
        },
        switchCheck: function(e) {
            var vm = this;
            var checkedCount = 0;
            vm.userList = vm.userList.map(function(item) {
                if (item.checked) checkedCount = checkedCount + 1;
                return item;
            });
            vm.checkAll = checkedCount === vm.userList.length;
            vm.isIndeterminate = checkedCount > 0 && checkedCount < vm.userList.length;
        },
        alldelete: function() {
            var vm = this;
            var idsList = [];
            vm.userList.forEach(function(item) {
                if (item.checked) {
                    idsList.push(item.id);
                }
            });
            vm.deleteUser(idsList.join(';'));
        }
    }
}
</script>
<style scoped>
.el-table__body tr.current-row>td {
    background-color: #c8e2f6;
}
</style>
