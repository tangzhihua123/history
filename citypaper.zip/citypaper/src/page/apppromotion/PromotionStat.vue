<!-- 推广统计组件 -->
<template>
    <el-row>
        <h4 class="moduleTitle">推广统计</h4>
        <el-row class="m-tool-bar">
            <el-col :span="12">
                反馈时间
                <el-date-picker v-model="dateRange" type="daterange" format="yyyy-MM-dd" placeholder="起始时间－结束时间" :picker-options="pickerOption">
                </el-date-picker>
                <el-button type="primary" class="u-primary-btn" size="small" @click="exportIf" v-if="checkAuth(authKeyMap.export)">导出</el-button>
            </el-col>
            <el-col :span="12" class="u-text-right">
                <el-input icon="search" placeholder="请输入手机号码" class="w217" v-model="filedValue"></el-input>
                <el-button type="primary" class="u-margin-left-xs u-primary-btn" size="small" @click="getstar()">搜索</el-button>
            </el-col>
        </el-row>
        <el-col :span="24" class="u-margin-bottom-xs">
            <el-table class="m-table" style="width: 100%" :data="promotionset" v-loading.body="loading" stripe>
                <el-table-column label="序号" prop="id">
                </el-table-column>
                <el-table-column label="手机号" prop="phoneNo">
                </el-table-column>
                <el-table-column label="用户昵称" prop="nickName">
                </el-table-column>
                <el-table-column label="注册时间" prop="registerTime">
                </el-table-column>
                <el-table-column label="邀请时间" prop="invitedTime">
                </el-table-column>
                <el-table-column label="邀请人手机号" prop="invitePhoneNo">
                </el-table-column>
                <el-table-column label="邀请人昵称" prop="inviteNickName">
                </el-table-column>
                <el-table-column label="部门" prop="department" width="120">
                    <template scope="scope">
                        <el-button type="text" size="mini" @click="getId(scope)">
                            {{scope.row.department}}
                        </el-button>
                    </template>
                </el-table-column>
            </el-table>
        </el-col>
        <!--  底部分页 -->
        <el-col :span="24" class="u-padding-vertical-sm u-text-right">
            <el-pagination @size-change="handleSizeChange" @current-change="handlePageChange" :current-page="pageParams.currentpage" :page-sizes="[10, 20, 50, 100]" :page-size="pageParams.pagesize" layout="total, sizes, prev, pager, next, jumper" :total="pageParams.total">
            </el-pagination>
        </el-col>
    </el-row>
</template>
<script>
import vhttp from '@/vhttp'
import config from '@/config.js';
export default {
    data: function() {
        return {
            authKeyMap: {
                export: 'apppromotion.stat.export'
            },
            dateRange: [null, null],
            loading: false,
            startTime: '',
            endTime: '',
            filedType: '', //检索类型
            filedValue: '', //检索内容
            departmentId: 1, //部门ID
            //分页数据
            pageParams: {
                currentpage: 1,
                pagesize: 10,
                total: 1
            },
            pickerOption: {
                onPick: this.refreshTable
            },
            promotionset: []
        }
    },
    created: function() {
        var vm = this;
        if (vm.$route.query.id) {
            vm.departmentId = vm.$route.query.id;
            vm.getstar();
        } else {
            vm.getstar();
        }
    },
    methods: {
        checkAuth: function(authKey) {
            var auth = this.$root.myauth;
            var hasauth = false;
            auth.forEach(function(a) {
                if (a.indexOf(authKey) >= 0) {
                    hasauth = true;
                }
            })
            return hasauth;
        },
        handlePageChange: function(currentpage) {
            this.pageParams.currentpage = currentpage;
            this.getstar();
        },
        handleSizeChange: function(pagesize) {
            this.pageParams.pagesize = pagesize;
            this.getstar();
        },
        exportIf: function() {
            this.$confirm('是否确认导出?', '信息确认', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning',
            }).then(() => {
                this.dwnstat();
                this.$message({
                    type: 'success',
                    message: '导出成功!'
                });
            }).catch(() => {
                this.$message({
                    type: 'info',
                    message: '已取消导出'
                });
            });
        },
        //时间函数
        refreshTable: function(dateRange) {
            if (dateRange.maxDate) {
                this.startTime = dateRange.minDate.getTime();
                this.endTime = dateRange.maxDate.getTime();
            }
        },
        //点击获取部门id函数
        getId: function(scope) {
            var vm = this;
            vm.departmentId = scope.row.id;
        },
        //查询
        getstar: function() {
            var vm = this;
            vhttp.get('/web/extension/statistic/department/detail', {
                pageSize: vm.pageParams.pagesize,
                pageNo: vm.pageParams.currentpage,
                startTime: vm.startTime,
                endTime: vm.endTime,
                filedType: 1,
                filedValue: vm.filedValue,
                departmentId: vm.departmentId
            }, function(res) {
                vm.promotionset = res.data.array;
                vm.pageParams = {
                    currentpage: res.data.pageNo,
                    pagesize: res.data.pageSize,
                    total: res.data.total
                };
            })
        },
        // 导出exe表格
        dwnstat: function() {
            var vm = this;
            var aLink = document.createElement('a');
            aLink.download = '推广统计.xls';
            aLink.href = config.api + '/web/extension/statistics/department/download?pageNo=1&pageSize=' + vm.pageParams.total + '&countyCode' + vhttp.getCountryCode();
            aLink.click()
        }
    }
}
</script>
