<!-- 推广设置组件 -->
<template>
    <el-row>
        <h4 class="moduleTitle">推广设置</h4>
        <el-row class="m-tool-bar">
            <el-col :span="24">
                <el-button type="primary" class="u-margin-left-xs u-primary-btn" size="small" @click="dialogFormDepartment = true" v-if="checkAuth(authKeyMap.create)">新建部门</el-button>
            </el-col>
        </el-row>
        <!--  新建弹框开始 -->
        <el-dialog title="新建 " :visible.sync="dialogFormDepartment">
            <el-form :model="newpart">
                <el-form-item label="部门名称" :label-width="formLabelWidth">
                    <el-input v-model="newpart.name" auto-complete="off"></el-input>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="dialogFormDepartment = false">取 消</el-button>
                <el-button type="primary" @click="getnnewpart()">确 定</el-button>
            </div>
        </el-dialog>
        <!--  新建弹框结束 -->
        <!--  编辑弹框开始 -->
        <el-dialog title="编辑" :visible.sync="amendDialogFormDepartment">
            <el-form :model="amendNewpart">
                <el-form-item label="部门名称" :label-width="formLabelWidth">
                    <el-input v-model="amendNewpart.name" auto-complete="off"></el-input>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="amendDialogFormDepartment = false">取 消</el-button>
                <el-button type="primary" @click="amendDetnnewpart()">确 定</el-button>
            </div>
        </el-dialog>
        <!--  编辑弹框结束 -->
        <el-col :span="24" class="u-margin-bottom-xs">
            <el-table class="m-table" style="width: 100%" :data="generalizelist" v-loading.body="loading" stripe>
                <el-table-column label="部门名称" prop="name">
                </el-table-column>
                <el-table-column label="部门推广码" prop="extensionCode">
                </el-table-column>
                <el-table-column label="创建时间" prop="createTime">
                    <template scope="scope">
                        {{scope.row.createTime | dateTimeFormat}}
                    </template>
                </el-table-column>
                <el-table-column label="推广人数" prop="extensionNum">
                </el-table-column>
                <el-table-column label="今日数据" prop="todayExtensionNum">
                </el-table-column>
                <el-table-column label="昨日数据" prop="yesterdayExtensionNum">
                </el-table-column>
                <el-table-column label="推广详情" prop="appVersion" width="120">
                    <template scope="scope">
                        <el-button type="text" size="mini" @click="look(scope.row)">查看</el-button>
                    </template>
                </el-table-column>
                <el-table-column label="操作" v-if="checkAuth(authKeyMap.edit)">
                    <template scope="scope">
                        <el-button type="text" size="mini" @click="amend(scope.row)">编辑</el-button>
                    </template>
                </el-table-column>
            </el-table>
        </el-col>
        <!-- 底部分页 -->
        <el-col :span="24" class="u-padding-vertical-sm u-text-right">
            <el-pagination @size-change="handleSizeChange" @current-change="handlePageChange" :current-page="pageParams.currentpage" :page-sizes="[10, 20, 50, 100]" :page-size="pageParams.pagesize" layout="total, sizes, prev, pager, next, jumper" :total="pageParams.total">
            </el-pagination>
        </el-col>
    </el-row>
</template>
<script>
import config from '@/config.js';
import vhttp from '@/vhttp'
export default {
    name: 'UserList',
    data: function() {
        return {
            authKeyMap: {
                create: 'apppromotion.set.create',
                edit: 'apppromotion.set.edit' 
            },
            //分页数据
            pageParams: {
                currentpage: 1,
                pagesize: 10,
                total: 1
            },
            loading: false,
            generalizelist: [],
            dialogFormDepartment: false, //新建
            amendDialogFormDepartment: false, //修改
            newpart: {
                name: ''
            },
            amendNewpart: {
                name: ''
            },
            formLabelWidth: '80px'
        }
    },
    created: function() {
        this.getset()
    },
    methods: {
        checkAuth: function(authKey) {
            var auth = this.$root.myauth;
            var hasauth = false;
            auth.forEach(function(a) {
                if (a.indexOf(authKey) >= 0) {
                    hasauth = true;
                }
            })
            return hasauth;
        },
        handlePageChange: function(currentPage) {
            this.pageParams.currentpage = currentPage;
            this.getset();
        },
        handleSizeChange: function(size) {
            this.pageParams.pagesize = size;
            this.getset();
        },
        //查询
        getset: function() {
            var vm = this;
            vhttp.get('/web/extension/statistic/department/list', {
                pageNo: vm.pageParams.currentpage,
                pageSize: vm.pageParams.pagesize
            }, function(res) {
                vm.generalizelist = res.data.array;
                vm.pageParams = {
                    currentpage: res.data.pageNo,
                    pagesize: res.data.pageSize,
                    total: res.data.total
                }
            })
        },
        // 新建部门
        getnnewpart: function() {
            var vm = this;
            vm.dialogFormDepartment = false;
            vhttp.post('/web/extension/statistic/department/add', {
                name: vm.newpart.name
            }, function() {
                vm.getset();
            })
        },
        //点击修改
        amend: function(gn) {
            var vm = this;
            vm.amendDialogFormDepartment = true;
            vm.amendNewpart = {
                id: gn.id,
                name: gn.name
            }
        },
        //点击修改确定按钮
        amendDetnnewpart: function() {
            var vm = this;
            vhttp.put('/web/extension/statistic/department/edit', {
                name: vm.amendNewpart.name,
                id: vm.amendNewpart.id
            }, function(res) {
                vm.amendDialogFormDepartment = false;
                vm.getset();
            })
        },
        //点击查看
        look: function(gn) {
            var vm = this;
            vm.$router.push({
                name: 'PromotionStat',
                query: {
                    id: gn.id
                }
            });
        }
    }
}
</script>
<style scoped>
.u-primary-btn {
    width: 81px;
}
</style>
