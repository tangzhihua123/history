<!-- 推广明细组件 -->
<template>
    <el-row>
        <h4 class="moduleTitle">推广明细</h4>
        <el-row class="m-tool-bar">
            <el-col :span="12">
                邀请时间
                <el-date-picker v-model="dateRange" type="daterange" format="yyyy-MM-dd" placeholder="起始时间－结束时间" :picker-options="pickerOption">
                </el-date-picker>
                <el-button type="primary" class="u-primary-btn" size="small" @click="exportIf" v-if="checkAuth(authKeyMap.export)">导出</el-button>
            </el-col>
            <el-col :span="12" class="u-text-right">
                <el-input icon="search" placeholder="请输入手机号码" class="w217" v-model="phoneNo"></el-input>
                <el-button type="primary" class="u-margin-left-xs u-primary-btn" size="small" @click="getdetail">搜索</el-button>
            </el-col>
        </el-row>
        <el-col :span="24" class="u-margin-bottom-xs">
            <el-table class="m-table" style="width: 100%" :data="popularize" v-loading.body="loading" stripe>
                <el-table-column label="序号" prop="id">
                </el-table-column>
                <el-table-column label="手机号" prop="phoneNo">
                </el-table-column>
                <el-table-column label="用户昵称" prop="nickName">
                </el-table-column>
                <el-table-column label="邀请时间" prop="inviteTime">
                </el-table-column>
                <el-table-column label="邀请成功" prop="status">
                    <template scope="scope">
                        <el-button type="text">
                            {{statusList[scope.row.status]}}
                        </el-button>
                    </template>
                </el-table-column>
                <el-table-column label="失败原因" prop="reason" width="120">
                </el-table-column>
            </el-table>
        </el-col>
        <!--  底部分页 -->
        <el-col :span="24" class="u-padding-vertical-sm u-text-right">
            <el-pagination @size-change="handleSizeChange" @current-change="handlePageChange" :current-page="pageParams.currentpage" :page-sizes="[10, 20, 50, 100]" :page-size="pageParams.pagesize" layout="total, sizes, prev, pager, next, jumper" :total="pageParams.total">
            </el-pagination>
        </el-col>
    </el-row>
</template>
<script>
import vhttp from '@/vhttp'
import config from '@/config.js';
export default {
    data: function() {
        return {
            authKeyMap: {
                export: 'apppromotion.detail.export' 
            },
            dateRange: [null, null],
            loading: false,
            phoneNo: '',
            statusList: ["是", "否"],
            //分页数据
            pageParams: {
                currentpage: 1,
                pagesize: 10,
                total: 1
            },
            pickerOption: {
                onPick: this.refreshTable
            },
            popularize: []
        }
    },
    created: function() {
        this.getdetail()
    },
    methods: {
        checkAuth: function(authKey) {
            var auth = this.$root.myauth;
            var hasauth = false;
            auth.forEach(function(a) {
                if (a.indexOf(authKey) >= 0) {
                    hasauth = true;
                }
            })
            return hasauth;
        },
        handlePageChange: function(currentpage) {
            this.pageParams.currentpage = currentpage;
            this.getdetail();
        },
        handleSizeChange: function(pagesize) {
            this.pageParams.pagesize = pagesize;
            this.getdetail();
        },
        exportIf: function() {
            this.$confirm('是否确认导出?', '信息确认', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                this.dwnpromotion();
                this.$message({
                    type: 'success',
                    message: '导出成功!'
                });
            }).catch(() => {
                this.$message({
                    type: 'info',
                    message: '已取消导出'
                });
            });
        },
        //时间函数
        refreshTable: function(dateRange) {
            if (dateRange.maxDate) {
                this.startTime = dateRange.minDate.getTime();
                this.endTime = dateRange.maxDate.getTime();
            }
        },
        //查询函数
        getdetail: function() {
            var vm = this;
            vhttp.get('/web/extension/statistic/log', {
                pageSize: vm.pageParams.pagesize,
                pageNo: vm.pageParams.currentpage,
                startTime: vm.startTime,
                endTime: vm.endTime,
                phoneNo: vm.phoneNo
            }, function(res) {
                vm.popularize = res.data.array;
                vm.pageParams = {
                    currentpage: res.data.pageNo,
                    pagesize: res.data.pageSize,
                    total: res.data.total
                }
            })
        },
        // 导出excle
        dwnpromotion: function() {
            var vm = this;
            var aLink = document.createElement('a');
            aLink.download = '推广明细.xls';
            aLink.href = config.api + '/web/extension/statistic/download?pageNo=1&pageSize=' + vm.pageParams.total + '&countyCode' + vhttp.getCountryCode();
            aLink.click();
        }
    }
}
</script>
