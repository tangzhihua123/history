 <!-- 文章统计组件 -->
<template>
<el-row>
  <h4 class="moduleTitle">文章统计</h4>
  <el-row class="m-tool-bar">
   <!--  时间选框 -->
     <el-col :span="16">
      筛选
      <el-date-picker
        v-model="dateRange"
        type="daterange" 
        format="yyyy-MM-dd"
        placeholder="起始时间－结束时间"
        :picker-options="pickerOption">
      </el-date-picker>
    <!--  栏目下拉菜单 -->
    <!--  trigger="click"  点击才会触发下拉菜单 -->
      <el-dropdown size="small" class="u-dropdown" @command="videoCommand"   trigger="click">
          <el-button >
            {{videoParmas[columnId-1].text}}<i class="el-icon-arrow-down"></i>
          </el-button>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item :command="video.key" v-for="(video,$index) in videoParmas" key="key">{{video.text}}</el-dropdown-item> 
          </el-dropdown-menu>
      </el-dropdown>

       <!--  排序下拉菜单 -->
        <el-dropdown size="small" class="u-dropdown" @command="sortCommandb"   trigger="click">
          <el-button>
            {{sortParmas[sortNum-1].text}}<i class="el-icon-arrow-down"></i>
          </el-button>
          <el-dropdown-menu   slot="dropdown">
            <el-dropdown-item :command="sort.key" v-for="(sort,$index) in sortParmas" key="key">{{sort.text}}</el-dropdown-item> 
          </el-dropdown-menu>
        </el-dropdown>   
    </el-col>

   <!--  搜索关键字 -->
    <el-col :span="8" class="u-text-right">
      <el-input placeholder="请输入关键字"   v-model="title" icon="search" class="w217"></el-input>
      <el-button type="primary" class="u-margin-left-xs u-primary-btn" size="small"  @click=" getarticle()">搜索</el-button>
    </el-col>
  </el-row>

  <!-- 标题栏 -->
  <el-col :span="24" class="u-margin-bottom-xs">
    <el-table class="m-table" style="width: 100%" :data="articlechart" v-loading.body="loading" stripe>
     <el-table-column
        label="文章ID" prop="articleId">
      </el-table-column>
      <el-table-column
        label="标题(链接)" prop="title">
      </el-table-column>
      <el-table-column
        label="发布时间" prop="publishDate">
      </el-table-column>
      <el-table-column
        label="作者" prop="fgdAuthorName">
      </el-table-column>
      <el-table-column
        label="所属栏目" prop="columnName">
      </el-table-column>
      <el-table-column
        label="PV" prop="pointNum">
      </el-table-column>
      <el-table-column
        label="UV" prop="readNum">
      </el-table-column>
      <el-table-column
        label="收藏量" prop="keepNum">
      </el-table-column>
      <el-table-column
        label="点赞量" prop="praiseNum">
      </el-table-column>
      <el-table-column
        label="评论量" prop="commentNum">
      </el-table-column>
      <el-table-column
        label="转发量" prop="shareNum">
      </el-table-column>
    </el-table>
  </el-col>

<!-- 底部分页 -->
  <el-col :span="24" class="u-padding-vertical-sm u-text-right">
      <el-pagination @size-change="handleSizeChange" 
        @current-change="handlePageChange" 
        :current-page="pageParams.currentpage" 
        :page-sizes="[10, 20, 50, 100]" 
        :page-size="pageParams.pagesize" 
        layout="total, sizes, prev, pager, next, jumper" 
        :total="pageParams.total">
      </el-pagination>
  </el-col>

</el-row>
</template>
<script>
import vhttp from '@/vhttp'
import dateUtil from 'element-ui/src/utils/date';
  export default {
    name: 'UserList',
    data:function() {
      return {
        dateRange:[null,null],
        loading:false,
        startTime:'',
        endTime:'',
        video:'栏目',
        sort: '排序',
        columnId:1,//栏目
        sortNum:1,//排序
        title:'',//搜索关键字
        //分页数据
        pageParams: {
            currentpage: 1,
            pagesize: 10,
            total: 1
        },
         //栏目数据
         videoParmas:[{text:'头条',key:'1'},{text:'视频',key:'2'},{text:'专题',key:'3'},{text:'时政',key:'4'},{text:'社会',key:'5'},{text:'体育',key:'6'},{text:'教育',key:'7'},{text:'文化',key:'8'}],
        //排序数据
        sortParmas:[{text:'PU',key:'1'},{text:'UV',key:'2'},{text:'收藏量',key:'3'},{text:'评论量',key:'4'},{text:'转发量',key:'5'},{text:'点赞数',key:'6'}],

        pickerOption:{
          onPick:this.refreshTable
        },
        articlechart: []
      }
    },
    created:function() {
          this.getarticle() 

    },
    methods: { 
        checkAuth: function(authKey) {
            var auth = this.$root.myauth;
            var hasauth = false;
            auth.forEach(function(a) {
                if (a.indexOf(authKey) >= 0) {
                    hasauth = true;
                }
            })
            return hasauth;
        },
      //当前页数变化时的回调函数。
      handlePageChange:function(currentpage){ 
          this.pageParams.currentpage = currentpage;   
          this.getarticle();
      },
      //每页大小变化时的回调函数。
      handleSizeChange:function(pagesize){
          this.pageParams.pagesize = pagesize;
          this.getarticle();
      },
      //栏目下拉菜单函数
      videoCommand:function(command) {
            var vm=this;  
            var command = Number(command);
            vm.columnId=command; 
      },
      //排序下拉菜单函数
      sortCommandb:function(command) {
            var vm=this;
            var command = Number(command);
            vm.sortNum=command;  
      },
      //时间函数
      refreshTable:function(dateRange){
        if(dateRange.maxDate){
          this.startTime=dateRange.minDate.getTime();
          this.endTime=dateRange.maxDate.getTime();  
        }
      },
      //查询请求,点击搜索按钮触发。
      //关于搜索目前后台只给定了columnId:286进行测试用
      //另外时间搜索未实现
      getarticle: function() {
        var vm = this; 
        vhttp.get('/web/statistics/articles', {pageNo:vm.pageParams.currentpage,pagesize:vm.pageParams.pagesize,startTime:vm.startTime,endTime:vm.endTime,columnId:286,sortNum:vm.sortNum,title:vm.title}, res => {
            vm.articlechart = res.data.array;
            vm.pageParams =Object.assign(vm.pageParams,{ 
                pagesize: res.data.pageSize,
                total: res.data.total
            });
 
        })
      }
    }
  }
</script>