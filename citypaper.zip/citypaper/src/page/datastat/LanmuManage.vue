<!-- 栏目统计组件 -->
<template>
    <el-row>
        <h4 class="moduleTitle">栏目统计</h4>
        <el-row class="m-tool-bar">
            <el-col :span="12">
                <!--  时间选框 -->
                <el-date-picker v-model="dateRange" type="daterange" format="yyyy-MM-dd" placeholder="统计时间范围" :picker-options="pickerOption">
                </el-date-picker>
                <!--  排序下拉菜单 -->
                <el-dropdown size="small" class="u-dropdown" @command="sortCommand" trigger="click">
                    <el-button>
                        {{sortParmas[sortNum-1].text}}<i class="el-icon-arrow-down"></i>
                    </el-button>
                    <el-dropdown-menu slot="dropdown">
                        <el-dropdown-item :command="sort.key" v-for="(sort,$index) in sortParmas" key="key">{{sort.text}}</el-dropdown-item>
                    </el-dropdown-menu>
                </el-dropdown>
            </el-col>
            <!-- 搜索栏目名称 -->
            <el-col :span="12" class="u-text-right">
                <el-input placeholder="请输入栏目名称" icon="search" class="w217" v-model="name"></el-input>
                <el-button type="primary" class="u-margin-left-xs u-primary-btn" size="small" @click="getlanmu()">搜索</el-button>
            </el-col>
        </el-row>
        <!--   标题栏 -->
        <el-col :span="24" class="u-margin-bottom-xs">
            <el-table class="m-table" style="width: 100%" :data="takeAskData" v-loading.body="loading" stripe>
                <el-table-column label="栏目编号" prop="columnId">
                </el-table-column>
                <el-table-column label="栏目名称" prop="name">
                </el-table-column>
                <el-table-column label="订阅量" prop="subscribesCount">
                </el-table-column>
                <el-table-column label="文章数" prop="articleNum">
                </el-table-column>
                <el-table-column label="原创数" prop="originalNum">
                </el-table-column>
                <el-table-column label="总点击量" prop="pointNum">
                </el-table-column>
                <el-table-column label="web点击" prop="webPv">
                </el-table-column>
                <el-table-column label="app点击" prop="appPv">
                </el-table-column>
                <el-table-column label="点赞量" prop="praiseNum">
                </el-table-column>
                <el-table-column label="收藏量" prop="keepNum">
                </el-table-column>
                <el-table-column label="评论量" prop="commentNum">
                </el-table-column>
                <el-table-column label="转发量" prop="shareNum">
                </el-table-column>
            </el-table>
        </el-col>
        <!--  底部分页 -->
        <el-col :span="24" class="u-padding-vertical-sm u-text-right">
            <el-pagination @size-change="handleSizeChange" @current-change="handlePageChange" :current-page="pageParams.currentpage" :page-sizes="[10, 20, 50, 100]" :page-size="pageParams.pagesize" layout="total, sizes, prev, pager, next, jumper" :total="pageParams.total">
            </el-pagination>
        </el-col>
    </el-row>
</template>
<script>
import vhttp from '@/vhttp'
import dateUtil from 'element-ui/src/utils/date';
export default {
    name: 'UserList',
    data: function() {
        return {
            dateRange: [null, null],
            loading: false,
            startTime: '',
            endTime: '',
            sort: '排序', //默认
            sortNum: 1, //排序
            name: '',
            //分页数据
            pageParams: {
                currentpage: 1,
                pagesize: 10,
                total: 1
            },
            pickerOption: {
                onPick: this.refreshTable
            },
            takeAskData: [],
            //排序数据
            sortParmas: [{
                text: '订阅量',
                key: '1'
            }, {
                text: '文章数',
                key: '2'
            }, {
                text: '原创数',
                key: '3'
            }, {
                text: '总点击量',
                key: '4'
            }, {
                text: 'web点击',
                key: '5'
            }, {
                text: 'app点击',
                key: '6'
            }, {
                text: '收藏量',
                key: '7'
            }, {
                text: '评论量',
                key: '8'
            }, {
                text: '转发量',
                key: '9'
            }]
        }
    },
    created: function() {
        this.getlanmu()
    },
    methods: {
        checkAuth: function(authKey) {
            var auth = this.$root.myauth;
            var hasauth = false;
            auth.forEach(function(a) {
                if (a.indexOf(authKey) >= 0) {
                    hasauth = true;
                }
            })
            return hasauth;
        },
        //当前页变化时的回调函数。
        handlePageChange: function(currentpage) {
            this.pageParams.currentpage = currentpage;
            this.getlanmu();
        },
        //页面大小变化时的回调函数。
        handleSizeChange: function(pagesize) {
            this.pageParams.pagesize = pagesize;
            this.getlanmu();
        },
        //排序下拉菜单函数
        sortCommand: function(command) {
            var vm = this;
            var command = Number(command);
            vm.sortNum = command;
            vm.getlanmu();
        },
        //时间函数
        refreshTable: function(dateRange) {
            if (dateRange.maxDate) {
                this.startTime = dateRange.minDate.getTime();
                this.endTime = dateRange.maxDate.getTime();
            }
        },
        //查询请求,点击搜索按钮触发。
        getlanmu: function() {
            var vm = this;
            vm.loading = true;
            vhttp.get('/web/statistics/columns', {
                startTime: vm.startTime,
                endTime: vm.endTime,
                sortNum: vm.sortNum,
                name: vm.name
            }, res => {
                vm.loading = false;
                vm.takeAskData = res.data.array;
                vm.pageParams = {
                    currentpage: res.data.pageNo,
                    pagesize: res.data.pageSize,
                    total: res.data.total
                }
            })
        }
    }
}
</script>
