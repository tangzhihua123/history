<!-- 文章管理组件 -->
<template>
    <el-row>
        <h4 class="moduleTitle">文章管理</h4>
        <el-row class="m-tool-bar">
            <el-col :span="12">
                <el-select v-model="type" size="small" class="middle-select" placeholder="请选择" v-on:change="getarticle">
                    <el-option :label="video.text" :value="video.key" :key="video.key" v-for="(video,$index) in videoParmas">
                    </el-option>
                </el-select>
                <el-date-picker v-model="dateRange" type="daterange" format="yyyy-MM-dd" placeholder="起始时间－结束时间" :picker-options="pickerOption">
                </el-date-picker>
                <el-select v-model="isHide" size="small" class="middle-select" placeholder="请选择" v-on:change="getarticle">
                    <el-option label="全部状态" value="">
                    </el-option>
                    <el-option label="显示" value="0">
                    </el-option>
                    <el-option label="隐藏" value="1">
                    </el-option>
                </el-select>
            </el-col>
            <el-col :span="12" class="u-text-right">
                <el-select v-model="fieldType" size="small" class="middle-select" placeholder="搜索选项">
                    <el-option label="新闻ID" value="1">
                    </el-option>
                    <el-option label="新闻标题" value="2">
                    </el-option>
                    <el-option label="发稿人" value="3">
                    </el-option>
                </el-select>
                <el-input class="w217" v-model="search"></el-input>
                <el-button type="primary" class="u-margin-left-xs u-primary-btn" size="small" @click="getarticle">搜索</el-button>
            </el-col>
        </el-row>
        <el-col :span="24" class="u-margin-bottom-xs">
            <el-table class="m-table" style="width: 100%" :data="arttableData" v-loading.body="loading" stripe>
                <el-table-column label="序号" width="50">
                    <template scope="scope">
                        {{scope.$index | fixno(pageParams.currentpage,pageParams.pagesize)}}
                    </template>
                </el-table-column>
                <el-table-column label="排序" prop="phoneNo" width="80">
                    <template scope="scope">
                        <el-button type="text" size="mini" v-on:click="artsortexchange(scope.$index-1)">
                            <i class="el-icon-arrow-up"></i>
                        </el-button>
                        <el-button type="text" size="mini" v-on:click="artsortexchange(scope.$index)">
                            <i class="el-icon-arrow-down"></i>
                        </el-button>
                    </template>
                </el-table-column>
                <el-table-column label="新闻ID" prop="id" width="80">
                </el-table-column>
                <el-table-column label="新闻标题" prop="title">
                </el-table-column>
                <el-table-column label="状态" prop="isHide" width="80">
                    <template scope="scope">
                        <span v-if="scope.row.isHide ==1" class="text-info">隐藏</span>
                        <span v-if="scope.row.isHide ==0" class="text-info">显示</span>
                    </template>
                </el-table-column>
                <el-table-column label="类型" prop="docType" width="80">
                    <template scope="scope">
                        <span>{{colTypes[scope.row.docType]}}</span>
                    </template>
                </el-table-column>
                <el-table-column label="创建人" prop="fgdAuthorName" width="80">
                </el-table-column>
                <el-table-column label="发布时间" width="120">
                    <template scope="scope">
                        {{scope.row.publishDate | dateTimeFormat}}
                    </template>
                </el-table-column>
                <el-table-column label="操作">
                    <template scope="scope">
                        <el-button type="text" size="mini" v-show="scope.row.pushHomepageStatus !=2 " @click="pushtop(scope.row)" v-if="checkAuth(authKeyMap.push)"> 推头条</el-button>
                        <el-button type="text" size="mini" v-show="scope.abandoned != 0" @click="retraction(scope.row)" v-if="checkAuth(authKeyMap.reback)">撤稿</el-button>
                        <el-button type="text" size="mini" v-show="scope.row.isHide == 0" @click="hidearticle(scope.row)" v-if="checkAuth(authKeyMap.hideandshow)">隐藏</el-button>
                        <el-button type="text" size="mini" v-show="scope.row.isHide == 1" @click="showarticle(scope.row)" v-if="checkAuth(authKeyMap.hideandshow)">显示</el-button>
                        <el-button type="text" size="mini" @click="switchDialog(scope.row)" 
                        v-if="checkAuth(authKeyMap.sort)">排序</el-button>
                        <el-button type="text" size="mini" @click="articlecomment(scope.row)" 
                        v-if="checkAuth(authKeyMap.comment)">评论管理</el-button>
                    </template>
                </el-table-column>
            </el-table>
        </el-col>
        <el-col :span="24" class="u-padding-vertical-sm u-text-right">
            <el-pagination @size-change="handleSizeChange" @current-change="handlePageChange" :current-page="pageParams.currentpage" :page-sizes="[10, 20, 50, 100]" :page-size="pageParams.pagesize" layout="total, sizes, prev, pager, next, jumper" :total="pageParams.total">
            </el-pagination>
        </el-col>
        <el-dialog title="排序" :visible.sync="dialogFormSort">
            <el-form :model="fixedno">
                <el-form-item label="序号" :label-width="formLabelWidth">
                    <el-input v-model="fixedno.No" placeholder="请输入序号"></el-input>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" @click="fixedsort(fixedno)">确 定</el-button>
            </div>
        </el-dialog>
    </el-row>
</template>
<script>
import config from '@/config.js';
import vhttp from '@/vhttp'
import dateUtil from 'element-ui/src/utils/date';
export default {
    data: function() {
        return {
            authKeyMap:{
                push:'contentadmin.article.push',
                reback:'contentadmin.article.reback',
                sort:'contentadmin.article.sort' ,
                hideandshow:'contentadmin.article.hideandshow',
                comment:'contentadmin.comment'
            },
            videoParmas: {},
            columnId: 1,
            type: '',
            search: '',
            loading: false,
            menutitle: '操作',
            currentvideo: '栏目类别',
            show: '状态',
            newtitle: '请选择',
            colTypes: {},
            dateRange: [null, null],
            pickerOption: {
                onPick: this.refreshTable
            },
            isHide: '',
            pageParams: {
                currentpage: 1,
                pagesize: 10,
                total: 1
            },
            arttableData: [],
            dialogTableSort: false,
            dialogFormSort: false,
            fixedno: {
                No: ''
            },
            fieldType: '1',
            formLabelWidth: '120px'
        }
    },
    created: function() {
        this.getColumnList();
        this.articleTypes();
    },
    methods: {
        checkAuth: function(authKey) {
            var auth = this.$root.myauth;
            var hasauth = false;
            auth.forEach(function(a) {
                if (a.indexOf(authKey) >= 0) {
                    hasauth = true;
                }
            })
            return hasauth;
        },
        handlePageChange: function(currentpage) {
            this.pageParams.currentpage = currentpage;
            this.getarticle();
        },
        handleSizeChange: function(pagesize) {
            this.pageParams.pagesize = pagesize;
            this.getarticle();
        },
        refreshTable: function(dateRange) {
            if (dateRange.maxDate) {
                this.startTime = dateRange.minDate.getTime();
                this.endTime = dateRange.maxDate.getTime();
            }
            this.getarticle();
        },
        switchDialog: function(gn) {
            this.dialogFormSort = true;
            this.fixedno = {
                id: gn.id
            };
        },
        // 交换位置
        artsortexchange: function(idx) {
            var vm = this;
            if (idx < 0 || idx + 1 >= vm.arttableData.length) {
                vm.$message.warning('无法移动');
            } else {
                var upitem = this.arttableData[idx];
                var downitem = this.arttableData[idx + 1];
                vhttp.put('/web/columns/articles/exchangeSortNum', {
                    articleIds: [upitem.id, downitem.id].join(';')
                }, (res) => {
                    vm.getarticle();
                });
            }
        },
        getarticle: function() {
            var vm = this;
            vm.loading = true;
            vhttp.get('/web/columns/articles', {
                pageSize: vm.pageParams.pagesize,
                pageNo: vm.pageParams.currentpage,
                fieldType: vm.fieldType,
                fieldValue: vm.search,
                startTime: vm.startTime,
                endTime: vm.endTime,
                isHide: vm.isHide,
                colunmId: vm.type
            }, function(res) {
                vm.loading = false;
                vm.arttableData = res.data.array;
                vm.pageParams = {
                    currentpage: res.data.pageNo,
                    pagesize: res.data.pageSize,
                    total: res.data.total
                }
            })
        },
        // 固定排序
        putartcleid: function(gn) {
            // 没有获取id值
            var vm = this;
            vhttp.put('/web/columns/channel/articles/', {
                ids: gn.id
            }, res => {
                vm.getarticle();
            })
        },
        // 撤稿     ****************数据异常
        retraction: function(gn) {
            var vm = this;
            vhttp.delete('/web/columns/abandon/articles', {
                ids: gn.id
            }, res => {
                vm.getarticle();
            })
        },
        // 推头条
        pushtop: function(gn) {
            var vm = this;
            vhttp.put('/web/columns/channel/articles/', {
                ids: gn.id
            }, res => {
                vm.pushHomePageStatus = 2;
                vm.getarticle();
            })
        },
        //排序
        fixedsort: function(fixedno) {
            var vm = this;
            vhttp.put('/web/columns/articleId/' + vm.fixedno.id + '/palace/' + vm.fixedno.No, {
                fixedSortnum: vm.fixedno.No
            }, function(res) {
                vm.pushHomePageStatus = 2;
                vm.dialogFormSort = false;
                vm.getarticle();
            })
        },
        // 隐藏稿件
        hidearticle: function(gn) {
            var vm = this;
            vhttp.put('/web/columns/hide/articles', {
                ids: gn.id
            }, function(res) {
                gn.isHide = 1;
            })
        },
        // 显示稿件
        showarticle: function(gn) {
            var vm = this;
            vhttp.put('/web/columns/cancelhide/articles', {
                ids: gn.id
            }, function(res) {
                gn.isHide = 0;
            })
        },
        // 评论管理
        articlecomment: function(gn) {
            var vm = this;
            vhttp.get('/web/comments/article/' + gn.id, {
                pageSize: vm.pageParams.pagesize,
                pageNo: vm.pageParams.currentpage
            }, function(res) {
                vm.$router.push({
                    name: 'CommentsManagement',
                    query: {
                        title: gn.title
                    }
                });
            })
        },
        // 下拉类型列表
        articleTypes: function() {
            var vm = this;
            vhttp.get('/web/articles/dictionary/doctype/', {}, function(res) {
                var arr = [];
                for (var key in res.data) {
                    arr.push({
                        key: key,
                        text: res.data[key]
                    });
                };
                vm.colTypes = res.data;
            })
        },
        // 下拉类型列表
        getColumnList: function() {
            var vm = this;
            vhttp.get('/web/syschannel/dictionary/column', {}, function(res) {
                var arr = [];
                for (var key in res.data) {
                    arr.push({
                        key: res.data[key].id,
                        text: res.data[key].name
                    });
                };
                vm.videoParmas = arr;
                vm.type = vm.videoParmas[0].key;
                vm.getarticle();
            })
        }
    }
}
</script>
<style scoped>
.text-info {
    color: #20A0FF;
}
</style>
