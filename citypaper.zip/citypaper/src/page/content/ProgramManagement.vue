<!-- 栏目管理组件 -->
<template>
    <el-row>
        <h4 class="moduleTitle">栏目管理</h4>
        <el-row class="m-tool-bar">
            <el-col :span="12">
                <el-select v-model="status" size="small" class="small-select" placeholder="请选择" v-on:change="getprogram">
                    <el-option label="全部" value="">
                    </el-option>
                    <el-option label="上架" value="1">
                    </el-option>
                    <el-option label="下架" value="0">
                    </el-option>
                </el-select>
            </el-col>
            <el-col :span="12" class="u-text-right">
                <el-select v-model="fieldType" size="small" class="middle-select" placeholder="请选择">
                    <el-option label="栏目名称" :value="0">
                    </el-option>
                    <el-option label="栏目简介" :value="1">
                    </el-option>
                </el-select>
                <el-input class="w217" v-model="fieldValue"></el-input>
                <el-button type="primary" class="u-margin-left-xs u-primary-btn" size="small" @click="getprogram">搜索</el-button>
            </el-col>
        </el-row>
        <el-col :span="24" class="u-margin-bottom-xs">
            <el-table class="m-table" style="width: 100%" :data="programtabledata" v-loading.body="loading" stripe>
                <el-table-column label="序号" prop="id" width="80">
                    <template scope="scope">
                        {{scope.$index | fixno(pageParams.currentpage,pageParams.pagesize)}}
                    </template>
                </el-table-column>
                <el-table-column label="排序" prop="defaultSortNum" width="130" v-if="checkAuth(authKeyMap.sort)">
                    <template scope="scope">
                        <el-button type="text" size="mini" v-on:click="prosortexchange(scope.$index-1)">
                            <i class="el-icon-arrow-up"></i>
                        </el-button>
                        <el-button type="text" size="mini" v-on:click="prosortexchange(scope.$index)">
                            <i class="el-icon-arrow-down"></i>
                        </el-button>
                    </template>
                </el-table-column>
                <el-table-column label="栏目名称" prop="name" width="130">
                </el-table-column>
                <el-table-column label="简介" prop="description">
                </el-table-column>
                <el-table-column label="操作">
                    <template scope="scope">
                        <el-button type="text" size="mini" @click="redactprogramform(scope.row)" v-if="checkAuth(authKeyMap.edit)">编辑</el-button>
                        <el-button type="text" size="mini" @click="Putaway(scope.row)" v-show="scope.row.status == 0" v-if="checkAuth(authKeyMap.upanddown)">上架</el-button>
                        <el-button type="text" size="mini" @click="soldout(scope.row)" v-show="scope.row.status == 1" v-if="checkAuth(authKeyMap.upanddown)">下架</el-button>
                        <el-button type="text" size="mini" @click="switchDialog(scope.row)" v-if="checkAuth(authKeyMap.sort)">排序</el-button>
                    </template>
                </el-table-column>
            </el-table>
        </el-col>
        <!-- 排序弹出框 start -->
        <el-dialog title="排序" :visible.sync="dialogformrank" size="mini">
            <el-form :model="sort">
                <el-form-item label="序号" :label-width="70">
                    <el-input v-model="sort.No" placeholder="请输入序号"></el-input>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="dialogformrank = false">取 消</el-button>
                <el-button type="primary" @click="fixedsort(sort)">确 定</el-button>
            </div>
        </el-dialog>
        <!-- 排序弹出框 end -->
        <!-- 编辑弹出框 start -->
        <el-dialog class="u-dialog" title="栏目编辑" :visible.sync="dialogredactprogram">
            <el-form :model="redactform">
                <el-form-item label="栏目名称:" :label-width="formLabelWidth">
                    <span >{{redactform.name}}</span>
                </el-form-item>
                <el-form-item label="简介:" :label-width="formLabelWidth">
                    <el-input type="textarea" v-model="redactform.description" :autosize="{ minRows: 8, maxRows: 10}"></el-input>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="dialogredactprogram = false">取 消</el-button>
                <el-button type="primary" @click="redactsure()">确 定</el-button>
            </div>
        </el-dialog>
        <!-- 编辑弹出框 end -->
        <el-col :span="24" class="u-padding-vertical-sm u-text-right">
            <el-pagination @size-change="handleSizeChange" @current-change="handlePageChange" :current-page="pageParams.currentpage" :page-sizes="[10, 20, 50, 100]" :page-size="pageParams.pagesize" layout="total, sizes, prev, pager, next, jumper" :total="pageParams.total">
            </el-pagination>
        </el-col>
    </el-row>
</template>
<script>
import config from '@/config.js';
import vhttp from '@/vhttp'
import dateUtil from 'element-ui/src/utils/date';
export default {
    data: function() {
        return {
            authKeyMap:{
                sort:'contentadmin.program.sort',
                edit:'contentadmin.program.edit',
                upanddown:'contentadmin.program.updown' 
            },
            dateV: '',
            loading: false,
            value: '',
            newtitle: '栏目名称',
            fieldValue: '',
            fieldType: 0,
            sort: {
                No: ''
            },
            pageParams: {
                currentpage: 1,
                pagesize: 10,
                total: 1
            },
            status: '',
            sortNum: 1,
            orderingrule: [{
                text: 'PU',
                key: '1'
            }, {
                text: 'UV',
                key: '2'
            }, {
                text: '收藏量',
                key: '3'
            }, {
                text: '点赞数',
                key: '4'
            }, {
                text: '评论量',
                key: '5'
            }, {
                text: '转发量',
                key: '6'
            }],
            redactform: {
                name: '',
                description: ''
            },
            programtabledata: [],
            dialogTableRank: false,
            dialogformrank: false,
            putprogramalterdialog: false,
            dialogredactprogram: false,
            form: {
                No: ''
            },
            formLabelWidth: '80px'
        }
    },
    created: function() {
        this.getprogram()
    },
    methods: {
        checkAuth: function(authKey) {
            var auth = this.$root.myauth;
            var hasauth = false;
            auth.forEach(function(a) {
                if (a.indexOf(authKey) >= 0) {
                    hasauth = true;
                    console.log(a);
                }
            })
            return hasauth;
        },
        handlePageChange: function(currentpage) {
            this.pageParams.currentpage = currentpage;
            this.getprogram();
        },
        handleSizeChange: function(pagesize) {
            this.pageParams.pagesize = pagesize;
            this.getprogram();
        },
        soldout: function(gn) {
            var vm = this;
            vm.$confirm('是否确认下架?', '信息确认', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                vhttp.put('/web/syschannel/down/columns/' + gn.id, {}, res => {
                    gn.status = 1;
                    vm.getprogram();
                    vm.$message({
                        type: 'success',
                        message: '下架成功!'
                    });
                })
            }, () => {
                vm.$message({
                    type: 'success',
                    message: '取消下架!'
                });
            }).catch(() => {
                vm.$message({
                    type: 'info',
                    message: '下架失败'
                });
            });
        },
        Putaway: function(gn) {
            var vm = this;
            vm.$confirm('是否确认上架?', '信息确认', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                vhttp.put('/web/syschannel/put/columns/' + gn.id, {}, res => {
                    gn.status = 0;
                    vm.$message({
                        type: 'success',
                        message: '上架成功!'
                    });
                    vm.getprogram();
                })
            }, () => {
                vm.$message({
                    type: 'info',
                    message: '取消上架!'
                });
            }).catch(() => {
                vm.$message({
                    type: 'danger',
                    message: '上架失败'
                });
            });
        },
        Sortlist: function(command) {
            var vm = this;
            var command = Number(command);
            vm.sortNum = command;
            console.log(command)
            vm.getprogram();
        },
        getprogram: function() {
            var vm = this;
            var keyword = vm.fieldValue.trim();
            vhttp.get('/web/syschannel/normal/columns', {
                pageSize: vm.pageParams.pagesize,
                pageNo: vm.pageParams.currentpage,
                putstatus: vm.status,
                fieldType: keyword ? vm.fieldType : '',
                fieldValue: keyword
            }, function(res) {
                vm.programtabledata = res.data.array;
                vm.pageParams = {
                    currentpage: res.data.pageNo,
                    pagesize: res.data.pageSize,
                    total: res.data.total
                }
            })
        },
        // 交换位置
        prosortexchange: function(idx) {
            var vm = this;
            if (idx < 0 || idx + 1 >= vm.programtabledata.length) {
                vm.$message.warning('无法移动');
            } else {
                var upitem = this.programtabledata[idx];
                var downitem = this.programtabledata[idx + 1];
                vhttp.put('/web/syschannel/position/exchange', {
                    ids: [upitem.id, downitem.id].join(';')
                }, (res) => {
                    vm.getprogram();
                });
            }
        },
        // 栏目修改，编辑    
        redactprogramform: function(gn) {
            var vm = this;
            vm.redactform = {
                id: gn.id,
                name: gn.name,
                description: gn.description
            };
            vm.dialogredactprogram = true;
        },
        //修改后发起保存数据请求
        redactsure: function() {
            var vm = this;
            vhttp.put('/web/syschannel/edit/columns/' + vm.redactform.id, {
                description: vm.redactform.description
            }, function(res) {
                vm.dialogredactprogram = false;
                vm.getprogram();
            })
        },
        // 固定排序
        switchDialog: function(gn) {
            this.dialogformrank = true;
            this.sort = {
                id: gn.id
            };
        },
        fixedsort: function(sort) {
            var vm = this;
            vhttp.put('/web/syschannel/change/' + vm.sort.id + '/palace/' + vm.sort.No, {}, function(res) {
                vm.dialogformrank = false;
                vm.getprogram();
            })
        }
    }
}
</script>
<style scoped>
.showOr {
    display: none;
}
</style>
