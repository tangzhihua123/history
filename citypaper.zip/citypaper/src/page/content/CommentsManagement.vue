<!-- 评论管理组件 -->
<template>
    <el-row>
        <h4 class="moduleTitle">评论管理</h4>
        <el-row class="m-tool-bar">
            <el-col :span="12">
                <el-select v-model="selectDay" size="small" class="middle-select" placeholder="审核状态" v-on:change="refreshComment">
                    <el-option label="全部时间" value="">
                    </el-option>
                    <el-option label="最近一天" :value="1">
                    </el-option>
                    <el-option label="最近三天" :value="3">
                    </el-option>
                    <el-option label="最近一个月" :value="30">
                    </el-option>
                </el-select>
                <el-select v-model="checkStatus" size="small" class="middle-select" placeholder="审核状态" v-on:change="refreshComment">
                    <el-option label="全部" value="">
                    </el-option>
                    <el-option label="已审核" :value="1">
                    </el-option>
                    <el-option label="未审核" :value="0">
                    </el-option>
                </el-select>
                <el-select v-model="type" size="small" class="middle-select" placeholder="请选择" v-on:change="refreshComment">
                    <el-option label="全部栏目" value="">
                    </el-option>
                    <el-option :label="video.text" :value="video.key" :key="video.key" v-for="(video,$index) in videoParmas">
                    </el-option>
                </el-select>
            </el-col>
            <el-col :span="12" class="u-text-right">
                <el-select v-model="fieldType" size="small" class="middle-select" placeholder="请选择" v-on:change="refreshComment">
                    <el-option label="新闻标题" :value="2">
                    </el-option>
                    <el-option label="评论内容" :value="1">
                    </el-option>
                </el-select>
                <el-input class="w217" v-model="search"></el-input>
                <el-button type="primary" class="u-margin-left-xs u-primary-btn" size="small" @click="refreshComment">搜索</el-button>
            </el-col>
        </el-row>
        <el-col :span="24" class="u-margin-bottom-xs">
            <el-table class="m-table" style="width: 100%" :data="commentchart" v-loading.body="loading" stripe ref="multipleTable">
                <el-table-column label="选择" prop="id" width="60" v-if="checkAuth(authKeyMap.delete)||checkAuth(authKeyMap.pass)">
                    <template scope="scope">
                        <el-checkbox v-model="commentchart[scope.$index].checked" @change="switchCheck"></el-checkbox>
                    </template>
                </el-table-column>
                <el-table-column label="文章ID" prop="sourceId" width="60">
                </el-table-column>
                <el-table-column label="评论内容" prop="content" width="200" :show-overflow-tooltip="true">
                </el-table-column>
                <el-table-column label="评论用户"  width="70" :show-overflow-tooltip="true">
                    <template scope="scope">
                        <span class="text-info">
                          {{scope.row.commentUserNickname}} 
                        </span>
                    </template>
                </el-table-column>
                <el-table-column label="新闻标题" prop="title">
                </el-table-column>
                <el-table-column label="栏目" prop="columnName">
                </el-table-column>
                <el-table-column label="发布时间" prop="publicTime" width="120">
                    <template scope="scope">
                        {{scope.row.publicTime | dateTimeFormat}}
                    </template>
                </el-table-column>
                <el-table-column label="发布人" prop="fgdAuthorName" width="70">
                </el-table-column>
                <el-table-column label="状态" prop="checkStatus" width="60">
                    <template scope="scope">
                        <span v-if="scope.row.checkStatus == 0" class="text-info">未审核</span>
                        <span v-if="scope.row.checkStatus == 1" class="text-info">已审核</span>
                        <span v-if="scope.row.checkStatus == 2" class="text-info">审核不通过</span>
                        <span v-if="scope.row.checkStatus == 3" class="text-info">删除</span>
                    </template>
                </el-table-column>
                <el-table-column label="操作" width="120">
                    <template scope="scope">
                        <el-button type="text" size="mini" v-show="scope.row.checkStatus ==0" @click="passcomments(scope)" v-if="checkAuth(authKeyMap.pass)">审核
                        </el-button>
                        <el-button type="text" size="mini" v-show="scope.row.checkStatus != 3" @click="deleteComment(scope)" v-if="checkAuth(authKeyMap.delete)">删除
                        </el-button>
                    </template>
                </el-table-column>
                <tr class="el-table__row" slot="append" v-show="commentchart.length" v-if="checkAuth(authKeyMap.delete)||checkAuth(authKeyMap.pass)">
                    <td class="el-table_1_column_1">
                        <div class="cell">
                            <span class="Selectall">全选</span>
                            <el-checkbox v-model="checkAll" @change="switchAllcheck" :indeterminate="isIndeterminate"></el-checkbox>
                        </div>
                    </td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td class="el-table_1_column_1">
                        <div class="cell">
                            <el-button type="text" @click="allpass" class="newel-button" v-if="checkAuth(authKeyMap.pass)">通过</el-button>
                            <el-button type="text" @click="alldelete" class="via" v-if="checkAuth(authKeyMap.delete)">删除</el-button>
                        </div>
                    </td>
                </tr>
            </el-table>
        </el-col>
        <el-col :span="24" class="u-padding-vertical-sm u-text-right">
            <el-pagination @size-change="handleSizeChange" @current-change="handlePageChange" :current-page="pageParams.currentpage" :page-sizes="[10, 20, 50, 100]" :page-size="pageParams.pagesize" layout="total, sizes, prev, pager, next, jumper" :total="pageParams.total">
            </el-pagination>
        </el-col>
        <el-dialog title="审核评论" :visible.sync="dialog4passcomment">
            <el-form>
                <el-form-item label="新闻标题:">
                    <span>{{comment.title}}</span>
                </el-form-item>
                <el-form-item label="评论内容:">
                    <span>{{comment.content}}</span>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button type="danger" class="pull-left" @click="putnopasscom(comment)">不通过</el-button>
                <el-button @click="dialog4passcomment = false">取 消</el-button>
                <el-button type="primary" @click="putpasscom(comment)">通 过</el-button>
            </div>
        </el-dialog>
    </el-row>
</template>
<script>
import config from '@/config.js';
import vhttp from '@/vhttp'
import dateUtil from 'element-ui/src/utils/date';
export default {
    data: function() {
        return {
            authKeyMap:{ 
                pass:'contentadmin.comment.pass',
                delete:'contentadmin.comment.delete' 
            },
            search: '',
            loading: false,
            checkAll: false,
            value: '',
            videoParmas: {},
            type: '',
            selectDay: '',
            checkStatus: '',
            multipleTable: [], //全选取消
            pageParams: {
                currentpage: 1,
                pagesize: 10,
                total: 1
            },
            fieldType: 2,
            isIndeterminate: false,
            commentchart: [],
            comment: '',
            dialog4passcomment: false
        }
    },
    created: function() {
        // console.log(this.$route.query)search
        if (this.$route.query.title) {
            this.search = this.$route.query.title;
            this.refresh();
        } else {

            this.getcomments();
        };
        this.articleTypes();
    },
    methods: {
        checkAuth: function(authKey) {
            var auth = this.$root.myauth;
            var hasauth = false;
            auth.forEach(function(a) {
                if (a.indexOf(authKey) >= 0) {
                    hasauth = true;
                }
            })
            return hasauth;
        },
        handlePageChange: function(currentpage) {
            this.pageParams.currentpage = currentpage;
            this.getcomments();
        },
        handleSizeChange: function(pagesize) {
            this.pageParams.pagesize = pagesize;
            this.getcomments();
        },
        refreshComment: function() {
            this.handlePageChange(1);
        },
        // 搜索框放值
        refresh: function() {
            var vm = this;
            vm.fieldType = 2;
            vm.content = '新闻标题';
            vm.getcomments();
        },
        switchAllcheck: function() {
            var vm = this;
            vm.commentchart.forEach(function(item) {
                item.checked = vm.checkAll;
            })
        },
        switchCheck: function(e) {
            var vm = this;
            var checkedCount = 0;
            vm.commentchart = vm.commentchart.map(function(item) {
                if (item.checked) checkedCount = checkedCount + 1;
                return item;
            });
            vm.checkAll = checkedCount === vm.commentchart.length;
            vm.isIndeterminate = checkedCount > 0 && checkedCount < vm.commentchart.length;
        },
        //删除     
        deleteComment: function(scope) {
            var vm = this;
            vm.$confirm('确认删除该条评论?', '信息确认', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                vm.dodeletecom(scope);
                vm.$message({
                    type: 'success',
                    message: '删除成功!'
                });
            })
        },
        // 批量通过
        allpass: function() {
            var vm = this;
            var idsList = [];
            vm.commentchart.forEach(function(item) {
                if (item.checked) {
                    idsList.push(item.id);
                }
            });
            if (idsList.length) {
                var arr = idsList.join(';');
                vhttp.get('/web/comments/audit/pass', {
                    ids: arr
                }, (response) => {
                    response.stutas = 1;
                    vm.getcomments();
                })
            } else {
                vm.$message({
                    type: 'warning',
                    message: '未选中任何评论!'
                });

            }
        },
        //批量删除
        alldelete: function() {
            var vm = this;
            var idsList = [];
            vm.commentchart.forEach(function(item) {
                if (item.checked) {
                    idsList.push(item.id);
                }
            });
            if (idsList.length) {
                var arr = idsList.join(';');
                vhttp.put('/web/comments/audit/del?ids=' + arr, {}, function(res) {
                    res.stutas = 1;
                    vm.getcomments();
                })
            } else {
                vm.$message({
                    type: 'warning',
                    message: '未选中任何评论!'
                });

            }
        },
        plate: function(command) {
            this.column = command;
        },
        getcomments: function() {
            var vm = this;
            vhttp.get('/web/comments', {
                pageSize: vm.pageParams.pagesize,
                pageNo: vm.pageParams.currentpage,
                fieldType: vm.fieldType,
                fieldValue: vm.search,
                selectDay: vm.selectDay,
                checkStatus: vm.checkStatus,
                columnId: vm.type
            }, function(res) {
                vm.commentchart = res.data.array.map(function(item) {
                    item.checked = false;
                    return item;
                });
                vm.checkAll = false;
                vm.pageParams = Object.assign(vm.pageParams, {
                    pagesize: res.data.pageSize,
                    total: res.data.total
                })
            })
        },
        // 通过
        passcomments: function(scope) {
            var vm = this;
            vm.comment = scope.row;
            vm.dialog4passcomment = true;
        },
        //通过
        putpasscom: function(comment) {
            var vm = this;
            vhttp.get('/web/comments/audit/pass', {
                ids: comment.id
            }, (response) => {
                vm.dialog4passcomment = false;
                vm.$message({
                    type: 'info',
                    message: '审核评论成功!'
                });
                vm.getcomments();
            })
        },
        // 审核不通过
        putnopasscom: function(comment) {
            var vm = this;
            vhttp.get('/web/comments/audit/nonpass', {
                ids: comment.id
            }, (response) => {
                vm.dialog4passcomment = false;
                vm.$message({
                    type: 'info',
                    message: '审核评论成功!'
                });
                vm.getcomments();
            })
        },
        // 删除
        dodeletecom: function(scope) {
            var vm = this;
            vhttp.put('/web/comments/audit/del?ids=' + scope.row.id, {}, function(res) {
                res.stutas = 3;
                vm.getcomments();
            })
        },
        // 下拉类型列表
        articleTypes: function() {
            var vm = this;
            vhttp.get('/web/syschannel/dictionary/column', {}, function(res) {
                var arr = [];
                for (var key in res.data) {
                    arr.push({
                        key: res.data[key].id,
                        text: res.data[key].name
                    });
                };
                vm.videoParmas = arr;
            })
        }
    }
}
</script>
<style>
.via {
    padding-right: 2.5%;
    font-size: 12px;
}

.newel-button {
    padding: 7px 7px 7px 8px;
}

.text-info {
    color: #20A0FF;
}
</style>
