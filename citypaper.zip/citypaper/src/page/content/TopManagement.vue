<!-- 头条管理组件 -->
<template>
    <el-row>
        <h4 class="moduleTitle">头条管理</h4>
        <el-row class="m-tool-bar">
            <el-col :span="12">
                <el-date-picker v-model="dateRange" type="daterange" format="yyyy-MM-dd" placeholder="起始时间－结束时间" :picker-options="pickerOption">
                </el-date-picker>
            </el-col>
            <el-col :span="12" class="u-text-right">
                <el-select v-model="fieldType" size="small" class="middle-select" placeholder="搜索选项">
                    <el-option label="新闻ID" value="1">
                    </el-option>
                    <el-option label="新闻标题" value="2">
                    </el-option>
                    <el-option label="发稿人" value="3">
                    </el-option>
                </el-select> 
                <el-input class="w217" v-model="search"></el-input>
                <el-button type="primary" class="u-margin-left-xs u-primary-btn" size="small" @click="gettop">搜索</el-button>
            </el-col>
        </el-row>
        <el-col :span="24" class="u-margin-bottom-xs">
            <el-table class="m-table" style="width: 100%" :data="topchart" v-loading.body="loading" stripe>
                <el-table-column label="序号" width="60">
                    <template scope="scope">
                        {{scope.$index | fixno(pageParams.currentpage,pageParams.pagesize)}}
                    </template>
                </el-table-column>
                <el-table-column label="排序" prop="phoneNo" width="100">
                    <template scope="scope">
                        <el-button type="text" size="mini">
                            <i class="el-icon-arrow-up" v-on:click="sortGovNotice(scope.$index-1)" style="padding-right:5px"></i>
                            <i class="el-icon-arrow-down" v-on:click="sortGovNotice(scope.$index)"></i>
                        </el-button>
                    </template>
                </el-table-column>
                <el-table-column label="新闻ID" prop="articleId" width="50">
                </el-table-column>
                <el-table-column label="新闻标题" prop="articleTitle">
                </el-table-column>
                <el-table-column label="状态" prop="phoneEmail" width="50">
                    <template scope="scope">
                        <span v-show="scope.row.isHide ==1">隐藏</span>
                        <span v-show="scope.row.isHide ==0">显示</span>
                    </template>
                </el-table-column>
                <el-table-column label="类型" prop="createTime" width="50">
                    <template scope="scope">
                        <span>{{colTypes[scope.row.docType]}}</span>
                    </template>
                </el-table-column>
                <el-table-column label="创建人" prop="fgdAuthorName" width="120">
                </el-table-column>
                <el-table-column label="发布时间" width="120">
                    <template scope="scope">
                        {{scope.row.publishDate | dateTimeFormat}}
                    </template>
                </el-table-column>
                <el-table-column label="操作">
                    <template scope="scope">
                        <el-button type="text" size="mini" @click="retraction(scope.row)"  v-if="checkAuth(authKeyMap.reback)">撤稿</el-button>
                        <el-button type="text" size="mini" v-show="scope.row.isHide == 0" @click="tophide(scope.row)" v-if="checkAuth(authKeyMap.hideandshow)">隐藏</el-button>
                        <el-button type="text" size="mini" v-show="scope.row.isHide == 1" @click="topshow(scope.row)" v-if="checkAuth(authKeyMap.hideandshow)">显示</el-button>
                        <el-button type="text" size="mini" @click="switchDialog(scope.row)" v-if="checkAuth(authKeyMap.sort)">排序</el-button>
                        <el-button type="text" size="mini" @click="articlecomment(scope.row)" v-if="checkAuth(authKeyMap.comment)">评论管理</el-button>
                    </template>
                </el-table-column>
            </el-table>
        </el-col>
        <el-col :span="24" class="u-padding-vertical-sm u-text-right">
            <el-pagination @size-change="handleSizeChange" @current-change="handlePageChange" :current-page="pageParams.currentpage" :page-sizes="[10, 20, 50, 100]" :page-size="pageParams.pagesize" layout="total, sizes, prev, pager, next, jumper" :total="pageParams.total">
            </el-pagination>
        </el-col>
        <el-dialog title="排序" :visible.sync="dialogFormSort">
            <el-form :model="fixedno">
                <el-form-item label="序号" :label-width="formLabelWidth">
                    <el-input v-model="fixedno.No" placeholder="请输入序号"></el-input>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" @click="fixedsort(fixedno)">确 定</el-button>
            </div>
        </el-dialog>
    </el-row>
</template>
<script>
import config from '@/config.js';
import vhttp from '@/vhttp'
import dateUtil from 'element-ui/src/utils/date';
export default {
    data: function() {
        return {
            authKeyMap:{
                reback:'contentadmin.topnews.reback', 
                sort:'contentadmin.topnews.sort' ,
                hideandshow:'contentadmin.topnews.hideandshow',
                comment:'contentadmin.comment'
            },
            search: '',
            dateV: '',
            loading: false,
            newtitle: '请选择',
            operate: '操作',
            fieldType:'',
            dateRange: [null, null],
            pickerOption: {
                onPick: this.refreshTable
            },
            status: '',
            pageParams: {
                currentpage: 1,
                pagesize: 10,
                total: 1
            },
            dialogTableSort: false,
            dialogFormSort: false,
            fixedno: {
                No: ''
            },
            colTypes: {},
            formLabelWidth: '120px',
            topchart: []
        }
    },
    created: function() {
        this.gettop();
        this.articleTypes();
    },
    methods: {
        checkAuth: function(authKey) {
            var auth = this.$root.myauth;
            var hasauth = false;
            auth.forEach(function(a) {
                if (a.indexOf(authKey) >= 0) {
                    hasauth = true;
                }
            })
            return hasauth;
        },
        handlePageChange: function(currentpage) {
            this.pageParams.currentpage = currentpage;
            this.gettop();
        },
        handleSizeChange: function(pagesize) {
            this.pageParams.pagesize = pagesize;
            this.gettop();
        },
        refreshTable: function(dateRange) {
            if (dateRange.maxDate) {
                this.startTime = dateRange.minDate.getTime();
                this.endTime = dateRange.maxDate.getTime();
            }
            this.gettop();
        },
        switchDialog: function(row) {
            this.dialogFormSort = true;
            this.fixedno = {
                articleId: row.articleId
            };
        },
        gettop: function() {
            var vm = this;
            vhttp.get('/web/channel/articles', {
                pageSize: vm.pageParams.pagesize,
                pageNo: vm.pageParams.currentpage,
                fieldType: vm.fieldType,
                fieldValue: vm.search,
                startTime: vm.startTime,
                endTime: vm.endTime,
                status: vm.status
            }, function(res) {
                vm.topchart = res.data.array;
                vm.pageParams = {
                    currentpage: res.data.pageNo,
                    pagesize: res.data.pageSize,
                    total: res.data.total
                };
            })
        },
        // 交换位置
        sortGovNotice: function(idx) {
            var vm = this;
            var upitem = this.topchart[idx];
            var downitem = this.topchart[idx + 1];
            vhttp.put('/web/channel/exchange/articles', {
                articleIds: [upitem.articleId, downitem.articleId].join(';')
            }, (res) => {
                vm.gettop();
            });
        },
        // 隐藏头条
        tophide: function(gn) {
            var vm = this;
            vhttp.put('/web/channel/hide/articles', {
                articleIds: gn.articleId
            }, function(res) {
                gn.isHide = 1;
            })
        },
        // 取消隐藏
        topshow: function(gn) {
            var vm = this;
            vhttp.put('/web/columns/cancelhide/articles', {
                ids: gn.articleId
            }, function(res) {
                gn.isHide = 0;
            })
        },
        // 撤稿
        retraction: function(gn) {
            var vm = this;
            vhttp.delete('/web/channel/abandon/articles', {
                articleIds: gn.articleId
            }, function(res) {
                vm.gettop();
            })
        },
        //头条固定排序
        fixedsort: function(fixedno) {
            var vm = this;
            vhttp.put('/web/channel/articleId/' + vm.fixedno.articleId + '/palace/' + vm.fixedno.No, {}, function(res) {
                vm.dialogFormSort = false;
                vm.gettop();
            })
        },
        // 评论管理
        articlecomment: function(gn) {
            var vm = this;
            vhttp.get('/web/comments/article/' + gn.id, {
                pageSize: vm.pageParams.pagesize,
                pageNo: vm.pageParams.currentpage
            }, function(res) {
                vm.$router.push({
                    name: 'CommentsManagement',
                    query: {
                        title: gn.articleTitle
                    }
                });
            })
        },
        articleTypes: function() {
            var vm = this;
            vhttp.get('/web/articles/dictionary/doctype/', {}, function(res) {
                vm.colTypes = res.data;
            })
        }
    }
}
</script>
<style scope>
.text-info {
    color: #20A0FF;
}
</style>
