<!-- 版本管理组件 -->
<template>
    <el-row>
        <h4 class="moduleTitle">版本管理</h4>
        <el-row class="m-tool-bar">
            <el-col :span="24">
                <el-button type="primary" class="u-margin-left-xs u-primary-btn" size="small" @click="showFormVersion" v-if="checkAuth(authKeyMap.create)">新增版本</el-button>  
                <template>
                    <el-select v-model="phoneType" v-on:change="selectPhoneType" class="middle-select"  placeholder="请选择">
                        <el-option v-for="item in options" :label="item.label" :value="item.value" :key="item.label">
                        </el-option>
                    </el-select>
                </template>
            </el-col>
        </el-row>
        <el-col :span="24" class="u-margin-bottom-xs">
            <el-table class="m-table" style="width: 100%" :data="versionchart" v-loading.body="loading" stripe>
                <el-table-column prop="os" label="系统" width="120">
                    <template scope="scope">
                        <el-tag :type="scope.row.os === 'IOS' ? 'primary' : 'success'" close-transition>{{scope.row.os}}</el-tag>
                    </template>
                </el-table-column>
                <el-table-column label="版本号" prop="version">
                </el-table-column>
                <el-table-column label="发布日期" prop="createTime">
                    <template scope="scope">
                        {{scope.row.createTime | dateTimeFormat}}
                    </template>
                </el-table-column>
                <el-table-column label="强制升级" prop="isForce">
                    <template scope="scope">
                        {{scope.row.isForce?'是':'否'}}
                    </template>
                </el-table-column>
                <el-table-column label="升级说明" prop="updateDescription">
                    <template scope="scope">
                        可兼容最低版本:{{scope.row.minVersion}}
                    </template>
                </el-table-column>
                <el-table-column label="下载地址" prop="downloadUrl" width="120">
                </el-table-column>
                <el-table-column label="版本说明" prop="description" width="120">
                </el-table-column>
                <el-table-column label="操作" v-if="checkAuth(authKeyMap.edit)">
                    <template scope="scope">
                        <el-button type="text" size="mini" @click="amendver(scope.row)">修改
                        </el-button>
                    </template>
                </el-table-column>
            </el-table>
        </el-col>
        <!--  底部分页 -->
        <el-col :span="24" class="u-padding-vertical-sm u-text-right">
            <el-pagination @size-change="handleSizeChange" @current-change="handlePageChange" :current-page="pageParams.currentpage" :page-sizes="[10, 20, 50, 100]" :page-size="pageParams.pagesize" layout="total, sizes, prev, pager, next, jumper" :total="pageParams.total">
            </el-pagination>
        </el-col>
        <!--start 弹出框 -->
        <el-dialog :title="titleName" :visible.sync="dialogFormVersion">
            <el-form label-position="left" :model="newversion" :rules="versonrules" ref="newversionForm">
                <el-form-item label="系统" :label-width="formLabelWidth" prop="os">
                    <el-select v-model="newversion.os" placeholder="系统" @change="getMinversion">
                        <el-option label="IOS" value="0"></el-option>
                        <el-option label="Android" value="1"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="版本号" :label-width="formLabelWidth" prop="version">
                    <el-input v-model="newversion.version" placeholder="请输入版本号"></el-input>
                </el-form-item>
                <el-form-item label="下载地址" :label-width="formLabelWidth" prop="downloadUrl">
                    <el-input v-model="newversion.downloadUrl" placeholder="请输入下载地址"></el-input>
                </el-form-item>
                <el-form-item label="版本说明" :label-width="formLabelWidth" prop="description">
                    <el-input type="textarea" :autosize="{ minRows: 2, maxRows: 4}" placeholder="请输入内容" v-model="newversion.description">
                    </el-input>
                </el-form-item>
                <el-form-item label="可兼容最低版本" :label-width="formLabelWidth" prop="minVersion">
                    <el-select v-model="newversion.minVersion" filterable placeholder="请选择">
                        <el-option v-if="newversion.version" :label="newversion.version" :value="newversion.version"></el-option>
                        <el-option v-for="item in versionopts" :key="item.value" :label="item.label" :value="item.value">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="强制升级" :label-width="formLabelWidth">
                    <el-switch v-model="newversion.isForce" on-color="#13ce66" off-color="#ff4949" :on-value="1" :off-value="0" on-text="是" off-text="否">
                    </el-switch>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="dialogFormVersion = false;">取 消</el-button>
                <el-button type="primary" @click="postversion()">确 定</el-button>
            </div>
        </el-dialog>
        <!--end 新建弹出框 -->
    </el-row>
</template>
<script>
import vhttp from '@/vhttp'
import dateUtil from 'element-ui/src/utils/date';
export default {
    name: 'UserList',
    data: function() {
        return { 
            authKeyMap: {
                create: 'version.create',
                edit: 'version.edit' 
            },
            loading: false,
            //分页数据
            pageParams: {
                currentpage: 1,
                pagesize: 10,
                total: 1
            },
            versionopts: [],
            //下拉框数据
            options: [{
                value: '',
                label: '全部'
            }, {
                value: '0',
                label: 'IOS'
            }, {
                value: '1',
                label: 'ANDROID'
            }],
            phoneType: '',
            versionchart: [],
            dialogVersion: false,
            dialogTableVersion: false,
            dialogFormVersion: false,
            newversion: {
                os: '',
                version: '',
                downloadUrl: '',
                description: '',
                minVersion: '',
                isForce: 0
            },
            //新建版本表单校验规则
            versonrules: {
                os: [{
                    required: true,
                    message: '请选择系统',
                    trigger: 'change'
                }],
                version: [{
                    required: true,
                    message: '请输入版本号',
                    trigger: 'blur'
                }],
                downloadUrl: [{
                    required: true,
                    message: '请输入下载地址',
                    trigger: 'blur'
                }, {
                    type: 'url',
                    message: '请输入正确的链接地址',
                    trigger: 'blur,change'
                }],
                description: [{
                    required: true,
                    message: '请输入版本说明',
                    trigger: 'blur'
                }],
                minVersion: [{
                    required: true,
                    message: '请选择可兼容最低版本',
                    trigger: 'change'
                }]
            },
            formLabelWidth: '125px'
        }
    },
    computed: {
        titleName: function() {
            return (this.newversion.id ? '修改' : '新建') + '版本'
        }
    },
    created: function() {
        this.getversion();
    },
    methods: {
        checkAuth: function(authKey) {
            var auth = this.$root.myauth;
            var hasauth = false;
            auth.forEach(function(a) {
                if (a.indexOf(authKey) >= 0) {
                    hasauth = true;
                }
            })
            return hasauth;
        },
        //当前页变化时的回调函数。
        handlePageChange: function(currentpage) {
            this.pageParams.currentpage = currentpage;
            this.getversion();
        },
        //页面大小变化时的回调函数。
        handleSizeChange: function(pagesize) {
            this.pageParams.pagesize = pagesize;
            this.getversion();
        },
        //下拉菜单事件
        selectPhoneType: function() {
            this.getversion();
        },
        getMinversion: function(id) {
            var vm = this;
            vhttp.get('/web/version/minVersion', {
                os: id
            }, res => {
                vm.versionopts = res.data.map(function(o) {
                    return {
                        label: o,
                        value: o
                    }
                });
            });
        },
        //查询
        getversion: function() {
            var vm = this;
            vhttp.get('/web/version/list', {
                pageSize: vm.pageParams.pagesize,
                pageNo: vm.pageParams.currentpage,
                os: vm.phoneType
            }, res => {
                vm.versionchart = res.data.array;
                vm.pageParams = {
                    currentpage: res.data.pageNo ? res.data.pageNo : 1,
                    pagesize: res.data.pageSize,
                    total: res.data.total
                };
            })
        },
        // 新建版本  
        postversion: function() {
            var vm = this;
            this.$refs.newversionForm.validate((valid) => {
                if (valid) {
                    if (vm.newversion.id) { 
                        vhttp.put('/web/version/' + vm.newversion.id, {
                            os: vm.newversion.os,
                            version: vm.newversion.version,
                            downloadUrl: vm.newversion.downloadUrl,
                            description: vm.newversion.description,
                            minVersion: Number(vm.newversion.minVersion),
                            isForce: vm.newversion.isForce
                        }, res => {
                            vm.dialogFormVersion = false;
                            vm.getversion();
                        })
                    } else {
                        vhttp.post('/web/version/add', {
                            os: vm.newversion.os,
                            version: vm.newversion.version,
                            downloadUrl: vm.newversion.downloadUrl,
                            description: vm.newversion.description,
                            minVersion: vm.newversion.minVersion,
                            isForce: vm.newversion.isForce
                        }, res => {
                            vm.getversion();
                            vm.dialogFormVersion = false;
                        })
                    }
                } else {
                    vm.$message.error('表单有误,请检查后重新提交');
                    return false;
                }
            });
        },
        // 修改版本   
        amendver: function(gn) {
            var vm = this;
            if (this.$refs.dilogVersionForm) {
                this.$refs.dilogVersionForm.resetFields();
            }
            // vm.dialogVersion = true;
            vm.dialogFormVersion = true;
            var osM = {
                'IOS': '0',
                'ANDROID': '1'
            }
            vm.newversion = {
                id: gn.id,
                os: osM[gn.os],
                version: gn.version,
                downloadUrl: gn.downloadUrl,
                description: gn.description,
                minVersion: gn.minVersion,
                isForce: gn.isForce
            }
            vm.getMinversion(osM[gn.os]);
        },
        showFormVersion() {
            if (this.$refs.newversionForm) {
                this.$refs.newversionForm.resetFields();
            }
            this.newversion = {
                os: '',
                version: '',
                downloadUrl: '',
                description: '',
                minVersion: '',
                isForce: 0
            };
            this.dialogFormVersion = true;
        }
    }
}
</script>
<style scoped>
.u-primary-btn {
    width: 67px;
}
</style>
