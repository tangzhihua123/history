<template>
    <el-row>
        <h4 class="moduleTitle">用户列表</h4>
        <el-row class="m-tool-bar">
            <el-col :span="12">
                <el-select v-model="timeType" size="small" class="middle-select" placeholder="请选择" @change="getuser">
                    <el-option label="最近登录时间" value="2">
                    </el-option>
                    <el-option label="注册时间" value="1">
                    </el-option>
                </el-select>
                <el-date-picker v-model="dateRange" type="daterange" format="yyyy-MM-dd" placeholder="起始时间－结束时间" :picker-options="pickerOption" :editable="false" :clearable="true" @change="changeDateRange">
                </el-date-picker>
                <el-button type="primary" class="u-primary-btn" size="small" @click="getdownload()"
                v-if="checkAuth(authKeyMap.export)">导出</el-button>
            </el-col>
            <el-col :span="12" class="u-text-right">
                <el-select v-model="fieldType" size="small" class="middle-select" placeholder="搜索选项">
                    <el-option label="手机号码" value="3">
                    </el-option>
                    <el-option label="用户ID" value="4">
                    </el-option>
                </el-select>
                <el-input class="w217" v-model="signage"></el-input>
                <el-button type="primary" class="u-margin-left-xs u-primary-btn" size="small" @click="getuser">搜索</el-button>
            </el-col>
        </el-row>
        <el-col :span="24" class="u-margin-bottom-xs">
            <el-table class="m-table" style="width: 100%" :data="userchart" v-loading.body="loading" stripe @sort-change="handleSortChange">
                <el-table-column label="ID" prop="id" width="30">
                </el-table-column>
                <el-table-column label="手机号" prop="phoneNo">
                </el-table-column>
                <el-table-column label="用户名" prop="nickName" width="80" :show-overflow-tooltip="true">
                    <template scope="scope">
                        <span class="text-info">
                          {{scope.row.nickName}} 
                        </span>
                    </template>
                </el-table-column>
                <el-table-column label="第三方登录" prop="thirdParty">
                </el-table-column>
                <el-table-column label="用户昵称" prop="nickName">
                </el-table-column>
                <el-table-column label="头像" width="30">
                    <template scope="scope">
                        <span>
                        {{scope.row.iconUrl?'有':'无'}} 
                      </span>
                    </template>
                </el-table-column>
                <el-table-column label="状态" prop="status" width="50">
                    <template scope="scope">
                        <span v-if="scope.row.status == 1">禁言</span>
                        <span v-if="scope.row.status == 2">禁止登陆</span>
                        <span v-if="scope.row.status == 3">正常</span>
                    </template>
                </el-table-column>
                <el-table-column label="注册时间" width="120" sortable="custom" prop="registerTime">
                    <template scope="scope">
                        <span class="">{{scope.row.registerTime | dateTimeFormat}}</span>
                    </template>
                </el-table-column>
                <el-table-column label="最近登录版本" prop="loginVersion">
                </el-table-column>
                <el-table-column label="地区" prop="countyName" width="30">
                </el-table-column>
                <el-table-column label="最近登录时间" prop="lastLoginTime" sortable="custom" width="100">
                    <template scope="scope">
                        <span class="">{{scope.row.lastLoginTime | dateTimeFormat}}</span>
                    </template>
                </el-table-column>
                <el-table-column label="机型" prop="model" width="40">
                </el-table-column>
                <el-table-column label="设备系统" prop="os">
                </el-table-column>
                <el-table-column label="系统版本" prop="systemVersion">
                </el-table-column>
                <el-table-column label="邀请码" prop="invitedCode" width="40">
                </el-table-column>
                <el-table-column label="操作">
                    <template scope="scope">
                        <el-button type="text" size="mini" @click="shutup(scope.row)" v-show="scope.row.status != 1" v-if="checkAuth(authKeyMap.forbidcomment)">禁止评论</el-button>
                        <el-button type="text" size="mini" @click="speak(scope.row)" v-show="scope.row.status == 1" v-if="checkAuth(authKeyMap.forbidcomment)">恢复评论</el-button>
                        <el-button type="text" size="mini" @click="forbidlogin(scope.row)" v-show="scope.row.status != 2" v-if="checkAuth(authKeyMap.forbidlogin)">禁止登录</el-button>
                        <el-button type="text" size="mini" @click="restorelogin(scope.row)" v-show="scope.row.status == 2" v-if="checkAuth(authKeyMap.forbidlogin)">恢复登录</el-button>
                    </template>
                </el-table-column>
            </el-table>
        </el-col>
        <el-col :span="24" class="u-padding-vertical-sm u-text-right">
            <el-pagination @size-change="handleSizeChange" @current-change="handlePageChange" :current-page="pageParams.currentpage" :page-sizes="[10, 20, 50, 100]" :page-size="pageParams.pagesize" layout="total, sizes, prev, pager, next, jumper" :total="pageParams.total">
            </el-pagination>
        </el-col>
    </el-row>
</template>
<script>
import vhttp from '@/vhttp';
import config from '@/config.js';
import dateUtil from 'element-ui/src/utils/date';
export default {
    data: function() {
        return {
            authKeyMap:{
                export:'useradmin.userlist.export',
                forbidcomment:'useradmin.userlist.forbidcomment',
                forbidlogin:'useradmin.userlist.forbidlogin' 
            },
            fieldType: '3',
            signage: '',
            dateRange: [null, null],
            pickerOption: {
                onPick: this.refreshTable
            },
            loading: false,
            menutime: '最近登录时间',
            menuno: '手机号码',
            pageParams: {
                currentpage: 1,
                pagesize: 10,
                total: 1
            },
            timeType: '2',
            userchart: [],
            sortMap: {
                registerTime: {
                    descending: 2,
                    ascending: 1
                },
                lastLoginTime: {
                    descending: 4,
                    ascending: 3
                }
            }
        }
    },
    created: function() {
        this.getuser()
    },
    methods: {
        checkAuth: function(authKey) {
            var auth = this.$root.myauth;
            var hasauth = false;
            auth.forEach(function(a) {
                if (a.indexOf(authKey) >= 0) {
                    hasauth = true;
                }
            })
            return hasauth;
        },
        handlePageChange: function(currentpage) {
            this.pageParams.currentpage = currentpage;
            this.getuser();
        },
        handleSizeChange: function(pagesize) {
            this.pageParams.pagesize = pagesize;
            this.getuser();
        },
        // 时间段选框
        refreshTable: function(dateRange) {
            if (dateRange.maxDate) {
                this.startTime = dateRange.minDate.getTime();
                this.endTime = dateRange.maxDate.getTime();
            }
            this.getuser();
        },
        timequantum: function(command) {
            this.menutime = command;
            switch (command) {
                case '注册时间':
                    this.fieldType = 1;
                    this.getuser();
                    break;
                case '最近登录时间':
                    this.fieldType = 2;
                    this.getuser();
                    break;
            }
        },
        typeselection: function(command) {
            this.menuno = command;
            switch (command) {
                case '手机号码':
                    this.fieldType = 5;
                    break;
                case '用户ID':
                    this.fieldType = 6;
                    break;
            }
        },
        // 禁言
        shutup: function(gn) {
            var vm = this;
            vhttp.post('/web/user/action/besilence/userinfo/' + gn.id, {}, function(res) {
                res.status = 1;
                vm.getuser();
            })
        },
        //恢复评论
        speak: function(gn) {
            var vm = this;
            vhttp.post('/web/user/action/cancelsilence/userinfo/' + gn.id, {}, function(res) {
                res.status = 3;
                vm.getuser();
            })
        },
        // 禁止登录
        forbidlogin: function(gn) {
            var vm = this;
            vhttp.post('/web/user/action/befreeze/userinfo/' + gn.id, {}, function(res) {
                res.status = 2;
                vm.getuser();
            })
        },
        // 恢复登录
        restorelogin: function(gn) {
            var vm = this;
            vhttp.post('/web/user/action/cancelfreeze/userinfo/' + gn.id, {}, function(res) {
                res.status = 3;
                vm.getuser();
            })
        },
        getuser: function() {
            var vm = this;
            vhttp.get('/web/users/list', {
                pageSize: vm.pageParams.pagesize,
                pageNo: vm.pageParams.currentpage,
                fieldType: vm.fieldType,
                timeType: vm.timeType,
                fieldValue: vm.signage,
                startTime: vm.startTime,
                endTime: vm.endTime,
                orderBy: vm.orderBy
            }, function(res) {
                vm.userchart = res.data.array;
                vm.pageParams = {
                    currentpage: res.data.pageNo,
                    pagesize: res.data.pageSize,
                    total: res.data.total
                };
            })
        },
        // 导出exe表格
        getdownload: function() {
            var vm = this;
            var aLink = document.createElement('a');
            aLink.download = '用户列表.xls';
            aLink.href = config.api + '/web/users/download?pageNo=1&pageSize=' + vm.pageParams.total + '&countyCode'+vhttp.getCountryCode();
            aLink.click()
        },
        changeDateRange: function(dateStr) {
            var vm = this;
            if (dateStr.trim().length === 0) {
                vm.startTime = '';
                vm.endTime = '';
                vm.getuser();
            };
        },
        handleSortChange: function(sortObj) {
            this.orderBy = this.sortMap[sortObj.prop][sortObj.order];
            this.getuser();
        }
    }
}
</script>
<style scoped>
.profile {
    line-height: 20px;
    text-align: center;
}

.profile img {
    width: 100px;
    height: 100px;
    border-radius: 50%;
    background: #ccc;
}

.text-info {
    color: #20A0FF;
}
</style>
