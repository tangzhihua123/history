<!-- 反馈列表组件 -->
<template>
    <el-row>
        <h4 class="moduleTitle">用户反馈列表</h4>
        <el-row :span="24" class="m-tool-bar">
            <el-col :span="12">
                <span>反馈时间</span>
                <el-date-picker v-model="dateRange" type="daterange" format="yyyy-MM-dd" placeholder="起始时间－结束时间" :picker-options="pickerOption">
                </el-date-picker>
                <el-button type="primary" class="u-primary-btn" size="small" @click="putfeedback()" v-if="checkAuth(authKeyMap.export)">导出</el-button>
            </el-col>
            <el-col :span="12" class="u-text-right">
                <el-dropdown size="small" class="u-dropdown" @command="typeselection" trigger="click">
                    <el-button>{{menuno}}
                        <i class="el-icon-arrow-down"></i>
                    </el-button>
                    <el-dropdown-menu slot="dropdown">
                        <el-dropdown-item command="手机号码">手机号码</el-dropdown-item>
                        <el-dropdown-item command="用户ID">用户ID</el-dropdown-item>
                    </el-dropdown-menu>
                </el-dropdown>
                <el-input v-model="signage" class="w217"></el-input>
                <el-button type="primary" class="u-margin-left-xs u-primary-btn" size="small" @click="getfeed">搜索</el-button>
            </el-col>
        </el-row>
        <el-col :span="24" class="u-margin-bottom-xs">
            <el-table class="m-table" style="width: 100%" :data="feedchart" v-loading.body="loading" stripe>
                <el-table-column label="ID" prop="id" width="40">
                </el-table-column>
                <el-table-column label="手机号" prop="phoneNo" width="90">
                </el-table-column>
                <el-table-column label="用户昵称" prop="nickName" width="70">
                </el-table-column>
                <el-table-column label="状态" prop="silenced" width="50">
                    <template scope="scope">
                        <span v-if="scope.row.silenced == 1">正常</span>
                        <span class="text-danger" v-if="scope.row.silenced == 0">禁言</span>
                    </template>
                </el-table-column>
                <el-table-column label="联系方式" prop="phoneEmail">
                </el-table-column>
                <el-table-column label="反馈时间" prop="createTime">
                </el-table-column>
                <el-table-column label="反馈内容" width="200" class-name="overvisible">
                    <template scope="scope">
                        <el-badge value="未读" :hidden="scope.row.status?true:false" class="item">
                            <el-button type="text" @click="toReadFeedback(scope)">
                                {{scope.row.content}}
                            </el-button>
                        </el-badge>
                    </template>
                </el-table-column>
                <el-table-column label="最近登录版本" prop="appVersion">
                </el-table-column>
                <el-table-column label="机型" prop="deviceType" width="60">
                </el-table-column>
                <el-table-column label="设备系统" prop="os">
                </el-table-column>
                <el-table-column label="操作" width="50">
                    <template scope="scope">
                        <el-button type="text" size="mini" v-if="scope.row.status" @click="toReadFeedback(scope)">
                            已读
                        </el-button>
                        <el-button type="text" size="mini" v-if="!scope.row.status" @click="toReadFeedback(scope)">
                            查看
                        </el-button>
                    </template>
                </el-table-column>
            </el-table>
        </el-col>
        <el-col :span="24" class="u-padding-vertical-sm u-text-right">
            <el-pagination @size-change="handleSizeChange" @current-change="handlePageChange" :current-page="pageParams.currentpage" :page-sizes="[10, 20, 50, 100]" :page-size="pageParams.pagesize" layout="total, sizes, prev, pager, next, jumper" :total="pageParams.total">
            </el-pagination>
        </el-col>
        <!-- 反馈详情弹出框 -->
        <el-dialog title="反馈详情:" :visible.sync="dialogFormVisible">
            <el-form :model="feedback">
                <el-form-item label="ID:" :label-width="formLabelWidth">
                    <span>{{feedback.id}}</span>
                </el-form-item>
                <el-form-item label="手机号:" :label-width="formLabelWidth">
                    <span>{{feedback.phoneNo}}</span>
                </el-form-item>
                <el-form-item label="用户昵称:" :label-width="formLabelWidth">
                    <span>{{feedback.nickName}}</span>
                </el-form-item>
                <el-form-item label="用户状态:" :label-width="formLabelWidth">
                    <span>{{feedback.silenced?'正常':'禁言'}}</span>
                </el-form-item>
                <el-form-item label="反馈详情:" :label-width="formLabelWidth">
                    <span class="box">{{feedback.content}}</span>
                    <!-- <el-input type="textarea" :rows="3" :disabled="true">
          {{feedback.content}}
        </el-input> -->
                </el-form-item>
                <el-form-item label="联系方式:" :label-width="formLabelWidth">
                    <span>{{feedback.phoneEmail}}</span>
                </el-form-item>
                <el-form-item label="反馈时间:" :label-width="formLabelWidth">
                    <span>{{feedback.createTime}}</span>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="dialogFormVisible = false">取 消</el-button>
                <el-button type="primary" @click="read(feedback)">已 读</el-button>
            </div>
        </el-dialog>
    </el-row>
</template>
<script>
import config from '@/config.js';
import vhttp from '@/vhttp'
import dateUtil from 'element-ui/src/utils/date';
export default {
    data: function() {
        return {
            authKeyMap: {
                export: 'useradmin.feedback.export'
            },
            signage: '',
            loading: false,
            menuno: '手机号码',
            fieldType: 1,
            dateRange: [null, null],
            pickerOption: {
                onPick: this.refreshTable
            },
            params: {
                expressCompany: '',
                phone: '',
                status: '',
                page: 1,
                rows: 10,
                pickerOptions2: ''
            },
            pageParams: {
                currentpage: 1,
                pagesize: 10,
                total: 1
            },
            feedback: {
                id: '',
                phoneNo: '',
                nickName: '',
                silenced: '',
                content: ''
            },
            feedchart: [],
            dialogTableVisible: false,
            dialogFormVisible: false,
            formLabelWidth: '120px'
        }
    },
    created: function() {
        this.getfeed()
    },
    methods: {
        checkAuth: function(authKey) {
            var auth = this.$root.myauth;
            var hasauth = false;
            auth.forEach(function(a) {
                if (a.indexOf(authKey) >= 0) {
                    hasauth = true;
                }
            })
            return hasauth;
        },
        handlePageChange: function(currentpage) {
            this.pageParams.currentpage = currentpage;
            this.getfeed();
        },
        handleSizeChange: function(pagesize) {
            this.pageParams.pagesize = pagesize;
            this.getfeed();
        },
        refreshTable: function(dateRange) {
            if (dateRange.maxDate) {
                this.startTime = dateRange.minDate.getTime();
                this.endTime = dateRange.maxDate.getTime();
            }
            this.getfeed();
        },
        typeselection: function(command) {
            this.menuno = command;
            switch (command) {
                case '手机号码':
                    this.fieldType = 1;
                    break;
                case '用户ID':
                    this.fieldType = 2;
                    break;
            }
        },
        getfeed: function() {
            var vm = this;
            var params = {
                pageSize: vm.pageParams.pagesize,
                pageNo: vm.pageParams.currentpage,
                startTime: vm.startTime,
                endTime: vm.endTime
            };
            if (vm.signage) {
                params.fieldType = vm.fieldType;
                params.fieldValue = vm.signage;
            }

            vhttp.get('/web/user/suggestion/list', params, function(res) {
                vm.feedchart = res.data.array.map(function(item) {
                    item.phoneNo = item.phoneNo ? item.phoneNo : '/';
                    return item;
                });
                vm.pageParams = {
                    currentpage: res.data.pageNo,
                    pagesize: res.data.pageSize,
                    total: res.data.total
                }
            })
        },
        // 导出excle
        putfeedback: function() {
            var vm = this;
            var aLink = document.createElement('a');
            aLink.download = '用户反馈.xls';
            aLink.href = config.api + '/web/user/suggestion/exportToExcel?startTime=' + vm.startTime + '&endTime' + vm.endTime + '&countyCode' + vhttp.getCountryCode();
            aLink.click()
        },
        toReadFeedback: function(scope) {
            this.dialogFormVisible = true
            this.feedback = scope.row;
        },
        // 处理未读
        read: function(feedback) {
            var vm = this;
            vhttp.post('/web/user/suggestion/handler/' + feedback.suggestionId, {
                serviceId: feedback.suggestionId
            }, function(res) {
                feedback.status = 1;
                vm.dialogFormVisible = false;
            })
        }
    }
}
</script>
<style scoped>
.unread {
    background: #FF4949;
    display: inline-block;
    font-size: 6px;
    height: 12px;
    line-height: 12px;
    color: #fff;
}

.box {
    display: block;
    width: 400px;
    height: 100px;
    border: solid 1px #ccc;
    background: #eaeaea;
}

.text-danger {
    color: #FF4949;
}

.search {
    margin-right: 4px;
}
</style>
