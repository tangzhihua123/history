<!-- 启动页管理组件 -->
<template>
    <el-row>
        <h4 class="moduleTitle">启动页管理</h4>
        <el-row class="m-tool-bar">
            <el-col :span="4">
                <el-button type="primary" class="u-margin-left-xs u-primary-btn" size="small" @click="toCreateStart"  v-if="checkAuth(authKeyMap.create)">新增</el-button>
            </el-col>
        </el-row>
        <el-col :span="24" class="u-margin-bottom-xs">
            <el-table class="m-table" style="width: 100%" :data="takeAskData" v-loading.body="loading" stripe>
                <el-table-column label="序号" width="80">
                    <template scope="scope">
                        {{scope.$index | fixno(pageParams.currentpage,pageParams.pagesize)}}
                    </template>
                </el-table-column>
                <el-table-column label="主题" prop="title">
                </el-table-column>
                <el-table-column label="链接地址">
                    <template scope="scope">
                        <span v-show="scope.row.type == 2">静态图片</span>
                        <span v-show="scope.row.type == 1">{{scope.row.linkUrl}}</span>
                        <span v-show="scope.row.type == 0">媒立方稿件:{{scope.row.articleId}}</span>
                    </template>
                </el-table-column>
                <el-table-column label="最近修改时间" prop="updateTime">
                    <template scope="scope">
                        {{scope.row.updateTime | dateTimeFormat}}
                    </template>
                </el-table-column>
                <el-table-column label="最近修改人" prop="updateUserName">
                </el-table-column>
                <el-table-column label="状态" prop="status">
                    <template scope="scope"> <span>{{statusList[scope.row.status-1]}}</span>
                    </template>
                </el-table-column>
                <el-table-column label="操作">
                    <template scope="scope">
                        <el-button type="text" size="mini" @click="edit(scope.row)"  v-if="checkAuth(authKeyMap.modify)">修改</el-button>
                        <el-button type="text" size="mini" v-show="scope.row.status ==2" @click="off(scope)"
                        v-if="checkAuth(authKeyMap.upanddown)">下架</el-button>
                        <el-button type="text" size="mini" v-show="scope.row.status ==3 || scope.row.status ==1" @click="on(scope)" v-if="checkAuth(authKeyMap.upanddown)">上架</el-button>
                        <el-button type="text" size="mini" @click="remove(scope)" v-show="scope.row.status !=2"
                         v-if="checkAuth(authKeyMap.delete)">删除</el-button>
                    </template>
                </el-table-column>
            </el-table>
        </el-col>
        <el-col :span="24" class="u-padding-vertical-sm u-text-right">
            <el-pagination @size-change="handleSizeChange" @current-change="handlePageChange" :current-page="pageParams.currentpage" :page-sizes="[10, 20, 50, 100]" :page-size="pageParams.pagesize" layout="total, sizes, prev, pager, next, jumper" :total="pageParams.total">
            </el-pagination>
        </el-col>
        <el-dialog :title="titleName" :visible.sync="dialogFormVisible">
            <el-form :model="form" :rules="rules" ref="startForm">
                <el-form-item label="输入标题" :label-width="formLabelWidth" prop="title">
                    <el-input placeholder="请输入标题" v-model="form.title"></el-input>
                </el-form-item>
                <el-form-item label="上传图片" :label-width="formLabelWidth" required>
                    <el-form-item prop="imageUrl">
                        <el-input v-show="false" v-model="form.imageUrl"></el-input>
                        <el-upload class="avatar-uploader" action="/api/web/xsb/image/upload" :show-file-list="false" :on-success="handleImageUpload" :before-upload="beforeImageUpload" :on-error="handleImageFailed">
                            <img v-if="imageUrl" :src="imageUrl" class="avatar">
                            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                        </el-upload>
                    </el-form-item>
                </el-form-item>
                <el-form-item label="关联链接" :label-width="formLabelWidth" required>
                    <el-radio-group v-model="form.linktype">
                        <el-form-item>
                            <el-radio :label="2">静态图片,无链接跳转</el-radio>
                        </el-form-item>
                        <el-form-item>
                            <el-radio :label="1">外部网页链接</el-radio>
                            <el-form-item prop="linkUrl" v-if="form.linktype==1" class="w306 di">
                                <el-input placeholder="请输入链接地址" v-model="form.linkUrl"></el-input>
                            </el-form-item>
                        </el-form-item>
                        <el-form-item>
                            <el-radio :label="0">媒立方稿件</el-radio>
                            <span v-show="form.articleId">{{form.articleId+':'+ form.articleTitle}} </span>
                            <el-form-item prop="articleId" v-if="form.linktype==0">
                                <el-input v-show="false" v-model="form.articleId"></el-input>
                            </el-form-item>
                        </el-form-item>
                    </el-radio-group>
                </el-form-item>
                <el-form-item :label-width="formLabelWidth">
                    <el-input v-show="form.linktype==0" placeholder="请输入稿件ID或标题关联" v-model="form.keyword">
                        <el-button slot="append" icon="search" @click="searchMlf"></el-button>
                    </el-input>
                </el-form-item>
                <el-table :data="mlfAricles" v-show="form.linktype==0 && mlfAricles.length" @current-change="handleArticleChange" highlight-current-row ref="mlfTable">
                    <el-table-column prop="id" label="稿件ID">
                    </el-table-column>
                    <el-table-column prop="title" label="原标题">
                    </el-table-column>
                </el-table>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="dialogFormVisible = false">取 消</el-button>
                <el-button type="primary" @click="postimage()">确 定</el-button>
            </div>
        </el-dialog>
    </el-row>
    </el-row>
</template>
<script>
import config from '@/config.js';
import vhttp from '@/vhttp'
import dateUtil from 'element-ui/src/utils/date';
export default {
    name: 'UserList',
    data: function() {
        return {
            authKeyMap: {
                create: 'apprunadmin.start.add',
                modify: 'apprunadmin.start.modify',
                upanddown: 'apprunadmin.start.upanddown', 
                delete: 'apprunadmin.start.delete'
            },
            imageUrl: '',
            loading: false,
            //新建启动页表单校验规则,
            rules: {
                title: [{
                    required: true,
                    message: '标题内容不能为空',
                    trigger: 'blur'
                }, {
                    max: 20,
                    message: '不能超过20个字符',
                    trigger: 'blur,change'
                }],
                imageUrl: [{
                    required: true,
                    message: '图片不能为空',
                    trigger: 'blur'
                }],
                linkUrl: [{
                    required: true,
                    message: '链接不能为空',
                    trigger: 'blur'
                }],
                articleId: [{
                    required: true,
                    type: 'number',
                    message: '必须选择一篇稿件',
                    trigger: 'change'
                }]
            },
            //分页数据
            pageParams: {
                currentpage: 1,
                pagesize: 10,
                total: 1
            },
            takeAskData: [],
            //新建弹框数据
            dialogFormVisible: false,
            form: {
                title: '',
                linkUrl: '',
                articleId: '',
                articleTitle: '',
                linktype: 2,
                imageUrl: ''
            },
            mlfAricles: [],
            //上传的图片文件列表 
            imgFileList: [],
            //状态列表
            statusList: ["新建", "展示中", "下架", "删除"],
            //刚上传的图片的地址
            imagePath: '',
            formLabelWidth: '90px',
        }
    },
    computed: {
        titleName: function() {
            return (this.form.id ? '修改' : '新建');
        }
    },
    created: function() {
        this.getstar();
    },
    methods: {
        checkAuth: function(authKey) {
            var auth = this.$root.myauth;
            var hasauth = false;
            auth.forEach(function(a) {
                if (a.indexOf(authKey) >= 0) {
                    hasauth = true;
                }
            })
            return hasauth;
        },
        //第几页改变时的回调。
        handlePageChange: function(currentPage) {
            this.pageParams.currentpage = currentPage;
            //调用查询方法        
            this.getstar();
        },
        //分页大小改变时的回调。
        handleSizeChange: function(size) {
            this.pageParams.pagesize = size;
            //调用查询方法。
            this.getstar();
        },
        handleArticleChange: function(article) {
            if (article) {
                this.form.articleId = article.id;
                this.form.articleTitle = article.title;
            }
        },
        handleImageUpload: function(res, file) {
            this.form.imageUrl = res.data;
            this.imageUrl = URL.createObjectURL(file.raw);
        },
        beforeImageUpload(file) {
            const imgFormatList = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
            const imgFormat = imgFormatList.indexOf(file.type) >= 0;
            const isLt4M = file.size / 1024 / 1024 < 4;
            if (!imgFormat) {
                this.$message.error('上传图片只能是JPG、PNG、GIF格式!');
            }
            if (!isLt4M) {
                this.$message.error('上传图片大小不能超过 4MB!');
            }
            return imgFormat && isLt4M;
        },
        handleImageFailed: function(err) {
            this.$message.error('文件上传失败');
        },
        toCreateStart: function() {
            var vm = this;
            vm.imageUrl = '';
            vm.form = {
                title: '',
                linkUrl: '',
                articleId: '',
                articleTitle: '',
                linktype: 2,
                imageUrl: ''
            };
            vm.mlfAricles = [];
            vm.dialogFormVisible = true;
        },
        //查询请求。
        getstar: function() {
            var vm = this;
            vhttp.get('/web/homepage', {
                pageNo: vm.pageParams.currentpage,
                pageSize: vm.pageParams.pagesize
            }, function(res) {
                //预备的takeAskData对象接收请求回的数据
                vm.takeAskData = res.data.array;
                vm.pageParams = {
                    currentpage: res.data.pageNo,
                    pagesize: res.data.pageSize,
                    total: res.data.total
                }
            })
        },

        //新建请求。
        postimage: function() {
            var vm = this;
            this.$refs.startForm.validate((valid) => {
                if (valid) {
                    var postData = {
                        title: vm.form.title,
                        imagePath: vm.form.imageUrl,
                        linkUrl: vm.form.linktype == 1 ? vm.form.linkUrl : '',
                        articleId: vm.form.linktype == 0 ? vm.form.articleId : '',
                        type: vm.form.linktype
                    };
                    if (vm.form.id) {
                        vhttp.post('/web/homepage/edit/' + vm.form.id, postData, function(res) {
                            vm.dialogFormVisible = false;
                            vm.getstar();
                        })
                    } else {
                        vhttp.post('/web/homepage', postData, function() {
                            vm.dialogFormVisible = false;
                            //调用查询方法
                            vm.getstar();
                        })
                    }
                } else {
                    vm.$message.error('表单有误,请检查后重新提交');
                    return false;
                }
            })

        },
        //修改请求。
        edit: function(sp) {
            var vm = this;
            vm.form = {
                linktype: sp.type,
                id: sp.id,
                title: sp.title,
                linkUrl: sp.linkUrl,
                imageUrl: sp.pageUrl,
                articleId: sp.articleId,
                keyword: sp.articleId,
                articleTitle: "*对应稿件可能已撤稿*"
            }; 
            vm.mlfAricles = [];
            if (sp.articleId) {
                vm.searchMlf();
            }
            vm.imageUrl = config.imagePath + sp.pageUrl;
            vm.dialogFormVisible = true;
        },
        //修改弹框确定按钮
        confirmamend: function() {
            var vm = this;
            vhttp.post('/web/homepage/edit/' + vm.amend.id, {
                title: vm.amend.title,
                id: vm.amend.id,
                linkUrl: vm.amend.linkUrl,
                imageShowScale: 1,
                type: 2
            }, function(res) {
                vm.dialogAmendVisible = false;
                //调用查询方法  
                vm.getstar();
            })
        },
        //下架请求。
        off: function(scope) {
            var vm = this;
            vhttp.put('/web/homepage/off/' + scope.row.id, {
                id: scope.row.id
            }, function() {
                //调用查询方法
                vm.getstar();
            })
        },
        //上架请求。
        on: function(scope) {
            var vm = this;
            vhttp.put('/web/homepage/on/' + scope.row.id, {
                id: scope.row.id
            }, function() {
                //调用查询方法
                vm.getstar();
            })
        },
        //删除请求。
        remove: function(scope) {
            var vm = this;
            vm.$confirm('确认删除该启动页吗?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(function() {
                vhttp.put('/web/homepage/remove/' + scope.row.id, {
                    id: scope.row.id
                }, function() {
                    //调用查询方法
                    vm.getstar();
                })
            }, function() {
                vm.$message({
                    type: 'info',
                    message: '取消删除'
                });
            }).catch(function(err) {
                vm.$message({
                    type: 'info',
                    message: '删除失败'
                });
            });
        },
        searchMlf: function() {
            var vm = this;
            if (vm.form.keyword && vm.form.keyword.toString().trim().length) {
                vhttp.get('/web/articles/all/amb/search', {
                    fieldValue: vm.form.keyword
                }, res => {
                    vm.mlfAricles = res.data;
                    if (vm.mlfAricles.length === 0) {
                        vm.$message({
                            type: 'info',
                            message: '没有指定ID或标题相关的稿件'
                        });
                    } else {
                        vm.mlfAricles.forEach(function(at, idx) {
                            if (at.id === vm.form.articleId) {
                                vm.$refs.mlfTable.setCurrentRow(at);
                            }
                        })
                    }
                })
            } else {
                vm.$message({
                    type: 'warning',
                    message: '请输入稿件ID或者标题！'
                });

            }
        }
    }
}
</script>
<style scoped>
.u-primary-btn {
    width: 81px;
}
</style>
