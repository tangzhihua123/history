<template>
    <el-row>
        <h4 class="moduleTitle">消息管理</h4>
        <el-row class="m-tool-bar">
            <el-col :span="8">
                <el-button type="primary" class="u-margin-left-xs u-primary-btn" size="small" @click="showdialogFormInstation()"  v-if="checkAuth(authKeyMap.addinner)">新建站内信</el-button>
                <el-button type="primary" class="u-margin-left-xs u-primary-btn" size="small" @click="showdialogFormPush()" v-if="checkAuth(authKeyMap.addpush)">新建推送</el-button>
                <el-button type="primary" class="u-margin-left-xs u-primary-btn" size="small" @click="showdialogshorMsg()" v-if="checkAuth(authKeyMap.addmsg)">新建短信</el-button>
            </el-col>
        </el-row>
        <el-col :span="24" class="u-margin-bottom-xs">
            <el-table class="m-table" style="width: 100%" :data="takeAskData" v-loading.body="loading" stripe>
                <el-table-column label="序号" prop="id" width="60">
                    <template scope="scope">
                        {{scope.$index | fixno(pageParams.currentpage,pageParams.pagesize)}}
                    </template>
                </el-table-column>
                <el-table-column label="消息方式" prop="messageType" width="80">
                    <template scope="scope">
                        <span>{{ msgTypeList[scope.row.messageType-1]}}</span>
                    </template>
                </el-table-column>
                <el-table-column label="消息类型" prop="messageType">
                    <template scope="scope">
                        <span v-if="scope.row.innerMessageType == 1">活动消息</span>
                        <span v-else-if="scope.row.innerMessageType == 2">系统消息</span>
                        <span v-else>/</span>
                    </template>
                </el-table-column>
                <el-table-column label="标题" prop="title">
                </el-table-column>
                <el-table-column label="内容" prop="content">
                </el-table-column>
                <el-table-column label="状态" prop="status">
                    <template scope="scope">
                        <span>{{ statusList[scope.row.status+2]}}</span>
                    </template>
                </el-table-column>
                <el-table-column label="创建时间" width="120">
                    <template scope="scope">
                        {{scope.row.createTime | dateTimeFormat}}
                    </template>
                </el-table-column>
                <el-table-column label="发送时间" width="120">
                    <template scope="scope">
                        {{scope.row.pushTime | dateTimeFormat}}
                    </template>
                </el-table-column>
                <el-table-column label="创建人" prop="createUserName">
                </el-table-column>
                <el-table-column label="操作">
                    <template scope="scope">
                        <el-button type="text" size="mini" v-show="scope.row.status == 1 || -1" @click="lookmsg(scope.row)">查看</el-button>
                        <el-button type="text" size="mini" v-show="scope.row.status == 0" @click="recall(scope)" v-if="checkAuth(authKeyMap.reback)">取消</el-button>
                    </template>
                </el-table-column>
            </el-table>
        </el-col>
        <el-col :span="24" class="u-padding-vertical-sm u-text-right">
            <el-pagination @size-change="handleSizeChange" @current-change="handlePageChange" :current-page="pageParams.currentpage" :page-sizes="[10, 20, 50, 100]" :page-size="pageParams.pagesize" layout="total, sizes, prev, pager, next, jumper" :total="pageParams.total">
            </el-pagination>
        </el-col>
        <!-- 新建站内消息弹框开始 -->
        <el-dialog title="新建站内消息" :visible.sync="dialogFormInstation">
            <el-form :model="instationForm" :rules="ifrules" ref="instationref">
                <el-form-item label="发送对象" :label-width="formLabelWidth" required>
                    <el-radio-group v-model="instationForm.group" style="width:100%">
                        <el-radio :label="1">选择用户组</el-radio>
                        <el-radio :label="2">导入用户</el-radio>
                    </el-radio-group>
                    <el-form-item prop="user" v-if="instationForm.group===2">
                        <el-input type="textarea" v-model="instationForm.user" placeholder="输入用户id，以英文分号分割: 1;3;5"></el-input>
                    </el-form-item>
                    <el-select v-model="instationForm.area" v-show="instationForm.group===1">
                        <el-option label="全部" :value="-1"></el-option>
                        <el-option :label="option.name" :value="option.id" v-for="option in areaoptions" :key="option.id"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="发送方式" :label-width="formLabelWidth">
                    <el-col :span="7">
                        <el-radio-group v-model="instationForm.limit">
                            <el-radio :label="0">即时</el-radio>
                            <el-radio :label="1">定时</el-radio>
                        </el-radio-group>
                    </el-col>
                    <el-col :span="17" v-show="instationForm.limit===1">
                        <el-date-picker type="datetime" placeholder="选择日期时间" v-model="instationForm.date"></el-date-picker>
                    </el-col>
                </el-form-item>
                <el-form-item label="消息类型" :label-width="formLabelWidth">
                    <el-select v-model="instationForm.type">
                        <el-option label="活动消息" :value="1"></el-option>
                        <el-option label="系统消息" :value="2"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="推送标题" :label-width="formLabelWidth" prop="title">
                    <el-input v-model="instationForm.title" placeholder="请输入标题" value="biaoti"></el-input>
                </el-form-item>
                <el-form-item label="推送内容" :label-width="formLabelWidth" prop="content">
                    <el-input type="textarea" :rows="4" placeholder="请输入推送内容" v-model="instationForm.content">
                    </el-input>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="dialogFormInstation = false">取 消</el-button>
                <el-button type="primary" @click="instation()">确 定</el-button>
            </div>
        </el-dialog>
        <!-- 新建站内消息弹框结束 -->
        <!-- 查看站内消息开始 -->
        <el-dialog title="查看站内消息" :visible.sync="lookDialogFormInstation">
            <el-form :model="readinstation">
                <el-form-item label="发送用户:" :label-width="formLabelWidth">
                    <span v-if="readinstation.targetType == 1">用户组</span>
                    <span v-if="readinstation.targetType == 2">推送确定人群</span>
                </el-form-item>
                <el-form-item label="发送对象:" v-show="readinstation.targetType == 1" :label-width="formLabelWidth">
                    <span v-if="readinstation.groups == -1">全部</span>
                    <span v-if="readinstation.groups != -1">{{areaOptMap[readinstation.groups] || '栏目ID:'+readinstation.groups}}</span>
                </el-form-item>
                <el-form-item label="导入用户:" v-show="readinstation.targetType == 2" :label-width="formLabelWidth">
                    <span>{{readinstation.pushPersons}}</span>
                </el-form-item>
                <el-form-item label="发送时间:" :label-width="formLabelWidth">
                    <span>{{readinstation.pushTime | dateTimeFormat}}</span>
                </el-form-item>
                <el-form-item label="消息类型:" :label-width="formLabelWidth">
                    <span v-if="readinstation.innerMessageType == 1">活动消息</span>
                    <span v-else-if="readinstation.innerMessageType == 2">系统消息</span>
                    <span v-else>/</span>
                </el-form-item>
                <el-form-item label="标题:" :label-width="formLabelWidth">
                    <span>{{readinstation.title}}</span>
                </el-form-item>
                <el-form-item label="内容:" :label-width="formLabelWidth">
                    <span>{{readinstation.content}}</span>
                </el-form-item>
            </el-form>
        </el-dialog>
        <!-- 查看站内消息结束 -->
        <!--  新建推送消息弹框开始 -->
        <el-dialog title="新建推送" :visible.sync="dialogFormPush">
            <el-form :model="pushForm" :rules="pfrules" ref="pushref">
                <el-form-item label="发送对象" :label-width="formLabelWidth" required>
                    <el-radio-group v-model="pushForm.group" style="width:100%">
                        <el-radio :label="1">选择用户组</el-radio>
                        <el-radio :label="2">导入用户</el-radio>
                    </el-radio-group>
                    <el-form-item prop="user" v-if="pushForm.group===2">
                        <el-input type="textarea" v-model="pushForm.user" placeholder="输入用户id，以英文分号分割: 1;3;5"></el-input>
                    </el-form-item>
                    <el-select v-model="pushForm.area" v-show="pushForm.group===1">
                        <el-option label="全部" :value="-1"></el-option>
                        <el-option :label="option.name" :value="option.id" v-for="option in areaoptions" :key="option.id"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="发送方式" :label-width="formLabelWidth">
                    <el-col :span="7">
                        <el-radio-group v-model="pushForm.limit">
                            <el-radio :label="0">即时</el-radio>
                            <el-radio :label="1">定时</el-radio>
                        </el-radio-group>
                    </el-col>
                    <el-col :span="17" v-show="pushForm.limit===1">
                        <el-date-picker type="datetime" placeholder="选择日期时间" v-model="pushForm.date"></el-date-picker>
                    </el-col>
                </el-form-item>
                <el-form-item label="推送内容" :label-width="formLabelWidth" prop="content" class="el-form-item">
                    <el-input type="textarea" :rows="4" placeholder="请输入内容" v-model="pushForm.content">
                    </el-input>
                </el-form-item>
                <el-form-item label="关联链接" :label-width="formLabelWidth">
                    <el-radio-group v-model="pushForm.linktype">
                        <el-form-item>
                            <el-radio :label="2">无链接跳转</el-radio>
                        </el-form-item>
                        <el-form-item>
                            <el-radio :label="0">外部网页链接</el-radio>
                            <el-form-item prop="url" v-if="pushForm.linktype==0" class="w306 di">
                                <el-input placeholder="请输入链接地址" v-model="pushForm.url"></el-input>
                            </el-form-item>
                        </el-form-item>
                        <el-form-item>
                            <el-radio :label="1">媒立方稿件</el-radio>
                            <span v-show="pushForm.articleId">{{pushForm.articleId+':'+ pushForm.articleTitle}} </span>
                            <el-form-item prop="articleId" v-if="pushForm.linktype==1">
                                <el-input v-show="false" v-model="pushForm.articleId"></el-input>
                            </el-form-item>
                        </el-form-item>
                    </el-radio-group>
                </el-form-item>
                <el-form-item :label-width="formLabelWidth">
                    <el-input v-show="pushForm.linktype==1" placeholder="请输入稿件ID或标题关联" v-model="pushForm.keyword">
                        <el-button slot="append" icon="search" @click="searchMlf"></el-button>
                    </el-input>
                </el-form-item>
                <el-table :data="mlfAricles" v-show="pushForm.linktype==1 && mlfAricles.length" @current-change="handleArticleChange" highlight-current-row ref="mlfTable">
                    <el-table-column prop="id" label="稿件ID">
                    </el-table-column>
                    <el-table-column prop="title" label="原标题">
                    </el-table-column>
                </el-table>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="dialogFormPush = false">取 消</el-button>
                <el-button type="primary" @click="push()">确 定</el-button>
            </div>
        </el-dialog>
        <!--  新建推送消息弹框开始 -->
        <!--  查看推送消息弹框开始 -->
        <el-dialog title="查看推送消息" :visible.sync="lookDialogFormPush">
            <el-form :model="readpush">
                <el-form-item label="发送用户:" :label-width="formLabelWidth">
                    <span v-if="readpush.targetType == 1">用户组</span>
                    <span v-if="readpush.targetType == 2">推送确定人群</span>
                </el-form-item>
                <el-form-item label="发送对象:" v-show="readpush.targetType == 1" :label-width="formLabelWidth">
                    <span v-if="readpush.groups == -1">全部</span>
                    <span v-if="readpush.groups != -1">{{areaOptMap[readpush.groups] || '栏目ID:'+readpush.groups}}</span>
                </el-form-item>
                <el-form-item label="导入用户:" v-show="readpush.targetType == 2" :label-width="formLabelWidth">
                    <span>{{readpush.pushPersons}}</span>
                </el-form-item>
                <el-form-item label="发送时间:" :label-width="formLabelWidth">
                    <span>{{readpush.pushTime  | dateTimeFormat}}</span>
                </el-form-item>
                <el-form-item label="标题:" :label-width="formLabelWidth">
                    <span>{{readpush.content}}</span>
                </el-form-item>
                <el-form-item label="链接关联:" :label-width="formLabelWidth">
                    <span v-if="readpush.linkRelationType == 2">无跳转链接</span>
                    <span v-if="readpush.linkRelationType == 0">{{readpush.url}}</span>
                    <span v-if="readpush.linkRelationType == 1">媒立方稿件:{{readpush.articleId}}</span>
                </el-form-item>
            </el-form>
        </el-dialog>
        <!--  查看推送消息弹框结束 -->
        <!-- 新建短信信息弹框开始 -->
        <el-dialog title="新建短信" :visible.sync="dialogshorMsgForm">
            <el-form :model="shorMsgForm" :rules="smrules" ref="shorref">
                <el-form-item label="发送对象" :label-width="formLabelWidth" required>
                    <el-radio-group v-model="shorMsgForm.group" style="width:100%">
                        <el-radio :label="1">选择用户组</el-radio>
                        <el-radio :label="2">导入用户</el-radio>
                    </el-radio-group>
                    <el-form-item prop="user" v-if="shorMsgForm.group===2">
                        <el-input type="textarea" v-model="shorMsgForm.user" placeholder="输入用户id，以英文分号分割: 1;3;5"></el-input>
                    </el-form-item>
                    <el-select v-model="shorMsgForm.area" v-show="shorMsgForm.group===1">
                        <el-option label="全部" :value="-1"></el-option>
                        <el-option :label="option.name" :value="option.id" v-for="option in areaoptions" :key="option.id"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="发送方式" :label-width="formLabelWidth">
                    <el-col :span="7">
                        <el-radio-group v-model="shorMsgForm.limit">
                            <el-radio :label="0">即时</el-radio>
                            <el-radio :label="1">定时</el-radio>
                        </el-radio-group>
                    </el-col>
                    <el-col :span="17" v-show="shorMsgForm.limit===1">
                        <el-date-picker type="datetime" placeholder="选择日期时间" v-model="shorMsgForm.date"></el-date-picker>
                    </el-col>
                </el-form-item>
                <el-form-item label="短信内容" :label-width="formLabelWidth" prop="content">
                    <el-input type="textarea" :rows="7" v-model="shorMsgForm.content" placeholder="请输入内容">
                    </el-input>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="dialogshorMsgForm = false">取 消</el-button>
                <el-button type="primary" @click="shorMsg()">确 定</el-button>
            </div>
        </el-dialog>
        <!-- 新建短信弹框结束 -->
        <!-- 查看短信消息开始 -->
        <el-dialog title="查看短信消息" :visible.sync="lookDialogshorMsg">
            <el-form :model="readShorMsg">
                <el-form-item label="发送用户:" :label-width="formLabelWidth">
                    <span v-if="readShorMsg.targetType == 1">用户组</span>
                    <span v-if="readShorMsg.targetType == 2">推送确定人群</span>
                </el-form-item>
                <el-form-item label="发送对象:" v-show="readShorMsg.targetType==1" :label-width="formLabelWidth">
                    <span v-if="readShorMsg.groups == -1">全部</span>
                    <span v-if="readShorMsg.groups != -1">{{areaOptMap[readShorMsg.groups] || '栏目ID:'+readShorMsg.groups}}</span>
                </el-form-item>
                <el-form-item label="导入用户ID:" v-show="readShorMsg.targetType==2" :label-width="formLabelWidth">
                    <span>{{readShorMsg.pushPersons}}</span>
                </el-form-item>
                <el-form-item label="发送时间:" :label-width="formLabelWidth">
                    <span>{{readShorMsg.pushTime | dateTimeFormat}}</span>
                </el-form-item>
                <el-form-item label="内容:" :label-width="formLabelWidth">
                    <span>{{readShorMsg.content}}</span>
                </el-form-item>
                </el-form-item>
            </el-form>
        </el-dialog>
        <!--   查看短信消息结束 -->
    </el-row>
</template>
<script>
import config from '@/config.js';
import vhttp from '@/vhttp';
import dateUtil from 'element-ui/src/utils/date';
export default {
    data: function() {
        return {
            authKeyMap: {
                addinner: 'apprunadmin.msg.addinner',
                addpush: 'apprunadmin.msg.addpush',
                addmsg: 'apprunadmin.msg.addmsg', 
                reback: 'apprunadmin.msg.reback'
            },
            loading: false,
            pageParams: {
                currentpage: 1,
                pagesize: 10,
                total: 1
            },
            areaoptions: [],
            areaOptMap: {},
            takeAskData: [],
            dialogFormInstation: false,
            instationForm: {},
            readinstation: {
                targetType: '',
                group: '',
                groups: '',
                pushTime: '',
                messageType: '',
                title: '',
                content: '',
                pushTime: new Date()
            },
            mlfAricles: [],
            //查看站内消息
            lookDialogFormInstation: false,
            //新建推送消息
            dialogFormPush: false,
            pushForm: {},
            readpush: {
                group: '',
                desc: '',
                limit: '',
                date: '',
                content: '',
                linktype: '',
                relevance: '',
                url: '',
                pushTime: new Date()
            },
            //查看推送消息
            lookDialogFormPush: false,
            //新建短信消息
            dialogshorMsgForm: false,
            shorMsgForm: {},
            readShorMsg: {
                groups: '',
                user: '',
                pushPersons: '',
                limit: '',
                date: '',
                content: '',
                pushTime: new Date()
            },
            //查看短信消息
            lookDialogshorMsg: false,
            msgTypeList: ["推送消息", "站内消息", "短信消息"],
            statusList: ["已删除", "已取消", "未推送", "推送中", "已推送"],
            formLabelWidth: '90px',
            ifrules: {
                user: [{
                    required: true,
                    message: '导入用户不能为空',
                    trigger: 'change'
                }],
                title: [{
                    required: true,
                    message: '请输入标题',
                    trigger: 'blur,change'
                }, {
                    min: 1,
                    max: 40,
                    message: '输入0-40个字符',
                    trigger: 'blur,change'
                }],
                content: [{
                    required: true,
                    message: '请输入内容',
                    trigger: 'change'
                }, {
                    min: 1,
                    max: 200,
                    message: '输入0-200个字符',
                    trigger: 'blur,change'
                }]
            },
            pfrules: {
                content: [{
                    required: true,
                    message: '请输入内容',
                    trigger: 'change'
                }, {
                    max: 40,
                    message: '不能超过40个字符',
                    trigger: 'blur,change'
                }],
                user: [{
                    required: true,
                    message: '导入用户不能为空',
                    trigger: 'change'
                }],
                url: [{
                    required: true,
                    message: '链接不能为空',
                    trigger: 'blur'
                }],
                articleId: [{
                    required: true,
                    type: 'number',
                    message: '必须选择一篇稿件',
                    trigger: 'change'
                }]
            },
            smrules: {
                user: [{
                    required: true,
                    message: '导入用户不能为空',
                    trigger: 'change'
                }],
                content: [{
                    required: true,
                    message: '请输入内容',
                    trigger: 'change'
                }, {
                    max: 40,
                    message: '不能超过40个字符',
                    trigger: 'blur,change'
                }]
            }
        }
    },
    //过滤器用来判断当前status的值返回不同内容
    filters: {
        restLength: function(value, totalLength) {
            return totalLength - value.length;
        }
    },
    //周期函数
    created: function() {
        //周期函数自动执行完毕就调用查询请求方法
        this.getmsg()
        this.getAreaOption()
    },
    methods: {
        checkAuth: function(authKey) {
            var auth = this.$root.myauth;
            var hasauth = false;
            auth.forEach(function(a) {
                if (a.indexOf(authKey) >= 0) {
                    hasauth = true;
                }
            })
            return hasauth;
        },
        getAreaOption: function() {
            var vm = this;
            vhttp.get('/web/syschannel/dictionary/column', {}, res => {
                vm.areaoptions = res.data;
                vm.areaOptMap = {};
                res.data.forEach(function(c) {
                    vm.areaOptMap[c.id] = c.name + '用户';
                })
            })

        },
        //初始化站内消息弹框 对象
        resetinstationForm: function() {
            this.instationForm = {
                group: 1,
                area: -1,
                user: '',
                date: new Date(),
                type: 1,
                title: '',
                limit: 0,
                content: ''
            };
        },
        resetpushForm: function() {
            this.pushForm = {
                group: 1,
                area: -1,
                user: '',
                date: new Date(),
                limit: 0,
                content: '',
                linktype: 2,
                url: '',
                articleId: '',
                articleTitle: ''
            };
        },
        resetshorMsgForm: function() {
            this.shorMsgForm = {
                group: 1,
                area: -1,
                user: '',
                limit: 0,
                date: new Date(),
                content: ''
            };
        },
        showdialogFormInstation: function() {
            this.resetinstationForm();
            this.dialogFormInstation = true;
        },
        showdialogFormPush: function() {
            this.resetpushForm();
            this.dialogFormPush = true;
        },
        showdialogshorMsg: function() {
            this.resetshorMsgForm();
            this.dialogshorMsgForm = true;
        },
        //点击撤回按钮提示是否执行撤回操作
        recall: function(scope) {
            if (-1 == scope.row.status) {
                return false;
            }
            var vm = this;
            vm.$confirm('确认要这样操作吗?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(function() {
                vhttp.put('/web/pushinfo/cancel/' + scope.row.id, {
                    id: scope.row.id
                }, res => {
                    vm.$message({
                        type: 'success',
                        message: '操作成功!'
                    });
                    vm.getmsg();
                })
            }, function() {
                vm.$message({
                    type: 'info',
                    message: '取消了操作'
                });
            });
        },
        //第几页改变时的回调。
        handlePageChange: function(currentPage) {
            this.pageParams.currentpage = currentPage;
            //调用查询方法        
            this.getmsg();
        },
        //分页大小改变时的回调。
        handleSizeChange: function(size) {
            this.pageParams.pagesize = size;
            //调用查询方法。
            this.getmsg();
        },
        //查询请求。
        getmsg: function() {
            var vm = this;
            vhttp.get('/web/pushinfo', {
                pageNo: vm.pageParams.currentpage,
                pageSize: vm.pageParams.pagesize
            }, function(res) {
                vm.takeAskData = res.data.array.map(function(item) {
                    item.title = item.title ? item.title : '/';
                    return item;
                });
                vm.pageParams = {
                    currentpage: res.data.pageNo,
                    pagesize: res.data.pageSize,
                    total: res.data.total
                }
            })
        },
        //新建站内
        instation: function() {
            var vm = this;
            vm.$refs.instationref.validate((valid) => {
                if (valid) {
                    var newinstation = Object.assign({}, vm.instationForm);
                    vhttp.post('/web/pushinfo', {
                        messageType: 2,
                        title: vm.instationForm.title,
                        pushTime: vm.instationForm.limit ? vm.instationForm.date.getTime() : new Date().getTime(),
                        groups: vm.instationForm.group == 1 ? vm.instationForm.area : '',
                        pushPersons: vm.instationForm.group == 2 ? vm.instationForm.user : '',
                        content: vm.instationForm.content,
                        targetType: vm.instationForm.group,
                        innerMessageType: vm.instationForm.type
                    }, (res) => {
                        vm.getmsg();
                        vm.dialogFormInstation = false;
                    });
                } else {
                    vm.$message.error('表单有误,请检查后重新提交');
                    return false;
                }
            });
        },
        //查看站内消息
        lookInstation: function() {
            var vm = this;
            vm.lookDialogFormInstation = false;
        },
        push: function() {
            var vm = this;
            vm.$refs.pushref.validate((valid) => {
                if (valid) {
                    vhttp.post('/web/pushinfo', {
                        messageType: 1,
                        pushTime: vm.pushForm.limit ? vm.pushForm.date.getTime() : new Date().getTime(),
                        content: vm.pushForm.content,
                        targetType: vm.pushForm.group,
                        groups: vm.pushForm.group == 1 ? vm.pushForm.area : '',
                        pushPersons: vm.pushForm.group == 2 ? vm.pushForm.user : '',
                        url: vm.pushForm.linktype === 0 ? vm.pushForm.url : '',
                        articleId: vm.pushForm.linktype === 1 ? vm.pushForm.articleId : '',
                        linkRelationType: vm.pushForm.linktype,
                    }, (res) => {
                        vm.getmsg();
                        vm.dialogFormPush = false;
                    })
                } else {
                    vm.$message.error('表单有误,请检查后重新提交');
                    return false;
                }
            });
        },
        //查看推送消息
        lookPush: function() {
            var vm = this;
            vm.lookDialogFormPush = false;
        },
        //新建短信
        shorMsg: function() {
            var vm = this;
            vm.$refs.shorref.validate((valid) => {
                if (valid) {
                    vhttp.post('/web/pushinfo', {
                        messageType: 3,
                        pushTime: vm.shorMsgForm.limit ? vm.shorMsgForm.date.getTime() : new Date().getTime(),
                        content: vm.shorMsgForm.content,
                        targetType: vm.shorMsgForm.group,
                        groups: vm.shorMsgForm.group == 1 ? vm.shorMsgForm.area : '',
                        pushPersons: vm.shorMsgForm.group == 2 ? vm.shorMsgForm.user : '',
                    }, (res) => {
                        vm.getmsg();
                        vm.dialogshorMsgForm = false;
                    })
                } else {
                    vm.$message.error('表单有误,请检查后重新提交');
                    return false;
                }
            });
        },
        //查看短信
        lookShorMsg: function() {
            var vm = this;
            vm.lookDialogshorMsg = false;
        },
        lookmsg: function(ms) {
            var vm = this;
            //点击查看按钮时根据消息类型不同弹出不同的窗口
            var cs = ms.messageType;
            switch (cs) {
                //查看推送消息
                case 1:
                    vm.lookDialogFormPush = true;
                    vm.readpush = ms;
                    break;
                    //查看站内消息
                case 2:
                    vm.lookDialogFormInstation = true;
                    vm.readinstation = ms;
                    break;
                    //查看短信消息
                case 3:
                    vm.lookDialogshorMsg = true;
                    vm.readShorMsg = ms;
                    break;
            }
        },
        handleArticleChange: function(article) {
            if (article) {
                this.pushForm.articleId = article.id;
                this.pushForm.articleTitle = article.title;
            }
        },
        searchMlf: function() {
            var vm = this;
            if (vm.pushForm.keyword && vm.pushForm.keyword.toString().trim().length) {
                vhttp.get('/web/articles/all/amb/search', {
                    fieldValue: vm.pushForm.keyword
                }, res => {
                    vm.mlfAricles = res.data;
                    if (vm.mlfAricles.length === 0) {
                        vm.$message({
                            type: 'info',
                            message: '没有指定ID或标题相关的稿件'
                        });
                    }
                })
            } else {
                vm.$message({
                    type: 'warning',
                    message: '请输入稿件ID或者标题！'
                });
            }
        }
    }
}
</script>
<style scoped>
.red {
    color: #f00;
}

.half {
    width: 50%;
}

.line {
    height: 10px;
}

.el-form-item {
    margin-bottom: 10px;
}
</style>
