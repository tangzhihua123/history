<!-- banner图管理组件 -->
<template>
    <el-row>
        <h4 class="moduleTitle">Banner图管理</h4>
        <el-row class="m-tool-bar">
            <el-col :span="24">
                <!-- <el-button type="primary" class="u-margin-left-xs u-primary-btn" size="small" @click="dialogFormVisible = true">新建banner</el-button> -->
                <el-button type="primary" class="u-margin-left-xs u-primary-btn" size="small" @click="goCreateBanner"  v-if="checkAuth(authKeyMap.create)">新建Banner</el-button>
            </el-col>
        </el-row>
        <el-col :span="24" class="u-margin-bottom-xs">
            <el-table class="m-table" style="width: 100%" :data="bannerchart" v-loading.body="loading" stripe>
                <el-table-column label="序号" width="40">
                    <template scope="scope">
                        {{scope.$index | fixno(pageParams.currentpage,pageParams.pagesize)}}
                    </template>
                </el-table-column>
                <!-- <el-table-column label="排序" prop="defaultSortNum"> -->
                <el-table-column label="排序" width="80" v-if="checkAuth(authKeyMap.sort)">
                    <template scope="scope">
                        <el-button type="text" size="mini" v-on:click="sortLocalService(scope.$index-1)">
                            <i class="el-icon-arrow-up"></i>
                        </el-button>
                        <el-button type="text" size="mini" v-on:click="sortLocalService(scope.$index)">
                            <i class="el-icon-arrow-down"></i>
                        </el-button>
                    </template>
                </el-table-column>
                <el-table-column label="标题" prop="title">
                </el-table-column>
                <el-table-column label="链接地址">
                    <template scope="scope">
                        <span v-if="scope.row.type == 1">静态图片</span>
                        <span v-if="scope.row.type == 2">{{scope.row.url}}</span>
                        <span v-if="scope.row.type == 3">媒立方稿件:{{scope.row.articleId}}</span>
                    </template>
                </el-table-column>
                <el-table-column label="最近修改时间" prop="updateTime" width="120">
                    <template scope="scope">
                        {{scope.row.updateTime || scope.row.createTime | dateTimeFormat}}
                    </template>
                </el-table-column>
                <el-table-column label="反馈时间" prop="createTime" width="120">
                    <template scope="scope">
                        {{scope.row.createTime | dateTimeFormat}}
                    </template>
                </el-table-column>
                <el-table-column label="创建人" prop="createUser" width="70">
                </el-table-column>
                <el-table-column label="状态" prop="statusText" width="60">
                </el-table-column>
                <el-table-column label="操作" width="150">
                    <template scope="scope">
                        <el-button type="text" size="mini" @click="postreviseimage(scope)" 
                        v-if="checkAuth(authKeyMap.modify)">修改</el-button>
                        <el-button type="text" size="mini" v-show="scope.row.status==0" v-on:click="turnonBanner(scope.row)" v-if="checkAuth(authKeyMap.upanddown)">上架
                        </el-button>
                        <el-button type="text" size="mini" v-show="scope.row.status==2" v-on:click="turnoffBanner(scope.row)" v-if="checkAuth(authKeyMap.upanddown)">下架
                        </el-button>
                        <el-button type="text" size="mini" v-show="scope.row.status!=2" @click="deletebanner(scope)" v-if="checkAuth(authKeyMap.delete)">删除</el-button>
                    </template>
                </el-table-column>
            </el-table>
        </el-col>
        <el-col :span="24" class="u-padding-vertical-sm u-text-right">
            <el-pagination @size-change="handleSizeChange" @current-change="handlePageChange" :current-page="pageParams.currentpage" :page-sizes="[10, 20, 50, 100]" :page-size="pageParams.pagesize" layout="total, sizes, prev, pager, next, jumper" :total="pageParams.total">
            </el-pagination>
        </el-col>
        <el-dialog :title="titleName" :visible.sync="dialogFormVisible" :close-on-click-modal='false'>
            <el-form :model="newbanner" :rules="rules" ref="bannerForm">
                <el-form-item label="输入标题" :label-width="formLabelWidth" prop="title">
                    <el-input placeholder="请输入标题" v-model="newbanner.title"></el-input>
                </el-form-item>
                <el-form-item label="上传图片" :label-width="formLabelWidth" required>
                    <el-form-item prop="imagePath">
                        <el-input v-show="false" v-model="newbanner.imagePath"></el-input>
                        <el-upload class="avatar-uploader" action="/api/web/xsb/image/upload" :show-file-list="true" :on-success="handleImageUpload" :before-upload="beforeImageUpload" :on-error="handleImageFailed">
                            <img v-if="imageUrl" :src="imageUrl" class="avatar">
                            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                        </el-upload>
                    </el-form-item>
                </el-form-item>
                <el-form-item label="关联链接" :label-width="formLabelWidth" required>
                    <el-radio-group v-model="newbanner.linktype">
                        <el-form-item>
                            <el-radio :label="1">静态图片,无链接跳转</el-radio>
                        </el-form-item>
                        <el-form-item>
                            <el-radio :label="2">外部网页链接</el-radio>
                            <el-form-item prop="url" v-if="newbanner.linktype==2" class="w306 di">
                                <el-input placeholder="请输入链接地址" v-model="newbanner.url"></el-input>
                            </el-form-item>
                        </el-form-item>
                        <el-form-item>
                            <el-radio :label="3">媒立方稿件</el-radio>
                            <span v-show="newbanner.articleId">{{newbanner.articleId+':'+ newbanner.articleTitle}} </span>
                            <el-form-item prop="articleId" v-if="newbanner.linktype==3">
                                <el-input v-show="false" v-model="newbanner.articleId"></el-input>
                            </el-form-item>
                        </el-form-item>
                    </el-radio-group>
                </el-form-item>
                <el-form-item :label-width="formLabelWidth">
                    <el-input v-show="newbanner.linktype==3" placeholder="请输入稿件ID或标题关联" v-model="newbanner.keyword">
                        <el-button slot="append" icon="search" @click="searchMlf"></el-button>
                    </el-input>
                </el-form-item>
                <el-table :data="mlfAricles" v-show="newbanner.linktype==3 && mlfAricles.length" @current-change="handleArticleChange" highlight-current-row ref="mlfTable">
                    <el-table-column prop="id" label="稿件ID">
                    </el-table-column>
                    <el-table-column prop="title" label="原标题">
                    </el-table-column>
                </el-table>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="dialogFormVisible = false">取 消</el-button>
                <el-button type="primary" @click="postimage()">确 定</el-button>
            </div>
        </el-dialog>
    </el-row>
</template>
<script>
import config from '@/config.js';
import vhttp from '@/vhttp';
export default {
    data: function() {
        return {
            authKeyMap: {
                create: 'apprunadmin.banner.add',
                modify: 'apprunadmin.banner.modify',
                upanddown: 'apprunadmin.banner.upanddown',
                sort: 'apprunadmin.banner.sort',
                delete: 'apprunadmin.banner.delete'
            },
            loading: false,
            pageParams: {
                currentpage: 1,
                pagesize: 10,
                total: 1
            },
            bannerchart: [],
            dialogTableVisible: false,
            dialogFormVisible: false,
            dialogFormPush: false,
            newbanner: {
                title: '',
                imagePath: '',
                url: '',
                linktype: 1,
                articleId: '',
                articleTitle: ''
            },
            imageUrl: '',
            formLabelWidth: '80px',
            mlfAricles: [],
            rules: {
                title: [{
                    required: true,
                    message: '标题内容不能为空',
                    trigger: 'blur'
                }, {
                    max: 20,
                    message: '不能超过20个字符',
                    trigger: 'blur,change'
                }],
                imagePath: [{
                    required: true,
                    message: '图片不能为空',
                    trigger: 'blur'
                }],
                url: [{
                    required: true,
                    message: '链接不能为空',
                    trigger: 'blur'
                }],
                articleId: [{
                    required: true,
                    type: 'number',
                    message: '必须选择一篇稿件',
                    trigger: 'change'
                }]
            }
        }
    },
    computed: {
        titleName: function() {
            return (this.newbanner.id ? '修改' : '新建') + 'Banner图'
        }
    },
    created: function() {
        this.getbanner();
    },
    methods: {
        checkAuth: function(authKey) {
            var auth = this.$root.myauth;
            var hasauth = false;
            auth.forEach(function(a) {
                if (a.indexOf(authKey) >= 0) {
                    hasauth = true;
                }
            })
            return hasauth;
        },
        sortLocalService: function(idx) {
            var vm = this;
            if (idx < 0 || idx + 1 >= vm.bannerchart.length) {
                vm.$message.warning('无法移动');
            } else {
                var upitem = this.bannerchart[idx];
                var downitem = this.bannerchart[idx + 1];
                vhttp.put('/web/sfocuspic/position/exchange', {
                    ids: [upitem.id, downitem.id].join(';')
                }, (res) => {
                    vm.getbanner();
                });
            }
        },
        handleImageUpload: function(res, file) {
            this.newbanner.imagePath = res.data;
            this.imageUrl = URL.createObjectURL(file.raw);
        },
        beforeImageUpload(file) {
            debugger;
            //const imgFormatList = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
            //const imgFormat = imgFormatList.indexOf(file.type) >= 0;
            //const isLt4M = file.size / 1024 / 1024 < 4;
            console.log(file.size)
            console.log(isLt4M)
            // if (!imgF/ormat) {
            //     this.$message.error('上传图片只能是JPG、PNG、GIF格式!');
            // }
            // if (!isLt4M) {
                //this.$message.error('上传图片大小不能超过 4MB!');
            //}
            return true;
        },
        handleImageFailed: function(err) {
            this.$message.error('文件上传失败');
        },
        handleArticleChange: function(article) {
            if (article) {
                this.newbanner.articleId = article.id;
                this.newbanner.articleTitle = article.title;
            }
        },
        handlePageChange: function(currentpage) {
            this.pageParams.currentpage = currentpage;
            this.getbanner();
        },
        handleSizeChange: function(pagesize) {
            this.pageParams.pagesize = pagesize;
            this.getbanner();
        },
        getbanner: function() {
            var vm = this;
            vhttp.get('/web/sfocuspic', {
                pageSize: vm.pageParams.pagesize,
                pageNo: vm.pageParams.currentpage
            }, (res) => {
                var statusMap = {
                    '0': '待展示',
                    '2': '展示中',
                    '-1': '已删除',
                };
                vm.bannerchart = res.data.array.map(function(b) {
                    b.statusText = statusMap[b.status];
                    return b;
                });
                vm.pageParams = {
                    currentpage: res.data.pageNo,
                    pagesize: res.data.pageSize,
                    total: res.data.total
                };
            })
        },
        goCreateBanner: function() {
            var vm = this;
            vm.imageUrl = '';
            vm.newbanner = {
                title: '',
                imagePath: '',
                url: '',
                articleId: '',
                linktype: 1,
                articleTitle: ''
            };
            vm.mlfAricles = [];
            vm.dialogFormVisible = true;
        },
        // 新建banner post
        postimage: function() {
            var vm = this;
            this.$refs.bannerForm.validate((valid) => {
                if (valid) {
                    var postData = {
                        title: vm.newbanner.title,
                        imagePath: vm.newbanner.imagePath,
                        type: vm.newbanner.linktype,
                        url: vm.newbanner.linktype === 2 ? vm.newbanner.url : '',
                        articleId: vm.newbanner.linktype === 3 ? vm.newbanner.articleId : ''
                    };
                    if (vm.newbanner.id) {
                        vhttp.post('/web/sfocuspic/' + vm.newbanner.id, postData, (res) => {
                            vm.dialogFormVisible = false;
                            vm.getbanner();
                        });
                    } else {
                        vhttp.post('/web/sfocuspic', postData, (res) => {
                            vm.dialogFormVisible = false;
                            vm.getbanner();
                        })
                    }
                } else {
                    vm.$message.error('表单有误,请检查后重新提交');
                    return false;
                }
            })

        },
        // 修改banner post
        postreviseimage: function(scope) {
            var vm = this;
            vm.imageUrl = config.imagePath + scope.row.imageUrl;
            vm.newbanner = {
                id: scope.row.id,
                title: scope.row.title,
                url: scope.row.url,
                imagePath: scope.row.imageUrl,
                articleId: scope.row.articleId,
                linktype: scope.row.type,
                keyword: scope.row.articleId,
                articleTitle: "*对应稿件可能已撤稿*"
            };
            vm.mlfAricles = [];
            if (scope.row.articleId) {
                vm.searchMlf();
            }
            vm.dialogFormVisible = true;
        },
        // 删除焦点图
        deletebanner: function(scope) {
            var vm = this
            vm.$confirm('确认删除该Banner吗?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(function() {
                vhttp.put('/web/sfocuspic/remove/' + scope.row.id, {}, res => {
                    vm.$message({
                        type: 'success',
                        message: '删除成功!'
                    });
                    vm.getbanner();
                })
            }, function() {
                vm.$message({
                    type: 'info',
                    message: '取消删除'
                });
            }).catch(function(err) {
                vm.$message({
                    type: 'info',
                    message: '删除失败'
                });
            });
        },
        turnonBanner: function(banner) {
            var vm = this;
            vm.$confirm('确认上架该Banner图吗?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(function() {
                vhttp.put('/web/sfocuspic/show/' + banner.id, {}, res => {
                    vm.$message({
                        type: 'success',
                        message: '上架成功!'
                    });
                    vm.getbanner()
                })
            }, function() {
                vm.$message({
                    type: 'info',
                    message: '取消操作'
                });
            }).catch(function(err) {
                console.error(err)
                vm.$message({
                    type: 'info',
                    message: '上架失败'
                });
            });
        },
        turnoffBanner: function(banner) {
            var vm = this;
            vm.$confirm('确认下架该Banner图吗?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(function() {
                vhttp.put('/web/sfocuspic/cancel/' + banner.id, {}, res => {
                    vm.$message({
                        type: 'success',
                        message: '下架成功!'
                    });
                    vm.getbanner()
                })
            }, function() {
                vm.$message({
                    type: 'info',
                    message: '取消操作'
                });
            }).catch(function(err) {
                vm.$message({
                    type: 'info',
                    message: '下架失败'
                });
            });
        },
        searchMlf: function() {
            var vm = this;
            if (vm.newbanner.keyword && vm.newbanner.keyword.toString().trim().length) {
                vhttp.get('/web/articles/all/amb/search', {
                    fieldValue: vm.newbanner.keyword
                }, res => {
                    vm.mlfAricles = res.data; 
                    if (vm.mlfAricles.length === 0) {
                        vm.$message({
                            type: 'info',
                            message: '没有指定ID或标题相关的稿件'
                        });
                    } else {
                        vm.mlfAricles.forEach(function(at, idx) {
                            if (at.id === vm.newbanner.articleId) {
                                vm.$refs.mlfTable.setCurrentRow(at);
                            }
                        })
                    }
                })
            } else {
                vm.$message({
                    type: 'warning',
                    message: '请输入稿件ID或者标题！'
                });
            }
        }
    }
}
</script>
<style scoped>
.u-primary-btn {
    width: 81px;
}
</style>
