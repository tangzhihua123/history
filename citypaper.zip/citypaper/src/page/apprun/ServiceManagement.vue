<!-- 服务管理组件 -->
<template>
    <el-row>
        <h4 class="moduleTitle">服务管理</h4>
        <el-row class="m-tool-bar">
            <el-col :span="24">
                <el-button-group class="btn-group">
                    <el-button type="default" :class="{ active: activeName=='announcement' }" size="small" @click="switchActivePanel('announcement')">政务公告</el-button>
                    <el-button type="default" :class="{ active: activeName=='localservice' }" size="small" @click="switchActivePanel('localservice')">地方服务</el-button>
                    <el-button type="default" :class="{ active: activeName=='orgservice' }" size="small" @click="switchActivePanel('orgservice')">政务服务</el-button>
                </el-button-group>
                <el-button-group>
                    <el-button type="primary" class="" size="small" v-if="activeName=='announcement'" @click="showCreateDialog" v-show="checkAuth(authKeyMap.addgn)">新建</el-button>
                    <el-button type="primary" class="" size="small" v-if="activeName=='localservice'" @click="showCreateDialog" v-show="checkAuth(authKeyMap.addls)">新建</el-button>
                    <el-button type="primary" class="" size="small" v-if="activeName=='orgservice'" @click="showCreateDialog" v-show="checkAuth(authKeyMap.addgs)">新建</el-button>
                </el-button-group>
            </el-col>
        </el-row>
        <el-row v-show="activeName=='announcement'">
            <el-col :span="24" class="u-margin-bottom-xs">
                <el-table class="m-table" style="width: 100%" :data="govnotice" v-loading.body="loading" stripe>
                    <el-table-column label="展示顺序" v-if="checkAuth(authKeyMap.sortgn)">
                        <template scope="scope">
                            <el-button type="text" size="mini" v-on:click="sortGovNotice(scope.$index-1)">
                                <i class="el-icon-arrow-up"></i>
                            </el-button>
                            <el-button type="text" size="mini" v-on:click="sortGovNotice(scope.$index)">
                                <i class="el-icon-arrow-down"></i>
                            </el-button>
                        </template>
                    </el-table-column>
                    <el-table-column label="公告类型" prop="announcementName">
                    </el-table-column>
                    <el-table-column label="内容" prop="title">
                    </el-table-column>
                    <el-table-column label="URL" prop="linkUrl">
                    </el-table-column>
                    <el-table-column label="创建时间">
                        <template scope="scope">
                            {{scope.row.createTime | dateTimeFormat}}
                        </template>
                    </el-table-column>
                    <el-table-column label="展示时间" :formatter="dateFormat" width="180px">
                    </el-table-column>
                    <el-table-column label="创建人" prop="createUserName">
                    </el-table-column>
                    <el-table-column label="操作">
                        <template scope="scope">
                            <el-button type="text" size="mini" v-on:click="modifyGovNotice(scope.row)"
                            v-if="checkAuth(authKeyMap.modifygn)">修改
                            </el-button>
                            <el-button type="text" size="mini" v-on:click="deleteGovNotice(scope.row)"
                            v-if="checkAuth(authKeyMap.deletegn)">删除
                            </el-button>
                        </template>
                    </el-table-column>
                </el-table>
            </el-col>
        </el-row>
        <el-row v-show="activeName=='localservice'">
            <el-col :span="24" class="u-margin-bottom-xs">
                <el-table class="m-table" style="width: 100%" :data="localservice" v-loading.body="loading" stripe>
                    <el-table-column label="展示顺序" v-if="checkAuth(authKeyMap.sortls)">
                        <template scope="scope">
                            <el-button type="text" size="mini" v-on:click="sortLocalService(scope.$index-1)">
                                <i class="el-icon-arrow-up"></i>
                            </el-button>
                            <el-button type="text" size="mini" v-on:click="sortLocalService(scope.$index)">
                                <i class="el-icon-arrow-down"></i>
                            </el-button>
                        </template>
                    </el-table-column>
                    <el-table-column label="服务名称" prop="title">
                    </el-table-column>
                    <el-table-column label="URL" prop="linkUrl">
                    </el-table-column>
                    <el-table-column label="最近修改时间">
                        <template scope="scope">
                            {{scope.row.updateTime | dateTimeFormat}}
                        </template>
                    </el-table-column>
                    <el-table-column label="创建人" prop="createUserName">
                    </el-table-column>
                    <el-table-column label="操作">
                        <template scope="scope">
                            <el-button type="text" size="mini" v-show="scope.row.status==0" v-on:click="turnonLocalService(scope.row)" v-if="checkAuth(authKeyMap.updownls)">上架
                            </el-button>
                            <el-button type="text" size="mini" v-show="scope.row.status==1" v-on:click="turnoffLocalService(scope.row)" v-if="checkAuth(authKeyMap.updownls)">下架
                            </el-button>
                            <el-button type="text" size="mini" v-on:click="modifyLocalService (scope.row)"
                            v-if="checkAuth(authKeyMap.modifyls)">修改
                            </el-button>
                            <el-button type="text" size="mini" v-on:click="deleteLocalService(scope.row)"
                            v-if="checkAuth(authKeyMap.modifyls)">删除
                            </el-button>
                        </template>
                    </el-table-column>
                </el-table>
            </el-col>
        </el-row>
        <el-row v-show="activeName=='orgservice'">
            <el-col :span="24" class="u-margin-bottom-xs">
                <el-table class="m-table" style="width: 100%" :data="govservice" v-loading.body="loading" stripe>
                    <el-table-column label="展示顺序" v-if="checkAuth(authKeyMap.sortgs)">
                        <template scope="scope">
                            <el-button type="text" size="mini" v-on:click="sortGovService(scope.$index-1)">
                                <i class="el-icon-arrow-up"></i>
                            </el-button>
                            <el-button type="text" size="mini" v-on:click="sortGovService(scope.$index)">
                                <i class="el-icon-arrow-down"></i>
                            </el-button>
                        </template>
                    </el-table-column>
                    <el-table-column label="服务名称" prop="title">
                    </el-table-column>
                    <el-table-column label="URL" prop="linkUrl">
                    </el-table-column>
                    <el-table-column label="最近修改时间">
                        <template scope="scope">
                            {{scope.row.updateTime | dateTimeFormat}}
                        </template>
                    </el-table-column>
                    <el-table-column label="创建人" prop="createUserName">
                    </el-table-column>
                    <el-table-column label="操作">
                        <template scope="scope">
                            <el-button type="text" size="mini" v-show="scope.row.status==0" v-on:click="turnonGovService(scope.row)" v-if="checkAuth(authKeyMap.updowngs)">上架
                            </el-button>
                            <el-button type="text" size="mini" v-show="scope.row.status==1" v-on:click="turnoffGovService(scope.row)" v-if="checkAuth(authKeyMap.updowngs)">下架
                            </el-button>
                            <el-button type="text" size="mini" v-on:click="modifyGovService(scope.row)"
                            v-if="checkAuth(authKeyMap.modifygs)">修改
                            </el-button>
                            <el-button type="text" size="mini" v-on:click="deleteGovService(scope.row)"
                            v-if="checkAuth(authKeyMap.modifygs)">删除
                            </el-button>
                        </template>
                    </el-table-column>
                </el-table>
            </el-col>
        </el-row>
        <el-col :span="24" class="u-padding-vertical-sm u-text-right">
            <el-pagination @size-change="handleSizeChange" @current-change="handlePageChange" :current-page="pageParams.currentpage" :page-sizes="[10, 20, 50, 100]" :page-size="pageParams.pagesize" layout="total, sizes, prev, pager, next, jumper" :total="pageParams.total">
            </el-pagination>
        </el-col>
        <!-- 政务公告弹窗BEGIN -->
        <el-dialog class="u-dialog" title="新建政务公告" :visible.sync="dialogVisible.announcement">
            <el-form :model="newgovnotice" :rules="ngnrules" ref="govnoticeForm">
                <el-form-item label="展示时间" :label-width="formLabelWidth" required>
                    <el-col :span="11">
                        <el-form-item prop="displayStartTime">
                            <el-date-picker type="date" placeholder="开始日期" v-model="newgovnotice.displayStartTime"></el-date-picker>
                        </el-form-item>
                    </el-col>
                    <el-col class="u-text-center" :span="2">-</el-col>
                    <el-col :span="11">
                        <el-form-item prop="displayEndTime">
                            <el-date-picker v-model="newgovnotice.displayEndTime" type="date" align="right" placeholder="结束日期">
                            </el-date-picker>
                        </el-form-item>
                    </el-col>
                </el-form-item>
                <el-form-item label="公告类型" prop="announcementName" :label-width="formLabelWidth">
                    <el-select v-model="newgovnotice.announcementName" placeholder="请选择公告类型">
                        <el-option label="政务公告" value="政务公告"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="内容" :label-width="formLabelWidth" prop="title">
                    <el-input type="textarea" :autosize="{ minRows: 8, maxRows: 10}" placeholder="请输入内容" v-model="newgovnotice.title">
                    </el-input>
                </el-form-item>
                <el-form-item label="URL" prop="linkUrl" :label-width="formLabelWidth">
                    <el-input placeholder="请输入链接地址" v-model="newgovnotice.linkUrl"></el-input>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="dialogVisible.announcement = false">取 消</el-button>
                <el-button type="primary" @click="saveGovNotice">确 定</el-button>
            </div>
        </el-dialog>
        <!-- 政务公告弹窗END -->
        <el-dialog title="新建地方服务" :visible.sync="dialogVisible.localservice" class="u-dialog u-dialog-sm">
            <el-form :model="newlocal" ref="localServiceForm" :rules="servicerules">
                <el-form-item label="服务名称" :label-width="formLabelWidth" prop="title">
                    <el-input placeholder="请输入服务名称" v-model="newlocal.title"></el-input>
                </el-form-item>
                <el-form-item label="上传图片" :label-width="formLabelWidth" required>
                    <el-form-item prop="iconSrc">
                        <el-input v-show="false" v-model="newlocal.iconSrc"></el-input>
                        <el-upload class="avatar-uploader" action="/api/web/xsb/image/upload" :show-file-list="false" :on-success="handleLocalImage" :before-upload="beforeImageUpload" :on-error="handleImageFailed">
                            <img v-if="imageUrl" :src="imageUrl" class="avatar">
                            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                        </el-upload>
                    </el-form-item>
                </el-form-item>
                <el-form-item label="URL" :label-width="formLabelWidth" prop="linkUrl">
                    <el-input placeholder="请输入链接地址" v-model="newlocal.linkUrl"></el-input>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="dialogVisible.localservice = false">取 消</el-button>
                <el-button type="primary" @click="saveLocalService">确 定</el-button>
            </div>
        </el-dialog>
        <el-dialog title="新建政务服务" :visible.sync="dialogVisible.orgservice" class="u-dialog u-dialog-sm">
            <el-form :model="newgovservice" ref="govServiceForm" :rules="servicerules">
                <el-form-item label="服务名称" :label-width="formLabelWidth" prop="title">
                    <el-input placeholder="请输入服务名称" v-model="newgovservice.title"></el-input>
                </el-form-item>
                <el-form-item label="上传图片" :label-width="formLabelWidth" required>
                    <el-form-item prop="iconSrc">
                        <el-input v-show="false" v-model="newgovservice.iconSrc"></el-input>
                        <el-upload class="avatar-uploader" action="/api/web/xsb/image/upload" :show-file-list="false" :on-success="handleGovServiceImage">
                            <img v-if="imageUrl" :src="imageUrl" class="avatar">
                            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                        </el-upload>
                    </el-form-item>
                </el-form-item>
                <el-form-item label="URL" :label-width="formLabelWidth" prop="linkUrl">
                    <el-input placeholder="请输入地址" v-model="newgovservice.linkUrl"></el-input>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="dialogVisible.orgservice = false">取 消</el-button>
                <el-button type="primary" @click="saveGovService">确 定</el-button>
            </div>
        </el-dialog>
    </el-row>
</template>
<script>
import vhttp from '@/vhttp';
import config from '@/config'
import dateUtil from 'element-ui/src/utils/date';
export default {
    name: 'UserList',
    data: function() {
        var minDate = (rule, value, callback) => {
            if (value.getTime() + 60 * 60 * 24 * 1000 < new Date().getTime()) {
                callback(new Error('起始日期不能早于今天'));
            } else {
                callback();
            }
        };
        var minEndDate = (rule, value, callback) => {
            this.$refs.govnoticeForm.validateField('displayStartTime');
            if (value.getTime() + 60 * 60 * 24 * 1000 < this.newgovnotice.displayStartTime.getTime()) {
                callback(new Error('结束日期不能早于起始日期'));
            } else {
                callback();
            }
        };
        return {
            authKeyMap: {
                addgn: 'apprunadmin.service.govnotice.add',
                modifygn: 'apprunadmin.service.govnotice.modify',
                deletegn: 'apprunadmin.service.govnotice.delete',
                sortgn: 'apprunadmin.service.govnotice.sort',
                addls: 'apprunadmin.service.localservice.add',
                modifyls: 'apprunadmin.service.localservice.modify',
                updownls: 'apprunadmin.service.localservice.upanddown',
                deletels: 'apprunadmin.service.localservice.delete',
                sortls: 'apprunadmin.service.localservice.sort',
                addgs: 'apprunadmin.service.govservice.add',
                modifygs: 'apprunadmin.service.govservice.modify',
                sortgs: 'apprunadmin.service.govservice.sort',
                updowngs: 'apprunadmin.service.govservice.upanddown',
                deletegs: 'apprunadmin.service.govservice.delete'
            },
            loading: false,
            activeName: 'announcement',
            pageParams: {
                currentpage: 1,
                pagesize: 10,
                total: 1
            },
            imageUrl: '',
            govnotice: [],
            localservice: [],
            govservice: [],
            dialogVisible: {
                announcement: false,
                localservice: false,
                orgservice: false
            },
            newgovnotice: {
                displayStartTime: '',
                displayEndTime: '',
                announcementName: '',
                title: '',
                linkUrl: ''
            },
            newlocal: {
                title: '',
                iconSrc: '',
                linkUrl: ''
            },
            newgovservice: {
                title: '',
                iconSrc: '',
                linkUrl: ''
            },
            formLabelWidth: '80px',
            //新建政务公告表单校验规则
            ngnrules: {
                announcementName: [{
                    required: true,
                    message: '请选择公告类型',
                    trigger: 'change'
                }],
                title: [{
                    required: true,
                    message: '内容不能为空',
                    trigger: 'blur'
                }, {
                    max: 200,
                    message: '不能超过200个字符',
                    trigger: 'blur,change'
                }],
                linkUrl: [{
                    type: 'url',
                    message: '请输入正确的链接地址',
                    trigger: 'blur,change'
                }],
                displayStartTime: [{
                    type: 'date',
                    required: true,
                    message: '请选择日期',
                    trigger: 'change'
                }, {
                    validator: minDate,
                    trigger: 'change'
                }],
                displayEndTime: [{
                    type: 'date',
                    required: true,
                    message: '请选择日期',
                    trigger: 'change'
                }, {
                    validator: minEndDate,
                    trigger: 'change'
                }]
            },
            servicerules: {
                iconSrc: [{
                    required: true,
                    message: '图片不能为空',
                    trigger: 'change'
                }],
                linkUrl: [{
                    required: true,
                    message: '请输入链接地址',
                    trigger: 'blur'
                }, {
                    type: 'url',
                    message: '请输入正确的链接地址',
                    trigger: 'blur,change'
                }],
                title: [{
                    required: true,
                    message: '服务名称不能为空',
                    trigger: 'blur'
                }]
            }
        }
    },
    created: function() {
        this.getgov()
    },
    methods: {
        checkAuth: function(authKey) {
            var auth = this.$root.myauth;
            var hasauth = false;
            auth.forEach(function(a) {
                if (a.indexOf(authKey) >= 0) {
                    hasauth = true;
                }
            })
            return hasauth;
        },
        dateFormat(row, column) {
            var strartTime = row.displayStartTime ? dateUtil.format(new Date(row.displayStartTime), 'yyyy-MM-dd') : '';
            var endTime = row.displayEndTime ? dateUtil.format(new Date(row.displayEndTime), 'yyyy-MM-dd') : ''
            return strartTime + '至' + endTime;
        },
        handleLocalImage(res, file) {
            this.newlocal.iconSrc = res.data;
            this.imageUrl = URL.createObjectURL(file.raw);
        },
        handleGovServiceImage(res, file) {
            this.newgovservice.iconSrc = res.data;
            this.imageUrl = URL.createObjectURL(file.raw);
        },
        beforeImageUpload(file) {
            const imgFormatList = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
            const imgFormat = imgFormatList.indexOf(file.type) >= 0;
            const isLt4M = file.size / 1024 / 1024 < 4;
            if (!imgFormat) {
                this.$message.error('上传图片只能是JPG、PNG、GIF格式!');
            }
            if (!isLt4M) {
                this.$message.error('上传图片大小不能超过 4MB!');
            }
            return imgFormat && isLt4M;
        },
        handleImageFailed: function(err) {
            this.$message.error('文件上传失败');
        },
        switchActivePanel: function(activeName) {
            var vm = this;
            if (activeName != vm.activeName) {
                vm.activeName = activeName;
                vm.pageParams = {
                    currentpage: 1,
                    pagesize: 10,
                    total: 1
                };
                vm.getActiveItem();
            }
        },
        showCreateDialog: function() {
            var vm = this;
            switch (vm.activeName) {
                case 'announcement':
                    vm.resetGovnotice();
                    vm.dialogVisible.announcement = true;
                    break;
                case 'localservice':
                    vm.resetLocalService();
                    vm.dialogVisible.localservice = true;
                    break;
                case 'orgservice':
                    vm.resetOrgService();
                    vm.dialogVisible.orgservice = true;
                    break;
            }
        },
        //the method to handle page
        handlePageChange: function(currentpage) {
            this.pageParams.currentpage = currentpage;
            this.getActiveItem();
        },
        handleSizeChange: function(pagesize) {
            this.pageParams.pagesize = pagesize;
            this.getActiveItem();
        },
        getActiveItem: function() {
            var vm = this;
            switch (vm.activeName) {
                case 'announcement':
                    vm.getgov()
                    break;
                case 'localservice':
                    vm.getLocalService()
                    break;
                case 'orgservice':
                    vm.getGovService();
                    break;
            }
        },
        //reset GovNotice LocalService
        resetGovnotice: function() {
            this.newgovnotice = {
                displayStartTime: '',
                displayEndTime: '',
                announcementName: '',
                title: '',
                linkUrl: ''
            };
            if (this.$refs.govnoticeForm) {
                this.$refs.govnoticeForm.resetFields()
            }
        },
        resetOrgService: function() {
            this.newgovservice = {
                title: '',
                iconSrc: '',
                linkUrl: ''
            };
            this.imageUrl = '';
            if (this.$refs.govServiceForm) {
                this.$refs.govServiceForm.resetFields()
            }
        },
        resetLocalService: function() {
            this.newlocal = {
                title: '',
                iconSrc: '',
                linkUrl: ''
            };
            this.imageUrl = '';
            if (this.$refs.localServiceForm) {
                this.$refs.localServiceForm.resetFields()
            }
        },
        getgov: function() {
            var vm = this;
            vhttp.get('/web/publicServices/announcementServices/query', {
                pageSize: vm.pageParams.pagesize,
                pageNo: vm.pageParams.currentpage
            }, function(res) {
                vm.govnotice = res.data.array;
                vm.pageParams = {
                    currentpage: res.data.pageNo,
                    pagesize: res.data.pageSize,
                    total: res.data.total
                }
            })
        },
        saveGovNotice: function() {
            var vm = this;
            this.$refs.govnoticeForm.validate((valid) => {
                if (valid) {
                    var newgovNotice = Object.assign({}, vm.newgovnotice, {
                        displayEndTime: vm.newgovnotice.displayEndTime.getTime(),
                        displayStartTime: vm.newgovnotice.displayStartTime.getTime()
                    });
                    /*请求路径： 有ID就update，没有id就insert  */
                    if (vm.newgovnotice.id) {
                        vhttp.post('/web/publicServices/announcementServices/update/' + vm.newgovnotice.id, newgovNotice, (res) => {
                            vm.getgov();
                            vm.dialogVisible.announcement = false;
                        })
                    } else {
                        vhttp.post('/web/publicServices/announcementServices/insert', newgovNotice, (res) => {
                            vm.getgov();
                            vm.dialogVisible.announcement = false;
                        })

                    }
                } else {
                    vm.$message.error('表单有误,请检查后重新提交');
                    return false;
                }
            });
        },
        modifyGovNotice: function(gn) {
            this.newgovnotice = Object.assign({}, gn, {
                displayStartTime: new Date(gn.displayStartTime),
                displayEndTime: new Date(gn.displayEndTime)
            });
            if (this.$refs.govnoticeForm) {
                this.$refs.govnoticeForm.resetFields()
            }
            this.dialogVisible.announcement = true;
        },
        deleteGovNotice: function(gn) {
            this.deleteService(gn, this.getgov)
        },
        sortGovNotice: function(idx) {
            var vm = this;
            if (idx < 0 || idx + 1 >= vm.govnotice.length) {
                vm.$message.warning('无法移动');
            } else {
                var upitem = this.govnotice[idx];
                var downitem = this.govnotice[idx + 1];
                vhttp.put('/web/publicServices/services/sort', {
                    ids: [upitem.id, downitem.id].join(';')
                }, (res) => {
                    vm.getgov();
                });
            }
        },
        getLocalService: function() {
            var vm = this;
            vhttp.get('/web/publicServices/customServices/query', {
                pageSize: vm.pageParams.pagesize,
                pageNo: vm.pageParams.currentpage
            }, function(res) {
                vm.localservice = res.data.array;
                vm.pageParams = {
                    currentpage: res.data.pageNo,
                    pagesize: res.data.pageSize,
                    total: res.data.total
                }

            })
        },
        saveLocalService: function() {
            var vm = this;
            this.$refs.localServiceForm.validate((valid) => {
                if (valid) {
                    var localservice = Object.assign({}, vm.newlocal);
                    /*请求路径： 有ID就update，没有id就insert  */
                    if (localservice.id) {
                        vhttp.post('/web/publicServices/customServices/update/' + localservice.id, localservice, (res) => {
                            vm.getLocalService();
                            vm.dialogVisible.localservice = false;
                        })
                    } else {
                        vhttp.post('/web/publicServices/customServices/insert', localservice, (res) => {
                            vm.getLocalService();
                            vm.dialogVisible.localservice = false;
                        })

                    }
                } else {
                    vm.$message.error('表单有误,请检查后重新提交');
                    return false;
                }
            });
        },
        modifyLocalService: function(ls) {
            this.newlocal = Object.assign({}, ls);
            this.imageUrl = config.imagePath + ls.iconSrc;
            if (this.$refs.localServiceForm) {
                this.$refs.localServiceForm.resetFields()
            }
            this.dialogVisible.localservice = true;
        },
        deleteLocalService: function(ls) {
            this.deleteService(ls, this.getLocalService)
        },
        turnonLocalService: function(ls) {
            this.turnonService(ls, function() {
                ls.status = 1
            })
        },
        turnoffLocalService: function(ls) {
            this.turnoffService(ls, function() {
                ls.status = 0
            })
        },
        sortLocalService: function(idx) {
            var vm = this;
            if (idx < 0 || idx + 1 >= vm.localservice.length) {
                vm.$message.warning('无法移动');
            } else {
                var upitem = this.localservice[idx];
                var downitem = this.localservice[idx + 1];
                vhttp.put('/web/publicServices/services/sort', {
                    ids: [upitem.id, downitem.id].join(';')
                }, (res) => {
                    vm.getgov();
                });
            }
        },
        getGovService: function() {
            var vm = this;
            vhttp.get('/web/publicServices/govServices/query', {
                pageSize: vm.pageParams.pagesize,
                pageNo: vm.pageParams.currentpage
            }, function(res) {
                vm.govservice = res.data.array;
                vm.pageParams = {
                    currentpage: res.data.pageNo,
                    pagesize: res.data.pageSize,
                    total: res.data.total
                }

            })
        },
        saveGovService: function() {
            var vm = this;
            this.$refs.govServiceForm.validate((valid) => {
                if (valid) {
                    var govservice = Object.assign({}, vm.newgovservice);
                    /*请求路径： 有ID就update，没有id就insert  */
                    if (govservice.id) {
                        vhttp.post('/web/publicServices/govServices/update/' + govservice.id, govservice, (res) => {
                            vm.getGovService();
                            vm.dialogVisible.orgservice = false;
                        })
                    } else {
                        vhttp.post('/web/publicServices/govServices/insert', govservice, (res) => {
                            vm.getGovService();
                            vm.dialogVisible.orgservice = false;
                        })

                    }

                } else {
                    vm.$message.error('表单有误,请检查后重新提交');
                    return false;
                }
            });
        },
        modifyGovService: function(gs) {
            this.newgovservice = Object.assign({}, gs);
            this.imageUrl = config.imagePath + gs.iconSrc;
            if (this.$refs.govServiceForm) {
                this.$refs.govServiceForm.resetFields()
            }
            this.dialogVisible.orgservice = true;
        },
        deleteGovService: function(gs) {
            this.deleteService(gs, this.getGovService)
        },
        sortGovService: function(idx) {
            var vm = this;
            if (idx < 0 || idx + 1 >= vm.govservice.length) {
                vm.$message.warning('无法移动');
            } else {
                var upitem = this.govservice[idx];
                var downitem = this.govservice[idx + 1];
                vhttp.put('/web/publicServices/services/sort', {
                    ids: [upitem.id, downitem.id].join(';')
                }, (res) => {
                    vm.getgov();
                });
            }
        },
        turnonGovService: function(gs) {
            this.turnonService(gs, function() {
                gs.status = 1
            })
        },
        turnoffGovService: function(gs) {
            this.turnoffService(gs, function() {
                gs.status = 0
            })
        },
        turnonService: function(service, callback) {
            var vm = this;
            vm.$confirm('确认上架该服务吗?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(function() {
                vhttp.put('/web/publicServices/services/show', {
                    id: service.id
                }, res => {
                    vm.$message({
                        type: 'success',
                        message: '上架成功!'
                    });
                    callback();
                })
            }, function() {
                vm.$message({
                    type: 'info',
                    message: '上架删除'
                });
            }).catch(function(err) {
                vm.$message({
                    type: 'info',
                    message: '上架失败'
                });
            });
        },
        turnoffService: function(service, callback) {
            var vm = this;
            vm.$confirm('确认下架该服务吗?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(function() {
                vhttp.put('/web/publicServices/services/hidden', {
                    id: service.id
                }, res => {
                    vm.$message({
                        type: 'success',
                        message: '下架成功!'
                    });
                    callback();
                })
            }, function() {
                vm.$message({
                    type: 'info',
                    message: '下架删除'
                });
            }).catch(function(err) {
                vm.$message({
                    type: 'info',
                    message: '下架失败'
                });
            });
        },
        deleteService: function(service, callback) {
            var vm = this;
            vm.$confirm('确认删除该记录吗?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(function() {
                vhttp.get('/web/publicServices/services/delete/' + service.id, {}, res => {
                    vm.$message({
                        type: 'success',
                        message: '删除成功!'
                    });
                    callback();
                })
            }, function() {
                vm.$message({
                    type: 'info',
                    message: '取消删除'
                });
            }).catch(function(err) {
                vm.$message({
                    type: 'info',
                    message: '删除失败'
                });
            });
        }

    }
}
</script>
<style scoped>
.m-tool-bar {
    height: 40px;
    line-height: 40px;
}

.startab {
    position: absolute;
    top: 34px;
    margin-left: 285px;
    z-index: 999;
    padding-top: 8px;
    padding-bottom: 8px;
}
</style>
