<template>
    <div>
        <el-row class="g-head" type="flex" justify="space-between" align="middle">
            <div class="u-logo"></div>
            <div class="u-areazone">
                <el-select v-model="countrycode" size="small" class="small-select" placeholder="请选择" v-on:change="switchCountry">
                    <el-option v-for="item in countryoptions" :key="item.value" :label="item.label" :value="item.value">
                    </el-option>
                </el-select>
            </div>
            <div class="u-text-right u-name-panel">
                <img src="http://www.ikea.com/cn/zh/images/products/si-da-qi-bei__0504538_PE633370_S4.JPG" alt="" class="u-circle-img">
                <strong>汤姆</strong>
                <span>欢迎你!</span>
            </div>
        </el-row>
        <el-row class="g-main">
            <el-col class="leftMenu">
                <lmenu :menu="menu"></lmenu>
            </el-col>
            <el-col class="content">
                <div  class="contentcontanier">
                    <el-row class="u-padding-round-sm">
                        <router-view></router-view>
                    </el-row>
                </div>
            </el-col>
        </el-row>
    </div>
</template>
<script>
import leftMenu from '@/components/LeftMenu'
import vhttp from '@/vhttp';
import config from '@/config';
import {
    Loading
} from 'element-ui';
export default {
    name: 'index',
    data: function() {
        return {
            city: '乐清',
            countrycode: vhttp.getCountryCode(),
            countryoptions: [{
                value: '1',
                label: '乐清'
            }, {
                value: '2',
                label: '海宁'
            }, {
                value: '3',
                label: '诸暨'
            }, {
                value: '4',
                label: '瑞安'
            }, {
                value: '5',
                label: '永康'
            }, {
                value: '6',
                label: '柯桥'
            }, {
                value: '7',
                label: '东阳'
            }, {
                value: '8',
                label: '温岭'
            }, {
                value: '9',
                label: '临海'
            }, {
                value: '10',
                label: '上虞'
            }],
            menu: config.menu
        }
    },
    created: function() {
        var vm = this;
        let loadingInstance = Loading.service({
            fullscreen: true,
            text: '正在请求权限',
            lock: true
        });
        vhttp.get('/web/autho/subject/perms', {}, function(res) {
            var county = vhttp.getCountryCode();
            var myauth = [];
            var hascountyAuth = false;
            if (res.data.isSystemRole) {
                myauth = config.Allperms;
                hascountyAuth = true;
            } else {
                res.data.authorizations.forEach(function(au) {
                    if (au.county == county) {
                        myauth = au.perms;
                        hascountyAuth = true;
                    }
                });
            }
            if (!hascountyAuth) {
                if (res.data.authorizations.length == 0) {
                    vm.$alert('当前用户没有任何县市权限,请联系管理员开放权限', '提示', {
                        confirmButtonText: '确定',
                        type: 'warning'
                    }).then(function() {

                    });
                } else {
                    loadingInstance.close();
                    vm.$alert('当前县市没有权限,将跳转到有权限的县市。', '提示', {
                        confirmButtonText: '确定',
                        type: 'warning'
                    }).then(function() {
                        vm.switchCountry(res.data.authorizations[0].county)
                    });
                }
            } else {
                vm.$root.myauth = myauth;
                vm.username = res.data.nickName;
                vm.menu = vm.packageMenu(vhttp.copy(config.menu), myauth);
                vm.$nextTick(function() {
                    loadingInstance.close();
                    if (myauth.length === 0) {
                        vm.$alert('当前用户在本县没有任何操作权限,请联系管理员开放权限', '提示', {
                            confirmButtonText: '确定',
                            type: 'warning'
                        }).then(function() {});
                    }
                })
            }
        }, function(err) {
            loadingInstance.close();
            vm.$message.error('请求权限失败请联系技术人员!');
        })
    },
    components: {
        lmenu: leftMenu
    },
    methods: {
        switchCountry: function(code) {
            vhttp.setCountryCode(code);
            this.$router.go(0);
        },
        packageMenu: function(menu, auth) {
            var result = menu.filter(function(m) {
                var mauth = m.authkey;
                var hasauth = false;
                auth.forEach(function(a) {
                    if (a.indexOf(mauth) >= 0) {
                        hasauth = true;
                    }
                })
                m.children = m.hasSubmenu ? m.children.filter(function(mc) {
                    var mcauth = mc.authkey;
                    var mchasauth = false;
                    auth.forEach(function(a) {
                        if (a.indexOf(mcauth) >= 0) {
                            mchasauth = true;
                        }
                    })
                    return mchasauth;
                }) : [];
                return hasauth;
            });
            return result
        }
    }
}
</script>
