<!-- 活动管理组件 -->
<template>
    <el-row>
        <h4 class="moduleTitle">活动管理</h4>
        <el-row class="m-tool-bar">
            <el-col :span="24">
                <el-button type="primary" class="u-margin-left-xs u-primary-btn" size="small" @click="createActivity" v-if="authList.indexOf('activity.create')>=0">新建活动</el-button>
            </el-col>
        </el-row>
        <el-col :span="24" class="u-margin-bottom-xs">
            <el-table class="m-table" style="width: 100%" :data="hotlist" v-loading.body="loading" stripe>
                <el-table-column label="序号">
                    <template scope="scope">
                        {{scope.$index | fixno(pageParams.currentpage,pageParams.pagesize)}}
                    </template>
                </el-table-column>
                <el-table-column label="排序" prop="defaultSortNum" v-if="authList.indexOf('activity.sort')>=0">
                    <template scope="scope">
                        <el-button type="text" size="mini">
                            <i class="el-icon-arrow-up" v-on:click="sortActivity(scope.$index-1)"></i>
                            <i class="el-icon-arrow-down" v-on:click="sortActivity(scope.$index)"></i>
                        </el-button>
                    </template>
                </el-table-column>
                <el-table-column label="活动名称" prop="activityName">
                </el-table-column>
                <el-table-column label="发布人" prop="createUser">
                </el-table-column>
                <el-table-column label="最近修改时间" width="140">
                    <template scope="scope">
                        {{scope.row.updateTime | dateTimeFormat}}
                    </template>
                </el-table-column>
                <el-table-column label="报名时间" width="120">
                    <template scope="scope">
                        <span>{{scope.row.signUpStartTime | dateTimeFormat}}</span>
                        <p class="normalLH">至</p>
                        <span>{{scope.row.signUpEndTime | dateTimeFormat}}</span>
                    </template>
                </el-table-column>
                <el-table-column label="活动时间" width="120">
                    <template scope="scope">
                        <span>{{scope.row.activityStartTime | dateTimeFormat}}</span>
                        <p class="normalLH">至</p>
                        <span>{{scope.row.activityEndTime | dateTimeFormat}}</span>
                    </template>
                </el-table-column>
                <el-table-column label="操作" width="180">
                    <template scope="scope">
                        <el-button type="text" size="mini" @click="Putaway(scope)" v-show="!scope.row.status" v-if="authList.indexOf('activity.upanddown')>=0">上架</el-button>
                        <el-button type="text" size="mini" @click="soldout(scope)" v-show="scope.row.status" v-if="authList.indexOf('activity.upanddown')>=0">下架</el-button>
                        <el-button type="text" size="mini" @click="modify(scope)" v-if="checkAuth(authKeyMap.edit)">编辑</el-button>
                        <el-button type="text" size="mini" v-show="!scope.row.status" @click="deletemsg(scope)" v-if="authList.indexOf('activity.delete')>=0">删除</el-button>
                    </template>
                </el-table-column>
                <el-table-column label="查看" prop="reason" width="120" v-if="authList.indexOf('activity.viewdetail')>=0">
                    <template scope="scope">
                        <el-button type="text" size="mini" @click="dialogtableApply(scope.row)">报名列表</el-button>
                    </template>
                </el-table-column>
            </el-table>
        </el-col>
        <el-col :span="24" class="u-padding-vertical-sm u-text-right">
            <el-pagination @size-change="handleSizeChange" @current-change="handlePageChange" :current-page="pageParams.currentpage" :page-sizes="[10, 20, 50, 100]" :page-size="pageParams.pagesize" layout="total, sizes, prev, pager, next, jumper" :total="pageParams.total">
            </el-pagination>
        </el-col>
        <!--start 弹出框 -->
        <el-dialog :title="titleName+'活动'" class="u-dialog" :visible.sync="dialogFormActivity" size="full">
            <el-form :model="activity" :rules="activityrules" ref="activityForm">
                <el-form-item label="活动名称" :label-width="formLabelWidth" prop="activityName">
                    <div class="middle_content">
                        <el-input v-model="activity.activityName" placeholder="请输入活动名称"></el-input>
                    </div>
                </el-form-item>
                <el-form-item label="报名时间" :label-width="formLabelWidth" required>
                    <div class="middle_content">
                        <el-col :span="11">
                            <el-form-item prop="signUpStartTime">
                                <el-date-picker type="date" placeholder="开始日期" v-model="activity.signUpStartTime" :disabled="activity.id?true:false"></el-date-picker>
                            </el-form-item>
                        </el-col>
                        <el-col class="u-text-center" :span="2">-</el-col>
                        <el-col :span="11">
                            <el-form-item prop="signUpEndTime">
                                <el-date-picker v-model="activity.signUpEndTime" type="date" align="right" placeholder="结束日期">
                                </el-date-picker>
                            </el-form-item>
                        </el-col>
                    </div>
                </el-form-item>
                <el-form-item label="活动时间" :label-width="formLabelWidth" required>
                    <div class="middle_content">
                        <el-col :span="11">
                            <el-form-item prop="activityStartTime">
                                <el-date-picker type="date" placeholder="开始日期" v-model="activity.activityStartTime" :disabled="activity.id?true:false"></el-date-picker>
                            </el-form-item>
                        </el-col>
                        <el-col class="u-text-center" :span="2">-</el-col>
                        <el-col :span="11">
                            <el-form-item prop="activityEndTime">
                                <el-date-picker v-model="activity.activityEndTime" type="date" align="right" placeholder="结束日期">
                                </el-date-picker>
                            </el-form-item>
                        </el-col>
                    </div>
                </el-form-item>
                <el-form-item label="活动地点" :label-width="formLabelWidth" prop="address">
                    <div class="middle_content">
                        <el-input placeholder="请输入活动地点" v-model="activity.address"></el-input>
                    </div>
                </el-form-item>
                <el-form-item label="图片上传" :label-width="formLabelWidth" prop="imageUrl">
                    <el-input v-show="false" v-model="activity.imageUrl"></el-input>
                    <el-upload class="avatar-uploader" action="/api/web/xsb/image/upload" :show-file-list="false" :on-success="handleImageUpload" :before-upload="beforeImageUpload" :on-error="handleImageFailed">
                        <img v-if="imageUrl" :src="imageUrl" class="avatar">
                        <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                    </el-upload>
                </el-form-item>
                <el-form-item label="活动详情" :label-width="formLabelWidth" prop="content">
                    <template>
                        <div>
                            <!-- <el-input v-show="false" v-model="activity.content"></el-input> -->
                            <vue-editor ueditorPath="../../static/" v-model="activity.content" @ready="editorReady" :ueditorConfig="editorOption"></vue-editor>
                        </div>
                    </template>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="dialogFormActivity = false">取 消</el-button>
                <el-button type="primary" @click="submitActivity">确 定</el-button>
            </div>
        </el-dialog>
        <el-dialog title="报名列表" :visible.sync="dialogTableActivity">
            <el-table :data="applyData" v-loading.body="applyListloading">
                <el-table-column label="报名日期">
                    <template scope="scope">
                        {{scope.row.signUpTime | dateTimeFormat}}
                    </template>
                </el-table-column>
                <el-table-column property="userName" label="姓名"></el-table-column>
                <el-table-column property="contactInfo" label="地址"></el-table-column>
            </el-table>
            <el-pagination @size-change="handleApplyListSizeChange" @current-change="handleApplyListPageChange" :current-page="pageParams4ApplyList.currentpage" :page-sizes="[10, 20, 50,100]" :page-size="pageParams4ApplyList.pagesize" layout="total, sizes, prev, pager, next, jumper" :total="pageParams4ApplyList.total">
            </el-pagination>
            <div slot="footer" class="dialog-footer">
                <el-button type="default" @click="dialogTableActivity= false ">关 闭</el-button>
                <el-button type="primary" @click="getdownload()">导 出</el-button>
            </div>
        </el-dialog>
        <!--end 弹出框 -->
    </el-row>
</template>
<script>
import config from '@/config.js';
import vhttp from '@/vhttp'
import dateUtil from 'element-ui/src/utils/date';
import VueEditor from 'vue-ueditor' //导入vue-ueditor 
export default {
    name: 'UserList',
    components: {
        VueEditor: VueEditor
    },
    data: function() {
        var minDate = (rule, value, callback) => {
            if (this.activity.id) {
                callback();
            } else if (value.getTime() + 60 * 60 * 24 * 1000 < new Date().getTime()) {
                callback(new Error('起始日期不能早于今天'));
            } else {
                callback();
            }
        };
        var minEndDate = (rule, value, callback) => {
            // this.$refs.activityForm.validateField('signUpStartTime');
            if (value.getTime() + 60 * 60 * 24 * 1000 < this.activity.signUpStartTime.getTime()) {
                callback(new Error('结束日期不能早于起始日期'));
            } else {
                callback();
            }
        };
        var activityMinEndDate = (rule, value, callback) => {
            //this.$refs.activityForm.validateField('activityStartTime');
            if (this.activity.id) {
                callback();
            } else if (value.getTime() + 60 * 60 * 24 * 1000 < this.activity.activityStartTime.getTime()) {
                callback(new Error('结束日期不能早于起始日期'));
            } else {
                callback();
            }
        };
        var editContent = (rule, value, callback) => {
            var editText = value.split('<p>')[1].split('</p>')[0];
            if (!editText) {
                callback(new Error('请输入活动详情'));
            } else {
                callback();
            }
        }
        return { 
            authKeyMap:{
                edit:'activity.edit',  
            },
            editorOption: {
                zIndex: 3000
            },
            activityId: 1,
            loading: false,
            applyListloading: false,
            pageParams: {
                currentpage: 1,
                pagesize: 10,
                total: 1
            },
            pageParams4ApplyList: {
                currentpage: 1,
                pagesize: 10,
                total: 1
            },
            imageUrl: '',
            editorInstance: '',
            hotlist: [],
            dialogTableActivity: false,
            dialogFormActivity: false,
            activity: {
                activityName: '',
                activityStartTime: '',
                activityEndTime: '',
                signUpStartTime: '',
                signUpEndTime: '',
                imageUrl: '',
                content: '',
                address: ''
            },
            activityrules: {
                activityName: [{
                    required: true,
                    message: '请输入活动名称',
                    trigger: 'blur'
                }, {
                    max: 40,
                    message: '活动名称不能超过40个字符',
                    trigger: 'blur,change'
                }],
                signUpStartTime: [{
                    type: 'date',
                    required: true,
                    message: '请选择日期',
                    trigger: 'change'
                }, {
                    validator: minDate,
                    trigger: 'change'
                }],
                signUpEndTime: [{
                    type: 'date',
                    required: true,
                    message: '请选择日期',
                    trigger: 'change'
                }, {
                    validator: minEndDate,
                    trigger: 'change'
                }],
                activityStartTime: [{
                    type: 'date',
                    required: true,
                    message: '请选择日期',
                    trigger: 'change'
                }, {
                    validator: minDate,
                    trigger: 'change'
                }],
                activityEndTime: [{
                    type: 'date',
                    required: true,
                    message: '请选择日期',
                    trigger: 'change'
                }, {
                    validator: activityMinEndDate,
                    trigger: 'change'
                }],
                address: [{
                    required: true,
                    message: '请输入活动地点',
                    trigger: 'blur'
                }, {
                    max: 40,
                    message: '活动地点不能超过40个字符',
                    trigger: 'blur,change'
                }],
                imageUrl: [{
                    required: true,
                    message: '请上传图片',
                    trigger: 'change'
                }],
                content: [{
                    required: true,
                    message: '请输入活动详情',
                    trigger: 'blur'
                }, {
                    validator: editContent,
                    trigger: 'blur'
                }]
            },
            applyData: [],
            formLabelWidth: '90px'
        }
    },
    created: function() {
        this.getactivity();
    },
    computed: {
        titleName: function() {
            return (this.activity.id ? '修改' : '新建');
        },
        authList: function() {
            return this.$root.myauth;
        }
    },
    methods: {
        checkAuth: function(authKey) {
            var auth = this.$root.myauth;
            var hasauth = false;
            auth.forEach(function(a) {
                if (a.indexOf(authKey) >= 0) {
                    hasauth = true;
                }
            })
            return hasauth;
        },
        activityTimeRange: function(row, column) {
            var strartTime = row.activityStartTime ? dateUtil.format(row.activityStartTime, 'yyyy-MM-dd HH:mm:ss') : '';
            var endTime = row.activityEndTime ? dateUtil.format(row.activityEndTime, 'yyyy-MM-dd HH:mm:ss') : ''
            return strartTime + '\n\r至\n\r' + endTime;
        },
        signUpTimeRange: function(row, column) {
            var strartTime = row.signUpStartTime ? dateUtil.format(row.signUpStartTime, 'yyyy-MM-dd HH:mm:ss') : '';
            var endTime = row.signUpEndTime ? dateUtil.format(row.signUpEndTime, 'yyyy-MM-dd HH:mm:ss') : ''
            return strartTime + '<br/>至<br/>' + endTime;
        },
        handlePageChange: function(currentpage) {
            this.pageParams.currentpage = currentpage;
            this.getactivity();
        },
        handleSizeChange: function(pagesize) {
            this.pageParams.pagesize = pagesize;
            this.getactivity();
        },
        handleApplyListPageChange: function(currentpage) {
            this.pageParams4ApplyList.currentpage = currentpage;
            this.getApplyList();
        },
        handleApplyListSizeChange: function(pagesize) {
            this.pageParams4ApplyList.pagesize = pagesize;
            this.getApplyList();
        },
        editorReady: function(editorInstance) {
            this.editorInstance = editorInstance;
            this.editorInstance.setContent(this.activity.content);
        },
        dialogtableApply: function(row) {
            this.dialogTableActivity = true;
            this.activityId = row.id;
            this.getApplyList()
        },
        getApplyList: function() {
            var vm = this;
            vhttp.get('/web/activity/signup/' + this.activityId, {
                pageSize: vm.pageParams4ApplyList.pagesize,
                pageNo: vm.pageParams4ApplyList.currentpage
            }, (res) => {
                vm.applyData = res.data.array;
                vm.pageParams4ApplyList = {
                    currentpage: res.data.pageNo > 0 ? res.data.pageNo : 1,
                    pagesize: res.data.pageSize,
                    total: res.data.total
                };
            })
        },
        createActivity: function() {
            this.resetActivity();
            if (this.editorInstance) {
                this.editorInstance.setContent(this.activity.content);
            }
            if (this.$refs.activityForm) {
                this.$refs.activityForm.resetFields();
            };
            this.dialogFormActivity = true;
        },
        resetActivity: function() {
            this.activity = {
                activityName: '',
                activityStartTime: '',
                activityEndTime: '',
                signUpStartTime: '',
                signUpEndTime: '',
                imageUrl: '',
                content: '',
                address: ''
            };
            this.imageUrl = '';
        },
        submitActivity: function() {
            var vm = this;
            vm.activity.content = vm.editorInstance.getContent();
            this.$refs.activityForm.validate((valid) => {
                if (valid) {
                    vm.activity.content = vm.editorInstance.getContent();
                    var activity = Object.assign({}, vm.activity, {
                        activityStartTime: vm.activity.activityStartTime.getTime(),
                        activityEndTime: vm.activity.activityEndTime.getTime(),
                        signUpStartTime: vm.activity.signUpStartTime.getTime(),
                        signUpEndTime: vm.activity.signUpEndTime.getTime()
                    });
                    /*请求路径： 有ID就update，没有id就insert  */
                    if (activity.id) {
                        vhttp.post('/web/activity/change', activity, (res) => {
                            vm.$message({
                                type: 'success',
                                message: '修改活动成功!'
                            });
                            vm.getactivity();
                            this.dialogFormActivity = false;
                        })
                    } else {
                        vhttp.post('/web/activity/add', activity, (res) => {
                            vm.$message({
                                type: 'success',
                                message: '新建活动成功!'
                            });
                            vm.getactivity();
                            this.dialogFormActivity = false;
                        })

                    }
                } else {
                    vm.$message.error('表单有误,请检查后重新提交');
                    return false;
                }
            });

        },
        handleImageUpload: function(res, file) {
            this.activity.imageUrl = res.data;
            this.imageUrl = URL.createObjectURL(file.raw);
        },
        beforeImageUpload(file) {
            const imgFormatList = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
            const imgFormat = imgFormatList.indexOf(file.type) >= 0;
            const isLt4M = file.size / 1024 / 1024 < 4;
            if (!imgFormat) {
                this.$message.error('上传图片只能是JPG、PNG、GIF格式!');
            }
            if (!isLt4M) {
                this.$message.error('上传图片大小不能超过 4MB!');
            }
            return imgFormat && isLt4M;
        },
        handleImageFailed: function(err) {
            this.$message.error('文件上传失败');
        },
        // 上架提示
        Putaway: function(scope) {
            var vm = this;
            vm.$confirm('是否确认上架?', '信息确认', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                vm.putupactivity(scope);
                vm.$message({
                    type: 'success',
                    message: '上架成功!'
                });
            })
        },
        // content=this.editorInstance.getContent()
        // 下架提示
        soldout: function(scope) {
            var vm = this;
            vm.$confirm('是否确认下架?', '信息确认', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                vm.putdownactivity(scope);
                vm.$message({
                    type: 'success',
                    message: '下架成功!'
                });
            })
        },
        deletemsg: function(scope) {
            var vm = this;
            vm.$confirm('是否确认删除?', '信息确认', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                vm.deleteactivity(scope, function() {
                    vm.$message({
                        type: 'success',
                        message: '删除成功!'
                    });
                });
            }, function() {
                vm.$message({
                    type: 'info',
                    message: '取消删除'
                });
            }).catch(function(err) {
                vm.$message({
                    type: 'info',
                    message: '删除失败'
                });
            });
        },
        getactivity: function() {
            var vm = this;
            vhttp.get('/web/activity/list', {
                pageSize: vm.pageParams.pagesize,
                pageNo: vm.pageParams.currentpage
            }, function(res) {
                vm.hotlist = res.data.array;
                vm.pageParams = {
                    currentpage: res.data.pageNo,
                    pagesize: res.data.pageSize,
                    total: res.data.total
                };
            })
        },
        // 导出报名列表
        getdownload: function() {
            var vm = this;
            var aLink = document.createElement('a');
            aLink.download = '用户报名列表.xls';
            aLink.href = config.api + '/web/activity/signup/export/';
            aLink.click()
        },
        // 上架请求
        putupactivity: function(scope) {
            var vm = this;
            vhttp.put('/web/activity/put/' + scope.row.id, {
                id: scope.row.id
            }, function(response) {
                vm.getactivity();
            })
        },
        // 下架请求
        putdownactivity: function(scope) {
            var vm = this;
            vhttp.put('/web/activity/down/' + scope.row.id, {
                id: scope.row.id
            }, function(response) {
                vm.getactivity();
            })
        },
        //删除请求
        deleteactivity: function(scope, callback) {
            var vm = this;
            vhttp.put('/web/activity/delete/' + scope.row.id, {
                id: scope.row.id
            }, (response) => {
                vm.getactivity();
                callback();
            })
        },
        modify: function(scope) {
            var activity = scope.row;
            this.imageUrl = config.imagePath + activity.imageUrl;
            this.activity = {
                id: activity.id,
                activityName: activity.activityName,
                activityStartTime: new Date(activity.activityStartTime),
                activityEndTime: new Date(activity.activityEndTime),
                signUpStartTime: new Date(activity.signUpStartTime),
                signUpEndTime: new Date(activity.signUpEndTime),
                imageUrl: activity.imageUrl,
                content: activity.content,
                address: activity.address
            };
            this.dialogFormActivity = true;

        },
        //上下交换位置
        sortActivity: function(idx) {
            var vm = this;
            var vm = this;
            if (idx < 0 || idx + 1 >= vm.hotlist.length) {
                vm.$message.warning('无法移动');
            } else {
                var upitem = vm.hotlist[idx];
                var downitem = vm.hotlist[idx + 1];
                vhttp.put('/web/activity/position/exchange', {
                    ids: [upitem.id, downitem.id].join(';')
                }, (res) => {
                    vm.getactivity();
                });
            }
        },
    }
}
</script>
<style scoped>
.u-primary-btn {
    width: 67px;
}
</style>
