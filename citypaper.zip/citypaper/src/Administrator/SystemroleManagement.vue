<!-- 系统角色管理组件 -->
<template>
    <el-row>
        <el-row>
            <el-col :span="24">
                <h2>系统角色管理</h2></el-col>
        </el-row>
        <el-col :span="4" class="area">
            <el-input v-model="search" placeholder="请输入角色名称"></el-input>
            <el-table :data="areaadmin">
                <el-table-column prop="menu" label="选择">
                </el-table-column>
            </el-table>
        </el-col>
        <el-col :span="20">
            <el-button type="primary" size="mini">添加用户</el-button>
            <el-table :data="adminname">
                <el-table-column prop="" label="选择">
                    <template scope="scope">
                      <el-checkbox v-model="tableData[scope.$index].checked"></el-checkbox>
                    </template>
                </el-table-column>
                <el-table-column prop="" label="序号">
                </el-table-column>
                <el-table-column prop="" label="用户名">
                </el-table-column>
                <el-table-column prop="" label="真实姓名">
                </el-table-column>
                <el-table-column prop="" label="操作">
                </el-table-column>
                <tr class="el-table__row" slot="append">
                    <td class="el-table_1_column_1">
                        <div class="cell">
                            <span class="Selectall">全选</span>
                            <el-checkbox  v-model="checkAll" @change="switchAllcheck"></el-checkbox>
                        </div>
                    </td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td class="el-table_1_column_1">
                    <div class="cell">
                        <el-button type="text" @click="" class="via">删除</el-button>
                    </div>
                </td>
                </tr>
            </el-table>
        </el-col>
        <el-col :span="24" class="u-padding-vertical-sm u-text-right">
            <el-pagination
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              :current-page="params.page"
              :page-sizes="[10, 20, 50, 100]"
              :page-size="params.rows"
              layout="total, sizes, prev, pager, next, jumper"
              :total="params.totalRows"
              :page-count="params.pageNum"
              >
            </el-pagination>
        </el-col>
    </el-row>
</template>
<script>
import vhttp from '@/vhttp'
import dateUtil from 'element-ui/src/utils/date';
export default {
    name: 'UserList',
    data() {

        return {
            search: '',
            areaadmin: [],
            adminname: [],
            checkAll:false,
            params: {
              expressCompany: '',
              phone: '',
              status: '',
              page: 1,
              rows:10
            }
        }
    },
    created() {
    },
    methods: {
        handleCurrentChange(currentPage){
          this.pageNum.pageNo=currentPage;//第几页     
          this.getcomments();
      },
      handleSizeChange(size){
          this.pageNum.pageSize=size;//每页几条
         this.getcomments();
      },
      switchAllcheck:function(){
        var vm=this; 
        vm.tableData =vm.tableData.map(function(item){
          item.checked=vm.checkAll;
          return item;
        }) 
      } 
    }
}
</script>
<style scoped>
.area {
  padding: 10px 20px 0 0;
}
.via {
  padding-right: 2.5%;
  font-size: 12px;
}
</style>
