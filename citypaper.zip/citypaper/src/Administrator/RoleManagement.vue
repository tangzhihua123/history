<!-- 角色组件 -->
<template>
  <el-row>
    <el-col :span="24">
      <h2>角色管理</h2>
    </el-col>
    <el-row :gutter="20">
      <el-col :span="5">
        <el-input v-model="search" placeholder="请输入角色名称"></el-input>
        <el-table :data="administrator">
          <el-table-column prop="menu" label="选择">
          </el-table-column>
        </el-table>
      </el-col>
      <el-col :span="19">
        <el-row>
          <el-button-group class="btn-group">
            <el-button type="default" :class="{ active: activeName=='roleeditor' }" size="small" @click="activeName='roleeditor'">角色编辑</el-button>
            <el-button type="default" :class="{ active: activeName=='accessconfiguration' }" size="small" @click="activeName = 'accessconfiguration'">权限分配</el-button>
            <el-button type="default" :class="{ active: activeName=='usermanagement' }" size="small" @click="activeName = 'usermanagement'">用户管理</el-button>
          </el-button-group>
        </el-row>
        <el-row v-show="activeName=='accessconfiguration'">
          <el-col :span="24" class="u-margin-bottom-xs">
            <el-col :span="24" class="u-margin-bottom-xs">
              <el-col :span="22">权限列表</el-col>
              <el-col :span="2">
                <el-button type="primary" size="mini">保存</el-button>
              </el-col>
            </el-col>
            <el-col :gutter="10" class="u-margin-bottom-xs">
              <el-row :span="12"></el-row>
              <el-row :span="12"></el-row>
            </el-col>
          </el-col>
        </el-row>
        <el-row v-show="activeName=='usermanagement'">
          <el-col :span="24" class="u-margin-bottom-xs">
            <el-table class="m-table" style="width: 100%" :data="govservice" v-loading.body="loading" stripe>
              <el-table-column label="显示顺序" prop="sortNum">
              </el-table-column>
              <el-table-column label="服务名称" prop="xxx">
              </el-table-column>
              <el-table-column label="URL" prop="linkUrl">
              </el-table-column>
              <el-table-column label="最近修改时间" prop="updateTime">
              </el-table-column>
              <el-table-column label="创建人" prop="createUserName">
              </el-table-column>
              <el-table-column label="操作">
              </el-table-column>
            </el-table>
          </el-col>
        </el-row>
      </el-col>
    </el-row>
  </el-row>
    <!-- 
        </el-col>
        
        <el-row v-show="activeName=='accessconfiguration'">
          <el-col :span="24" class="u-margin-bottom-xs">
            <el-col :span="24" class="u-margin-bottom-xs">
              <el-col :span="22">权限列表</el-col>
              <el-col :span="2">
                <el-button type="primary" size="mini">保存</el-button>
              </el-col>
            </el-col>
            <el-col :gutter="23" class="u-margin-bottom-xs">
              <el-row :span="12"></el-row>
              <el-row :span="12"></el-row>
            </el-col>
          </el-col>
        </el-row>
        <el-row v-show="activeName=='usermanagement'">
          <el-col :span="24" class="u-margin-bottom-xs">
            <el-table class="m-table" style="width: 100%" :data="govservice" v-loading.body="loading" stripe>
              <el-table-column label="显示顺序" prop="sortNum">
              </el-table-column>
              <el-table-column label="服务名称" prop="xxx">
              </el-table-column>
              <el-table-column label="URL" prop="linkUrl">
              </el-table-column>
              <el-table-column label="最近修改时间" prop="updateTime">
              </el-table-column>
              <el-table-column label="创建人" prop="createUserName">
              </el-table-column>
              <el-table-column label="操作">
              </el-table-column>
            </el-table>
          </el-col>
        </el-row>    
      </el-col>
        
        
    </el-row> -->
</template>
<script>
import vhttp from '@/vhttp'
import dateUtil from 'element-ui/src/utils/date';
export default {
    name: '',
    data() {
        return {
          search: '',
          administrator: [],
          activeName: 'roleeditor',
        }
    },
    created() {
    },
    methods: {
         
    }
}
</script>
<style scoped>

</style>
