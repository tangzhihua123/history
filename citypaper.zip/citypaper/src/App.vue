<template>
    <router-view class="appcontainer"></router-view>
</template>
<script>
export default {
    name: 'app'
}
</script>
