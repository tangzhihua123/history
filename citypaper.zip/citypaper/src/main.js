// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import ElementUI from 'element-ui'
import VueResource from 'vue-resource'
import dateUtil from 'element-ui/src/utils/date'
import config from './config';

import 'element-ui/lib/theme-default/index.css'
import './assets/css/global.css'
import './assets/css/MessageBox.css'

Vue.config.productionTip = false
Vue.use(ElementUI)
Vue.use(VueResource)


Vue.filter('dateTimeFormat', function (time, fmt) {
  return time ? dateUtil.format(time, fmt ? fmt : 'yyyy-MM-dd HH:mm:ss') : '/';
});

Vue.filter('fixno', function (index, pageno, pagesize) {
  return (pageno - 1) * pagesize + index + 1;
});
Vue.filter('imagepath', function (path) {
  return config.imagePath + path;
});

/* eslint-disable no-new */
new Vue({
  el: '#app',
  data: {
    myauth: []
  },
  router,
  template: '<App/>',
  components: { App }
})
