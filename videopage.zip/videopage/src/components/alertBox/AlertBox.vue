<template>
  <!--删除弹框-->
  <el-dialog :visible.sync="showDetelBox" class="ui-dialog-sm alert-box" :close-on-click-modal='false'>
    <el-form>
      <!-- <img src="../../assets/img/success.png"> -->
      <img :src="imgIcon">
      <div v-text="textInfo">确认删除?</div>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button class="btn-1" @click="cancelBox">取 消</el-button>
      <el-button class="btn-2" type="primary" @click="onOk">确 定</el-button>
    </div>
  </el-dialog>
</template>

<script>
  export default {
    name: 'hello',
    data () {
      return {
        showDetelBox: this.showalter
      }
    },
    props: {
      showalter: {
        type: Boolean,
        required:true
      },
      textInfo: {
        type: String,
        default:'确定删除?'
      },
      imgIcon:{
        type:String,
        default:'/static/assets/img/success.png'
      }
    },
    watch:{

      showalter:function(nv,ov){
        console.log(nv)
        this.showDetelBox=nv;
      }
    }
    ,

    methods:{
      onOk(){
        this.showDetelBox = false;
        this.$emit('event-ok');
      },
      cancelBox(){
        this.showDetelBox=false;
      }
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
