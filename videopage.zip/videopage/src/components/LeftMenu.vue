<template>
    <!-- <el-col :span="24">
        <el-menu default-active="1" class="m-menu" @open="handleOpen">
            <div class="home-btn">
                <img class="home-img" src="../assets/img/home_btn.png">
                <div class="home-text">首页</div>
            </div>
            <template v-for="(m,index) in menu">
                <el-submenu :index="''+index" v-if="m.hasSubmenu">
                    <template slot="title"><i class="u-menu-icon" :class="['u-menu-icon-'+(index+1)]"></i>{{m.title}}</template>
                    <el-menu-item class="item" :index="index+'-'+i" v-for="(n,i) in m.children" :key="i" v-on:click="handleOpen(n)"><i class="u-menu-icon" :class="['u-menu-icon-'+(index+1+'-'+i)]"></i>{{n.title}}</el-menu-item>
                </el-submenu>
                <el-menu-item class="subitem" :index="''+index" v-if="!m.hasSubmenu" v-on:click="handleOpen(m)"><i class="u-menu-icon" :class="['u-menu-icon-'+(index+1)]"></i>{{m.title}}</el-menu-item>
            </template>
        </el-menu>
    </el-col> -->
    <el-col :span="24">
        <el-menu default-active="1" class="m-menu" @open="handleOpen"><!--一级菜单-->
            <div class="home-btn">
                <img class="home-img" src="../assets/img/home_btn.png">
                <div class="home-text">首页</div>
            </div>
            <template v-for="(m,index) in menu">
                <el-submenu :index="''+index" v-if="m.hasSubmenu"><!--二级菜单-->
                   <!--  <template slot="title"><i class="u-menu-icon" :class="['u-menu-icon-'+(index+1)]"></i>{{m.title}}</template> -->
                   <template slot="title"><i class=" icon iconfont icon-rigint" :class="m.icon"></i>{{m.title}}</template>
                    <template v-for="(n,i) in m.children">
                        <el-submenu v-if="n.hasSubmenu" :index="index+'-'+i"><!--三级菜单-->
                            <template slot="title"><i class="icon iconfont icon-rigint" :class="n.icon"></i>{{n.title}}</template>
                            <el-menu-item class="item" :index="index+'-'+i+'-'+i" v-for="(t,i) in n.children" :key="i" v-on:click="handleOpen(t)"><i class="icon iconfont icon-rigint" :class="t.icon"></i>{{t.title}}</el-menu-item>
                        </el-submenu>
                        <el-menu-item v-if="!n.hasSubmenu" :index="index+'-'+i" v-on:click="handleOpen(n)">
                            <i class="icon iconfont icon-rigint" :class="n.icon"></i>{{n.title}}
                        </el-menu-item>
                    </template>
                </el-submenu>
                <el-menu-item class="subitem" :index="''+index" v-if="!m.hasSubmenu" v-on:click="handleOpen(m)"><i class="icon iconfont icon-rigint" :class="m.icon"></i>{{m.title}}</el-menu-item>
            </template>
        </el-menu>
    </el-col>
</template>
<script>
    export default {
        name: 'leftMenu',
        data: function() {
            return {
                curRouter: '',
                menuHeight: 300,
                curMenu: 'search'
            }
        },
        props: {
            menu: {
                type: Array,
                require:true,
                menuHeight:500
            },
        },
        updated: function() {
            this.calculateMenuHeight(); 
        },
        methods: {
            handleOpen:function(item) {
                this.$router.push({
                    name: item.goto
                });
            },
            calculateMenuHeight:function() {
                var window_ht = window.innerHeight || 600,
                body_ht = document.body.clientHeight || 600;
                this.menuHeight = Math.max(window_ht, body_ht) - 63;
            }
        }
    }
</script>
