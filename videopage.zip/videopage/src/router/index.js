import Vue from 'vue'
import Router from 'vue-router'
import Hello from '@/components/Hello'
import Index from '@/page/Index'
import TraditionalManagement from '@/page/video/TraditionalManagement'
import SaveReplay from '@/page/video/saveReplay'
import VideoPerson from '@/page/video/videoPerson'
import VideoList from '@/page/videoManagement/videoList'

Vue.use(Router)

export default new Router({
	routes: [
	{
		path: '/',
		redirect: '/index',
		name: 'Index'
	},
	{
		path: '/',
		name: 'Index',
		component: Index
	},{
		path: '/index',
		name: 'Index',
		component: Index,
		children: [{
			path: 'TraditionalManagement',
			name: 'TraditionalManagement',
			component: TraditionalManagement
		},{
			path: 'SaveReplay',
			name: 'SaveReplay',
			component: SaveReplay
		},{
			path: 'VideoPerson',
			name: 'VideoPerson',
			component: VideoPerson
		},{
			path: 'VideoList',
			name: 'VideoList',
			component: VideoList
		}]
	}
	]
})
