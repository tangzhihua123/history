<template>
<el-row>
  <div class="content-box u-padding-round-sm">
    <el-button class="w76" @click="dialogTableVisible = true">新建</el-button>
    <!-- <el-table class="m-table" style="width: 100%" :data="traditionalData" v-loading.body="loading"  @
    cell-mouse-enter="handleMouseEnter" stripe> -->
    <el-table class="m-table" style="width: 100%" :data="traditionalData" stripe>
     <el-table-column
        label="序号" width="47" prop="id">
      </el-table-column>
      <el-table-column
        label="流名称" prop="streamname">
      </el-table-column>
      <el-table-column width="100"
        label="用户名" prop="username">
      </el-table-column>
      <el-table-column
        label="推流地址" prop="publishurl">
      </el-table-column>
      <el-table-column
        label="播放地址" prop="liveurl" >
        <template scope="scope">
        <div @mouseenter="showBtn(scope)" @mouseleave="hidenBtn(scope)">
          <span class="copy-btn" :class="['copy-btn-'+(scope.$index)]" v-text="copyText" @click="goCopyText(scope)">复制链接</span>
          <span :class="['copy-content-'+(scope.$index)]" >{{scope.row.liveurl}}</span>
        </div>
        
        </template>
      </el-table-column>
      <el-table-column width="50"
        label="状态" prop="status">
        <template scope="scope">
          <span class="statring" v-if="scope.row.status == 1">启用</span>
          <span class="runding" v-if="scope.row.status == 0">禁用</span>
        </template>
      </el-table-column>
      <el-table-column width="100"
        label="操作" prop="keepNum">
         <template scope="scope">
            <!-- <el-button class="font-color" type="text" size="mini" @click="showDeleteBox = true" >启用</el-button>
            <el-button class="font-color" type="text" size="mini" v-on:click="saveReplayVisible = true">禁用</el-button> -->
            <div class="btn-start" v-if="scope.row.status == 0" @click="toStop(scope)">启用</div>
            <div class="btn-stop" v-if="scope.row.status == 1" @click="toStart(scope)">禁用</div>

          </template>
      </el-table-column>
    </el-table>
  </div>
  <el-col :span="24" class="u-padding-top-xs u-text-center">
     <el-pagination @size-change="handleSizeChange" @current-change="handlePageChange" :current-page="pageParams.currentpage" :page-sizes="[10, 20, 50, 100]" :page-size="pageParams.pagesize" layout="total, sizes, prev, pager, next, jumper" :total="pageParams.total">
     </el-pagination>
  </el-col>
<!--新建弹框-->
  <el-dialog title="新建直播员" :visible.sync="dialogTableVisible" class="ui-dialog-sm" :close-on-click-modal='false'>
  <el-form :model="newVideo">
    <el-form-item label="直播员" :label-width="formLabelWidth">
      <!-- <el-input v-model="newVideo.videoUser" auto-complete="off"></el-input> -->
      <el-select v-model="newVideo.videoUser" filterable placeholder="请选择">
          
          <el-option v-for="item in liveUser" :key="item.value" :label="item.truename" :value="item.id">
          </el-option>
      </el-select>
    </el-form-item>
    </el-form>
  <div slot="footer" class="dialog-footer">
    <el-button class="btn-1" @click="dialogTableVisible = false">取 消</el-button>
    <el-button class="btn-2" type="primary" @click="creatVideo">确 定</el-button>
  </div>
</el-dialog>

<!--删除弹框-->
 <!-- <el-dialog :visible.sync="showDetelBox" class="ui-dialog-sm alert-box" :close-on-click-modal='false'>
  <el-form :model="newVideo">
    <img src="../../assets/img/success.png">
    <div>确认删除?</div>
    </el-form>
  <div slot="footer" class="dialog-footer">
    <el-button class="btn-1" @click="showDetelBox = false">取 消</el-button>
    <el-button class="btn-2" type="primary" @click="creatVideo">确 定</el-button>
  </div>
</el-dialog> -->

</el-row>
</template>
<script>
    import vhttp from '@/vhttp'
    import dateUtil from 'element-ui/src/utils/date';
    import allData from '@/data.js'
    import alertBox from '@/components/alertBox/AlertBox'
    export default {
        name: 'TraditionalManagement',
        data: function() {
            return {
                traditionalData: [],
                pageParams: {
                  currentpage: 1,
                  pagesize: 10,
                  total: 1
                },
                liveUser:[],
                copyText:'复制地址',
                showCopy:false,
                dialogTableVisible:false,
                saveReplayVisible:false,
                formLabelWidth: '80px',
                newVideo:{
                  videoUser:'',
                  videoName:''
                },
                saveReplay:{
                  date:'2017-07-09',
                  startTime:'',
                  endTime:''
                },
                showText:'确定锁定？',
                imgSrc:'/static/assets/img/success.png',
                showDeleteBox:false,
                videoUserList:[{name:'小王',id:'1'},{name:'小李',id:'2'},{name:'小唐',id:'3'},{name:'小张',id:'4'},{name:'小雪',id:'5'},{name:'小二',id:'6'},{name:'小三',id:'7'}]
            }
        },
        props: {
            menu: {
                type: Array,
                require:true
            },
        },
        created:function(){
            this.getPersonData();
        },
        methods: {
          // loading: function(){
          //   return false;
          // },
            getPersonData: function(){
                vhttp.post('/traditional/user', {pageNo:1,pagesize:10}, res => {
                  this.traditionalData = res.data.traditionalUserList;
                  this.liveUser = res.data.liveUser;
                })
                
                //this.traditionalData = [];
            },
            handlePageChange: function(currentpage) {
                this.pageParams.currentpage = currentpage;
                this.getPersonData();
              },
              handleSizeChange: function(pagesize) {
                this.pageParams.pagesize = pagesize;
                this.getPersonData();
              },
            getText(scope){
              console.log(scope);
            },
            showBtn(scope){
              // this.showCopy = true;
              this.copyText = "复制地址";
              window.document.querySelector('.copy-btn-'+scope.$index).style.visibility = 'visible';
            },
            hidenBtn(scope){
                this.copyText = "复制地址";
                window.document.querySelector('.copy-btn-'+scope.$index).style.visibility = 'hidden';
            },
            goCopyText(scope){
              /* 创建range对象   */
              const range = document.createRange();
              range.selectNode(document.querySelector('.copy-content-'+scope.$index));    // 设定range包含的节点对象 

              /* 窗口的selection对象，表示用户选择的文本 */
              const selection = window.getSelection();
              if(selection.rangeCount > 0) selection.removeAllRanges(); // 将已经包含的已选择的对象清除掉
              selection.addRange(range);                                // 将要复制的区域的range对象添加到selection对象中

              document.execCommand('Copy'); // 执行copy命令，copy用户选择的文本
              this.copyText = "复制成功";
              window.document.querySelector('.copy-btn-'+scope.$index).style.backgroundColor = '#d2d6dc'
            },
            creatVideo(){
              this.dialogTableVisible = false;
              var vm = this;
              vhttp.post('/traditional/user/new', {userId:vm.newVideo.videoUser}, res => {
                console.log(res);
                vm.$message({
                  type: 'success',
                  message: '新建成功!'
                });
                vm.getPersonData();
              })
            },
            toStart(scope){
              var vm = this;
              vhttp.post('/traditional/stream/disable', {streamId:scope.row.id, streamKey:scope.row.streamkey}, res => {
                console.log(res);
                vm.$message({
                  type: 'success',
                  message: '启用成功!'
                });
                vm.getPersonData();
              })
            },
            toStop(scope){
              var vm = this;
              vhttp.post('/traditional/stream/enable', {streamId:scope.row.id, streamKey:scope.row.streamkey}, res => {
                console.log(res);
                vm.$message({
                  type: 'success',
                  message: '禁用成功!'
                });
                vm.getPersonData();
              })
            }
        },
        components: {
        }
    }
</script>
