<template>
  <el-row>
    <div class="content-box u-padding-round-sm">
      <el-button class="w76" @click="showCreateTable">新建</el-button>
    <!-- <el-table class="m-table" style="width: 100%" :data="traditionalData" v-loading.body="loading"  @
    cell-mouse-enter="handleMouseEnter" stripe> -->
    <el-table class="m-table" style="width: 100%" :data="traditionalData" stripe>
     <el-table-column
     label="ID" width="47" prop="id">
   </el-table-column>
   <el-table-column 
   label="稿件标题" prop="title">
 </el-table-column>
 <el-table-column width="60"
 label="创建人" prop="createby">
</el-table-column>
<el-table-column 
label="创建时间" prop="createat">
<template scope="scope">{{scope.row.createat | dateTimeFormat}}</template>
</el-table-column>
<el-table-column width="150"
label="流地址" prop="publishurl" >
<template scope="scope">
  <div @mouseenter="showBtn(scope)" @mouseleave="hidenBtn(scope)">
    <span class="copy-btn" :class="['copy-btn-'+(scope.$index)]" v-text="copyText" @click="goCopyText(scope)">复制链接</span>
    <span :class="['copy-content-'+(scope.$index)]" >{{scope.row.publishurl}}</span>
  </div>

</template>
</el-table-column>
<el-table-column width="150"
label="播放地址" prop="liveurl">
</el-table-column>
<el-table-column width="50"
label="状态" prop="streamstatus">
<template scope="scope">
  <span class="statring" v-if="scope.row.streamstatus == 0">待开始</span>
  <span class="runding" v-if="scope.row.streamstatus == 1">进行中</span>
  <span class="ending" v-if="scope.row.streamstatus == 2">结束</span>
</template>
</el-table-column>
<el-table-column width="250"
label="操作" prop="keepNum">
<template scope="scope">
  <i class="detel-icon"></i>
  <el-button class="font-color" type="text" size="mini" @click="goDelete(scope)" >删除</el-button>
  <i class="save-icon"></i>
  <el-button class="font-color" type="text" size="mini" v-on:click="alertSaveReplay(scope)">保存回放</el-button>
  <i class="save-icon"></i>
  <el-button class="font-color" type="text" size="mini" v-on:click="saveReplayVisible = true">查看回放</el-button>
</template>
</el-table-column>
</el-table>
</div>
<el-col :span="24" class="u-padding-top-xs u-text-center">
 <el-pagination @size-change="handleSizeChange" @current-change="handlePageChange" :current-page="pageParams.currentpage" :page-sizes="[10, 20, 50, 100]" :page-size="pageParams.pagesize" layout="total, sizes, prev, pager, next, jumper" :total="pageParams.total">
 </el-pagination>
</el-col>
<!--新建弹框-->
<el-dialog title="新建直播" :visible.sync="dialogTableVisible" class="ui-dialog-sm" :close-on-click-modal='false'>
  <el-form :model="newVideo">
    <el-form-item label="直播员" :label-width="formLabelWidth">
      <!-- <el-input v-model="newVideo.videoUser" auto-complete="off"></el-input> -->
      <el-select v-model="newVideo.videoUser" filterable placeholder="请选择">

        <el-option v-for="item in liveUser" :key="item.id" :label="item.username" :value="item.id">
        </el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="直播名称" :label-width="formLabelWidth">
      <el-input v-model="newVideo.videoName" auto-complete="off" placeholder="请输入直播名称"></el-input>
    </el-form-item>
  </el-form>
  <div slot="footer" class="dialog-footer">
    <el-button class="btn-1" @click="dialogTableVisible = false">取 消</el-button>
    <el-button class="btn-2" type="primary" @click="creatVideo">确 定</el-button>
  </div>
</el-dialog>
<!--保存回放-->
<el-dialog title="保存回放" :visible.sync="saveReplayVisible" class="ui-dialog-sm" :close-on-click-modal='false'>
  <el-form :model="saveReplay">
    <el-form-item label="日期" :label-width="formLabelWidth" >
      <!-- <el-input v-model="saveReplay.date" auto-complete="off" :disabled="true"></el-input> -->
      <el-date-picker
      v-model="saveReplay.date"
      type="date"
      placeholder="选择日期"
      :default-value="replayDate"
      :picker-options="pickerOptions0">
    </el-date-picker>
  </el-form-item>
  <el-form-item label="开始时间" :label-width="formLabelWidth">
    <el-time-picker v-model="saveReplay.startTime"
    :picker-options="{
    selectableRange: '00:00:00 - 23:59:59'
  }"
  placeholder="请选择开始时间">
</el-time-picker>
</el-form-item>
<el-form-item label="结束时间" :label-width="formLabelWidth">
  <!-- <el-input v-model="saveReplay.endTime" auto-complete="off" placeholder="请选择结束时间"></el-input> -->
  <el-time-picker v-model="saveReplay.endTime"
  :picker-options="{
  selectableRange: '00:00:00 - 23:59:59'
}"
placeholder="请选择结束时间">
</el-time-picker>
</el-form-item>
</el-form>
<div slot="footer" class="dialog-footer">
  <el-button class="btn-1" @click="saveReplayVisible = false">取 消</el-button>
  <el-button class="btn-2" type="primary" @click="toSaveReplay">确 定</el-button>
</div>
</el-dialog>
<!--删除弹框-->
 <!-- <el-dialog :visible.sync="showDetelBox" class="ui-dialog-sm alert-box" :close-on-click-modal='false'>
  <el-form :model="newVideo">
    <img src="../../assets/img/success.png">
    <div>确认删除?</div>
    </el-form>
  <div slot="footer" class="dialog-footer">
    <el-button class="btn-1" @click="showDetelBox = false">取 消</el-button>
    <el-button class="btn-2" type="primary" @click="creatVideo">确 定</el-button>
  </div>
</el-dialog> -->
<alert-delete :showalter="showDeleteBox" @event-ok="goDelete"></alert-delete>
</el-row>
</template>
<script>
  import vhttp from '@/vhttp'
  import dateUtil from 'element-ui/src/utils/date';
  import util from '@/Util'
  import allData from '@/data.js'
  import alertDelete from '@/components/alertBox/AlertBox'
  export default {
    name: 'TraditionalManagement',
    data: function() {
      return {
        traditionalData: [],
        pageParams: {
          currentpage: 1,
          pagesize: 10,
          total: 1
        },
        liveUser:[],
        replayDate:'',
        copyText:'复制地址',
        showCopy:false,
        dialogTableVisible:false,
        saveReplayVisible:false,
        formLabelWidth: '80px',
        newVideo:{
          videoUser:'',
          videoName:''
        },
        saveReplay:{
          date:'2017-07-09',
          startTime:'',
          endTime:''
        },
        showDeleteBox:false,
        videoUserList:[{name:'小王',id:'1'},{name:'小李',id:'2'},{name:'小唐',id:'3'},{name:'小张',id:'4'},{name:'小雪',id:'5'},{name:'小二',id:'6'},{name:'小三',id:'7'}]
      }
    },
    props: {
      menu: {
        type: Array,
        require:true
      },
    },
    created:function(){
      this.getTraditionalData();
    },
    methods: {
          // loading: function(){
          //   return false;
          // },
          showCreateTable:function(){
            this.dialogTableVisible = true;
            this.newVideo = {
              videoUser:'',
              videoName:''
            }
          },
          getTraditionalData: function(){
            var vm = this;
            vhttp.post('/traditional/stream', {page:vm.pageParams.currentpage, pageSize :vm.pageParams.pagesize}, res => {
              console.log(res);
              this.traditionalData = res.data.traditionalStreamList;
              vm.pageParams.total = res.total;
              vm.liveUser = res.data.liveUser;
            })
                //this.traditionalData = [];
              },
              handlePageChange: function(currentpage) {
                this.pageParams.currentpage = currentpage;
                this.getTraditionalData();
              },
              handleSizeChange: function(pagesize) {
                alert(pagesize);
                this.pageParams.pagesize = pagesize;
                this.getTraditionalData();
              },
              getText(scope){
                console.log(scope);
              },
              showBtn(scope){
              // this.showCopy = true;
              this.copyText = "复制地址";
              window.document.querySelector('.copy-btn-'+scope.$index).style.visibility = 'visible';
            },
            hidenBtn(scope){
              this.copyText = "复制地址";
              window.document.querySelector('.copy-btn-'+scope.$index).style.visibility = 'hidden';
            },
            goCopyText(scope){
              /* 创建range对象   */
              const range = document.createRange();
              range.selectNode(document.querySelector('.copy-content-'+scope.$index));    // 设定range包含的节点对象 

              /* 窗口的selection对象，表示用户选择的文本 */
              const selection = window.getSelection();
              if(selection.rangeCount > 0) selection.removeAllRanges(); // 将已经包含的已选择的对象清除掉
              selection.addRange(range);                                // 将要复制的区域的range对象添加到selection对象中

              document.execCommand('Copy'); // 执行copy命令，copy用户选择的文本
              this.copyText = "复制成功";
              window.document.querySelector('.copy-btn-'+scope.$index).style.backgroundColor = '#d2d6dc'
            },
            creatVideo(){
              this.dialogTableVisible = false;
              var vm = this;
              vhttp.post('/traditional/stream/new', {user:vm.newVideo.videoUser,title:vm.newVideo.videoName}, res => {
                console.log(res);
                vm.$message({
                  type: 'success',
                  message: '新建成功!'
                });
                vm.getTraditionalData();
              })
            },
            goDelete(scope){
              var vm = this;
              vm.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
              }).then(() => {
                vm.goDeleteTradition(scope);
                vm.$message({
                  type: 'success',
                  message: '删除成功!'
                });
              })
            },
            goDeleteTradition(scope){
              debugger;
              var vm = this;
              // vhttp.pust('/traditional/stream/delete', {
              //   id: scope.row.id
              // }, function(response) {
              //   vm.getTraditionalData();
              // })
              vhttp.post('/traditional/stream/delete', {id: scope.row.id}, res => {
                console.log(res);
                vm.getTraditionalData();
              })
            },
            alertSaveReplay(scope){
             this.saveReplay = {
              date:'',
              startTime:'',
              endTime:''
            };
            this.replayDate = scope.row.createat;
            this.saveReplayVisible = true;
          },
          toSaveReplay(){
            console.log(this.saveReplay);
            var date = util.dateFormat(this.saveReplay.date,'yy-mm-dd');
            var startTime = util.dateFormat(this.saveReplay.startTime,'h:m:s');
            var endTime = util.dateFormat(this.saveReplay.endTime,'h:m:s');
            //var postStartTime = date+' '+startTime;
            //alert(postStartTime);
            var postStartTime = new Date(date+' '+startTime).getTime();
            alert(postStartTime);
            this.$router.push({name:'SaveReplay'});
          }
        },
        components: {
          alertDelete: alertDelete
        }
      }
    </script>
