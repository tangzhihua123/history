<template>
  <el-row>
    <div class="content-box u-padding-round-sm">
      <el-breadcrumb separator=">">
        <el-breadcrumb-item :to="{ name: 'TraditionalManagement' }"><i class="u-menu-icon-1-0 u-menu-icon"></i>传统直播管理</el-breadcrumb-item>
        <el-breadcrumb-item>回放</el-breadcrumb-item>
      </el-breadcrumb>
      <el-button class="w76 float-right ui-back-btn" @click="goBack">返回</el-button>
      <video class="video-size" src="http://www.zhangxinxu.com/study/media/cat.mp4" controls autobuffer></video>

    </div>
    <div class="replay-box">
      <div class="replay-text">
        <span class="text-title">转码状态</span>
        <span class="text-content">转码中</span>
        <div class="progress-div"><el-progress :percentage="70"></el-progress></div>
        <div class="progress-success">转码成功</div>
      </div>
      <div class="replay-text">
        <span class="text-title">ID</span>
        <span class="text-content">1212121</span>
      </div>
      <div class="replay-text">
        <span class="text-title">标题</span>
        <span class="text-content">新信息新</span>
      </div>
      <div class="replay-text">
        <span class="text-title">创建人</span>
        <span class="text-content">新信息新</span>
      </div>
      <div class="replay-text">
        <span class="text-title">创建时间</span>
        <span class="text-content">新信息新</span>
      </div>
      <div class="replay-text" @mouseenter="showCopyBtn = true" @mouseleave="showCopyBtn= false">
        <span class="text-title">视频地址</span>
        <span class="text-content">新信息新</span>
        <div class="copy-btn-show" v-if="showCopyBtn" @click="goCopyText(scope)">复制链接</div>
      </div>
    </div>
    
  </el-row>
</template>

<script>
  import vhttp from '@/vhttp';
  import config from '@/config';
  export default {
    data () {
      return {
        showCopyBtn:false
      }
    },
    created:function(){
    },
    methods:{
      goCopyText(){},
      goBack(){
        this.$router.go(-1);
      }

    },
    components: {
    }
  }
</script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
