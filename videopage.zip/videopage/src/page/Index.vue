<template>
  <div class="">
    <el-row class="g-head" type="flex" justify="space-between" align="middle">
      <div class="u-logo">
        <div class="title">媒资系统</div>
        <div class="e-title">MediaResourceSystem</div>
      </div>
      <div class="u-text-right u-name-panel">
        <img src="http://www.ikea.com/cn/zh/images/products/si-da-qi-bei__0504538_PE633370_S4.JPG" alt="" class="u-circle-img">
        <span class="user-name">汤姆</span>
        <span class="line">1</span>
        <span class="u-exit-btn"></span>
      </div>
    </el-row>
    <el-row class="g-main">
      <div class="leftMenu" :style="{ 'min-height': menuHeight + 'px' }">
      <!-- <div class="leftMenu"> -->
        <lmenu :menu="menu"></lmenu>
      </div>
      <div class="content">
        <div  class="contentcontanier" :style="{ 'width': contentWidth + 'px' }"> 
          <router-view></router-view> 
        </div>
      </div>
    </el-row>
  </div>
</template>

<script>
  import leftMenu from '@/components/LeftMenu';
  import vhttp from '@/vhttp';
  import config from '@/config';
  export default {
    data () {
      return {
        menu: config.menu,
        menuHeight:0,
        contentWidth:1129
      }
    },
    created:function(){
      this.getMenuHeight();
      this.getContentWidth();
    },
    methods:{
      getMenuHeight: function(){
        this.menuHeight = window.innerHeight-72;
      },
      getContentWidth: function(){
        // alert(window.innerWidth);
        this.contentWidth = window.innerWidth-220-17;
      }
    },
    components: {
      lmenu: leftMenu
    }
  }
</script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
