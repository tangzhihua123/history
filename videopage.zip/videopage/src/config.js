export default {
  api: '/app_dev.php/api',
  imagePath: '/api/images',
  menu: [{
    title: '直播管理',
    authkey: 'sysmenu',
    icon:'icon-vedio',
    hasSubmenu: true,
    children: [{
      title: '传统直播管理',
      // goto: 'TraditionalManagement',
      authkey: 'sysmenu.sysrole',
      icon:'icon-tvshow',
      hasSubmenu: true,
      children: [{
        title: '直播列表',
        icon:'icon-livelist',
        goto: 'TraditionalManagement',
        authkey: 'sysmenu.sysrole.add'
      }, {
        title: '直播员',
        icon:'icon-liveplayer',
        goto: 'VideoPerson',
        authkey: 'sysmenu.sysrole.delete'
      }]
    }]
  }, {
    title: '视频管理',
    authkey: 'useradmin',
    icon:'icon-vedioplay',
    hasSubmenu: true,
    children: [{
      title: '视频列表',
      goto: 'VideoList',
      authkey: 'useradmin.userlist',
      icon:'icon-livelist',
      hasSubmenu: false
    }, {
      title: '视频分类',
      goto: 'Feedback',
      icon:'icon-vediotype',
      authkey: 'useradmin.feedback',
      hasSubmenu: false
    }, {
      title: '媒体来源',
      icon:'icon-media',
      goto: 'Feedback',
      authkey: 'useradmin.feedback',
      hasSubmenu: false
    }]
  }, {
    title: '数据中心',
    authkey: 'contentadmin',
    icon:'icon-datachart',
    hasSubmenu: true,
    children: [{
      title: '播放统计',
      icon:'icon-datastat',
      goto: 'ProgramManagement',
      authkey: 'contentadmin.program',
      hasSubmenu: false,
    }, {
      title: '用户统计',
      icon:'icon-userplayer',
      goto: 'CommentsManagement',
      authkey: 'contentadmin.comment',
      hasSubmenu: false
    }]
  }, {
    title: '系统管理',
    authkey: 'apprunadmin',
    icon:'icon-system',
    hasSubmenu: true,
    children: [{
      title: '账户管理',
      icon:'icon-userplayer',
      goto: 'ServiceManagement',
      authkey: 'apprunadmin.service',
      hasSubmenu: false
    }, {
      title: '角色管理',
      icon:'icon-key',
      goto: 'BannerManagement',
      authkey: 'apprunadmin.banner',
      hasSubmenu: false
    }, {
      title: '修改密码',
      icon:'icon-lock',
      goto: 'StartManagement',
      authkey: 'apprunadmin.start',
      hasSubmenu: false
    }]
  }],
  Allperms: ["sysmenu", "sysmenu.sysrole", "sysmenu.sysrole.add", "sysmenu.sysrole.delete", "sysmenu.commonrole", "sysmenu.commonrole.add", "sysmenu.commonrole.delete", "sysmenu.commonrole.edit", "sysmenu.commonrole.user", "sysmenu.commonrole.user.add", "sysmenu.commonrole.user.delete", "contentadmin", "contentadmin.program", "contentadmin.program.edit", "contentadmin.program.updown", "contentadmin.program.sort", "contentadmin.comment", "contentadmin.comment.pass", "contentadmin.comment.delete", "contentadmin.article", "contentadmin.article.push", "contentadmin.article.reback", "contentadmin.article.sort", "useradmin", "useradmin.userlist", "useradmin.feedback", "contentadmin.article.hideandshow", "contentadmin.topnews", "contentadmin.topnews.reback", "contentadmin.topnews.sort", "contentadmin.topnews.hideandshow", "sysmenu.commonrole.authedit", "useradmin.userlist.forbidcomment", "useradmin.userlist.forbidlogin", "useradmin.feedback.export", "apprunadmin", "apprunadmin.service", "apprunadmin.service.govnotice", "apprunadmin.service.govnotice.add", "apprunadmin.service.govnotice.modify", "apprunadmin.service.govnotice.delete", "apprunadmin.service.localservice", "apprunadmin.service.localservice.add", "apprunadmin.service.localservice.modify", "apprunadmin.service.localservice.delete", "apprunadmin.service.govservice", "apprunadmin.service.govservice.add", "apprunadmin.service.govservice.modify", "apprunadmin.service.govservice.delete", "apprunadmin.banner", "apprunadmin.banner.add", "apprunadmin.banner.modify", "apprunadmin.banner.upanddown", "apprunadmin.banner.sort", "apprunadmin.banner.delete", "apprunadmin.start", "apprunadmin.start.add", "apprunadmin.start.modify", "apprunadmin.start.upanddown", "apprunadmin.start.delete", "apprunadmin.msg", "apprunadmin.msg.addinner", "apprunadmin.msg.addpush", "apprunadmin.msg.addmsg", "apppromotion", "apppromotion.stat", "apppromotion.stat.export", "apppromotion.set", "apppromotion.set.create", "apppromotion.set.edit", "apppromotion.detail", "apppromotion.detail.export", "activity", "activity.create", "activity.edit", "activity.delete", "activity.sort", "activity.upanddown", "activity.viewdetail", "datastat", "datastat.article", "datastat.program", "version", "version.create", "version.edit", "useradmin.userlist.export", "apprunadmin.service.govnotice.sort", "apprunadmin.service.localservice.sort", "apprunadmin.service.localservice.upanddown", "apprunadmin.service.govservice.sort", "apprunadmin.service.govservice.upanddown", "apprunadmin.msg.reback"]
}
