// 工具类
export default {
    // 时间补0  lkdfjgldkjglksd lfdjgldksfg 
    timeAddZero (time) {
        return time < 10 ? `0${time}` : `${time}`;
    },

    dateFormat (date, fmt) {
        if (date && fmt) {
            const year = date.getFullYear(),
                month = date.getMonth() < 9 ? `0${parseInt(date.getMonth() + 1)}` : date.getMonth() + 1,
                day = date.getDate() < 10 ? `0${date.getDate()}` : date.getDate(),
                hour = date.getHours() < 10 ? `0${date.getHours()}` : date.getHours(),
                minute = date.getMinutes() < 10 ? `0${date.getMinutes()}` : date.getMinutes(),
                second = date.getSeconds() < 10 ? `0${date.getSeconds()}` : date.getSeconds(),
                dayArr = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'];

            switch (fmt) {
                case 'yy-mm-dd h:m:s':
                    return `${year}-${month}-${day} ${hour}:${minute}:${second}`;

                case 'yy-mm-dd h:m':
                    return `${year}-${month}-${day} ${hour}:${minute}`;

                case 'yy-mm-dd':
                    return `${year}-${month}-${day}`;

                case 'mm-dd h:m':
                    return `${month}-${day} ${hour}:${minute}`;

                case 'mm-dd':
                    return `${month}-${day}`;

                case 'h:m':
                    return `${hour}:${minute}`;
                case 'h:m:s':
                return `${hour}:${minute}:${second}`;

                case 'HH:mm MM/dd/yyyy':
                    return `${hour}:${minute} ${month}/${day}/${year}`;

                case 'mm-dd d':
                    return `${month}月${day} ${dayArr[date.getDay()]}`;
            }
        }
    },

    // 换行替换
    interceptContent (content) {
        return !content ? '' : content.replace(/\n|\r/g, '<br>').replace(/\s/g, '&nbsp;');
    }


};

